/* ===== BEGIN native invoice forms module ===== */
/* Native invoice forms (seller / buyer). Generated from the former embedded pages by tools/build_native.py.
   The form logic is unchanged; it now runs inside the app page, scoped to one host element. */
(function(){
var NF=window.NativeForms={};var DEFS={};
DEFS["seller"]={css:".nf-host *{box-sizing:border-box;margin:0;padding:0}.nf-host{\n  \n  --accent:#B71C3D;--bg-soft:#F5F0F1;\n  --text-secondary:#7B6B6B;--text-muted:#9E8E8E;\n  --border:#E8D8DD;--border-light:#F5EBEE;\n  --green:#43A047;--green-dark:#2E7D32;--red:#E53935;--red-dark:#C62828;\n  --blue:#1E88E5;--blue-dark:#1565C0;--orange:#FB8C00;--orange-dark:#F57C00;\n  --shadow:0 4px 20px rgba(107,26,47,0.10);\n  --radius-sm:10px;--radius:16px;\n}.nf-host{font-family:'Tajawal','Segoe UI',sans-serif;background:#2D2D2D;color:var(--text);direction:rtl;font-weight:500;line-height:1.6}.nf-host .nf-app{max-width:720px;margin:0 auto;min-height:100%;padding-bottom:80px;background:var(--bg);box-shadow:var(--shadow)}.nf-host .nf-topbar{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:linear-gradient(135deg,var(--primary-dark) 0%,var(--primary) 100%);border-radius:0 0 22px 22px;box-shadow:0 4px 20px rgba(0,0,0,.15);position:sticky;top:0;z-index:30;gap:8px}.nf-host .nf-topbar .title{font-size:20px;font-weight:900;color:#fff;text-shadow:0 2px 4px rgba(0,0,0,.25);flex:1;text-align:center}.nf-host .top-icon{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;font-size:16px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);color:#fff;cursor:pointer;transition:.2s}.nf-host .top-icon:hover{background:rgba(255,255,255,.25)}.nf-host .nf-screen{display:none;padding:14px 16px;animation:nfs-fadeIn .3s ease}.nf-host .nf-screen.active{display:block}@keyframes nfs-fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}.nf-host .nf-btn{padding:11px 18px;border-radius:var(--radius-sm);border:none;font-size:14px;cursor:pointer;font-weight:800;font-family:'Tajawal',sans-serif;display:inline-flex;align-items:center;justify-content:center;gap:6px;transition:.2s}.nf-host .nf-btn:active{transform:scale(.97)}.nf-host .nf-btn-primary{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;box-shadow:0 4px 16px rgba(107,26,47,.3)}.nf-host .btn-secondary{background:#fff;color:var(--primary);border:2px solid var(--primary)}.nf-host .btn-danger{background:linear-gradient(135deg,var(--red),var(--red-dark));color:#fff}.nf-host .btn-save{background:linear-gradient(135deg,var(--green),var(--green-dark));color:#fff;border:2px solid var(--green-dark)}.nf-host .btn-cancel{background:#fff;color:var(--primary);border:2px solid var(--primary)}.nf-host .add-btn{border:1.5px solid var(--primary);background:#fff;color:var(--primary);padding:5px 12px;border-radius:9px;font-family:inherit;font-size:12px;font-weight:800;cursor:pointer;transition:.15s}.nf-host .add-btn:hover{background:var(--primary);color:#fff}.nf-host .form-group{margin-bottom:16px}.nf-host .form-group label{display:block;font-size:13px;margin-bottom:7px;color:var(--text-secondary);font-weight:700}.nf-host .form-group input,.nf-host .form-group select,.nf-host .form-group textarea{width:100%;padding:13px 15px;border:2px solid var(--border);border-radius:var(--radius-sm);font-size:15px;background:#fff;font-weight:600;color:var(--text);transition:.2s;font-family:'Tajawal',sans-serif}.nf-host .form-group input:focus,.nf-host .form-group select:focus,.nf-host .form-group textarea:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 4px rgba(107,26,47,.08)}.nf-host .seller-row{display:flex;gap:8px;align-items:center;width:100%}.nf-host .seller-row input{flex:1;min-width:0}.nf-host .thumb-btn{width:48px;height:48px;border-radius:12px;border:2px dashed var(--border);background:var(--bg-soft);display:inline-flex;align-items:center;justify-content:center;overflow:hidden;padding:0;flex:0 0 auto;cursor:pointer;transition:.15s}.nf-host .thumb-btn:hover{border-color:var(--primary);background:var(--primary-light)}.nf-host .thumb-btn img{width:100%;height:100%;object-fit:cover;display:none}.nf-host .thumb-btn.has-photo{border-style:solid;border-color:var(--primary)}.nf-host .thumb-btn.has-photo img{display:block}.nf-host .thumb-btn .thumb-empty{font-size:20px;color:var(--text-muted)}.nf-host .thumb-btn.has-photo .thumb-empty{display:none}.nf-host .photo-quick{display:inline-flex;gap:5px;flex:0 0 auto}.nf-host .photo-quick button{width:42px;height:42px;border-radius:10px;border:1.5px solid var(--border);background:#fff;cursor:pointer;font-size:17px;display:grid;place-items:center;transition:.15s}.nf-host .photo-quick button:hover{background:var(--primary-light);border-color:var(--primary)}.nf-host .sales-page{width:100%}.nf-host .sales-page .sec{background:#fff;border:2px solid var(--border);border-radius:var(--radius);margin-bottom:12px;overflow:hidden}.nf-host .sales-page .sec-title{background:linear-gradient(180deg,var(--primary),var(--primary-dark));color:#fff;padding:10px 14px;font-weight:900;font-size:14px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap}.nf-host .sales-page .sec-title .nf-actions{display:flex;gap:6px;flex-wrap:wrap}.nf-host .sales-page .meta{display:grid;grid-template-columns:1fr 1fr;gap:0;border-bottom:1px solid var(--border)}.nf-host .sales-page .meta label{padding:9px 10px;border-left:1px solid var(--border);border-bottom:1px solid var(--border);display:flex;flex-direction:column;gap:5px;font-weight:700;font-size:12px;color:var(--text-secondary);min-width:0}.nf-host .sales-page .meta label:nth-child(2n){border-left:0}.nf-host .sales-page .meta label:nth-last-child(-n+2){border-bottom:0}.nf-host .sales-page .meta input{border:1px solid var(--border);border-radius:8px;padding:8px;background:#fff;width:100%;min-width:0;font:inherit;text-align:center;font-weight:700;color:var(--text)}.nf-host .sales-page .meta input[type=date]{direction:ltr;min-height:40px;cursor:pointer;-webkit-appearance:auto;appearance:auto}.nf-host .table-date-text{display:block;min-height:16px;font-size:11px;line-height:1.35;text-align:center;color:var(--primary);font-weight:800}.nf-host .sales-page .tw{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;padding:8px;scrollbar-width:thin}.nf-host .sales-page table.nf-g{width:100%;border-collapse:collapse;background:#fff;table-layout:auto}.nf-host .sales-page table.nf-g th,.nf-host .sales-page table.nf-g td{border:1px solid var(--border);padding:6px 4px;text-align:center;font-size:12px;font-weight:700;word-wrap:break-word;vertical-align:middle}.nf-host .sales-page table.nf-g th{background:linear-gradient(180deg,var(--primary),var(--primary-dark));color:#fff;font-weight:800}.nf-host .sales-page table.nf-g input{width:100%;min-width:0;border:0;background:transparent;text-align:center;padding:5px 2px;font:inherit;color:inherit;outline:none;font-weight:700;direction:ltr;box-sizing:border-box;font-variant-numeric:tabular-nums}.nf-host .sales-page table.nf-g input:focus{background:#FFFBE0;border-radius:4px}.nf-host .sales-page table.nf-g th .col-del-btn{background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:6px;width:24px;height:24px;padding:0;font-size:12px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:.15s;line-height:1}.nf-host .sales-page table.nf-g th .col-del-btn:hover{background:var(--red);border-color:var(--red);transform:scale(1.1)}.nf-host .sales-page .total-row{background:linear-gradient(180deg,#FEF3F6,#F5E1E7)!important;border-top:2px solid var(--primary)!important}.nf-host .sales-page .total-row td{background:transparent!important;font-weight:900!important;color:var(--primary-dark)!important;padding:8px 4px!important}.nf-host .sales-page .total-row .total-num{display:inline-block;min-width:38px;padding:2px 8px;background:#fff;border-radius:6px;border:1.5px solid var(--primary);color:var(--primary-dark);font-weight:900;font-size:12px;direction:ltr;font-variant-numeric:tabular-nums}.nf-host .sales-page .total-row .total-pair{display:flex;align-items:center;justify-content:center;gap:4px;flex-wrap:wrap}.nf-host .sales-page .total-row .total-lbl{font-size:10px;color:var(--text-secondary);font-weight:800}.nf-host .sales-page .row-del{width:30px;padding:0}.nf-host .sales-page .row-del button{border:0;background:transparent;color:#b00;cursor:pointer;width:100%;padding:6px 0;font-size:14px}.nf-host .sales-page .row-del button:hover{background:#ffd0d0}.nf-host .sales-page .mini3{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:10px}.nf-host .sales-page .mini3 .nf-panel{border:1px solid var(--border);border-radius:10px;overflow:hidden;background:#fff}.nf-host .sales-page .mini3 .nf-panel h4{margin:0;padding:8px 10px;background:var(--bg-soft);border-bottom:1px solid var(--border);font-size:12px;font-weight:900;display:flex;justify-content:space-between;align-items:center;color:var(--primary-dark)}.nf-host .sales-page .mini3 table{width:100%;border-collapse:collapse}.nf-host .sales-page .mini3 td,.nf-host .sales-page .mini3 th{border:1px solid var(--border);padding:5px;font-size:12px;text-align:center;background:#fff}.nf-host .sales-page .mini3 th{background:var(--bg-soft);font-weight:800}.nf-host .sales-page .mini3 input{width:100%;border:0;background:transparent;text-align:center;font:inherit;padding:4px;outline:none;font-weight:700;font-variant-numeric:tabular-nums}.nf-host .sales-page .mini3 input:focus{background:#FFFBE0;border-radius:4px}.nf-host .sales-page .sum2{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:10px}.nf-host .sales-page .sum2 .card-box{border:2px solid var(--border);border-radius:10px;overflow:hidden;background:#fff}.nf-host .sales-page .sum2 .card-box h4{margin:0;padding:8px 10px;background:var(--bg-soft);border-bottom:1px solid var(--border);font-size:13px;font-weight:900;color:var(--primary-dark)}.nf-host .sales-page .sum2 .card-box table{width:100%;border-collapse:collapse}.nf-host .sales-page .sum2 .card-box td,.nf-host .sales-page .sum2 .card-box th{border:1px solid var(--border);padding:7px;font-size:13px}.nf-host .sales-page .sum2 .card-box th{background:var(--bg-soft);text-align:right;font-weight:800;width:55%}.nf-host .sales-page .sum2 .card-box td{text-align:center;font-weight:900}.nf-host .sales-page .sum2 .card-box td .val{display:inline-block;min-width:40px;font-variant-numeric:tabular-nums}.nf-host .sales-page .cur{padding:10px}.nf-host .sales-page .cur table{width:100%;border-collapse:collapse;background:#fff}.nf-host .sales-page .cur th,.nf-host .sales-page .cur td{border:1px solid var(--border);padding:6px;text-align:center;font-size:12px;font-weight:700}.nf-host .sales-page .cur th{background:linear-gradient(180deg,var(--primary),var(--primary-dark));color:#fff;font-weight:900}.nf-host .sales-page .cur input{width:100%;border:0;background:transparent;text-align:center;font:inherit;padding:5px;outline:none;font-weight:700;font-variant-numeric:tabular-nums}.nf-host .sales-page .cur input:focus{background:#FFFBE0;border-radius:4px}.nf-host .sales-page .note-box{width:100%;min-height:70px;border:1px solid var(--border);border-radius:8px;padding:9px;font-family:inherit;font-size:13px;background:#fff;resize:vertical;text-align:right;outline:none;font-weight:600;color:var(--text)}.nf-host .sales-page .note-box:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(107,26,47,.08)}.nf-host .footer-bar{display:flex;gap:10px;justify-content:center;margin-top:16px;padding:14px;background:#fff;border:2px solid var(--border);border-radius:12px;flex-wrap:wrap}.nf-host .footer-bar .nf-btn{min-width:130px;font-size:15px;padding:12px 20px}.nf-host .saved-badge{display:inline-block;background:var(--green);color:#fff;font-size:12px;padding:4px 12px;border-radius:12px;opacity:0;transition:.3s;align-self:center;font-weight:800}.nf-host .saved-badge.show{opacity:1}.nf-host .notify-overlay{position:fixed;inset:0;background:rgba(45,45,45,.6);backdrop-filter:blur(4px);display:none;align-items:center;justify-content:center;padding:16px;z-index:9999}.nf-host .notify-overlay.show{display:flex;animation:nfs-nfade .2s ease}@keyframes nfs-nfade{from{opacity:0}to{opacity:1}}.nf-host .notify-box{background:#fff;border-radius:24px;width:90%;max-width:420px;padding:26px 22px 20px;text-align:center;box-shadow:0 8px 32px rgba(107,26,47,.25);position:relative;animation:nfs-npin .3s cubic-bezier(.34,1.56,.64,1)}@keyframes nfs-npin{from{opacity:0;transform:scale(.9) translateY(20px)}to{opacity:1;transform:scale(1) translateY(0)}}.nf-host .notify-box::before{content:'';position:absolute;top:0;right:0;left:0;height:5px;background:linear-gradient(90deg,var(--primary),var(--accent),var(--primary))}.nf-host .notify-icon{font-size:56px;line-height:1;margin:6px 0 14px;display:inline-block}.nf-host .notify-title{font-size:19px;font-weight:900;color:var(--primary);margin:0 0 10px}.nf-host .notify-msg{font-size:14px;color:var(--text-secondary);line-height:1.75;margin:0 0 22px;white-space:pre-wrap;font-weight:600}.nf-host .notify-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}.nf-host .notify-actions.single{grid-template-columns:1fr}.nf-host .notify-btn{padding:13px 16px;border-radius:12px;border:none;font-family:'Tajawal',sans-serif;font-size:15px;font-weight:800;cursor:pointer;transition:.2s}.nf-host .notify-btn-cancel{background:#fff;color:var(--primary);border:2px solid var(--primary)}.nf-host .notify-btn-confirm{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff}.nf-host .notify-btn-danger{background:linear-gradient(135deg,var(--red),var(--red-dark));color:#fff}.nf-host .app-toast{position:fixed;top:80px;left:50%;transform:translateX(-50%) translateY(-30px);padding:11px 20px;border-radius:14px;color:#fff;font-family:'Tajawal',sans-serif;font-size:13px;font-weight:800;z-index:10000;opacity:0;pointer-events:none;transition:.3s cubic-bezier(.34,1.56,.64,1);max-width:90vw;text-align:center;box-shadow:0 6px 20px rgba(107,26,47,.25);display:flex;align-items:center;gap:8px}.nf-host .app-toast.show{opacity:1;transform:translateX(-50%) translateY(0)}.nf-host .app-toast.success{background:linear-gradient(135deg,var(--green),var(--green-dark))}.nf-host .app-toast.error{background:linear-gradient(135deg,var(--red),var(--red-dark))}.nf-host .app-toast.warning{background:linear-gradient(135deg,var(--orange),var(--orange-dark))}.nf-host .app-toast.info{background:linear-gradient(135deg,var(--blue),var(--blue-dark))}.nf-host .app-toast.default{background:linear-gradient(135deg,var(--primary),var(--primary-dark))}@media(max-width:600px){.nf-host .sales-page .mini3{grid-template-columns:1fr;gap:8px;padding:8px}.nf-host .sales-page .sum2{grid-template-columns:1fr;gap:8px;padding:8px}.nf-host .sales-page .meta{grid-template-columns:1fr}.nf-host .sales-page .meta label{border-left:0;border-bottom:1px solid var(--border)}.nf-host .sales-page .meta label:last-child{border-bottom:0}.nf-host .nf-topbar .title{font-size:17px}}@media print{.nf-host.print-a3 @page{ size: A3 portrait; }.nf-host.print-gray,.nf-host.print-gray *{ -webkit-print-color-adjust: economy !important; print-color-adjust: economy !important; }.nf-host.print-gray .invoice-view,.nf-host.print-gray .inv-table th{ filter: grayscale(1) !important; }.nf-host.print-bw,.nf-host.print-bw *{ color:#000 !important; background:#fff !important; border-color:#000 !important; box-shadow:none !important; text-shadow:none !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }.nf-host.print-bw .inv-table th{ background:#fff !important; color:#000 !important; }.nf-host.print-color .inv-table th{ background:var(--print-accent, var(--primary-dark)) !important; color:#fff !important; }}.nf-host .sale-summary-table{width:100%;border-collapse:collapse}.nf-host .sale-summary-table th,.nf-host .sale-summary-table td{padding:7px 8px;border-bottom:1px solid var(--border,#e8d8dd);font-size:13px}.nf-host .sale-summary-table th{text-align:right}.nf-host .sale-summary-table td{text-align:center;font-weight:900}.nf-host .sale-summary-table .subtotal-row th,.nf-host .sale-summary-table .subtotal-row td{background:#eef6ff;color:#164e86;font-weight:900}.nf-host .sale-summary-table .final-total-row th,.nf-host .sale-summary-table .final-total-row td{background:#fff3cd;color:#4a3510;font-weight:900;border-top:2px solid #d9a441}.nf-host .sales-page .sec-title{font-size:13px;font-weight:900}.nf-host .sales-page .meta{grid-template-columns:repeat(4,minmax(0,1fr))}.nf-host .sales-page .tw{overflow-x:auto}.nf-host .sales-page table{min-width:0}.nf-host .sales-page #salesTable{min-width:620px}.nf-host .sales-page .mini3{grid-template-columns:repeat(3,minmax(0,1fr))}.nf-host .sales-page .footer-bar{position:sticky;bottom:0;z-index:20}@media(max-width:700px){.nf-host .sales-page .meta{grid-template-columns:repeat(2,minmax(0,1fr))}.nf-host .sales-page .mini3{grid-template-columns:1fr}.nf-host .sales-page .sum2{grid-template-columns:1fr}}.nf-host .sales-page .sum2 .card-box table,.nf-host .sales-page .sum2 .card-box table.sale-summary-table{min-width:0!important;width:100%!important;table-layout:fixed}.nf-host .sales-page .sum2 .card-box th{width:58%!important}.nf-host .sales-page .sum2 .card-box td{width:42%!important;overflow:hidden}.nf-host .sales-page .sum2 .card-box td .val{min-width:0;display:inline-block;direction:ltr;font-weight:900}.nf-host .sales-page .cur table{min-width:0!important}.nf-host .sales-page .mini3{min-width:0;grid-template-columns:repeat(3,minmax(0,1fr))}.nf-host .sales-page .mini3 .nf-panel{min-width:0;overflow:hidden}.nf-host .sales-page .mini3 .nf-panel table,.nf-host .sales-page .sec > .tw table:not(#salesTable){width:100%!important;min-width:0!important;max-width:100%!important;table-layout:fixed!important;border-collapse:collapse}.nf-host .sales-page .mini3 .nf-panel th:first-child,.nf-host .sales-page .mini3 .nf-panel td:first-child{width:43%}.nf-host .sales-page .mini3 .nf-panel th:nth-child(2),.nf-host .sales-page .mini3 .nf-panel td:nth-child(2){width:42%}.nf-host .sales-page .mini3 .nf-panel th:last-child,.nf-host .sales-page .mini3 .nf-panel td:last-child{width:15%}.nf-host .sales-page .mini3 .nf-panel td input,.nf-host .sales-page .sec > .tw td input{display:block;width:100%!important;min-width:0!important;max-width:100%!important;box-sizing:border-box!important;padding-left:2px!important;padding-right:2px!important;font-size:12px!important}.nf-host .sales-page .mini3 .nf-panel td,.nf-host .sales-page .mini3 .nf-panel th{padding:5px 2px!important;overflow:hidden}.nf-host .sales-page .sec > .tw table:not(#salesTable) th:first-child,.nf-host .sales-page .sec > .tw table:not(#salesTable) td:first-child{width:43%}.nf-host .sales-page .sec > .tw table:not(#salesTable) th:nth-child(2),.nf-host .sales-page .sec > .tw table:not(#salesTable) td:nth-child(2){width:42%}.nf-host .sales-page .sec > .tw table:not(#salesTable) th:last-child,.nf-host .sales-page .sec > .tw table:not(#salesTable) td:last-child{width:15%}@media(max-width:700px){.nf-host .sales-page .mini3{grid-template-columns:minmax(0,1fr)!important}.nf-host .sales-page .mini3 .nf-panel{width:100%;min-width:0}}.nf-host.nf-native{--accent:var(--primary);--accent-light:var(--primary-light);--blue:var(--primary);--blue-dark:var(--primary-dark);--bg-soft:var(--bg2,var(--bg));--bg-card:var(--bg);--text-secondary:var(--text2,var(--text));--text-muted:var(--muted,#64748b);--border:var(--line,#e2e8f0);--border-light:var(--line,#e2e8f0);background:var(--bg);color:var(--text);font-family:var(--app-font,\"Tajawal\",sans-serif)}.nf-host.nf-native .nf-app{background:var(--bg);height:auto!important;max-height:none!important;overflow:visible!important;max-width:1100px}.nf-host.nf-native .nf-topbar{display:none!important}.nf-host.nf-native .nf-screen{animation:none!important}.nf-host.nf-native{min-height:100%;height:auto}",html:"<div class=\"nf-app\">\n\n  <!-- الترويسة -->\n  <div class=\"nf-topbar\">\n    <button class=\"top-icon\" data-nf-onclick=\"cancelInvoiceForm()\" title=\"العودة إلى مجلد الفواتير\">←</button>\n    <div class=\"title\" id=\"mainTitle\">إضافة فاتورة</div>\n    <div style=\"width:38px\"></div>\n  </div>\n\n  <!-- ═════════ شاشة بيانات الفاتورة الأولية ═════════ -->\n  <div class=\"nf-screen active\" id=\"screen-invoice-init\">\n    <h2 style=\"text-align:center;margin-bottom:16px;font-size:20px;font-weight:900;color:var(--primary)\">بيانات الفاتورة الجديدة</h2>\n\n    <div class=\"form-group\">\n      <label>📅 التاريخ (من التقويم)</label>\n      <input type=\"date\" id=\"initDate\" data-nf-onchange=\"updateInitDateText()\">\n      <div id=\"initDateText\" style=\"font-size:13px;color:var(--primary);margin-top:6px;text-align:center;font-weight:800\"></div>\n    </div>\n\n    <div class=\"form-group\">\n      <label>👤 اسم البياع</label>\n      <div class=\"seller-row\">\n        <input type=\"text\" id=\"initSeller\" placeholder=\"\">\n        <button type=\"button\" class=\"thumb-btn\" id=\"sellerThumb\" data-nf-onclick=\"openSellerPhotoViewer()\" title=\"عرض / إرفاق صورة\">\n          <img id=\"sellerThumbImg\" alt=\"\">\n          <span class=\"thumb-empty\">📎</span>\n        </button>\n        <div class=\"photo-quick\">\n          <button type=\"button\" data-nf-onclick=\"document.getElementById('initSellerCamera').click()\" title=\"تصوير\">📷</button>\n          <button type=\"button\" data-nf-onclick=\"document.getElementById('initSellerGallery').click()\" title=\"استوديو\">🖼️</button>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"form-group\">\n      <label>🗓️ الفلتر الأسبوعي</label>\n      <select id=\"initPlace\" required data-nf-onchange=\"syncWeeklyFilterSelection(this.value)\">\n        <option value=\"\">اختر الفلتر الأسبوعي</option>\n      </select>\n      <small style=\"display:block;margin-top:6px;color:var(--text-secondary)\">الفلتر الأسبوعي: <b id=\"weeklyFilterChosenName\">—</b></small>\n    </div>\n\n    <div class=\"form-group\">\n      <label>🔢 رقم الجدول</label>\n      <input type=\"text\" id=\"initNo\" placeholder=\"\" data-nf-oninput=\"blockArabicNums(this)\">\n    </div>\n\n    <div style=\"display:flex;gap:10px;margin-top:20px\">\n      <button class=\"nf-btn nf-btn-primary\" style=\"flex:1;padding:14px;font-size:16px\" data-nf-onclick=\"proceedToForm()\">✅ حفظ وفتح الجدول</button>\n      <button class=\"nf-btn btn-secondary\" style=\"flex:1\" data-nf-onclick=\"cancelInvoiceForm()\">إلغاء</button>\n    </div>\n  </div>\n\n  <!-- ═════════ شاشة الجدول ═════════ -->\n  <div class=\"nf-screen\" id=\"screen-add\">\n    <div class=\"sales-page\" id=\"salesFormPage\">\n\n      <div class=\"sec\">\n        <div class=\"sec-title\">\n          <span>📋 بيانات الفاتورة</span>\n          <div class=\"nf-actions\">\n            <button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addSaleColumn()\">＋ عمود بيع</button>\n            <button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addSaleRow()\">＋ صف</button>\n            <button class=\"add-btn paper-camera-btn\" type=\"button\" data-nf-onclick=\"document.getElementById('invoicePaperCamera').click()\" title=\"تصوير ورقة الفاتورة\">📷 تصوير الورقة</button>\n            <button class=\"add-btn paper-camera-btn\" type=\"button\" data-nf-onclick=\"openInvCamera()\" title=\"تصوير الورقة وقراءة بياناتها آلياً\">🤖 تصوير وقراءة</button>\n            <button class=\"add-btn\" id=\"viewInvoicePaperBtn\" type=\"button\" data-nf-onclick=\"viewInvoicePaperPhoto()\" style=\"display:none\" title=\"عرض صورة الورقة\">👁️ عرض الصورة</button>\n            <span id=\"invoicePaperPhotoStatus\" style=\"font-size:11px;font-weight:800;color:var(--green);display:none\">✓ تم إرفاق صورة الورقة</span>\n          </div>\n        </div>\n        <div class=\"meta\">\n          <label>اليوم والتاريخ<input id=\"sDate\" type=\"date\" aria-label=\"تاريخ الفاتورة داخل الجدول\" data-nf-onchange=\"onTableInvoiceDateChange()\"><small id=\"sDateText\" class=\"table-date-text\"></small></label>\n          <label>رقم الجدول<input id=\"sNo\" type=\"text\" data-nf-oninput=\"blockArabicNums(this)\"></label>\n          <label>اسم البيع<input id=\"sSeller\" type=\"text\"></label>\n          <label>الفلتر الأسبوعي<select id=\"sPlace\" data-nf-onchange=\"syncWeeklyFilterSelection(this.value)\"><option value=\"\">اختر الفلتر الأسبوعي</option></select></label>\n        </div>\n        <div class=\"tw\">\n          <table class=\"nf-g\" id=\"salesTable\">\n            <thead id=\"salesHead\"></thead>\n            <tbody id=\"salesBody\"></tbody>\n            <tfoot id=\"salesFoot\"></tfoot>\n          </table>\n        </div>\n      </div>\n\n      <div class=\"mini3\">\n        <div class=\"nf-panel\">\n          <h4>💰 مسلم فلوس<button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addMoneyRow('received')\">＋</button></h4>\n          <table>\n            <thead><tr><th>الاسم</th><th>المبلغ</th><th></th></tr></thead>\n            <tbody id=\"receivedBody\"></tbody>\n            <tfoot><tr><th>الجملة</th><th id=\"receivedTotal\"></th><th></th></tr></tfoot>\n          </table>\n        </div>\n        <div class=\"nf-panel\">\n          <h4>↘️ الخرج فلوس<button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addMoneyRow('out')\">＋</button></h4>\n          <table>\n            <thead><tr><th>الاسم</th><th>المبلغ</th><th></th></tr></thead>\n            <tbody id=\"outBody\"></tbody>\n            <tfoot><tr><th>الجملة</th><th id=\"outTotal\"></th><th></th></tr></tfoot>\n          </table>\n        </div>\n        <div class=\"nf-panel\">\n          <h4>🏦 سحب فلوس<button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addMoneyRow('withdraw')\">＋</button></h4>\n          <table>\n            <thead><tr><th>الاسم</th><th>المبلغ</th><th></th></tr></thead>\n            <tbody id=\"withdrawBody\"></tbody>\n            <tfoot><tr><th>الجملة</th><th id=\"withdrawTotal\"></th><th></th></tr></tfoot>\n          </table>\n        </div>\n      </div>\n\n      <div class=\"sec\">\n        <div class=\"sec-title\"><span>📅 مسلم أسبوع</span><button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addWeeklyMoneyRow()\">＋ إضافة اسم</button></div>\n        <div class=\"tw\"><table class=\"nf-g\"><thead><tr><th>الاسم</th><th>المبلغ</th><th></th></tr></thead><tbody id=\"weeklyMoneyBody\"></tbody><tfoot><tr class=\"total-row\"><th>الجملة</th><th id=\"weeklyMoneyTotal\">0</th><th></th></tr></tfoot></table></div>\n      </div>\n\n      <div class=\"sec\">\n        <div class=\"sec-title\">📊 حساب الحركة المالية والتصفية</div>\n        <div class=\"sum2\">\n          <div class=\"card-box\">\n            <h4>عمود الكمية</h4>\n            <table>\n              <tr><th>الكمية</th><td><input id=\"qty\" type=\"number\" step=\"any\" value=\"\" data-nf-oninput=\"recalcSales()\" style=\"width:100%;border:0;background:transparent;text-align:center;font:inherit;font-weight:900;outline:none;direction:ltr\"></td></tr>\n              <tr><th>النقد</th><td><span class=\"val\" id=\"sumCash\"></span></td></tr>\n              <tr><th>القات الدين</th><td><span class=\"val\" id=\"sumDebt\"></span></td></tr>\n              <tr><th>القات خرج</th><td><span class=\"val\" id=\"sumQatOut\"></span></td></tr>\n              <tr><th>الباقي</th><td><span class=\"val\" id=\"qtyBalance\" style=\"background:#cfe2ff;padding:3px 10px;border-radius:6px;display:inline-block;min-width:50px\"></span></td></tr>\n            </table>\n          </div>\n          <div class=\"card-box\">\n            <h4>عمود البيع</h4>\n            <table class=\"sale-summary-table\">\n              <tr><th>البيع نقد</th><td><span class=\"val\" id=\"saleCash\"></span></td></tr>\n              <tr><th>− فلوس خرج</th><td><span class=\"val\" id=\"sumOut\"></span></td></tr>\n              <tr class=\"subtotal-row\"><th>= نقد الباقي</th><td><span class=\"val\" id=\"cashAfterOut\"></span></td></tr>\n              <tr><th>+ مسلم أسبوع</th><td><span class=\"val\" id=\"sumWeekly\"></span></td></tr>\n              <tr><th>+ مسلم فلوس</th><td><span class=\"val\" id=\"sumReceived\"></span></td></tr>\n              <tr><th>− السحب فلوس</th><td><span class=\"val\" id=\"sumWithdraw\"></span></td></tr>\n              <tr class=\"final-total-row\"><th>= الباقي نقد</th><td><span class=\"val\" id=\"cashBalance\"></span></td></tr>\n            </table>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"sec\">\n        <div class=\"sec-title\">\n          <span>💱 العملة — إدخال وتصفيتها</span>\n          <div class=\"nf-actions\">\n            <button class=\"add-btn\" type=\"button\" data-nf-onclick=\"addCurrency()\">＋ عملة</button>\n          </div>\n        </div>\n        <div class=\"cur\">\n          <div class=\"tw\">\n            <table>\n              <thead><tr><th>العملة</th><th>مبلغ العملة</th><th>سعر الصرف</th><th>الناتج</th><th></th></tr></thead>\n              <tbody id=\"currencyBody\"></tbody>\n              <tfoot><tr><th colspan=\"3\">جملة الصرف</th><th id=\"currencyTotal\"></th><th></th></tr></tfoot>\n            </table>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"sec\">\n        <div class=\"sec-title\">📝 التنويه</div>\n        <div style=\"padding:10px\">\n          <textarea id=\"note\" class=\"note-box\" placeholder=\"ملاحظات...\"></textarea>\n        </div>\n      </div>\n\n      <div class=\"footer-bar\">\n        <button class=\"nf-btn btn-save\" type=\"button\" data-nf-onclick=\"saveInvoiceNow()\">💾 حفظ الفاتورة</button>\n        <button class=\"nf-btn btn-cancel\" type=\"button\" data-nf-onclick=\"cancelInvoiceForm()\">✖ إلغاء</button>\n        <span class=\"saved-badge\" id=\"savedBadge\">✓ تم الحفظ</span>\n      </div>\n    </div>\n  </div>\n\n</div>\n\n<!-- مدخلات الصور: صورة البياع وصورة ورقة الفاتورة -->\n<input type=\"file\" id=\"initSellerCamera\" accept=\"image/*\" capture=\"environment\" style=\"display:none\">\n<input type=\"file\" id=\"initSellerGallery\" accept=\"image/*\" style=\"display:none\">\n<input type=\"file\" id=\"invoicePaperCamera\" accept=\"image/*\" capture=\"environment\" style=\"display:none\">\n\n<!-- نافذة التنبيه -->\n<div class=\"notify-overlay\" id=\"notifyOverlay\">\n  <div class=\"notify-box\">\n    <div class=\"notify-icon\" id=\"notifyIcon\">❓</div>\n    <h3 class=\"notify-title\" id=\"notifyTitle\">تأكيد</h3>\n    <p class=\"notify-msg\" id=\"notifyMsg\">هل أنت متأكد؟</p>\n    <div class=\"notify-actions\" id=\"notifyActions\">\n      <button class=\"notify-btn notify-btn-cancel\" id=\"notifyCancelBtn\">إلغاء</button>\n      <button class=\"notify-btn notify-btn-confirm\" id=\"notifyConfirmBtn\">موافق</button>\n    </div>\n  </div>\n</div>\n\n<!-- التوست -->\n<!-- نافذة تصوير الجداول داخل الفاتورة -->\n<div id=\"inv-camera-modal\" style=\"display:none;position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.62);padding:12px;overflow:auto\">\n <div style=\"max-width:760px;margin:12px auto;background:var(--card,#fff);color:var(--text,#222);border-radius:16px;padding:16px;box-shadow:0 12px 40px #0005\">\n  <div style=\"display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:12px\"><strong style=\"font-size:18px\">📷 تصوير ورقة وإدخال بياناتها</strong><button class=\"add-btn\" data-nf-onclick=\"closeInvCamera()\">✕ إغلاق</button></div>\n  <p style=\"margin:0 0 10px\">اختر نوع الجدول الذي ستصوّره، ثم التقط صورة واضحة للورقة.</p>\n  <div id=\"inv-camera-types\" style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px\">\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('sale')\">عمود بيع</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('qatOut')\">القات خرج</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('qatDebt')\">القات دين</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('recv')\">مسلمه فلوس</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('weekly')\">مسلم اسبوع</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('out')\">خرج فلوس</button>\n   <button class=\"btn-outline\" data-nf-onclick=\"chooseInvCameraType('wd')\">سحب فلوس</button>\n  </div>\n  <div id=\"inv-camera-capture\" style=\"display:none;margin-top:14px\">\n   <div id=\"inv-camera-selected\" style=\"font-weight:800;margin-bottom:8px\"></div>\n   <div style=\"display:flex;gap:10px;flex-wrap:wrap;margin:10px 0\">\n    <button type=\"button\" class=\"btn-green\" data-nf-onclick=\"document.getElementById('inv-camera-file').click()\">📷 الكاميرا — التقاط صورة</button>\n    <button type=\"button\" class=\"btn-outline\" data-nf-onclick=\"document.getElementById('inv-gallery-file').click()\">🖼️ الاستوديو / المعرض — اختيار صورة</button>\n   </div>\n   <input id=\"inv-camera-file\" type=\"file\" accept=\"image/*\" capture=\"environment\" data-nf-onchange=\"processInvCameraImage(event)\" style=\"display:none\">\n   <input id=\"inv-gallery-file\" type=\"file\" accept=\"image/*\" data-nf-onchange=\"processInvCameraImage(event)\" style=\"display:none\">\n   <img id=\"inv-camera-preview\" alt=\"معاينة الورقة\" style=\"display:none;max-width:100%;max-height:260px;object-fit:contain;border:1px solid #ddd;border-radius:8px;margin:8px auto\">\n   <div id=\"inv-camera-status\" style=\"font-size:13px;margin:8px 0\"></div>\n   <label style=\"display:block;font-weight:700;margin:8px 0 4px\">ملاحظات القراءة (تتم القراءة عبر Gemini على الخادم)</label>\n   <textarea id=\"inv-camera-text\" rows=\"5\" placeholder=\"تظهر هنا ملاحظات القراءة. صحّح الصفوف في الجدول أدناه قبل الحفظ\" style=\"width:100%;box-sizing:border-box;border:1px solid #bbb;border-radius:8px;padding:10px;font:inherit\"></textarea>\n   <div style=\"display:flex;gap:8px;flex-wrap:wrap;margin-top:10px\"><button class=\"btn-outline\" data-nf-onclick=\"parseInvCameraText()\">تحويل إلى صفوف</button><button class=\"btn-outline\" data-nf-onclick=\"resetInvCameraCapture()\">تصوير ورقة أخرى</button></div>\n   <div id=\"inv-camera-rows-wrap\" style=\"display:none;margin-top:12px;overflow-x:auto\"><strong>راجع البيانات قبل الإضافة</strong><table style=\"width:100%;margin-top:8px\"><thead id=\"inv-camera-result-head\"></thead><tbody id=\"inv-camera-result-body\"></tbody><tfoot><tr><th>الجملة</th><th id=\"inv-camera-result-total\">0</th><th id=\"inv-camera-result-extra\"></th></tr></tfoot></table><button class=\"btn-green\" style=\"margin-top:12px;width:100%\" data-nf-onclick=\"applyInvCameraRows()\">✓ إضافة البيانات إلى الفاتورة</button></div>\n  </div>\n </div>\n</div>\n\n\n<div class=\"app-toast\" id=\"appToast\">\n  <span id=\"appToastIcon\">ℹ️</span>\n  <span id=\"appToastText\"></span>\n</div>",run:function(document,window,parent,setTimeout,clearTimeout,setInterval,clearInterval,__nf){

/* ═══════════════════════════════════════════════════════════════
   المتغيرات العامة
   ═══════════════════════════════════════════════════════════════ */
let saleColCount = 1;
let salesRows = [];
let receivedRows = [];
let outRows = [];
let withdrawRows = [];
let weeklyRows = [];
let currencyRows = [];
let pendingSellerPhoto = null;
let pendingInvoicePaperPhoto = null;

/* ═══════════════════════════════════════════════════════════════
   أدوات مساعدة
   ═══════════════════════════════════════════════════════════════ */
function uid(){ return Math.random().toString(36).slice(2,9); }
function toEnDigits(s){ return String(s||'').replace(/[\u0660-\u0669]/g,d=>String.fromCharCode(d.charCodeAt(0)-1584+48)); }
function blockArabicNums(el){
  if(!el || !el.value) return;
  let v = toEnDigits(el.value);
  v = v.replace(/[٫،]/g, '.');
  el.value = v;
}
function escapeHtml(s){
  return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function nVal(v){
  if(v === null || v === undefined) return 0;
  let s = String(v).trim();
  if(!s) return 0;
  s = toEnDigits(s);
  s = s.replace(/[,\s\u00A0]/g, '');
  s = s.replace(/[٫،]/g, '.');
  const firstDot = s.indexOf('.');
  if(firstDot !== -1){
    s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
  }
  const x = parseFloat(s);
  return isNaN(x) ? 0 : x;
}
function fmt(v){
  const x = nVal(v);
  if(x === 0) return '0';
  let out = x.toLocaleString('en-US',{maximumFractionDigits:10,minimumFractionDigits:0,useGrouping:true});
  return toEnDigits(out);
}
function round6(v){ return Math.round(v * 1e6) / 1e6; }

/* ═══════════════════════════════════════════════════════════════
   التنبيهات
   ═══════════════════════════════════════════════════════════════ */
function showConfirm(options){
  return new Promise(resolve => {
    const opt = Object.assign({
      title:'تأكيد', message:'هل أنت متأكد؟', icon:'❓',
      confirmText:'موافق', cancelText:'إلغاء', danger:false, single:false
    }, options||{});
    const overlay = document.getElementById('notifyOverlay');
    document.getElementById('notifyIcon').textContent = opt.icon;
    document.getElementById('notifyTitle').textContent = opt.title;
    document.getElementById('notifyMsg').textContent = opt.message;
    const confirmBtn = document.getElementById('notifyConfirmBtn');
    const cancelBtn = document.getElementById('notifyCancelBtn');
    confirmBtn.textContent = opt.confirmText;
    confirmBtn.className = 'notify-btn' + (opt.danger ? 'notify-btn-danger' : 'notify-btn-confirm');
    cancelBtn.textContent = opt.cancelText;
    if(opt.single){ cancelBtn.style.display = 'none'; } else { cancelBtn.style.display = ''; }
    const cleanup = () => { overlay.classList.remove('show'); confirmBtn.onclick = null; cancelBtn.onclick = null; overlay.onclick = null; };
    cancelBtn.onclick = () => { cleanup(); resolve(false); };
    confirmBtn.onclick = () => { cleanup(); resolve(true); };
    overlay.onclick = e => { if(e.target === overlay){ cleanup(); resolve(false); } };
    overlay.classList.add('show');
  });
}
function showAlert(o){ return showConfirm(Object.assign({title:'تنبيه',icon:'ℹ️',confirmText:'حسناً',single:true},o||{})); }

let _toastTimer = null;
function showToast(text, type, icon){
  const toast = document.getElementById('appToast');
  const t = type || 'default';
  const ic = icon || (t==='success'?'✅':t==='error'?'❌':t==='warning'?'⚠️':t==='info'?'ℹ️':'📢');
  document.getElementById('appToastIcon').textContent = ic;
  document.getElementById('appToastText').textContent = text;
  toast.className = 'app-toast' + t;
  clearTimeout(_toastTimer);
  requestAnimationFrame(() => toast.classList.add('show'));
  _toastTimer = setTimeout(() => toast.classList.remove('show'), 2000);
}
function notifySuccess(m,i){ showToast(m,'success',i); }
function notifyError(m,i){ showToast(m,'error',i); }
function notifyWarning(m,i){ showToast(m,'warning',i); }
function notifyInfo(m,i){ showToast(m,'info',i); }

/* ═══════════════════════════════════════════════════════════════
   التنقل
   ═══════════════════════════════════════════════════════════════ */
function showScreen(id){
  document.querySelectorAll('.nf-screen').forEach(s => s.classList.remove('active'));
  const t = document.getElementById(id);
  if(t) t.classList.add('active');
  const titles = {
    'screen-invoice-init':'إضافة فاتورة',
    'screen-add':'الجدول'
  };
  document.getElementById('mainTitle').textContent = titles[id] || 'الفاتورة';
  window.scrollTo(0,0);
}

/* ═══════════════════════════════════════════════════════════════
   الفاتورة الأولية
   ═══════════════════════════════════════════════════════════════ */
function formatInvoiceDateISO(val){
  val=String(val||'').trim();
  if(!/^\d{4}-\d{2}-\d{2}$/.test(val))return '';
  const d=new Date(val+'T00:00:00');if(isNaN(d.getTime()))return '';
  const days=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  return days[d.getDay()]+' - '+val;
}
function parseInvoiceDateISO(val){
  const m=String(val||'').match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  return m?m[1]+'-'+String(m[2]).padStart(2,'0')+'-'+String(m[3]).padStart(2,'0'):'';
}
function updateInitDateText(){
  const val=document.getElementById('initDate').value;
  const el=document.getElementById('initDateText');
  if(el)el.textContent=formatInvoiceDateISO(val);
}
function updateTableInvoiceDate(){
  const input=document.getElementById('sDate');
  const iso=input?input.value:'';
  const text=formatInvoiceDateISO(iso);
  const label=document.getElementById('sDateText');if(label)label.textContent=text;
  if(window._invoiceInitData){window._invoiceInitData.date=text;window._invoiceInitData.dateISO=iso;}
}

let availableWeeklyFilters = [];
function populateWeeklyFilterSelects(filters){
  availableWeeklyFilters = Array.isArray(filters) ? filters : [];
  ['initPlace','sPlace'].forEach(id=>{
    const sel=document.getElementById(id); if(!sel) return;
    const previous=sel.value;
    sel.innerHTML='<option value="">اختر الفلتر الأسبوعي</option>' + availableWeeklyFilters.map(f=>'<option value="'+String(f.name||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')+'">'+String(f.name||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</option>').join('');
    if(previous && availableWeeklyFilters.some(f=>String(f.name||'')===previous)) sel.value=previous;
  });
  if(invoiceWeekContext) applyInvoiceWeekContext(invoiceWeekContext);
  const chosen=document.getElementById('weeklyFilterChosenName'); if(chosen) chosen.textContent=document.getElementById('initPlace')?.value||'—';
}
function syncWeeklyFilterSelection(value){
  ['initPlace','sPlace'].forEach(id=>{const el=document.getElementById(id);if(!el)return;let opt=Array.from(el.options||[]).find(o=>o.value===value);if(!opt&&value){opt=document.createElement('option');opt.value=value;opt.textContent=value;el.appendChild(opt);}el.value=value;});
  const chosen=document.getElementById('weeklyFilterChosenName');if(chosen)chosen.textContent=value||'—';
}
let invoiceWeekContext = null;
let invoiceFolderRange={from:'',to:''};
let invoiceTakenDates=[];
function isInvoiceDateTaken(iso){return !!iso && invoiceTakenDates.indexOf(iso)>=0;}
function isIsoDate(v){return /^\d{4}-\d{2}-\d{2}$/.test(String(v||''));}
function isInvoiceDateInRange(iso){
  if(!isIsoDate(iso))return false;
  if(invoiceFolderRange.from&&iso<invoiceFolderRange.from)return false;
  if(invoiceFolderRange.to&&iso>invoiceFolderRange.to)return false;
  return true;
}
function invoiceRangeText(){
  const f=invoiceFolderRange.from, t=invoiceFolderRange.to;
  return (f&&t)?('من '+f+' إلى '+t):'';
}
// التاريخ المقترح للفاتورة الجديدة: اليوم التالي لآخر فاتورة في الأسبوع،
// وإن لم توجد فواتير فأول يوم في الأسبوع. يتخطى الأيام التي فيها فواتير.
function suggestNextInvoiceDate(from, to, taken){
  const pad=n=>String(n).padStart(2,'0');
  const addDay=s=>{const d=new Date(s+'T12:00:00');d.setDate(d.getDate()+1);return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  const inRange=s=>(!from||s>=from)&&(!to||s<=to);
  const free=s=>inRange(s)&&taken.indexOf(s)<0;
  const inWeek=taken.filter(inRange).sort();
  let start=inWeek.length?addDay(inWeek[inWeek.length-1]):(from||'');
  if(!start)return '';
  for(let s=start,n=0;n<400&&(!to||s<=to);s=addDay(s),n++){if(free(s))return s;}
  if(from&&to){for(let s=from,n=0;n<400&&s<=to;s=addDay(s),n++){if(free(s))return s;}}
  return '';
}
function applyInvoiceFolderRange(ctx){
  invoiceTakenDates=Array.isArray(ctx.takenDates)?ctx.takenDates.map(String):[];
  const from=isIsoDate(ctx.startDate)?ctx.startDate:'';
  const to=isIsoDate(ctx.endDate)?ctx.endDate:'';
  invoiceFolderRange={from,to};
  ['initDate','sDate'].forEach(id=>{
    const el=document.getElementById(id); if(!el)return;
    if(from)el.min=from; else el.removeAttribute('min');
    if(to)el.max=to; else el.removeAttribute('max');
  });
  // فاتورة جديدة داخل الأسبوع: اقترح اليوم التالي لآخر فاتورة (يبقى قابلاً للتعديل)
  const suggested=suggestNextInvoiceDate(from,to,invoiceTakenDates);
  if(suggested){
    const el=document.getElementById('initDate');
    if(el){el.value=suggested;updateInitDateText();}
  }
}
function onTableInvoiceDateChange(){
  const input=document.getElementById('sDate');
  const iso=input?input.value:'';
  if(iso && isInvoiceDateTaken(iso)){
    notifyWarning('⚠️ يوجد فاتورة أخرى بهذا التاريخ في هذا الأسبوع');
    const prevT=window._invoiceInitData&&window._invoiceInitData.dateISO;
    input.value=(prevT&&!isInvoiceDateTaken(prevT))?prevT:'';
  } else if(iso && !isInvoiceDateInRange(iso)){
    notifyWarning('⚠️ التاريخ يجب أن يكون ' + invoiceRangeText());
    const prev=window._invoiceInitData&&window._invoiceInitData.dateISO;
    input.value=isInvoiceDateInRange(prev)?prev:'';
  }
  updateTableInvoiceDate();
}
function applyInvoiceWeekContext(ctx){
  if(!ctx)return;
  invoiceWeekContext=ctx;
  applyInvoiceFolderRange(ctx);
  const filters=Array.isArray(availableWeeklyFilters)?availableWeeklyFilters:[];
  const folderId=String(ctx.folderId||'');
  const weekName=String(ctx.weekName||'').trim();
  let match=filters.find(f=>String(f.sourceFolderId||'')===folderId);
  if(!match&&folderId)match=filters.find(f=>String(f.id||'')===folderId);
  if(!match&&weekName)match=filters.find(f=>String(f.name||'').trim()===weekName);
  if(match) syncWeeklyFilterSelection(String(match.name||''));
  else if(weekName) syncWeeklyFilterSelection(weekName);
  const seller=document.getElementById('initSeller');
  if(seller&&ctx.seller!==undefined&&ctx.seller!==null&&String(ctx.seller).trim())seller.value=String(ctx.seller).trim();
  const no=document.getElementById('initNo');
  if(no&&ctx.tableNo!==undefined&&ctx.tableNo!==null&&String(ctx.tableNo)!=='')no.value=String(ctx.tableNo);
  const chosen=document.getElementById('weeklyFilterChosenName');if(chosen)chosen.textContent=document.getElementById('initPlace')?.value||'—';
}
window.addEventListener('message',function(event){
  const msg=event.data;
  if(msg&&msg.type==='WEEKLY_FILTERS'){populateWeeklyFilterSelects(msg.filters||[]);}
  if(msg&&msg.type==='INVOICE_WEEK_CONTEXT'){applyInvoiceWeekContext(msg.context||{});}
});

function proceedToForm(){
  const dateVal = document.getElementById('initDate').value;
  const seller = document.getElementById('initSeller').value.trim();
  const place = document.getElementById('initPlace').value.trim();
  if(!place){ notifyWarning('⚠️ اختر الفلتر الأسبوعي'); return; }
  const no = document.getElementById('initNo').value.trim();
  if(!dateVal){ notifyWarning('⚠️ اختر التاريخ'); return; }
  if(!isInvoiceDateInRange(dateVal)){ notifyWarning('⚠️ التاريخ يجب أن يكون ' + invoiceRangeText()); return; }
  if(isInvoiceDateTaken(dateVal)){ notifyWarning('⚠️ يوجد فاتورة أخرى بهذا التاريخ في هذا الأسبوع'); return; }
  if(!seller){ notifyWarning('⚠️ أدخل اسم البياع'); return; }
  const dateObj = new Date(dateVal + 'T00:00:00');
  const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const dateText = days[dateObj.getDay()] + ' - ' + dateVal;
  window._invoiceInitData = {date:dateText, dateISO:dateVal, seller, place, no};
  openNewInvoiceForm();
}

function openNewInvoiceForm(){
  const dataInit = window._invoiceInitData || {};
  document.getElementById('sDate').value = dataInit.dateISO || parseInvoiceDateISO(dataInit.date) || '';
  updateTableInvoiceDate();
  document.getElementById('sNo').value = dataInit.no || '';
  document.getElementById('sSeller').value = dataInit.seller || '';
  document.getElementById('sPlace').value = dataInit.place || '';
  saleColCount = 1;
  salesRows = [makeSaleRow()];
  receivedRows = [{id:uid(),name:'',amount:''}];
  outRows = [{id:uid(),name:'',amount:''}];
  withdrawRows = [{id:uid(),name:'',amount:''}];
  weeklyRows = [{id:uid(),name:'',amount:''}];
  currencyRows = [];
  renderSalesForm();
  renderMoneyList('received');
  renderMoneyList('out');
  renderMoneyList('withdraw');
  renderWeeklyMoney();
  renderCurrencyList();
  document.getElementById('qty').value = '';
  document.getElementById('note').value = '';
  document.getElementById('savedBadge').classList.remove('show');
  pendingSellerPhoto = null;
  refreshSellerThumb();
  recalcSales();
  showScreen('screen-add');
}

/* ═══════════════════════════════════════════════════════════════
   الجدول
   ═══════════════════════════════════════════════════════════════ */
function makeSaleRow(){
  return { id: uid(), s1n:'', s1m:'', s2n:'', s2m:'', s3n:'', s3m:'', dname:'', dn:'', dm:'', oname:'', on:'', om:'' };
}

function addSaleRow(){
  salesRows.push(makeSaleRow());
  renderSalesForm();
  recalcSales();
}

function addSaleColumn(){
  if(saleColCount >= 3){ notifyWarning('⚠️ الحد الأقصى 3 أعمدة بيع'); return; }
  saleColCount++;
  renderSalesForm();
  recalcSales();
  notifySuccess('✅ تمت إضافة عمود بيع ' + saleColCount);
}

function removeSaleRow(id){
  salesRows = salesRows.filter(r => r.id !== id);
  if(!salesRows.length) salesRows.push(makeSaleRow());
  renderSalesForm();
  recalcSales();
}

async function removeSaleColumn(colNumber){
  if(saleColCount <= 1){ notifyWarning('⚠️ لا يمكن حذف العمود الوحيد'); return; }
  let filledCount = 0;
  salesRows.forEach(r => {
    if((r['s'+colNumber+'n'] && String(r['s'+colNumber+'n']).trim()) ||
       (r['s'+colNumber+'m'] && String(r['s'+colNumber+'m']).trim())) filledCount++;
  });
  const warningText = filledCount > 0
    ? `⚠️ سيتم حذف «عمود بيع ${colNumber}» مع ${filledCount} صف يحتوي على بيانات!\n\nهل أنت متأكد؟`
    : `سيتم حذف «عمود بيع ${colNumber}» (فارغ).\n\nمتابعة؟`;
  const ok = await showConfirm({icon:'🗑️',title:'حذف عمود البيع',message:warningText,confirmText:'حذف نهائي',danger:true});
  if(!ok) return;
  for(let c = colNumber; c < saleColCount; c++){
    const next = c + 1;
    salesRows.forEach(r => {
      r['s'+c+'n'] = r['s'+next+'n'] !== undefined ? r['s'+next+'n'] : '';
      r['s'+c+'m'] = r['s'+next+'m'] !== undefined ? r['s'+next+'m'] : '';
    });
  }
  salesRows.forEach(r => {
    delete r['s'+saleColCount+'n'];
    delete r['s'+saleColCount+'m'];
  });
  saleColCount--;
  renderSalesForm();
  recalcSales();
  notifySuccess(`✅ تم حذف عمود بيع ${colNumber}`);
}

function renderSalesForm(){
  const head = document.getElementById('salesHead');
  const body = document.getElementById('salesBody');
  const foot = document.getElementById('salesFoot');
  if(!head) return;

  const saleHead = Array.from({length: saleColCount}, (_,i) => {
    const c = i + 1;
    const canDelete = saleColCount > 1;
    return `<th colspan="2" style="position:relative">
      <div style="display:flex;align-items:center;justify-content:center;gap:6px">
        <span>عمود بيع ${c}</span>
        ${canDelete ? `<button type="button" class="col-del-btn" data-nf-onclick="event.stopPropagation();removeSaleColumn(${c})" title="حذف">🗑️</button>` : ''}
      </div>
    </th>`;
  }).join('');

  const saleSub = Array.from({length: saleColCount}, () => '<th>الرقم</th><th>المبلغ</th>').join('');

  head.innerHTML = `<tr>${saleHead}<th colspan="3">القات دين</th><th colspan="3">القات خرج</th><th></th></tr>
    <tr>${saleSub}<th>الاسم</th><th>الكمية</th><th>المبلغ</th><th>الاسم</th><th>الكمية</th><th>المبلغ</th><th></th></tr>`;

  body.innerHTML = salesRows.map(r => {
    const sc = Array.from({length: saleColCount}, (_,i) => {
      const c = i + 1;
      return `<td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r['s'+c+'n'])}" data-nf-oninput="upSale('${r.id}','s${c}n',this.value)"></td>
              <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r['s'+c+'m'])}" data-nf-oninput="upSale('${r.id}','s${c}m',this.value)"></td>`;
    }).join('');
    return `<tr>${sc}
      <td><input type="text" value="${escapeHtml(r.dname)}" data-nf-oninput="upSale('${r.id}','dname',this.value)"></td>
      <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.dn)}" data-nf-oninput="upSale('${r.id}','dn',this.value)"></td>
      <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.dm)}" data-nf-oninput="upSale('${r.id}','dm',this.value)"></td>
      <td><input type="text" value="${escapeHtml(r.oname)}" data-nf-oninput="upSale('${r.id}','oname',this.value)"></td>
      <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.on)}" data-nf-oninput="upSale('${r.id}','on',this.value)"></td>
      <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.om)}" data-nf-oninput="upSale('${r.id}','om',this.value)"></td>
      <td class="row-del"><button type="button" data-nf-onclick="removeSaleRow('${r.id}')">✕</button></td>
    </tr>`;
  }).join('');

  const saleTotals = Array.from({length: saleColCount}, (_,i) => {
    const c = i + 1;
    return `<td class="col-total-n" data-col="${c}"><span class="total-num">0</span></td>
            <td class="col-total-m" data-col="${c}"><span class="total-num">0</span></td>`;
  }).join('');

  foot.innerHTML = `<tr class="total-row">
    ${saleTotals}
    <td colspan="2" class="col-total-d" style="position:relative">
      <div class="total-pair">
        <span class="total-lbl">كمية:</span><span class="total-num col-total-dn">0</span>
        <span class="total-lbl" style="margin-right:10px">مبلغ:</span><span class="total-num col-total-dm">0</span>
      </div>
    </td>
    <td colspan="2" class="col-total-o" style="position:relative">
      <div class="total-pair">
        <span class="total-lbl">كمية:</span><span class="total-num col-total-on">0</span>
        <span class="total-lbl" style="margin-right:10px">مبلغ:</span><span class="total-num col-total-om">0</span>
      </div>
    </td>
    <td></td>
  </tr>`;

  updateColumnTotals();
  setTimeout(attachNumericInputs, 30);
}

function upSale(id, field, v){
  const r = salesRows.find(x => x.id === id);
  if(r){ r[field] = v; recalcSales(); }
}

function updateColumnTotals(){
  for(let c = 1; c <= saleColCount; c++){
    let sumN = 0, sumM = 0;
    salesRows.forEach(r => { sumN += nVal(r['s'+c+'n']); sumM += nVal(r['s'+c+'m']); });
    sumN = round6(sumN); sumM = round6(sumM);
    const elN = document.querySelector(`.col-total-n[data-col="${c}"] .total-num`);
    const elM = document.querySelector(`.col-total-m[data-col="${c}"] .total-num`);
    if(elN) elN.textContent = fmt(sumN);
    if(elM) elM.textContent = fmt(sumM);
  }
  let dN = 0, dM = 0, oN = 0, oM = 0;
  salesRows.forEach(r => { dN += nVal(r.dn); dM += nVal(r.dm); oN += nVal(r.on); oM += nVal(r.om); });
  dN = round6(dN); dM = round6(dM); oN = round6(oN); oM = round6(oM);
  const setTxt = (sel, v) => { const el = document.querySelector(sel); if(el) el.textContent = fmt(v); };
  setTxt('.col-total-dn', dN);
  setTxt('.col-total-dm', dM);
  setTxt('.col-total-on', oN);
  setTxt('.col-total-om', oM);
}

/* ═══════════════════════════════════════════════════════════════
   المسلم / الخرج / السحب
   ═══════════════════════════════════════════════════════════════ */
function renderMoneyList(kind){
  const map = {received:'receivedBody', out:'outBody', withdraw:'withdrawBody'};
  const arr = {received:receivedRows, out:outRows, withdraw:withdrawRows}[kind];
  /* اظهر صف إدخال الاسم والمبلغ مباشرة بدل إخفاء الجدول حتى الضغط على + */
  if(Array.isArray(arr) && arr.length===0){ arr.push({id:uid(),name:'',amount:''}); }
  const body = document.getElementById(map[kind]);
  if(!body) return;
  if(arr.length === 0){
    body.innerHTML = '<tr><td colspan="3" style="color:#aaa;font-size:11px">لا توجد بيانات</td></tr>';
    return;
  }
  body.innerHTML = arr.map(r => `<tr>
    <td><input type="text" value="${escapeHtml(r.name)}" data-nf-oninput="upMoney('${kind}','${r.id}','name',this.value)"></td>
    <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.amount)}" data-nf-oninput="upMoney('${kind}','${r.id}','amount',this.value)"></td>
    <td class="row-del"><button type="button" data-nf-onclick="removeMoney('${kind}','${r.id}')">✕</button></td>
  </tr>`).join('');
  setTimeout(attachNumericInputs, 30);
}
function addMoneyRow(kind){
  ({received:receivedRows, out:outRows, withdraw:withdrawRows})[kind].push({id:uid(), name:'', amount:''});
  renderMoneyList(kind);
  recalcSales();
}
function removeMoney(kind, id){
  const arr = {received:receivedRows, out:outRows, withdraw:withdrawRows}[kind];
  const i = arr.findIndex(x => x.id === id);
  if(i>=0) arr.splice(i,1);
  renderMoneyList(kind);
  recalcSales();
}
function upMoney(kind, id, f, v){
  const arr = {received:receivedRows, out:outRows, withdraw:withdrawRows}[kind];
  const r = arr.find(x => x.id === id);
  if(r){ r[f] = v; recalcSales(); }
}

/* مسلم أسبوع: صفوف مرتبطة بالفاتورة وتدخل في حساب الباقي */
function renderWeeklyMoney(){
  const body=document.getElementById('weeklyMoneyBody');if(!body)return;
  if(weeklyRows.length===0) weeklyRows.push({id:uid(),name:'',amount:''});
  body.innerHTML=weeklyRows.length?weeklyRows.map(r=>`<tr><td><input value="${escapeHtml(r.name||'')}" data-nf-oninput="upWeeklyMoney('${r.id}','name',this.value)"></td><td><input inputmode="decimal" dir="ltr" value="${escapeHtml(r.amount||'')}" data-nf-oninput="upWeeklyMoney('${r.id}','amount',this.value)"></td><td class="row-del"><button type="button" data-nf-onclick="removeWeeklyMoney('${r.id}')">✕</button></td></tr>`).join(''):'<tr><td colspan="3" style="color:#aaa;font-size:11px">لا توجد بيانات</td></tr>';
  setTimeout(attachNumericInputs,30);
}
function addWeeklyMoneyRow(){weeklyRows.push({id:uid(),name:'',amount:''});renderWeeklyMoney();recalcSales();}
function upWeeklyMoney(id,f,v){const r=weeklyRows.find(x=>x.id===id);if(r){r[f]=v;recalcSales();}}
function removeWeeklyMoney(id){weeklyRows=weeklyRows.filter(x=>x.id!==id);renderWeeklyMoney();recalcSales();}

/* ═══════════════════════════════════════════════════════════════
   العملات
   ═══════════════════════════════════════════════════════════════ */
function renderCurrencyList(){
  const body = document.getElementById('currencyBody');
  if(!body) return;
  if(currencyRows.length === 0){
    currencyRows=['يمني','سعودي','عماني','درهم'].map(cur=>({id:uid(),cur,amt:'',rate:cur==='يمني'?'1':''}));
  }
  if(currencyRows.length === 0){
    body.innerHTML = '<tr><td colspan="5" style="color:#aaa;font-size:11px">لا توجد عملات</td></tr>';
    return;
  }
  body.innerHTML = currencyRows.map(r => `<tr>
    <td><input type="text" value="${escapeHtml(r.cur)}" data-nf-oninput="upCur('${r.id}','cur',this.value)"></td>
    <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(r.amt)}" data-nf-oninput="upCur('${r.id}','amt',this.value)"></td>
    <td><input type="text" inputmode="decimal" dir="ltr" value="${escapeHtml(String(r.cur||'').trim()==='يمني'?'1':r.rate)}" ${String(r.cur||'').trim()==='يمني'?'readonly title="سعر صرف اليمني ثابت 1"':''} data-nf-oninput="upCur('${r.id}','rate',this.value)"></td>
    <td class="cv-${r.id}">${fmt(nVal(r.amt)*nVal(r.rate||1))}</td>
    <td class="row-del"><button type="button" data-nf-onclick="removeCur('${r.id}')">✕</button></td>
  </tr>`).join('');
  setTimeout(attachNumericInputs, 30);
}
function addCurrency(){
  currencyRows.push({id:uid(), cur:'', amt:'', rate:''});
  renderCurrencyList();
  recalcSales();
}
function removeCur(id){
  currencyRows = currencyRows.filter(x => x.id !== id);
  renderCurrencyList();
  recalcSales();
}
function upCur(id, f, v){
  const r = currencyRows.find(x => x.id === id);
  if(r){
    if(f==='rate' && String(r.cur||'').trim()==='يمني') r.rate='1';
    else if(f==='cur') { r.cur=v; if(String(v||'').trim()==='يمني') r.rate='1'; }
    else r[f] = v;
    if(f==='cur' && String(r.cur||'').trim()==='يمني'){const row=document.querySelector('.cv-'+r.id)?.parentElement;const rateInput=row&&row.querySelectorAll('input')[2];if(rateInput){rateInput.value='1';rateInput.readOnly=true;}}
    recalcSales();
  }
}


/* ═══════════════════════════════════════════════════════════════
   الحساب
   ═══════════════════════════════════════════════════════════════ */
function recalcSales(){
  const sumField=(rows,field)=>round6((Array.isArray(rows)?rows:[]).reduce((t,r)=>t+nVal(r&&r[field]),0));
  // أعمدة البيع: الرقم يدخل في حساب الكمية، والمبلغ يدخل في حساب البيع النقدي.
  let cashNumbers=0, saleAmounts=0;
  for(let c=1;c<=(Number(saleColCount)||1);c++){
    cashNumbers+=sumField(salesRows,'s'+c+'n');
    saleAmounts+=sumField(salesRows,'s'+c+'m');
  }
  cashNumbers=round6(cashNumbers); saleAmounts=round6(saleAmounts);
  const debtQty=sumField(salesRows,'dn'), debtAmount=sumField(salesRows,'dm');
  const outQty=sumField(salesRows,'on'), outAmount=sumField(salesRows,'om');
  const received=sumField(receivedRows,'amount');
  const outMoney=sumField(outRows,'amount');
  const withdrawn=sumField(withdrawRows,'amount');
  const weekly=sumField(weeklyRows,'amount');
  const qtyEl=document.getElementById('qty');
  const enteredQty=qtyEl?nVal(qtyEl.value):0;
  // الكمية المتبقية = الكمية المدخلة - أرقام البيع - كمية الدين - كمية الخرج.
  const qtyBalance=round6(enteredQty-cashNumbers-debtQty-outQty);
  // نقد الباقي = مبالغ البيع - خرج فلوس.
  const cashAfterOut=round6(saleAmounts-outMoney);
  // الباقي نقد = نقد الباقي + مسلم أسبوع + مسلم فلوس - السحب فلوس.
  const cashBalance=round6(cashAfterOut+weekly+received-withdrawn);
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=fmt(round6(v));};
  set('sumCash',cashNumbers); set('sumDebt',debtQty); set('sumQatOut',outQty);
  set('qtyBalance',qtyBalance); set('saleCash',saleAmounts);
  set('sumReceived',received); set('sumOut',outMoney); set('sumWithdraw',withdrawn);
  set('sumWeekly',weekly); set('weeklyMoneyTotal',weekly);
  set('cashAfterOut',cashAfterOut); set('cashBalance',cashBalance);
  set('receivedTotal',received); set('outTotal',outMoney); set('withdrawTotal',withdrawn);
  // تحديث مجموعات مبالغ وكميات القات وأعمدة البيع.
  updateColumnTotals();
  // ناتج كل عملة = المبلغ × سعر الصرف، واليمني سعره ثابت 1.
  let currencyTotal=0;
  (Array.isArray(currencyRows)?currencyRows:[]).forEach(r=>{
    if(String(r.cur||'').trim()==='يمني') r.rate='1';
    const result=round6(nVal(r.amt)*nVal(r.rate||1));
    currencyTotal=round6(currencyTotal+result);
    const el=document.querySelector('.cv-'+r.id); if(el)el.textContent=fmt(result);
  });
  set('currencyTotal',currencyTotal);
}

/* ═+
   الإدخال الرقمي الكسري
   ═══════════════════════════════════════════════════════════════ */
function attachNumericInputs(){
  const selectors = [
    '#salesTable input[inputmode="decimal"]',
    '#receivedBody input[inputmode="decimal"]',
    '#outBody input[inputmode="decimal"]',
    '#withdrawBody input[inputmode="decimal"]',
    '#weeklyMoneyBody input[inputmode="decimal"]',
    '#currencyBody input[inputmode="decimal"]',
    '#qty'
  ];
  document.querySelectorAll(selectors.join(',')).forEach(inp => {
    if(inp.dataset.numAttached) return;
    inp.dataset.numAttached = '1';
    inp.addEventListener('beforeinput', e => {
      if(e.data && /[^\d.\-\u0660-\u0669٫،]/.test(e.data)) e.preventDefault();
    });
    inp.addEventListener('input', () => {
      const v = inp.value;
      const en = toEnDigits(v).replace(/[٫،]/g, '.').replace(/[^\d.\-]/g, '');
      const parts = en.split('.');
      const cleaned = parts.length > 2 ? parts[0] + '.' + parts.slice(1).join('') : en;
      if(cleaned !== v) inp.value = cleaned;
      /* ضمان تحديث المجاميع فور إدخال الرقم حتى على لوحات المفاتيح العربية */
      if(typeof recalcSales==='function') recalcSales();
    });
  });
}


window.addEventListener('message', function(event){
  const msg=event.data;
  if(!msg || msg.type!=='LOAD_INVOICE' || !msg.payload) return;
  const p=msg.payload, f=p.formData||{};
  const loadedDateISO=String(p.initDateISO||p.invoiceDateISO||parseInvoiceDateISO(p.initDate)||'');
  window._invoiceInitData={date:formatInvoiceDateISO(loadedDateISO)||p.initDate||'',dateISO:loadedDateISO,seller:p.initSeller||'',place:p.initWeeklyFilter||p.initPlace||'',no:p.initNo||''};
  document.getElementById('initDate').value=loadedDateISO;
  updateInitDateText();
  document.getElementById('initSeller').value=p.initSeller||'';
  document.getElementById('initPlace').value=p.initWeeklyFilter||p.initPlace||'';
  syncWeeklyFilterSelection(document.getElementById('initPlace').value);
  document.getElementById('initNo').value=p.initNo||'';
  pendingSellerPhoto=p.sellerPhoto||null; refreshSellerThumb();
  pendingInvoicePaperPhoto=p.invoicePaperPhoto||null; refreshInvoicePaperPhotoUI();
  saleColCount=Math.max(1,Math.min(3,Number(f.saleColCount)||1));
  salesRows=Array.isArray(f.salesRows)&&f.salesRows.length?JSON.parse(JSON.stringify(f.salesRows)):[makeSaleRow()];
  receivedRows=Array.isArray(f.receivedRows)?JSON.parse(JSON.stringify(f.receivedRows)):[];
  outRows=Array.isArray(f.outRows)?JSON.parse(JSON.stringify(f.outRows)):[];
  withdrawRows=Array.isArray(f.withdrawRows)?JSON.parse(JSON.stringify(f.withdrawRows)):[];
  weeklyRows=Array.isArray(f.weeklyRows)?JSON.parse(JSON.stringify(f.weeklyRows)):[];
  if(!receivedRows.length) receivedRows.push({id:uid(),name:'',amount:''});
  if(!outRows.length) outRows.push({id:uid(),name:'',amount:''});
  if(!withdrawRows.length) withdrawRows.push({id:uid(),name:'',amount:''});
  if(!weeklyRows.length) weeklyRows.push({id:uid(),name:'',amount:''});
  currencyRows=Array.isArray(f.currencyRows)?JSON.parse(JSON.stringify(f.currencyRows)):[];
  document.getElementById('sDate').value=loadedDateISO;
  updateTableInvoiceDate();
  document.getElementById('sNo').value=p.initNo||'';
  document.getElementById('sSeller').value=p.initSeller||'';
  document.getElementById('sPlace').value=p.initWeeklyFilter||p.initPlace||'';
  document.getElementById('qty').value=f.qty||'';
  document.getElementById('note').value=p.note||f.note||'';
  renderSalesForm(); renderMoneyList('received'); renderMoneyList('out'); renderMoneyList('withdraw'); renderWeeklyMoney(); renderCurrencyList(); recalcSales();
  document.getElementById('savedBadge').classList.remove('show');
  showScreen('screen-add');
});

/* ═══════════════════════════════════════════════════════════════
   التهيئة
   ═══════════════════════════════════════════════════════════════ */
(function init(){
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('initDate').value = today;
  updateInitDateText();
})();
window.addEventListener('message', function(e){
  if(!e.data || e.data.type!=='PRINT_SETTINGS') return;
  const cfg=e.data.settings||{};
  document.body.classList.remove('print-a3','print-a4','print-gray','print-bw','print-color');
  document.body.classList.add(cfg.paper==='a3'?'print-a3':'print-a4');
  document.body.classList.add(cfg.printColorMode==='gray'?'print-gray':cfg.printColorMode==='bw'?'print-bw':'print-color');
  if(cfg.printColor) document.documentElement.style.setProperty('--print-accent',cfg.printColor);
  let st=document.getElementById('dynamicPrintPageSize');
  if(!st){st=document.createElement('style');st.id='dynamicPrintPageSize';document.head.appendChild(st);}
  st.textContent='@media print { @page { size: '+(cfg.paper==='a3'?'A3':'A4')+' portrait; margin: 8mm; } }';
});


(function(){
  function refreshInvoiceMath(){ if(typeof window.recalcSales==='function') window.recalcSales(); }
  document.addEventListener('input',function(ev){ if(ev.target && ev.target.matches('input,select,textarea')) { Promise.resolve().then(refreshInvoiceMath); } },true);
  document.addEventListener('change',function(ev){ if(ev.target && ev.target.matches('input,select,textarea')) { Promise.resolve().then(refreshInvoiceMath); } },true);
  window.addEventListener('load',function(){ refreshInvoiceMath(); setTimeout(refreshInvoiceMath,100); });
})();


/* ═══ دوال مفقودة: الصور، الحفظ، الإلغاء، التصوير ═══ */
function _readFileAsDataURL(file,cb){const r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(file);}
function refreshSellerThumb(){
  const btn=document.getElementById('sellerThumb'),img=document.getElementById('sellerThumbImg');
  if(!btn||!img)return;
  if(pendingSellerPhoto){img.src=pendingSellerPhoto;img.style.display='block';btn.classList.add('has-photo');}
  else{img.removeAttribute('src');img.style.display='none';btn.classList.remove('has-photo');}
}
function refreshInvoicePaperPhotoUI(){
  const v=document.getElementById('viewInvoicePaperBtn'),s=document.getElementById('invoicePaperPhotoStatus');
  if(v)v.style.display=pendingInvoicePaperPhoto?'':'none';
  if(s)s.style.display=pendingInvoicePaperPhoto?'':'none';
}
function _showPhoto(src){
  if(!src)return;
  const w=document.createElement('div');
  w.style.cssText='position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:12px';
  w.innerHTML='<img style="max-width:100%;max-height:100%;object-fit:contain;border-radius:8px">';
  w.firstChild.src=src;w.onclick=()=>w.remove();document.body.appendChild(w);
}
function openSellerPhotoViewer(){
  if(pendingSellerPhoto)_showPhoto(pendingSellerPhoto);
  else document.getElementById('initSellerGallery').click();
}
function viewInvoicePaperPhoto(){ _showPhoto(pendingInvoicePaperPhoto); }
document.addEventListener('change',function(e){
  const t=e.target;if(!t||!t.files||!t.files[0])return;
  if(t.id==='initSellerCamera'||t.id==='initSellerGallery'){_readFileAsDataURL(t.files[0],d=>{pendingSellerPhoto=d;refreshSellerThumb();});t.value='';}
  else if(t.id==='invoicePaperCamera'){_readFileAsDataURL(t.files[0],d=>{pendingInvoicePaperPhoto=d;refreshInvoicePaperPhotoUI();notifySuccess('تم إرفاق صورة الورقة');});t.value='';}
});
function collectInvoiceData(){
  return {saleColCount,salesRows:JSON.parse(JSON.stringify(salesRows)),receivedRows:JSON.parse(JSON.stringify(receivedRows)),
    outRows:JSON.parse(JSON.stringify(outRows)),withdrawRows:JSON.parse(JSON.stringify(withdrawRows)),
    weeklyRows:JSON.parse(JSON.stringify(weeklyRows)),currencyRows:JSON.parse(JSON.stringify(currencyRows)),
    qty:(document.getElementById('qty')||{}).value||'',note:(document.getElementById('note')||{}).value||''};
}
function saveInvoiceNow(){
  recalcSales();
  const init=window._invoiceInitData||{};
  const g=id=>((document.getElementById(id)||{}).value||'').trim();
  const place=g('sPlace')||init.place||'';
  const dateISO=String(g('sDate')||init.dateISO||init.date_iso||parseInvoiceDateISO(init.date)||'').trim();
  const dateText=formatInvoiceDateISO(dateISO)||String(init.date||'').trim();
  const payload={
    initDate:dateText, initDateISO:dateISO,
    initSeller:g('sSeller')||init.seller||'', initPlace:place, initWeeklyFilter:place,
    initNo:g('sNo')||init.no||'', note:g('note'),
    sellerPhoto:pendingSellerPhoto||'', invoicePaperPhoto:pendingInvoicePaperPhoto||'',
    formData:collectInvoiceData(), invoiceDateISO:dateISO,
    folderId:String(invoiceWeekContext&&invoiceWeekContext.folderId||''),
    weekName:String(invoiceWeekContext&&invoiceWeekContext.weekName||'')
  };
  if(!payload.initDate||!payload.initSeller){notifyWarning('⚠️ أدخل التاريخ واسم البياع قبل الحفظ');return;}
  if(!isInvoiceDateInRange(dateISO)){notifyWarning('⚠️ التاريخ يجب أن يكون ' + invoiceRangeText());return;}
  if(isInvoiceDateTaken(dateISO)){notifyWarning('⚠️ يوجد فاتورة أخرى بهذا التاريخ في هذا الأسبوع');return;}
  const sb=document.getElementById('savedBadge');if(sb)sb.classList.add('show');
  parent.postMessage({type:'INVOICE_SAVE',payload},'*');
}
function cancelInvoiceForm(){ parent.postMessage({type:'INVOICE_CANCEL'},'*'); }

/* ═══ تصوير الورقة وإدخالها ═══ */
let _invCamType=null;
const _invCamNames={sale:'عمود بيع',qatOut:'القات خرج',qatDebt:'القات دين',recv:'مسلمه فلوس',weekly:'مسلم اسبوع',out:'خرج فلوس',wd:'سحب فلوس'};
function openInvCamera(){document.getElementById('inv-camera-modal').style.display='block';resetInvCameraCapture(true);}
function closeInvCamera(){document.getElementById('inv-camera-modal').style.display='none';}
function chooseInvCameraType(t){
  _invCamType=t;
  document.getElementById('inv-camera-capture').style.display='block';
  document.getElementById('inv-camera-selected').textContent='النوع المختار: '+_invCamNames[t];
}
function resetInvCameraCapture(hideAll){
  const p=document.getElementById('inv-camera-preview');if(p){p.style.display='none';p.removeAttribute('src');}
  const st=document.getElementById('inv-camera-status');if(st)st.textContent='';
  const tx=document.getElementById('inv-camera-text');if(tx)tx.value='';
  if(hideAll===true){_invCamType=null;document.getElementById('inv-camera-capture').style.display='none';}
}
function processInvCameraImage(ev){
  const f=ev.target.files&&ev.target.files[0];if(!f)return;
  _readFileAsDataURL(f,d=>{
    const p=document.getElementById('inv-camera-preview');p.src=d;p.style.display='block';
    pendingInvoicePaperPhoto=d;refreshInvoicePaperPhotoUI();
    document.getElementById('inv-camera-status').textContent='تم إرفاق الصورة. القراءة الآلية غير متاحة دون اتصال بالخادم؛ اكتب الأسطر في المربع (اسم ثم رقم أو رقم ثم مبلغ) واضغط «تحويل إلى صفوف».';
  });
  ev.target.value='';
}
function parseInvCameraText(){
  const t=_invCamType;if(!t){notifyWarning('اختر نوع الجدول أولاً');return;}
  const lines=toEnDigits(document.getElementById('inv-camera-text').value).split('\n').map(x=>x.trim()).filter(Boolean);
  if(!lines.length){notifyWarning('اكتب الأسطر أولاً');return;}
  const parsed=lines.map(l=>{const nums=(l.match(/-?\d+(?:\.\d+)?/g)||[]);const name=l.replace(/-?\d+(?:\.\d+)?/g,'').replace(/[:،,\-]/g,' ').trim();return {name,nums};});
  const emptyRow=(rows,test)=>rows.find(test);
  parsed.forEach(({name,nums})=>{
    if(t==='sale'){let r=salesRows.find(x=>!x.s1n&&!x.s1m);if(!r){r=makeSaleRow();salesRows.push(r);}r.s1n=nums[0]||'';r.s1m=nums[1]||'';}
    else if(t==='qatOut'){let r=salesRows.find(x=>!x.on&&!x.om&&!x.oname);if(!r){r=makeSaleRow();salesRows.push(r);}r.oname=name;r.on=nums[0]||'';r.om=nums[1]||'';}
    else if(t==='qatDebt'){let r=salesRows.find(x=>!x.dn&&!x.dm&&!x.dname);if(!r){r=makeSaleRow();salesRows.push(r);}r.dname=name;r.dn=nums[0]||'';r.dm=nums[1]||'';}
    else{
      const arr={recv:receivedRows,out:outRows,wd:withdrawRows,weekly:weeklyRows}[t];
      let r=arr.find(x=>!x.name&&!x.amount);if(!r){r={id:uid(),name:'',amount:''};arr.push(r);}
      r.name=name;r.amount=nums[nums.length-1]||'';
    }
  });
  renderSalesForm();renderMoneyList('received');renderMoneyList('out');renderMoneyList('withdraw');renderWeeklyMoney();recalcSales();
  closeInvCamera();notifySuccess('تمت إضافة '+parsed.length+' صف');
}
function applyInvCameraRows(){parseInvCameraText();}


/* exports: global functions of the former iframe page */
try{window.uid=uid}catch(_e){}
try{window.toEnDigits=toEnDigits}catch(_e){}
try{window.blockArabicNums=blockArabicNums}catch(_e){}
try{window.escapeHtml=escapeHtml}catch(_e){}
try{window.nVal=nVal}catch(_e){}
try{window.fmt=fmt}catch(_e){}
try{window.round6=round6}catch(_e){}
try{window.showConfirm=showConfirm}catch(_e){}
try{window.showAlert=showAlert}catch(_e){}
try{window.showToast=showToast}catch(_e){}
try{window.notifySuccess=notifySuccess}catch(_e){}
try{window.notifyError=notifyError}catch(_e){}
try{window.notifyWarning=notifyWarning}catch(_e){}
try{window.notifyInfo=notifyInfo}catch(_e){}
try{window.showScreen=showScreen}catch(_e){}
try{window.formatInvoiceDateISO=formatInvoiceDateISO}catch(_e){}
try{window.parseInvoiceDateISO=parseInvoiceDateISO}catch(_e){}
try{window.updateInitDateText=updateInitDateText}catch(_e){}
try{window.updateTableInvoiceDate=updateTableInvoiceDate}catch(_e){}
try{window.populateWeeklyFilterSelects=populateWeeklyFilterSelects}catch(_e){}
try{window.syncWeeklyFilterSelection=syncWeeklyFilterSelection}catch(_e){}
try{window.isInvoiceDateTaken=isInvoiceDateTaken}catch(_e){}
try{window.isIsoDate=isIsoDate}catch(_e){}
try{window.isInvoiceDateInRange=isInvoiceDateInRange}catch(_e){}
try{window.invoiceRangeText=invoiceRangeText}catch(_e){}
try{window.applyInvoiceFolderRange=applyInvoiceFolderRange}catch(_e){}
try{window.onTableInvoiceDateChange=onTableInvoiceDateChange}catch(_e){}
try{window.applyInvoiceWeekContext=applyInvoiceWeekContext}catch(_e){}
try{window.proceedToForm=proceedToForm}catch(_e){}
try{window.openNewInvoiceForm=openNewInvoiceForm}catch(_e){}
try{window.makeSaleRow=makeSaleRow}catch(_e){}
try{window.addSaleRow=addSaleRow}catch(_e){}
try{window.addSaleColumn=addSaleColumn}catch(_e){}
try{window.removeSaleRow=removeSaleRow}catch(_e){}
try{window.removeSaleColumn=removeSaleColumn}catch(_e){}
try{window.renderSalesForm=renderSalesForm}catch(_e){}
try{window.upSale=upSale}catch(_e){}
try{window.updateColumnTotals=updateColumnTotals}catch(_e){}
try{window.renderMoneyList=renderMoneyList}catch(_e){}
try{window.addMoneyRow=addMoneyRow}catch(_e){}
try{window.removeMoney=removeMoney}catch(_e){}
try{window.upMoney=upMoney}catch(_e){}
try{window.renderWeeklyMoney=renderWeeklyMoney}catch(_e){}
try{window.addWeeklyMoneyRow=addWeeklyMoneyRow}catch(_e){}
try{window.upWeeklyMoney=upWeeklyMoney}catch(_e){}
try{window.removeWeeklyMoney=removeWeeklyMoney}catch(_e){}
try{window.renderCurrencyList=renderCurrencyList}catch(_e){}
try{window.addCurrency=addCurrency}catch(_e){}
try{window.removeCur=removeCur}catch(_e){}
try{window.upCur=upCur}catch(_e){}
try{window.recalcSales=recalcSales}catch(_e){}
try{window.attachNumericInputs=attachNumericInputs}catch(_e){}
try{window._readFileAsDataURL=_readFileAsDataURL}catch(_e){}
try{window.refreshSellerThumb=refreshSellerThumb}catch(_e){}
try{window.refreshInvoicePaperPhotoUI=refreshInvoicePaperPhotoUI}catch(_e){}
try{window._showPhoto=_showPhoto}catch(_e){}
try{window.openSellerPhotoViewer=openSellerPhotoViewer}catch(_e){}
try{window.viewInvoicePaperPhoto=viewInvoicePaperPhoto}catch(_e){}
try{window.collectInvoiceData=collectInvoiceData}catch(_e){}
try{window.saveInvoiceNow=saveInvoiceNow}catch(_e){}
try{window.cancelInvoiceForm=cancelInvoiceForm}catch(_e){}
try{window.openInvCamera=openInvCamera}catch(_e){}
try{window.closeInvCamera=closeInvCamera}catch(_e){}
try{window.chooseInvCameraType=chooseInvCameraType}catch(_e){}
try{window.resetInvCameraCapture=resetInvCameraCapture}catch(_e){}
try{window.processInvCameraImage=processInvCameraImage}catch(_e){}
try{window.parseInvCameraText=parseInvCameraText}catch(_e){}
try{window.applyInvCameraRows=applyInvCameraRows}catch(_e){}

__nf.setEval(function(__code,event){return eval(__code)});
}};
DEFS["buyer"]={css:".nf-host{--green:#52b788;--red:#d64545;--line:#d6dde6;--txt:#1f2d3d;--muted:#6b7a8c}.nf-host *{box-sizing:border-box}.nf-host,.nf-host{margin:0;background:var(--bg);color:var(--txt);font-family:system-ui,-apple-system,\"Segoe UI\",Tahoma,Arial,sans-serif}.nf-host .container{max-width:760px;margin:10px auto;background:#fff;border-radius:18px;padding:18px 16px 22px;box-shadow:0 4px 16px rgba(20,40,70,.08)}.nf-host h1{font-size:19px;margin:6px 4px 12px;padding-bottom:12px;border-bottom:3px solid #e8edf4}.nf-host h2{font-size:16px;margin:16px 4px 10px}.nf-host .details{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}.nf-host label{display:block;font-size:13px;color:var(--muted);margin:0 2px 6px}.nf-host input{width:100%;height:44px;border:1px solid var(--line);border-radius:12px;padding:0 10px;font:inherit;font-size:15px;background:#fff;color:var(--txt)}.nf-host input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(42,111,176,.15)}.nf-host input[readonly]{background:#f2f5fa}.nf-host .tbl-wrap{overflow-x:auto;margin-top:16px}.nf-host table{width:100%;border-collapse:collapse;min-width:560px;border:1px solid #cfe3f5}.nf-host th{background:#e3f1fc;color:#1f5b8f;font-size:14px;padding:12px 6px;border:1px solid #cfe3f5}.nf-host td{padding:10px 6px;border:1px solid #e3e9f0;text-align:center}.nf-host td input{height:40px;border-radius:10px}.nf-host .del{width:36px;height:36px;border:1px solid #f1b8b8;background:#fbe3e3;color:var(--red);border-radius:9px;font-size:18px;font-weight:700;cursor:pointer}.nf-host .add{width:100%;margin-top:14px;height:48px;border:2px dashed #8fc4ea;background:#e3f1fc;color:#1f5b8f;border-radius:12px;font:inherit;font-weight:700;font-size:15px;cursor:pointer}.nf-host .nf-card{margin-top:18px;border:1px solid var(--line);background:#f9fafc;border-radius:14px;padding:12px 16px}.nf-host .nf-card h3{margin:4px 0 10px;padding-bottom:10px;border-bottom:1px solid var(--line);font-size:16px}.nf-host .line{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:10px 0}.nf-host .line span{font-size:15px;flex:1}.nf-host .line input{max-width:190px}.nf-host .net input{font-weight:800}.nf-host .net.neg input{color:var(--red)}.nf-host .btns{display:flex;gap:10px;margin-top:18px}.nf-host .btns button{height:50px;padding:0 22px;border:0;border-radius:11px;font:inherit;font-weight:700;font-size:15px;cursor:pointer}.nf-host .save{background:var(--green);color:#fff}.nf-host .prev{background:#e6e9f0;color:#2b3a4d}.nf-host .cancel{background:#fff;color:var(--muted);border:1px solid var(--line)!important}.nf-host .nf-toast{position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#243447;color:#fff;padding:11px 18px;border-radius:10px;font-size:14px;opacity:0;pointer-events:none;transition:opacity .25s;z-index:50}.nf-host .nf-toast.show{opacity:1}.nf-host #pv{display:none;position:fixed;inset:0;background:#fff;overflow:auto;z-index:40;padding:18px}.nf-host #pv.on{display:block}.nf-host #pv h2{text-align:center;font-size:20px}.nf-host #pv table{min-width:0}.nf-host #pv .meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin:10px 0;font-size:15px}.nf-host #pv .tot{margin-top:14px;font-size:16px;line-height:2}.nf-host #pv .acts{display:flex;gap:10px;margin-top:16px}@media(max-width:600px){.nf-host .details{grid-template-columns:1fr}.nf-host .btns button{flex:1;padding:0 8px}}@media print{.nf-host.printing .container,.nf-host.printing .nf-toast{display:none}.nf-host #pv .acts{display:none}}.nf-host.nf-native{--accent:var(--primary);--accent-light:var(--primary-light);--blue:var(--primary);--blue-dark:var(--primary-dark);--bg-soft:var(--bg2,var(--bg));--bg-card:var(--bg);--text-secondary:var(--text2,var(--text));--text-muted:var(--muted,#64748b);--border:var(--line,#e2e8f0);--border-light:var(--line,#e2e8f0);background:var(--bg);color:var(--text);font-family:var(--app-font,\"Tajawal\",sans-serif)}.nf-host.nf-native .nf-app{background:var(--bg);height:auto!important;max-height:none!important;overflow:visible!important;max-width:1100px}.nf-host.nf-native .nf-topbar{display:none!important}.nf-host.nf-native .nf-screen{animation:none!important}.nf-host.nf-native{min-height:100%;height:auto}",html:"<div class=\"container\" id=\"form\">\n <h1>بيانات فاتورة الشراء اليومية</h1>\n <h2>التفاصيل الأساسية</h2>\n <div class=\"details\">\n  <div><label>رقم الجدول</label><input id=\"tableNo\" inputmode=\"numeric\"></div>\n  <div><label>الاسم</label><input id=\"pname\"></div>\n  <div><label>التاريخ</label><input id=\"pdate\" type=\"date\"></div>\n </div>\n <div class=\"tbl-wrap\"><table>\n  <thead><tr><th>اسم الشروة</th><th style=\"width:80px\">العدد</th><th>مبلغ الشراء</th><th>إجمالي شراء الشروة</th><th style=\"width:60px\">حذف</th></tr></thead>\n  <tbody id=\"rows\"></tbody>\n </table></div>\n <button class=\"add\" type=\"button\" id=\"addRow\">+ إضافة صف جديد</button>\n <div class=\"nf-card\">\n  <h3>التفصيل النهائي</h3>\n  <div class=\"line\"><span>إجمالي شراء الشروات</span><input id=\"total\" readonly></div>\n  <div class=\"line\"><span>إجمالي الخرج اليومي</span><input id=\"expense\" inputmode=\"decimal\"></div>\n </div>\n <div class=\"btns\">\n  <button class=\"save\" type=\"button\" id=\"saveBtn\">حفظ البيانات ✓</button>\n  <button class=\"prev\" type=\"button\" id=\"prevBtn\">عرض المعاينة</button>\n  <button class=\"cancel\" type=\"button\" id=\"cancelBtn\">إلغاء</button>\n </div>\n</div>\n<div id=\"pv\"></div>\n<div class=\"nf-toast\" id=\"toast\"></div>",run:function(document,window,parent,setTimeout,clearTimeout,setInterval,clearInterval,__nf){

(function(){
 var $=function(i){return document.getElementById(i)};
 var ctx={}, num=function(v){var n=parseFloat(String(v==null?'':v).replace(/,/g,''));return isFinite(n)?n:0};
 var fmt=function(n){return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})};
 var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 var tt;function toast(m){var t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(tt);tt=setTimeout(function(){t.classList.remove('show')},2200)}
 var pad=function(n){return String(n).padStart(2,'0')};
 var iso=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
 var disp=function(s){var p=String(s||'').split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s};
 function rowHTML(r){r=r||{};return '<tr><td><input class="n" value="'+esc(r.name)+'"></td><td><input class="q" inputmode="decimal" value="'+esc(r.qty)+'"></td><td><input class="p" inputmode="decimal" value="'+esc(r.price)+'"></td><td><input class="t" readonly></td><td><button type="button" class="del">×</button></td></tr>'}
 function addRow(r,focus){$('rows').insertAdjacentHTML('beforeend',rowHTML(r));var rs=$('rows').querySelectorAll('tr');var tr=rs[rs.length-1];if(focus)tr.querySelector('.n').focus();recalc()}
 function compRow(tr){var q=tr.querySelector('.q').value.trim(),p=tr.querySelector('.p').value.trim(),t=tr.querySelector('.t');if(q===''||p===''){t.value='';return 0}var v=num(q)*num(p);t.value=fmt(v);return v}
 function recalc(){var s=0;Array.prototype.forEach.call($('rows').querySelectorAll('tr'),function(tr){s+=compRow(tr)});$('total').value=fmt(s);var n=s-num($('expense').value);return {total:s,net:n}}
 function collect(){var rows=[];Array.prototype.forEach.call($('rows').querySelectorAll('tr'),function(tr){var n=tr.querySelector('.n').value.trim(),q=tr.querySelector('.q').value.trim(),p=tr.querySelector('.p').value.trim();if(!n&&!q&&!p)return;rows.push({name:n,qty:q,price:p,total:num(q)*num(p)})});var r=recalc();return {tableNo:$('tableNo').value.trim(),name:$('pname').value.trim(),dateISO:$('pdate').value,rows:rows,total:r.total,expense:num($('expense').value),net:r.net}}
 $('rows').addEventListener('input',recalc);
 $('expense').addEventListener('input',recalc);
 $('rows').addEventListener('click',function(e){var b=e.target.closest('.del');if(!b)return;var tr=b.closest('tr');var rs=$('rows').querySelectorAll('tr');if(rs.length>1)tr.remove();else Array.prototype.forEach.call(tr.querySelectorAll('input'),function(i){i.value=''});recalc()});
 $('addRow').addEventListener('click',function(){addRow(null,true)});
 $('cancelBtn').addEventListener('click',function(){parent.postMessage({type:'INVOICE_CANCEL'},'*')});
 $('saveBtn').addEventListener('click',function(){
  var d=collect();
  if(!d.name){toast('أدخل الاسم');return}
  if(!d.dateISO){toast('أدخل التاريخ');return}
  if((ctx.startDate&&d.dateISO<ctx.startDate)||(ctx.endDate&&d.dateISO>ctx.endDate)){toast('التاريخ يجب أن يكون ضمن الأسبوع: من '+disp(ctx.startDate)+' إلى '+disp(ctx.endDate));return}
  if((ctx.takenDates||[]).indexOf(d.dateISO)>=0){toast('يوجد فاتورة أخرى بنفس هذا التاريخ في هذا الأسبوع');return}
  if(!d.rows.length&&!d.expense){toast('لا توجد بيانات للحفظ');return}
  parent.postMessage({type:'INVOICE_SAVE',payload:{invoiceKind:'buyer',initNo:d.tableNo,initSeller:d.name,initDate:disp(d.dateISO),initDateISO:d.dateISO,invoiceDateISO:d.dateISO,buyerRows:d.rows,buyerTotal:d.total,buyerExpense:d.expense,buyerNet:d.net,amount:d.net}},'*');
 });
 $('prevBtn').addEventListener('click',function(){
  var d=collect();
  var body=d.rows.map(function(r){return '<tr><td>'+esc(r.name)+'</td><td>'+esc(r.qty)+'</td><td>'+fmt(num(r.price))+'</td><td>'+fmt(r.total)+'</td></tr>'}).join('');
  $('pv').innerHTML='<h2>فاتورة الشراء اليومية</h2><div class="meta"><span>رقم الجدول: '+esc(d.tableNo)+'</span><span>الاسم: '+esc(d.name)+'</span><span>التاريخ: '+esc(disp(d.dateISO))+'</span></div><table><thead><tr><th>اسم الشروة</th><th>العدد</th><th>مبلغ الشراء</th><th>الإجمالي</th></tr></thead><tbody>'+body+'</tbody></table><div class="tot">إجمالي الشراء: <b>'+fmt(d.total)+'</b><br>الخرج اليومي: <b>'+fmt(d.expense)+'</b><br>الصافي: <b style="color:'+(d.net<0?'#d64545':'#1f2d3d')+'">'+fmt(d.net)+'</b></div><div class="acts"><button class="save" type="button" id="pvPrint">🖨 طباعة</button><button class="prev" type="button" id="pvClose">رجوع</button></div>';
  $('pv').classList.add('on');
  $('pvClose').onclick=function(){$('pv').classList.remove('on')};
  $('pvPrint').onclick=function(){
   try{
    var c=$('pv').cloneNode(true);
    ['.acts','h2'].forEach(function(s){var n=c.querySelector(s);if(n)n.remove()});
    if(parent&&typeof parent.__buyerPrintDoc==='function'){
     parent.__buyerPrintDoc('فاتورة الشراء اليومية',c.innerHTML,'.meta{display:flex;justify-content:space-between;gap:8px;margin:10px 0;font-weight:700}.tot{margin-top:12px;line-height:2;font-weight:700}');
     return;
    }
   }catch(e){}
   document.body.classList.add('printing');try{window.print()}catch(e){}setTimeout(function(){document.body.classList.remove('printing')},500)
  };
 });
 function setDate(){
  var inp=$('pdate');if(ctx.startDate)inp.min=ctx.startDate;if(ctx.endDate)inp.max=ctx.endDate;
  if(inp.value)return;
  // اليوم التالي لآخر فاتورة في الأسبوع، وإن لم توجد فأول يوم فيه؛ يتخطى الأيام المشغولة
  var taken=ctx.takenDates||[],from=ctx.startDate||'',to=ctx.endDate||'',s,n;
  var inRange=function(x){return (!from||x>=from)&&(!to||x<=to)};
  var free=function(x){return inRange(x)&&taken.indexOf(x)<0};
  var addDay=function(x){var d=new Date(x+'T12:00:00');d.setDate(d.getDate()+1);return iso(d)};
  var inWeek=taken.filter(inRange).sort();
  s=inWeek.length?addDay(inWeek[inWeek.length-1]):from;
  if(s){for(n=0;n<400&&(!to||s<=to);s=addDay(s),n++){if(free(s)){inp.value=s;return}}}
  if(from&&to){for(s=from,n=0;n<400&&s<=to;s=addDay(s),n++){if(free(s)){inp.value=s;return}}}
  inp.value=iso(new Date());
 }
 window.addEventListener('message',function(e){
  var m=e.data||{};
  if(m.type==='INVOICE_WEEK_CONTEXT'){ctx=m.context||{};if(!$('tableNo').value)$('tableNo').value=ctx.tableNo||'';if(!$('pname').value)$('pname').value=ctx.seller||'';$('pdate').value='';setDate()}
  else if(m.type==='LOAD_INVOICE'&&m.payload){var p=m.payload;$('tableNo').value=p.initNo||'';$('pname').value=p.initSeller||'';$('pdate').value=p.initDateISO||'';$('rows').innerHTML='';(p.buyerRows&&p.buyerRows.length?p.buyerRows:[null]).forEach(function(r){addRow(r,false)});$('expense').value=p.buyerExpense||'';recalc()}
 });
 addRow(null,false);setDate();recalc();
})();

/* exports: global functions of the former iframe page */

__nf.setEval(function(__code,event){return eval(__code)});
}};
DEFS["detail"]={css:".nf-host 500;700;800;900&display=swap');\n  *{ box-sizing: border-box; margin: 0; padding: 0; }.nf-host{\n      \n    --accent: #B71C3D; --accent-light: #FAD4E0; --gold: #D4AF37; --gold-dark: #B8860B;\n     --bg-soft: #F5F0F1; --bg-card: #FFFFFF;\n     --text-secondary: #7B6B6B; --text-muted: #9E8E8E;\n    --border: #E8D8DD; --border-light: #F5EBEE;\n    --shadow-sm: 0 1px 3px rgba(107,26,47,0.06);\n    --shadow: 0 4px 20px rgba(107,26,47,0.10);\n    --shadow-lg: 0 8px 32px rgba(107,26,47,0.14);\n    --radius-sm: 10px; --radius: 16px; --radius-lg: 24px;\n  }.nf-host{\n    font-family: 'Tajawal', 'Segoe UI', sans-serif;\n    background: #2D2D2D; color: var(--text); direction: rtl;\n    font-weight: 500; line-height: 1.6; -webkit-font-smoothing: antialiased;\n  }.nf-host .nf-app{\n    max-width: 720px; margin: 0 auto; position: relative;\n    min-height: 100%; padding-bottom: 24px;\n    background: var(--bg); box-shadow: var(--shadow-lg);\n  }.nf-host .nf-topbar{\n    display: flex; align-items: center; justify-content: space-between;\n    padding: 16px 20px;\n    background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);\n    border-radius: 0 0 var(--radius-lg) var(--radius-lg);\n    margin-bottom: 16px; box-shadow: var(--shadow);\n    position: sticky; top: 0; z-index: 30;\n  }.nf-host .nf-topbar .title{\n    font-size: 20px; font-weight: 900; color: #fff;\n    letter-spacing: 0.5px; flex: 1; text-align: center;\n  }.nf-host .nf-topbar button{\n    background: rgba(255,255,255,0.15); backdrop-filter: blur(10px);\n    border: 1px solid rgba(255,255,255,0.2); cursor: pointer; color: #fff;\n    font-size: 13px; font-weight: 700; padding: 8px 14px;\n    border-radius: var(--radius-sm); display: flex; align-items: center;\n    gap: 6px; transition: all 0.2s ease;\n  }.nf-host .nf-topbar button:hover{ background: rgba(255,255,255,0.25); transform: translateY(-1px); }.nf-host .topbar-side{ display: flex; align-items: center; gap: 7px; min-width: 86px; }.nf-host .top-icon{\n    width: 40px !important; height: 40px !important;\n    padding: 0 !important; border-radius: 50% !important;\n    display: grid !important; place-items: center !important;\n    font-size: 18px !important; background: rgba(255,255,255,.14) !important;\n  }.nf-host .nf-screen{ display: none; padding: 16px 20px; animation: nfd-fadeIn 0.3s ease; }.nf-host .nf-screen.active{ display: block; }@keyframes nfd-fadeIn{\n    from { opacity: 0; transform: translateY(8px); }\n    to { opacity: 1; transform: translateY(0); }\n  }.nf-host .form-group{ margin-bottom: 18px; }.nf-host .form-group label{\n    display: block; font-size: 14px; margin-bottom: 8px;\n    color: var(--text-secondary); font-weight: 700;\n  }.nf-host .form-group input,.nf-host .form-group select{\n    width: 100%; padding: 14px 16px; border: 2px solid var(--border);\n    border-radius: var(--radius-sm); font-size: 15px; background: var(--bg);\n    font-weight: 600; color: var(--text); transition: all 0.2s ease;\n    font-family: 'Tajawal', sans-serif;\n  }.nf-host .form-group input:focus,.nf-host .form-group select:focus{\n    outline: none; border-color: var(--primary-light);\n    box-shadow: 0 0 0 4px rgba(107,26,47,0.08);\n  }.nf-host .nf-btn{\n    padding: 12px 20px; border-radius: var(--radius-sm); border: none;\n    font-size: 15px; cursor: pointer; font-weight: 800; transition: all 0.2s ease;\n    font-family: 'Tajawal', sans-serif; display: inline-flex; align-items: center;\n    justify-content: center; gap: 6px;\n  }.nf-host .nf-btn:active{ transform: scale(0.97); }.nf-host .nf-btn-primary{\n    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);\n    color: #fff; box-shadow: 0 4px 16px rgba(107,26,47,0.3);\n  }.nf-host .nf-btn-primary:hover{ box-shadow: 0 6px 24px rgba(107,26,47,0.4); transform: translateY(-1px); }.nf-host .btn-secondary{ background: #FFFFFF; color: var(--primary); border: 2px solid var(--primary); }.nf-host .btn-secondary:hover{ background: var(--primary-light); }.nf-host .new-sale-form{ font-family: 'Tajawal', sans-serif; color: var(--text); }.nf-host .new-sale-form .nf-toolbar{\n    display: flex; gap: 8px; justify-content: center;\n    margin-bottom: 14px; flex-wrap: wrap;\n  }.nf-host .new-sale-form .nf-toolbar button{\n    font: inherit; padding: 7px 14px; border: 1px solid var(--border);\n    border-radius: 8px; background: #fff; cursor: pointer;\n    transition: .15s; color: var(--text); font-weight: 700; font-size: 13px;\n  }.nf-host .new-sale-form .nf-toolbar button:hover{ background: var(--primary-light); border-color: var(--primary); }.nf-host .new-sale-form .nf-toolbar button.on{ background: var(--primary); color: #fff; border-color: var(--primary); }.nf-host .new-sale-form table{\n    width: 100%; border-collapse: collapse; background: #fff;\n    table-layout: fixed; margin: 0;\n  }.nf-host .new-sale-form th,.nf-host .new-sale-form td{\n    border: 1px solid var(--border); padding: 3px 5px;\n    text-align: center; vertical-align: middle;\n    font-size: 13px; font-weight: 600;\n  }.nf-host .new-sale-form th{\n    background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);\n    color: #fff; font-weight: 800; font-size: 12px; padding: 8px 4px;\n    border: none; border-right: 1px solid rgba(255,255,255,0.15);\n  }.nf-host .new-sale-form th:last-child{ border-right: none; }.nf-host .new-sale-form input,.nf-host .new-sale-form textarea{\n    width: 100%; border: 0; background: transparent; font: inherit;\n    text-align: center; padding: 4px 2px; outline: none;\n    color: var(--text); font-weight: 700;\n  }.nf-host .new-sale-form input:focus,.nf-host .new-sale-form textarea:focus{\n    background: #fffbe0; border-radius: 3px;\n  }.nf-host .new-sale-form input[type=number]::-webkit-outer-spin-button,.nf-host .new-sale-form input[type=number]::-webkit-inner-spin-button{\n    -webkit-appearance: none; margin: 0;\n  }.nf-host .new-sale-form input[type=number]{ -moz-appearance: textfield; }.nf-host .new-sale-form input[inputmode=\"decimal\"],.nf-host .new-sale-form input[inputmode=\"numeric\"]{\n    direction: ltr; unicode-bidi: plaintext;\n    font-family: \"Segoe UI\", Tahoma, Arial, sans-serif; letter-spacing: .4px;\n  }.nf-host .new-sale-form td.calc{ background: var(--primary-light); font-weight: 700; padding: 0; }.nf-host .new-sale-form td.calc input{ font-weight: 700; color: var(--primary-dark); cursor: default; }.nf-host.edit-mode .new-sale-form td.calc,.nf-host .new-sale-form.edit-mode td.calc{ background: #FFF3C4; }.nf-host.edit-mode .new-sale-form td.calc input,.nf-host .new-sale-form.edit-mode td.calc input{ cursor: text; }.nf-host .new-sale-form td.calc input.manual{\n    color: #8a4b00; background: #ffe8b0; border-radius: 3px; font-style: italic;\n  }.nf-host .new-sale-form td.calc.bad{ background: #ffdede; }.nf-host .new-sale-form td.calc.bad input{ color: #b00000; }.nf-host.edit-mode .new-sale-form td.calc.bad{ background: #ffd0d0; }.nf-host .new-sale-form .grid{ display: grid; grid-template-columns: 1fr 1.35fr; gap: 10px; margin-top: 10px; }.nf-host .new-sale-form .stack{ display: flex; flex-direction: column; gap: 10px; }.nf-host .new-sale-form .two{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }.nf-host .new-sale-form .mt{ margin-top: 10px; }.nf-host .new-sale-form .debt-table th{ font-size: 11px; padding: 7px 2px; line-height: 1.3; }.nf-host .new-sale-form .debt-table td input{ font-size: 12px; padding: 4px 1px; }.nf-host .new-sale-form .debt-table td.calc input.rest{ color: var(--primary-dark); }.nf-host .new-sale-form .debt-table td.calc input.rest.neg{ color: #b00000; }.nf-host .new-sale-form .nf-del{ width: 34px; padding: 0; }.nf-host .new-sale-form .nf-del button{\n    border: 0; background: transparent; color: #b00;\n    cursor: pointer; font-size: 15px; width: 100%; padding: 4px 0;\n  }.nf-host .new-sale-form .nf-del button:hover{ background: #ffd0d0; }.nf-host .new-sale-form .add{\n    width: 22px; height: 22px; line-height: 1; padding: 0; margin: 0 6px;\n    border: 1px solid var(--primary); border-radius: 50%; background: #fff;\n    cursor: pointer; font-weight: 700; font-size: 14px; color: var(--primary);\n  }.nf-host .new-sale-form .add:hover{ background: var(--primary); color: #fff; }.nf-host .new-sale-form .note-box{\n    min-height: 75px; text-align: right; padding: 6px;\n    resize: vertical; background: #fff;\n  }.nf-host .new-sale-form .hint{ font-size: 12px; color: var(--text-muted); margin: 4px 3px; font-weight: 600; }.nf-host .new-sale-form .status{\n    text-align: center; font-size: 12px; color: var(--text-muted);\n    margin: 6px 0; min-height: 16px;\n  }.nf-host .new-sale-form #moneyTable th:nth-child(1){ width: 34% }.nf-host .new-sale-form #moneyTable th:nth-child(2){ width: 33% }.nf-host .new-sale-form #moneyTable th:nth-child(3){ width: 33% }.nf-host .new-sale-form #moneyTable th:last-child{ width: 34px }.nf-host .new-sale-form .fixed-row th{\n    background: var(--primary-light) !important; color: var(--primary-dark) !important;\n    font-weight: 800 !important;\n  }.nf-host .new-sale-form .footer-bar{\n    display: flex; gap: 12px; justify-content: center;\n    margin-top: 18px; padding: 14px; background: #fff;\n    border: 2px solid var(--border); border-radius: 10px; flex-wrap: wrap;\n  }.nf-host .new-sale-form .footer-bar button{\n    font: inherit; font-size: 17px; font-weight: 700;\n    padding: 12px 44px; border: 2px solid var(--primary);\n    border-radius: 10px; cursor: pointer; transition: .15s; min-width: 170px;\n  }.nf-host .new-sale-form .btn-save{\n    background: linear-gradient(135deg, #43A047 0%, #2E7D32 100%);\n    color: #fff; border-color: #2E7D32;\n  }.nf-host .new-sale-form .btn-save:hover{ background: linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%); }.nf-host .new-sale-form .btn-cancel{ background: #fff; color: var(--primary); }.nf-host .new-sale-form .btn-cancel:hover{ background: var(--primary-light); }.nf-host .new-sale-form .saved-badge{\n    display: inline-block; background: #1f9d3d; color: #fff;\n    font-size: 12px; padding: 2px 10px; border-radius: 12px;\n    margin-inline-start: 8px; opacity: 0; transition: .3s;\n  }.nf-host .new-sale-form .saved-badge.show{ opacity: 1; }@media (max-width: 820px){.nf-host .new-sale-form .grid{ grid-template-columns: 1fr }.nf-host .new-sale-form .two{ grid-template-columns: 1fr }.nf-host .new-sale-form .footer-bar button{ min-width: 130px; padding: 10px 24px }}@media (max-width: 480px){.nf-host .nf-app{ max-width: 100%; box-shadow: none; }.nf-host .nf-topbar{ padding: 12px 14px; }.nf-host .nf-topbar .title{ font-size: 16px; }.nf-host .nf-screen{ padding: 12px 14px; }.nf-host .form-group input,.nf-host .form-group select{ padding: 12px 14px; font-size: 14px; }.nf-host .top-icon{ width: 36px !important; height: 36px !important; font-size: 16px !important; }}.nf-host .nf-topbar{display:none!important}.nf-host.nf-native{--accent:var(--primary);--accent-light:var(--primary-light);--blue:var(--primary);--blue-dark:var(--primary-dark);--bg-soft:var(--bg2,var(--bg));--bg-card:var(--bg);--text-secondary:var(--text2,var(--text));--text-muted:var(--muted,#64748b);--border:var(--line,#e2e8f0);--border-light:var(--line,#e2e8f0);background:var(--bg);color:var(--text);font-family:var(--app-font,\"Tajawal\",sans-serif)}.nf-host.nf-native .nf-app{background:var(--bg);height:auto!important;max-height:none!important;overflow:visible!important;max-width:1100px}.nf-host.nf-native .nf-topbar{display:none!important}.nf-host.nf-native .nf-screen{animation:none!important}.nf-host.nf-native{min-height:100%;height:auto}",html:"<div class=\"nf-app\">\n\n  <!-- TOP BAR -->\n  <div class=\"nf-topbar\">\n    <div class=\"topbar-side\">\n      <button id=\"top-back-btn\" class=\"top-icon\" type=\"button\" data-nf-onclick=\"topBarBack()\" title=\"رجوع\" style=\"display:none\">↩️</button>\n    </div>\n    <div class=\"title\">«التفصيل»</div>\n    <div class=\"topbar-side\">\n      <button class=\"top-icon\" type=\"button\" data-nf-onclick=\"handleFab()\" title=\"تفصيل جديد\">＋</button>\n    </div>\n  </div>\n\n  <!-- SCREEN: INVOICE INIT -->\n  <div class=\"nf-screen active\" id=\"screen-invoice-init\">\n    <h2 style=\"text-align:center;margin-bottom:16px;font-size:20px;font-weight:900;\">بيانات التفصيل الجديد</h2>\n    <section id=\"saved-details-panel\" style=\"margin:0 0 18px;padding:12px;border:1px solid var(--border);border-radius:12px;background:var(--bg-soft,#f7f7f7);\">\n      <h3 style=\"margin:0 0 10px;font-size:16px;\">📂 معاملات التفصيل المحفوظة</h3>\n      <div id=\"saved-details-list\"></div>\n    </section>\n\n    <div class=\"form-group\">\n      <label>📅 التاريخ من</label>\n      <input type=\"date\" id=\"init-date-from\" data-nf-onchange=\"updateInitDateText()\">\n    </div>\n\n    <div class=\"form-group\">\n      <label>📅 التاريخ إلى</label>\n      <input type=\"date\" id=\"init-date-to\" data-nf-onchange=\"updateInitDateText()\">\n    </div>\n\n    <div id=\"init-date-text\" style=\"font-size:13px;color:var(--primary);margin:-8px 0 16px;text-align:center;font-weight:800;\"></div>\n\n    <div class=\"form-group\">\n      <label>👤 اسم التفصيل</label>\n      <input type=\"text\" id=\"init-detail\" placeholder=\"أدخل اسم التفصيل\">\n    </div>\n\n    <div class=\"form-group\">\n      <label>🗓️ اسم الفلتر الأسبوعي</label>\n      <select id=\"init-filter\" aria-label=\"الفلتر الأسبوعي\">\n        <option value=\"\">الفلتر الأسبوعي [اختار الفلتر]</option>\n      </select>\n    </div>\n\n    <div class=\"form-group\">\n      <label>🔢 رقم الجدول</label>\n      <input type=\"text\" id=\"init-no\" placeholder=\"أدخل رقم الجدول\" data-nf-oninput=\"blockArabicNums(this)\">\n    </div>\n\n    <div style=\"display:flex;gap:10px;margin-top:20px;flex-wrap:wrap;\">\n      <button class=\"nf-btn nf-btn-primary\" style=\"flex:1;min-width:160px;padding:14px;font-size:16px;\" data-nf-onclick=\"proceedToForm()\">✅ حفظ وفتح الجدول</button>\n      <button class=\"nf-btn btn-secondary\" style=\"flex:1;min-width:120px;\" data-nf-onclick=\"resetInitForm()\">🔄 جديد</button>\n    </div>\n  </div>\n\n  <!-- SCREEN: ADD INVOICE -->\n  <div class=\"nf-screen\" id=\"screen-add\">\n    <div class=\"new-sale-form\" id=\"new-sale-form-container\">\n      <div class=\"nf-toolbar\">\n        <button type=\"button\" id=\"editBtn\" data-nf-onclick=\"toggleEdit()\">🔓 تعديل أي بيانات</button>\n        <button type=\"button\" data-nf-onclick=\"newSheet()\">🆕 جديد</button>\n        <button type=\"button\" data-nf-onclick=\"clearManual()\">↩️ إلغاء التعديل اليدوي</button>\n      </div>\n      <div class=\"status\" id=\"status\"></div>\n\n      <!-- HEADER: يظهر فقط اسم التفصيل + التاريخ من/إلى -->\n      <table>\n        <colgroup><col style=\"width:33.33%\"><col style=\"width:33.33%\"><col style=\"width:33.34%\"></colgroup>\n        <tr><th>اسم التفصيل</th><th>التاريخ من</th><th>التاريخ إلى</th></tr>\n        <tr>\n          <td><input id=\"hDetail\"   type=\"text\"></td>\n          <td><input id=\"hDateFrom\" type=\"text\"></td>\n          <td><input id=\"hDateTo\"   type=\"text\"></td>\n        </tr>\n      </table>\n\n      <div class=\"grid\">\n        <table>\n          <colgroup><col style=\"width:55%\"><col style=\"width:45%\"></colgroup>\n          <tr><th colspan=\"2\">عمود الكمية</th></tr>\n          <tr><th>الكمية</th><td><input id=\"qQty\"  type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n          <tr><th>النقد</th> <td><input id=\"qCash\" type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n          <tr><th>الدين</th> <td><input id=\"qDebt\" type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n          <tr><th>الخرج</th> <td><input id=\"qOut\"  type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n          <tr><th>الباقي</th>\n              <td class=\"calc\" id=\"qRestCell\"><input id=\"qRest\" type=\"text\" inputmode=\"decimal\" readonly></td></tr>\n        </table>\n        <div class=\"hint\">الباقي = الكمية − النقد − الدين − الخرج</div>\n\n        <div class=\"stack\">\n          <table>\n            <colgroup><col style=\"width:55%\"><col style=\"width:45%\"></colgroup>\n            <tr><th colspan=\"2\">البيع (تقسيم)</th></tr>\n            <tr><th>جملة نقد البيع</th>   <td><input id=\"sSale\"       type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n            <tr><th>+ مسلم أسبوع</th>       <td><input id=\"sWeekly\"     type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n            <tr><th>خرج العمال</th>        <td><input id=\"sPrivateOut\" type=\"number\" inputmode=\"decimal\" step=\"any\"></td></tr>\n            <tr><th>باقي النقد</th>        <td class=\"calc\"><input id=\"sCashRest\" type=\"text\" inputmode=\"decimal\" readonly></td></tr>\n            <tr><th>جملة بيع الدين</th>    <td class=\"calc\"><input id=\"sDebtSale\" type=\"text\" inputmode=\"decimal\" readonly></td></tr>\n            <tr><th>جملة البيع النهائية</th><td class=\"calc\"><input id=\"sGrand\" type=\"text\" inputmode=\"decimal\" readonly></td></tr>\n          </table>\n\n          <div class=\"stack\">\n            <table>\n              <colgroup><col><col style=\"width:32%\"><col style=\"width:32px\"></colgroup>\n              <tr><th colspan=\"3\">مسلم فلوس <button type=\"button\" class=\"add\" data-nf-onclick=\"addRow('prevBody')\">+</button></th></tr>\n              <tr><th>الاسم</th><th>المبلغ</th><th class=\"nf-del\"></th></tr>\n              <tbody id=\"prevBody\"></tbody>\n              <tr><th>المجموع</th><td class=\"calc\"><input id=\"prevTotal\" type=\"text\" inputmode=\"decimal\" readonly></td><td class=\"nf-del\"></td></tr>\n            </table>\n\n            <table class=\"debt-table\">\n              <colgroup><col style=\"width:27%\"><col style=\"width:14%\"><col style=\"width:20%\"><col style=\"width:19%\"><col style=\"width:20%\"><col style=\"width:34px\"></colgroup>\n              <tr><th colspan=\"6\">بيع الدين <button type=\"button\" class=\"add\" id=\"debtAddBtn\" data-nf-onclick=\"addDebtRow()\">+</button></th></tr>\n              <tr><th>الاسم</th><th>الكمية</th><th>المبلغ</th><th>مسلم أسبوع</th><th>مبلغ الدين الباقي</th><th class=\"nf-del\"></th></tr>\n              <tbody id=\"debtBody\"></tbody>\n              <tr><th colspan=\"4\">المجموع</th><td class=\"calc\"><input id=\"debtTotal\" type=\"text\" inputmode=\"decimal\" readonly></td><td class=\"nf-del\"></td></tr>\n            </table>\n          </div>\n        </div>\n      </div>\n\n      <table class=\"mt\">\n        <colgroup><col style=\"width:25%\"><col style=\"width:25%\"><col style=\"width:25%\"><col style=\"width:25%\"></colgroup>\n        <tr><th colspan=\"4\">تجميع البيع</th></tr>\n        <tr><th>باقي النقد</th><th>مسلم فلوس</th><th>خرج العمال</th><th>الجملة</th></tr>\n        <tr>\n          <td class=\"calc\"><input id=\"midCashRest\" type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"calc\"><input id=\"midPrev\"     type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"calc\"><input id=\"midPrivate\"  type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"calc\"><input id=\"midTotal\"    type=\"text\" inputmode=\"decimal\" readonly></td>\n        </tr>\n      </table>\n      <div class=\"hint\">الجملة = باقي النقد + مسلم فلوس + خرج العمال</div>\n\n      <table class=\"mt\" id=\"moneyTable\">\n        <colgroup>\n          <col style=\"width:34%\"><col style=\"width:33%\"><col style=\"width:33%\"><col style=\"width:34px\">\n        </colgroup>\n        <tr>\n          <th colspan=\"4\">\n            العملات\n            <button type=\"button\" class=\"add\" data-nf-onclick=\"addMoneyRow()\" title=\"إضافة عملة\">+</button>\n          </th>\n        </tr>\n        <tr>\n          <th>العملة</th><th>مبلغ العملة</th><th>مبلغ صرف العملة</th><th class=\"nf-del\"></th>\n        </tr>\n        <tbody id=\"moneyBody\"></tbody>\n        <tr class=\"fixed-row\">\n          <th>السحب فلوس</th>\n          <td><input id=\"wNote\" type=\"text\" placeholder=\"ملاحظة\"></td>\n          <td><input id=\"wValue\" type=\"number\" inputmode=\"decimal\" step=\"any\"></td>\n          <td class=\"nf-del\"></td>\n        </tr>\n        <tr>\n          <th colspan=\"2\">جملة مبلغ صرف</th>\n          <td class=\"calc\" id=\"mTotalCell\"><input id=\"mTotal\" type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"nf-del\"></td>\n        </tr>\n      </table>\n      <div class=\"hint\">جملة مبلغ صرف = مجموع مبالغ صرف العملات + قيمة السحب فلوس</div>\n\n      <table class=\"mt\">\n        <colgroup><col><col><col></colgroup>\n        <tr><th>الجملة المطلوبة (تجميع البيع)</th><th>مجموع العملات</th><th>الفرق</th></tr>\n        <tr>\n          <td class=\"calc\"><input id=\"chkRequired\" type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"calc\"><input id=\"chkMoney\"    type=\"text\" inputmode=\"decimal\" readonly></td>\n          <td class=\"calc\" id=\"chkDiffCell\"><input id=\"chkDiff\" type=\"text\" inputmode=\"decimal\" readonly></td>\n        </tr>\n      </table>\n\n      <table class=\"mt\">\n        <tr><th>ملاحظة عامة</th></tr>\n        <tr><td><textarea id=\"note\" class=\"note-box\"></textarea></td></tr>\n      </table>\n\n      <div class=\"footer-bar\">\n        <button type=\"button\" class=\"btn-save\"   data-nf-onclick=\"saveInvoiceNow()\">💾 حفظ التفصيل</button>\n        <button type=\"button\" class=\"btn-cancel\" data-nf-onclick=\"cancelInvoiceForm()\">✖ إلغاء</button>\n        <span class=\"saved-badge\" id=\"savedBadge\">✓ تم الحفظ</span>\n      </div>\n    </div>\n  </div>\n\n</div>",run:function(document,window,parent,setTimeout,clearTimeout,setInterval,clearInterval,__nf){

/* ═══════════════════════════════════════════════════
   المتغيرات العامة
   ═══════════════════════════════════════════════════ */
let accounts = [];
let currentAccountId = null;
let editingInvoiceId = null;
const currencies = ['يمني', 'سعودي', 'عماني', 'درهم'];

const STORAGE_KEY  = 'sale_app_data_v2';
const DRAFT_KEY    = 'sale_app_draft_v2';

/* ═══════════════════════════════════════════════════
   أدوات مساعدة
   ═══════════════════════════════════════════════════ */
const AR_TO_EN = { '\u0660':'0','\u0661':'1','\u0662':'2','\u0663':'3','\u0664':'4','\u0665':'5','\u0666':'6','\u0667':'7','\u0668':'8','\u0669':'9','\u06f0':'0','\u06f1':'1','\u06f2':'2','\u06f3':'3','\u06f4':'4','\u06f5':'5','\u06f6':'6','\u06f7':'7','\u06f8':'8','\u06f9':'9' };
function toEnDigits(str) { return String(str).replace(/[\u0660-\u0669\u06f0-\u06f9]/g, ch => AR_TO_EN[ch] || ch); }
function hasArabicDigits(str) { return /[\u0660-\u0669\u06f0-\u06f9]/.test(str); }
function blockArabicNums(el) { el.value = toEnDigits(el.value); }
function fmt(n) {
  if (n === 0 || n === '' || n === null || n === undefined) return '0';
  const num = typeof n === 'number' ? n : parseFloat(n);
  if (isNaN(num)) return '0';
  return toEnDigits(num.toLocaleString('en-US', { maximumFractionDigits: 3 }));
}
const $ = id => document.getElementById(id);
const numOf = el => {
  if (!el) return 0;
  const v = parseFloat(toEnDigits(el.value).replace(/,/g, '').trim());
  return isNaN(v) ? 0 : v;
};
const val = id => numOf($(id));
const localFmt = v => {
  const r = Math.round(v * 100) / 100;
  return r.toLocaleString('en-US', { maximumFractionDigits: 2, useGrouping: false });
};

const CALC_IDS = ['qRest','sCashRest','sDebtSale','sGrand','prevTotal','debtTotal',
                  'midTotal','midPrivate','midPrev','midCashRest','mTotal',
                  'chkRequired','chkMoney','chkDiff'];
let editMode = false;
const overrides = new Set();

/* ═══════════════════════════════════════════════════
   التخزين
   ═══════════════════════════════════════════════════ */
function saveData() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts)); } catch (e) { console.error(e); }
}
function loadData() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) { accounts = JSON.parse(data); if (!Array.isArray(accounts)) accounts = []; }
  } catch (e) { accounts = []; }
}
function saveState() {
  try { localStorage.setItem(DRAFT_KEY, JSON.stringify(collectData())); } catch (e) {}
}

/* ═══════════════════════════════════════════════════
   التنقل
   ═══════════════════════════════════════════════════ */
function updateTopBarNavigation(screenId) {
  const back = document.getElementById('top-back-btn');
  if (!back) return;
  back.style.display = (screenId === 'screen-add') ? 'grid' : 'none';
}
function showScreen(id) {
  document.querySelectorAll('.nf-screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(id);
  if (!target) return;
  target.classList.add('active');
  updateTopBarNavigation(id);
}
function topBarBack() {
  const active = document.querySelector('.nf-screen.active');
  const id = active ? active.id : 'screen-invoice-init';
  if (id === 'screen-add') { showScreen('screen-invoice-init'); return; }
  showScreen('screen-invoice-init');
}
function goHome() { resetInitForm(); renderSavedDetails(); showScreen('screen-invoice-init'); }
function populateWeeklyFilterOptions(selectedName = '') {
  const select = $('init-filter');
  if (!select) return;
  let filters = [];
  try {
    filters = JSON.parse(localStorage.getItem('smartadmin_weekly_filters_v1') || '[]');
    if (!Array.isArray(filters)) filters = [];
  } catch (_) { filters = []; }
  const names = [...new Set(filters.filter(f => f && f.name).map(f => String(f.name).trim()).filter(Boolean))];
  select.innerHTML = '<option value="">الفلتر الأسبوعي [اختار الفلتر]</option>' +
    names.map(name => '<option value="' + name.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') + '">' + name.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</option>').join('');
  if (selectedName && names.includes(selectedName)) select.value = selectedName;
}

function populateWeeklyFilterOptions(selectedName='') {
  const sel = $('init-filter'); if (!sel) return;
  let filters=[]; try { filters=JSON.parse(localStorage.getItem('smartadmin_weekly_filters_v1')||'[]'); } catch(e) { filters=[]; }
  sel.innerHTML='<option value="">الفلتر الأسبوعي [اختار الفلتر]</option>';
  filters.filter(f=>f&&f.name).forEach(f=>{ const o=document.createElement('option'); o.value=f.name; o.textContent=f.name; if(f.name===selectedName)o.selected=true; sel.appendChild(o); });
}
function getWeeklyFilterByName(name) {
  try { return (JSON.parse(localStorage.getItem('smartadmin_weekly_filters_v1')||'[]')||[]).find(f=>f&&String(f.name)===String(name))||null; } catch(e) { return null; }
}
function weeklyNum(v){ const n=parseFloat(String(v??'').replace(/,/g,'')); return Number.isFinite(n)?n:0; }
function applyWeeklyFilterTotals(name) {
  const f=getWeeklyFilterByName(name); if(!f) return false;
  const r2=n=>Math.round(n*1000)/1000;
  const sum=(rows,key)=>Array.isArray(rows)?r2(rows.reduce((t,r)=>t+weeklyNum(r&&r[key]),0)):0;
  const q=f.qtyRows||[], sales=f.salesRows||[], money=f.moneyRows||[];
  // عمود الكمية: شريط الجملة -> الكمية / النقد / الدين / الخرج (الباقي يُحسب داخل التفصيل)
  $('qQty').value=String(sum(q,'qty')); $('qCash').value=String(sum(q,'cash')); $('qDebt').value=String(sum(q,'debt')); $('qOut').value=String(sum(q,'expense'));
  // التجميل النهائي: إجمالي نقد الباقي -> جملة نقد البيع | إجمالي مسلم أسبوع -> + مسلم أسبوع
  $('sSale').value=String(sum(sales,'cash'));
  $('sWeekly').value=String(sum(sales,'weeklySalesAmt'));
  // إجمالي مسلم فلوس -> مبلغ مسلم فلوس فقط؛ الاسم يبقى للإدخال اليدوي (ويُحفظ إن كان مكتوبًا)
  const oldPrev=(typeof rowsToArray==='function'?rowsToArray('prevBody'):[]);
  const keepName=(oldPrev.find(r=>r&&String(r.name||'').trim())||{}).name||'';
  $('prevBody').innerHTML=''; addRow('prevBody',keepName,String(sum(sales,'weeklyAmt')));
  // العملات: مبلغ كل عملة + مبلغ صرفها
  $('moneyBody').innerHTML='';
  const yemeni=sum(money,'yemeni'), saAmt=sum(money,'saudiAmt'), saEx=sum(money,'saudiExch'), omAmt=sum(money,'omaniAmt'), omEx=sum(money,'omaniExch'), dhAmt=sum(money,'dirhamAmt'), dhEx=sum(money,'dirhamExch');
  if(yemeni || (!saAmt&&!saEx&&!omAmt&&!omEx&&!dhAmt&&!dhEx)) addMoneyRow('يمني',String(yemeni),String(yemeni));
  if(saAmt||saEx) addMoneyRow('سعودي',String(saAmt),String(saEx));
  if(omAmt||omEx) addMoneyRow('عماني',String(omAmt),String(omEx));
  if(dhAmt||dhEx) addMoneyRow('درهم',String(dhAmt),String(dhEx));
  if(!$('moneyBody').children.length) currencies.forEach(cur=>addMoneyRow(cur));
  // السحب: إجمالي السحب -> السحب فلوس
  $('wValue').value=String(sum(sales,'prevAmt'));
  // العملات لكل فاتورة يومية: صفوف كل عملة في نفس اليوم تُجمع في سند واحد لذلك اليوم
  window.__moneyDays=money.filter(r=>r&&r.date).map(r=>{
    const rows=[{name:'يمني',amount:r2(weeklyNum(r.yemeni)),value:r2(weeklyNum(r.yemeni))},{name:'سعودي',amount:r2(weeklyNum(r.saudiAmt)),value:r2(weeklyNum(r.saudiExch))},{name:'عماني',amount:r2(weeklyNum(r.omaniAmt)),value:r2(weeklyNum(r.omaniExch))},{name:'درهم',amount:r2(weeklyNum(r.dirhamAmt)),value:r2(weeklyNum(r.dirhamExch))}].filter(x=>x.value);
    return {name:r.day||'',date:r.date,rows:rows};
  }).filter(d=>d.rows.length);
  // السحب لكل فاتورة يومية: سند منفصل لكل يوم له سحب
  window.__withdrawDays=sales.filter(r=>r&&weeklyNum(r.prevAmt)).map(r=>({name:r.day||'',date:r.date||'',amount:r2(weeklyNum(r.prevAmt))}));
  // لا يُلمس: خرج العمال (sPrivateOut)، بيع الدين، اسم مسلم فلوس، ملاحظة السحب
  // حقول الإدخال اليدوي تبقى مفتوحة دائمًا: خرج العمال، بيع الدين، اسم مسلم فلوس
  if(!$('debtBody').children.length) addDebtRow();
  document.querySelectorAll('#prevBody input,#prevBody button').forEach(el=>{el.readOnly=false; el.disabled=false;});
  update(); saveState();
  const status=$('weekly-copy-status'); if(status) status.textContent='تم نقل إجماليات الفلتر «'+name+'». يبقى يدويًا: خرج العمال، بيع الدين (الاسم والمبلغ)، اسم مسلم فلوس.';
  return true;
}
function renderSavedDetails() {
  const box = $('saved-details-list');
  if (!box) return;
  const acc = accounts.find(a => a.id === currentAccountId);
  const list = acc && Array.isArray(acc.invoices) ? [...acc.invoices].sort((a,b)=>(b.createdAt||b.id||0)-(a.createdAt||a.id||0)) : [];
  if (!list.length) { box.innerHTML = '<div style="padding:10px;text-align:center;color:var(--text-secondary);font-size:13px;">لا توجد معاملات تفصيل محفوظة بعد.</div>'; return; }
  box.innerHTML = list.map(inv => `<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px;margin-top:8px;background:var(--bg,#fff);border:1px solid var(--border);border-radius:9px;flex-wrap:wrap;"><div style="min-width:0;flex:1"><div style="font-weight:800;overflow-wrap:anywhere">${escapeDetailText(inv.initDetail||'تفصيل بدون اسم')}</div><div style="font-size:12px;color:var(--text-secondary)">${escapeDetailText(inv.initDateFrom||'')} ← ${escapeDetailText(inv.initDateTo||'')}${inv.initNo ? ' | رقم الجدول: '+escapeDetailText(inv.initNo):''}</div></div><button type="button" class="nf-btn nf-btn-primary" style="padding:7px 12px" data-nf-onclick="openSavedDetail(${Number(inv.id)})">فتح</button></div>`).join('');
}
function escapeDetailText(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function openSavedDetail(id) {
  const acc = accounts.find(a => a.id === currentAccountId);
  const inv = acc && acc.invoices.find(i => String(i.id) === String(id));
  if (!inv) { alert('لم يتم العثور على معاملة التفصيل'); renderSavedDetails(); return; }
  editingInvoiceId = inv.id;
  window._invoiceInitData = { detail: inv.initDetail||'', dateFrom: inv.initDateFrom||'', dateTo: inv.initDateTo||'', filter: inv.initFilter||'', no: inv.initNo||'' };
  openNewInvoiceForm();
}

function resetInitForm() {
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const dd = String(today.getDate()).padStart(2, '0');
  const todayStr = `${yyyy}-${mm}-${dd}`;
  if ($('init-date-from')) $('init-date-from').value = todayStr;
  if ($('init-date-to'))   $('init-date-to').value   = todayStr;
  if ($('init-detail'))    $('init-detail').value    = '';
  populateWeeklyFilterOptions();
  if ($('init-filter'))    $('init-filter').value    = '';
  populateWeeklyFilterOptions();
  if ($('init-no'))        $('init-no').value        = '';
  updateInitDateText();
  editingInvoiceId = null;
}
function handleFab() {
  const active = document.querySelector('.nf-screen.active');
  const id = active ? active.id : '';
  if (id === 'screen-add') {
    if (!confirm('بدء تفصيل جديد؟ سيتم فقدان البيانات غير المحفوظة.')) return;
  }
  goHome();
}

/* ═══════════════════════════════════════════════════
   بيانات التفصيل الأولية
   ═══════════════════════════════════════════════════ */
const daysAr = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
function formatDayDate(v) {
  if (!v) return '';
  const date = new Date(v + 'T00:00:00');
  return `${daysAr[date.getDay()]} - ${v}`;
}
function updateInitDateText() {
  const from = $('init-date-from').value;
  const to   = $('init-date-to').value;
  const el = $('init-date-text');
  if (!from && !to) { el.textContent = ''; return; }
  let text = '';
  if (from) text = formatDayDate(from);
  if (to)   text += (text ? '  ←  ' : '') + formatDayDate(to);
  el.textContent = text;
}
function proceedToForm() {
  const dateFrom = $('init-date-from').value;
  const dateTo   = $('init-date-to').value;
  const detail   = $('init-detail').value.trim();
  const filter   = $('init-filter').value.trim();
  const no       = $('init-no').value.trim();

  if (!dateFrom) { alert('⚠️ اختر تاريخ البداية'); return; }
  if (!dateTo)   { alert('⚠️ اختر تاريخ النهاية'); return; }
  if (dateFrom > dateTo) { alert('⚠️ تاريخ البداية يجب أن يكون قبل أو يساوي تاريخ النهاية'); return; }
  if (!detail)   { alert('⚠️ أدخل اسم التفصيل'); return; }

  window._invoiceInitData = { dateFrom, dateTo, detail, filter, no };
  openNewInvoiceForm();
  if(filter){
    if(!applyWeeklyFilterTotals(filter)) alert('لم يتم العثور على الفلتر الأسبوعي المختار. تحقق من حفظه أولاً.');
  }
}

/* ═══════════════════════════════════════════════════
   فتح نموذج التفصيل
   ═══════════════════════════════════════════════════ */
const HEADER_IDS = ['hDetail','hDateFrom','hDateTo'];
function openNewInvoiceForm() {
  const data = window._invoiceInitData || {};
  populateWeeklyFilterOptions(data.filter || '');
  $('hDetail').value   = data.detail   || '';
  $('hDateFrom').value = data.dateFrom || '';
  $('hDateTo').value   = data.dateTo   || '';

  document.querySelectorAll('#screen-add input, #screen-add textarea').forEach(el => {
    if (HEADER_IDS.includes(el.id)) return;
    if (el.id && !CALC_IDS.includes(el.id)) el.value = '';
    if (CALC_IDS.includes(el.id)) el.value = '';
  });

  $('prevBody').innerHTML = ''; addRow('prevBody'); addRow('prevBody');
  $('debtBody').innerHTML = ''; addDebtRow(); addDebtRow();
  $('moneyBody').innerHTML = '';
  currencies.forEach(cur => addMoneyRow(cur));

  editMode = false;
  document.body.classList.remove('edit-mode');
  const container = $('new-sale-form-container');
  if (container) container.classList.remove('edit-mode');
  applyCalcReadonly();
  $('editBtn').textContent = '🔓 تعديل أي بيانات';
  $('editBtn').classList.remove('on');
  overrides.clear();
  document.querySelectorAll('#screen-add input.manual').forEach(i => i.classList.remove('manual'));

  if (editingInvoiceId) {
    const acc = accounts.find(a => a.id === currentAccountId);
    const inv = acc ? acc.invoices.find(i => i.id === editingInvoiceId) : null;
    if (inv) {
      if (inv.formData) applyData(inv.formData);
      $('hDetail').value   = data.detail   || inv.initDetail   || '';
      $('hDateFrom').value = data.dateFrom || inv.initDateFrom || '';
      $('hDateTo').value   = data.dateTo   || inv.initDateTo   || '';
      $('note').value      = inv.note || '';
    }
  }

  update();
  showScreen('screen-add');
  flash(editingInvoiceId ? '✏️ تم تحميل التفصيل للتعديل' : '📝 تفصيل جديد');
}

/* ═══════════════════════════════════════════════════
   التعديل اليدوي
   ═══════════════════════════════════════════════════ */
function toggleEdit() {
  editMode = !editMode;
  document.body.classList.toggle('edit-mode', editMode);
  const container = $('new-sale-form-container');
  if (container) container.classList.toggle('edit-mode', editMode);
  applyCalcReadonly();
  $('editBtn').textContent = editMode ? '🔒 إغلاق التعديل اليدوي' : '🔓 تعديل أي بيانات';
  $('editBtn').classList.toggle('on', editMode);
  flash(editMode ? 'وضع التعديل اليدوي مُفعّل' : 'تم إرجاع الحساب التلقائي');
  update();
}
function applyCalcReadonly() {
  CALC_IDS.forEach(id => {
    const el = $(id);
    if (!el) return;
    el.readOnly = !editMode;
    if (!editMode) { overrides.delete(id); el.classList.remove('manual'); }
  });
}
function clearManual() {
  overrides.clear();
  document.querySelectorAll('#screen-add input.manual').forEach(i => i.classList.remove('manual'));
  flash('تم إلغاء جميع التعديلات اليدوية');
  update();
}
function setCalc(id, autoValue) {
  const el = $(id);
  if (!el) return autoValue;
  if (editMode && overrides.has(id)) return numOf(el);
  el.value = localFmt(autoValue);
  return autoValue;
}

/* ═══════════════════════════════════════════════════
   إضافة صفوف
   ═══════════════════════════════════════════════════ */
function addRow(tbodyId, name = '', amount = '') {
  const tr = document.createElement('tr');
  tr.innerHTML =
    '<td><input type="text" class="name" value="' + name + '"></td>' +
    '<td><input type="number" inputmode="decimal" step="any" class="amount" value="' + amount + '"></td>' +
    '<td class="nf-del"><button type="button" title="حذف">✕</button></td>';
  tr.querySelector('.nf-del button').addEventListener('click', () => { tr.remove(); update(); saveState(); });
  $(tbodyId).appendChild(tr);
}
/* ── جدول بيع الدين: الاسم | الكمية | المبلغ | مسلم أسبوع | مبلغ الدين الباقي ── */
function calcDebtRow(tr) {
  const amt = numOf(tr.querySelector('.amount'));
  const wk  = numOf(tr.querySelector('.weekly'));
  const rest = Math.round((amt - wk) * 1000) / 1000;
  const el = tr.querySelector('.rest');
  const empty = !String(tr.querySelector('.amount').value).trim() && !String(tr.querySelector('.weekly').value).trim();
  el.value = empty ? '' : localFmt(rest);
  el.classList.toggle('neg', rest < 0);
  return empty ? 0 : rest;
}
function addDebtRow(name = '', qty = '', amount = '', weekly = '') {
  const tr = document.createElement('tr');
  tr.innerHTML =
    '<td><input type="text" class="name"></td>' +
    '<td><input type="text" class="qty"></td>' +
    '<td><input type="number" inputmode="decimal" step="any" class="amount"></td>' +
    '<td><input type="number" inputmode="decimal" step="any" class="weekly"></td>' +
    '<td class="calc"><input type="text" inputmode="decimal" class="rest" readonly tabindex="-1"></td>' +
    '<td class="nf-del"><button type="button" title="حذف">✕</button></td>';
  tr.querySelector('.name').value   = name   == null ? '' : name;
  tr.querySelector('.qty').value    = qty    == null ? '' : qty;
  tr.querySelector('.amount').value = amount == null ? '' : amount;
  tr.querySelector('.weekly').value = weekly == null ? '' : weekly;
  tr.querySelector('.nf-del button').addEventListener('click', () => { tr.remove(); update(); saveState(); });
  $('debtBody').appendChild(tr);
  calcDebtRow(tr);
  return tr;
}
function debtSum() {
  let t = 0;
  $('debtBody').querySelectorAll('tr').forEach(tr => { t += calcDebtRow(tr); });
  return Math.round(t * 1000) / 1000;
}
function debtRowsToArray() {
  return [...$('debtBody').querySelectorAll('tr')].map(tr => ({
    name:   tr.querySelector('.name').value,
    qty:    tr.querySelector('.qty').value,
    amount: tr.querySelector('.amount').value,
    weekly: tr.querySelector('.weekly').value
  }));
}
function sumBody(tbodyId) {
  let t = 0;
  $(tbodyId).querySelectorAll('.amount').forEach(i => t += numOf(i));
  return t;
}
function addMoneyRow(name = '', amount = '', value = '') {
  const tr = document.createElement('tr');
  const tdName = document.createElement('td');
  const inName = document.createElement('select');
  inName.className = 'm-name';
  inName.style.cssText = "width:100%;border:none;background:transparent;text-align:center;font-weight:700;font-family:'Tajawal',sans-serif;font-size:13px;color:var(--text);padding:4px 2px;outline:none;";
  currencies.forEach(cur => {
    const opt = document.createElement('option');
    opt.value = cur; opt.textContent = cur;
    if (cur === name) opt.selected = true;
    inName.appendChild(opt);
  });
  if (name && !currencies.includes(name)) {
    const opt = document.createElement('option');
    opt.value = name; opt.textContent = name + ' (قديمة)'; opt.selected = true;
    inName.appendChild(opt);
  }
  if (!name && currencies.length > 0) inName.value = currencies[0];
  inName.addEventListener('change', saveState);
  tdName.appendChild(inName);

  const tdAmt = document.createElement('td');
  const inAmt = document.createElement('input');
  inAmt.type = 'number'; inAmt.inputMode = 'decimal'; inAmt.step = 'any';
  inAmt.className = 'm-amount'; inAmt.value = amount;
  tdAmt.appendChild(inAmt);

  const tdVal = document.createElement('td');
  const inVal = document.createElement('input');
  inVal.type = 'number'; inVal.inputMode = 'decimal'; inVal.step = 'any';
  inVal.className = 'm-value'; inVal.value = value;
  tdVal.appendChild(inVal);

  const tdDel = document.createElement('td');
  tdDel.className = 'nf-del';
  const btn = document.createElement('button');
  btn.type = 'button'; btn.textContent = '✕'; btn.title = 'حذف';
  btn.addEventListener('click', () => { tr.remove(); update(); saveState(); });
  tdDel.appendChild(btn);

  tr.append(tdName, tdAmt, tdVal, tdDel);
  $('moneyBody').appendChild(tr);
}

/* ═══════════════════════════════════════════════════
   الحسابات التلقائية
   ═══════════════════════════════════════════════════ */
function lockAutoFields() {
  const sp = $('sPrivateOut'); if (sp) sp.readOnly = true;
  const add = $('debtAddBtn'); if (add) add.disabled = !editMode;
  document.querySelectorAll('#debtBody input, #debtBody button').forEach(el => {
    if (el.tagName === 'BUTTON') { el.disabled = !editMode; return; }
    el.disabled = false;
    el.readOnly = !editMode || el.classList.contains('rest');
  });
}
function update() {
  lockAutoFields();
  const restAuto = val('qQty') - val('qCash') - val('qDebt') - val('qOut');
  setCalc('qRest', restAuto);
  $('qRestCell').classList.toggle('bad', restAuto < 0);

  const prevT = sumBody('prevBody');
  const debtT = debtSum();
  const prevV = setCalc('prevTotal', prevT);
  const debtV = setCalc('debtTotal', debtT);

  // حُذف "مسلم بيع" و"خرج السوق" — الصيغة الآن: جملة نقد الباقي − خرج العمال
  const cashRestAuto = val('sSale') + val('sWeekly') - val('sPrivateOut');
  const cashRest = setCalc('sCashRest', cashRestAuto);
  const debtSale = setCalc('sDebtSale', debtV);
  setCalc('sGrand', cashRest + debtSale);

  const midVal = setCalc('midTotal', cashRest + prevV + val('sPrivateOut'));
  setCalc('midCashRest', cashRest);
  setCalc('midPrev',     prevV);
  setCalc('midPrivate',  val('sPrivateOut'));

  let moneySum = 0;
  document.querySelectorAll('#moneyBody tr').forEach(tr => {
    const valEl = tr.querySelector('.m-value');
    if (valEl) moneySum += numOf(valEl);
  });
  const withdraw = val('wValue');
  const totalMoney = moneySum + withdraw;
  setCalc('mTotal', totalMoney);

  setCalc('chkRequired', midVal);
  const chkMoney = setCalc('chkMoney', totalMoney);
  const diff = chkMoney - midVal;
  if (!(editMode && overrides.has('chkDiff'))) {
    $('chkDiff').value = localFmt(diff);
  }
  $('chkDiffCell').classList.toggle('bad', Math.abs(diff) > 1e-9);
}

let flashTimer = null;
function flash(msg) {
  const el = $('status');
  if (!el) return;
  el.textContent = msg;
  clearTimeout(flashTimer);
  flashTimer = setTimeout(() => el.textContent = '', 2200);
}

/* ═══════════════════════════════════════════════════
   جمع وتفريغ البيانات
   ═══════════════════════════════════════════════════ */
function collectData() {
  const data = {};
  document.querySelectorAll('#screen-add input, #screen-add textarea').forEach(el => {
    if (el.id && !CALC_IDS.includes(el.id)) data[el.id] = el.value;
  });
  data.__prev      = rowsToArray('prevBody');
  data.__debt      = debtRowsToArray();
  data.__money     = moneyRowsToArray();
  data.__withdraw  = Array.isArray(window.__withdrawDays) ? window.__withdrawDays : [];
  data.__moneyDays = Array.isArray(window.__moneyDays) ? window.__moneyDays : [];
  data.__editMode  = editMode;
  data.__overrides = [...overrides];
  CALC_IDS.forEach(id => { if ($(id)) data['calc_' + id] = $(id).value; });
  return data;
}
function applyData(data) {
  Object.entries(data).forEach(([k, v]) => {
    if (k.startsWith('__') || k.startsWith('calc_')) return;
    const el = $(k);
    if (el) el.value = toEnDigits(v);
  });
  if (Array.isArray(data.__prev)) {
    $('prevBody').innerHTML = '';
    data.__prev.forEach(r => addRow('prevBody', r.name, r.amount));
    if (!data.__prev.length) addRow('prevBody');
  }
  if (Array.isArray(data.__debt)) {
    $('debtBody').innerHTML = '';
    data.__debt.forEach(r => addDebtRow(r.name, r.qty, r.amount, r.weekly));
    if (!data.__debt.length) addDebtRow();
  }
  window.__withdrawDays = Array.isArray(data.__withdraw) ? data.__withdraw : [];
  window.__moneyDays = Array.isArray(data.__moneyDays) ? data.__moneyDays : [];
  if (Array.isArray(data.__money)) {
    $('moneyBody').innerHTML = '';
    data.__money.forEach(r => addMoneyRow(r.name, r.amount, r.value));
    if (!data.__money.length) addMoneyRow();
  }
  editMode = !!data.__editMode;
  document.body.classList.toggle('edit-mode', editMode);
  const container = $('new-sale-form-container');
  if (container) container.classList.toggle('edit-mode', editMode);
  applyCalcReadonly();
  $('editBtn').textContent = editMode ? '🔒 إغلاق التعديل اليدوي' : '🔓 تعديل أي بيانات';
  $('editBtn').classList.toggle('on', editMode);
  overrides.clear();
  (data.__overrides || []).forEach(id => {
    const el = $(id);
    if (el) { overrides.add(id); el.classList.add('manual'); }
  });
  CALC_IDS.forEach(id => {
    if (data['calc_' + id] && $(id) && overrides.has(id)) {
      $(id).value = toEnDigits(data['calc_' + id]);
    }
  });
  update();
}
function rowsToArray(tbodyId) {
  return [...$(tbodyId).querySelectorAll('tr')].map(tr => ({
    name:   tr.querySelector('.name')   ? tr.querySelector('.name').value   : '',
    amount: tr.querySelector('.amount') ? tr.querySelector('.amount').value : ''
  }));
}
function moneyRowsToArray() {
  return [...document.querySelectorAll('#moneyBody tr')].map(tr => ({
    name:   tr.querySelector('.m-name')   ? tr.querySelector('.m-name').value   : '',
    amount: tr.querySelector('.m-amount') ? tr.querySelector('.m-amount').value : '',
    value:  tr.querySelector('.m-value')  ? tr.querySelector('.m-value').value  : ''
  }));
}

/* ═══════════════════════════════════════════════════
   مستمعات الأحداث
   ═══════════════════════════════════════════════════ */
document.addEventListener('input', e => {
  const el = e.target;
  if (!el.matches('#screen-add input, #screen-add textarea')) return;
  if (hasArabicDigits(el.value)) {
    const caret = el.selectionStart;
    el.value = toEnDigits(el.value);
    try { el.setSelectionRange(caret, caret); } catch (_) {}
  }
  if (editMode && CALC_IDS.includes(el.id)) {
    overrides.add(el.id);
    el.classList.add('manual');
  }
  update();
  saveState();
});
document.addEventListener('paste', e => {
  const el = e.target;
  if (!el.matches('#screen-add input, #screen-add textarea')) return;
  const text = (e.clipboardData || window.clipboardData).getData('text');
  if (text && hasArabicDigits(text)) {
    e.preventDefault();
    const converted = toEnDigits(text);
    const start = el.selectionStart ?? el.value.length;
    const end   = el.selectionEnd   ?? el.value.length;
    el.value = el.value.slice(0, start) + converted + el.value.slice(end);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
});

/* ═══════════════════════════════════════════════════
   جديد / إلغاء
   ═══════════════════════════════════════════════════ */
function newSheet() {
  if (!confirm('سيتم حذف جميع البيانات والبدء من جديد. متابعة؟')) return;
  try { localStorage.removeItem(DRAFT_KEY); } catch (e) {}
  document.querySelectorAll('#screen-add input, #screen-add textarea').forEach(el => {
    if (HEADER_IDS.includes(el.id)) return;
    if (el.id && !CALC_IDS.includes(el.id)) el.value = '';
    if (CALC_IDS.includes(el.id)) el.value = '';
  });
  $('prevBody').innerHTML = ''; addRow('prevBody'); addRow('prevBody');
  $('debtBody').innerHTML = ''; addDebtRow(); addDebtRow();
  $('moneyBody').innerHTML = '';
  currencies.forEach(cur => addMoneyRow(cur));
  editMode = false;
  document.body.classList.remove('edit-mode');
  const container = $('new-sale-form-container');
  if (container) container.classList.remove('edit-mode');
  applyCalcReadonly();
  $('editBtn').textContent = '🔓 تعديل أي بيانات';
  $('editBtn').classList.remove('on');
  overrides.clear();
  document.querySelectorAll('#screen-add input.manual').forEach(i => i.classList.remove('manual'));
  update();
  flash('تم البدء من جديد');
}
function cancelInvoiceForm() {
  if (confirm('هل أنت متأكد من إلغاء التفصيل؟')) {
    editingInvoiceId = null;
    goHome();
  }
}

/* ═══════════════════════════════════════════════════
   حفظ التفصيل
   ═══════════════════════════════════════════════════ */
function saveInvoiceNow() {
  const acc = accounts.find(a => a.id === currentAccountId);
  if (!acc) { alert('خطأ: لا يوجد حساب مفتوح'); return; }

  const finalDetail   = $('hDetail').value.trim();
  const finalDateFrom = $('hDateFrom').value.trim();
  const finalDateTo   = $('hDateTo').value.trim();
  const finalNote     = $('note').value;

  if (!finalDateFrom) { alert('⚠️ التاريخ من مطلوب'); return; }
  if (!finalDateTo)   { alert('⚠️ التاريخ إلى مطلوب'); return; }
  if (!finalDetail)   { alert('⚠️ اسم التفصيل مطلوب'); return; }

  const formData = collectData();
  const initData = window._invoiceInitData || {};
  const filter = initData.filter || '';
  const no     = initData.no || '';

  if (editingInvoiceId) {
    const inv = acc.invoices.find(i => i.id === editingInvoiceId);
    if (inv) {
      inv.initDetail   = finalDetail;
      inv.initDateFrom = finalDateFrom;
      inv.initDateTo   = finalDateTo;
      inv.initNo       = no;
      inv.initFilter   = filter;
      inv.formData     = formData;
      inv.note         = finalNote;
      saveData();
      editingInvoiceId = null;
      notifySaved(inv.id, true);
    }
  } else {
    const inv = {
      id: Date.now(),
      initDetail:   finalDetail,
      initDateFrom: finalDateFrom,
      initDateTo:   finalDateTo,
      initNo:       no,
      initFilter:   filter,
      formData:     formData,
      note:         finalNote,
      createdAt:    Date.now()
    };
    acc.invoices.push(inv);
    saveData();
    notifySaved(inv.id, false);
  }
}

/* ═══════════════════════════════════════════════════
   التهيئة
   ═══════════════════════════════════════════════════ */
function ensureDefaultAccount() {
  if (!accounts.length) {
    accounts.push({ id: 1, invoices: [] });
    saveData();
  }
  currentAccountId = accounts[0].id;
}


/* ── ربط النموذج بالشاشة الرئيسية: بعد الحفظ يرجع لشاشة التفصيل ويظهر الجدول ── */
function notifySaved(id, updated) {
  let sent = false;
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'DETAIL_SAVED', id: id, updated: !!updated, accounts: accounts }, '*');
      sent = true;
    }
  } catch (e) {}
  if (!sent) { flash(updated ? '✅ تم تحديث التفصيل' : '✅ تم حفظ التفصيل'); goHome(); }
}
window.appBack = function () {
  const a = document.querySelector('.nf-screen.active');
  if (a && a.id === 'screen-add') {
    if (window._readonly) return false;
    if (window._openedForEdit) {
      return confirm('الخروج دون حفظ التعديلات؟') ? false : true;
    }
    showScreen('screen-invoice-init');
    return true;
  }
  return false;
};
window.addEventListener('message', function (e) {
  const m = e.data || {};
  if (m.type !== 'DETAIL_INIT') return;
  if (Array.isArray(m.accounts) && m.accounts.length) {
    accounts = m.accounts; saveData(); currentAccountId = accounts[0].id;
  }
  if (m.theme) {
    const r = document.documentElement.style;
    ['--primary','--primary-dark','--accent','--primary-light','--accent-light'].forEach(k => { if (m.theme[k]) r.setProperty(k, m.theme[k]); });
  }
  renderSavedDetails();
  if (m.editId) { window._openedForEdit = true; openSavedDetail(m.editId); }
  if (m.readonly) {
    document.querySelectorAll('#screen-add input,#screen-add textarea,#screen-add select,#screen-add button').forEach(e => { e.disabled = true; });
    document.querySelectorAll('.btn-save,.btn-cancel,.nf-toolbar').forEach(e => { e.style.display = 'none'; });
    window._openedForEdit = false; window._readonly = true;
  }
});

loadData();
ensureDefaultAccount();
resetInitForm();
populateWeeklyFilterOptions();
renderSavedDetails();

document.addEventListener('DOMContentLoaded', () => {
  if (!$('prevBody').hasChildNodes() || $('prevBody').children.length === 0) {
    addRow('prevBody'); addRow('prevBody');
    addDebtRow(); addDebtRow();
    $('moneyBody').innerHTML = '';
    currencies.forEach(cur => addMoneyRow(cur));
  }
  update();
});

/* exports: global functions of the former iframe page */
try{window.toEnDigits=toEnDigits}catch(_e){}
try{window.hasArabicDigits=hasArabicDigits}catch(_e){}
try{window.blockArabicNums=blockArabicNums}catch(_e){}
try{window.fmt=fmt}catch(_e){}
try{window.saveData=saveData}catch(_e){}
try{window.loadData=loadData}catch(_e){}
try{window.saveState=saveState}catch(_e){}
try{window.updateTopBarNavigation=updateTopBarNavigation}catch(_e){}
try{window.showScreen=showScreen}catch(_e){}
try{window.topBarBack=topBarBack}catch(_e){}
try{window.goHome=goHome}catch(_e){}
try{window.populateWeeklyFilterOptions=populateWeeklyFilterOptions}catch(_e){}
try{window.getWeeklyFilterByName=getWeeklyFilterByName}catch(_e){}
try{window.weeklyNum=weeklyNum}catch(_e){}
try{window.applyWeeklyFilterTotals=applyWeeklyFilterTotals}catch(_e){}
try{window.renderSavedDetails=renderSavedDetails}catch(_e){}
try{window.escapeDetailText=escapeDetailText}catch(_e){}
try{window.openSavedDetail=openSavedDetail}catch(_e){}
try{window.resetInitForm=resetInitForm}catch(_e){}
try{window.handleFab=handleFab}catch(_e){}
try{window.formatDayDate=formatDayDate}catch(_e){}
try{window.updateInitDateText=updateInitDateText}catch(_e){}
try{window.proceedToForm=proceedToForm}catch(_e){}
try{window.openNewInvoiceForm=openNewInvoiceForm}catch(_e){}
try{window.toggleEdit=toggleEdit}catch(_e){}
try{window.applyCalcReadonly=applyCalcReadonly}catch(_e){}
try{window.clearManual=clearManual}catch(_e){}
try{window.setCalc=setCalc}catch(_e){}
try{window.addRow=addRow}catch(_e){}
try{window.calcDebtRow=calcDebtRow}catch(_e){}
try{window.addDebtRow=addDebtRow}catch(_e){}
try{window.debtSum=debtSum}catch(_e){}
try{window.debtRowsToArray=debtRowsToArray}catch(_e){}
try{window.sumBody=sumBody}catch(_e){}
try{window.addMoneyRow=addMoneyRow}catch(_e){}
try{window.lockAutoFields=lockAutoFields}catch(_e){}
try{window.update=update}catch(_e){}
try{window.flash=flash}catch(_e){}
try{window.collectData=collectData}catch(_e){}
try{window.applyData=applyData}catch(_e){}
try{window.rowsToArray=rowsToArray}catch(_e){}
try{window.moneyRowsToArray=moneyRowsToArray}catch(_e){}
try{window.newSheet=newSheet}catch(_e){}
try{window.cancelInvoiceForm=cancelInvoiceForm}catch(_e){}
try{window.saveInvoiceNow=saveInvoiceNow}catch(_e){}
try{window.ensureDefaultAccount=ensureDefaultAccount}catch(_e){}
try{window.notifySaved=notifySaved}catch(_e){}

__nf.setEval(function(__code,event){return eval(__code)});
}};
DEFS["weekly"]={css:".nf-host 500;700;800;900&display=swap');\n  *{ box-sizing: border-box; margin: 0; padding: 0; }.nf-host{\n      \n    --accent: #B71C3D; --accent-light: #FAD4E0;\n     --bg-soft: #F5F0F1; --bg-card: #FFFFFF;\n     --text-secondary: #7B6B6B; --text-muted: #9E8E8E;\n    --border: #E8D8DD; --border-light: #F5EBEE;\n    --shadow-sm: 0 1px 3px rgba(107,26,47,0.06);\n    --shadow: 0 4px 20px rgba(107,26,47,0.10);\n    --shadow-lg: 0 8px 32px rgba(107,26,47,0.14);\n    --radius-sm: 10px; --radius: 16px; --radius-lg: 24px;\n  }.nf-host{\n    font-family: 'Tajawal', 'Segoe UI', sans-serif;\n    background: #2D2D2D; color: var(--text); direction: rtl;\n    font-weight: 500; line-height: 1.6; -webkit-font-smoothing: antialiased;\n  }.nf-host .nf-app{\n    max-width: 900px; margin: 20px auto; background: var(--bg);\n    border-radius: var(--radius-lg); min-height: calc(100vh - 40px);\n    padding-bottom: 40px; box-shadow: var(--shadow-lg); overflow: hidden;\n  }.nf-host .nf-topbar{\n    display: flex; align-items: center; justify-content: space-between; gap: 8px;\n    padding: 14px 18px;\n    background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);\n    border-radius: 0 0 28px 28px; box-shadow: var(--shadow);\n  }.nf-host .nf-topbar .title{\n    flex: 1; text-align: center; font-size: 20px; font-weight: 900;\n    color: #fff; text-shadow: 0 2px 4px rgba(0,0,0,0.2);\n  }.nf-host .nf-topbar .spacer{ width: 48px; }.nf-host .nf-screen{ display: none; padding: 16px 20px; animation: nfw-fadeIn 0.3s ease; }.nf-host .nf-screen.active{ display: block; }@keyframes nfw-fadeIn{ from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }.nf-host .form-group{ margin-bottom: 18px; }.nf-host .form-group label{\n    display: block; font-size: 14px; margin-bottom: 8px;\n    color: var(--text-secondary); font-weight: 700;\n  }.nf-host .form-group input,.nf-host .form-group select{\n    width: 100%; padding: 14px 16px; border: 2px solid var(--border);\n    border-radius: var(--radius-sm); font-size: 15px; background: var(--bg);\n    font-weight: 600; color: var(--text); transition: all 0.2s ease;\n    font-family: 'Tajawal', sans-serif;\n  }.nf-host .form-group input:focus,.nf-host .form-group select:focus{\n    outline: none; border-color: var(--primary-light);\n    box-shadow: 0 0 0 4px rgba(107,26,47,0.08);\n  }.nf-host .form-group input::placeholder{ color: var(--text-muted); font-weight: 400; }.nf-host .form-row{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }.nf-host .date-field{ display: flex; gap: 8px; align-items: stretch; }.nf-host .date-text{\n    flex: 1; padding: 14px 12px; border: 2px solid var(--border);\n    border-radius: var(--radius-sm); font-size: 15px; font-weight: 700;\n    font-family: 'Tajawal', sans-serif; text-align: center; direction: ltr;\n    background: var(--bg); color: var(--text);\n  }.nf-host .date-text:focus{\n    outline: none; border-color: var(--primary-light);\n    box-shadow: 0 0 0 4px rgba(107,26,47,0.08);\n  }.nf-host .date-btn{\n    position: relative; width: 54px; flex-shrink: 0;\n    display: flex; align-items: center; justify-content: center;\n    border: 2px solid var(--primary); border-radius: var(--radius-sm);\n    background: var(--primary-light); font-size: 20px; cursor: pointer;\n    transition: all 0.2s ease;\n  }.nf-host .date-btn:hover{ background: var(--accent-light); }.nf-host .date-btn input[type=\"date\"]{\n    position: absolute; inset: 0; width: 100%; height: 100%;\n    opacity: 0; cursor: pointer; border: none; padding: 0;\n  }.nf-host .nf-btn{\n    padding: 12px 20px; border-radius: var(--radius-sm); border: none;\n    font-size: 15px; cursor: pointer; font-weight: 800; transition: all 0.2s ease;\n    font-family: 'Tajawal', sans-serif; display: inline-flex; align-items: center;\n    justify-content: center; gap: 6px; position: relative; overflow: hidden;\n  }.nf-host .nf-btn:active{ transform: scale(0.97); }.nf-host .nf-btn-primary{\n    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);\n    color: #fff; box-shadow: 0 4px 16px rgba(107,26,47,0.3);\n  }.nf-host .nf-btn-primary:hover{ box-shadow: 0 6px 24px rgba(107,26,47,0.4); transform: translateY(-1px); }.nf-host .btn-secondary{ background: #FFFFFF; color: var(--primary); border: 2px solid var(--primary); }.nf-host .btn-secondary:hover{ background: var(--primary-light); }.nf-host .btn-danger{ background: linear-gradient(135deg, #E53935 0%, #C62828 100%); color: #fff; }.nf-host .nf-section-header{\n    background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);\n    color: #fff; text-align: center; padding: 14px; border-radius: var(--radius-sm);\n    font-size: 17px; font-weight: 900; margin: 20px 0 12px 0;\n    box-shadow: var(--shadow-sm); letter-spacing: 0.5px;\n  }.nf-host .header-info{\n    background: linear-gradient(135deg, #FAFAFA 0%, #F5F0F1 100%);\n    border: 2px solid var(--border); border-radius: var(--radius);\n    padding: 14px; margin-bottom: 14px;\n    display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;\n    box-shadow: var(--shadow-sm);\n  }.nf-host .header-info .item{\n    font-size: 13px; text-align: center; font-weight: 600;\n    color: var(--text-secondary); padding: 8px 6px; border-radius: 8px;\n    background: rgba(255,255,255,0.6);\n  }.nf-host .header-info .item b{\n    display: block; font-size: 11px; color: var(--text-muted);\n    margin-bottom: 4px; font-weight: 700;\n  }.nf-host .header-info .item span{ font-weight: 800; color: var(--text); font-size: 14px; }.nf-host .nf-table-wrapper{\n    width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;\n    margin-bottom: 14px; border-radius: var(--radius-sm);\n    box-shadow: var(--shadow-sm);\n  }.nf-host .data-table{\n    width: 100%; border-collapse: separate; border-spacing: 0;\n    font-size: 13px; margin-bottom: 0; border-radius: var(--radius-sm);\n    overflow: hidden; box-shadow: var(--shadow-sm); min-width: 640px;\n  }.nf-host .data-table th,.nf-host .data-table td{\n    border: 1px solid var(--border); padding: 8px 4px; text-align: center;\n  }.nf-host .data-table th{\n    background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);\n    color: #fff; font-weight: 800; font-size: 12px; padding: 10px 4px;\n    border: none; border-right: 1px solid rgba(255,255,255,0.15);\n  }.nf-host .data-table th:last-child{ border-right: none; }.nf-host .data-table td{ background: var(--bg); font-weight: 600; border-top: none; }.nf-host .data-table td input{\n    width: 100%; border: none; background: transparent; text-align: center;\n    font-size: 13px; padding: 6px; font-weight: 700; color: var(--text);\n    font-family: 'Tajawal', sans-serif;\n  }.nf-host .data-table td input:focus{ outline: 2px solid var(--primary-light); border-radius: 6px; }.nf-host .data-table .total-row td{\n    background: linear-gradient(180deg, #F5E1E7 0%, #FAD4E0 100%);\n    font-weight: 900; color: var(--primary-dark); font-size: 13px;\n    border-top: 2px solid var(--primary-light);\n  }.nf-host .data-table .day-col{\n    font-weight: 800; background: var(--bg-soft); min-width: 90px;\n    color: var(--primary-dark); padding: 4px;\n  }.nf-host .readonly{ background: var(--bg-soft) !important; color: var(--text-muted) !important; }.nf-host .data-table,.nf-host .data-table *{\n    -webkit-user-select: none;\n    -moz-user-select: none;\n    -ms-user-select: none;\n    user-select: none;\n    -webkit-touch-callout: none;\n  }.nf-host .data-table input{\n    -webkit-user-select: text;\n    -moz-user-select: text;\n    -ms-user-select: text;\n    user-select: text;\n  }.nf-host .row-date{ position: relative; margin-top: 4px; }.nf-host .row-date-text{\n    width: 100%; border: none; background: transparent; text-align: center;\n    font-size: 10px; padding: 2px; font-weight: 700; color: var(--text-secondary);\n    font-family: 'Tajawal', sans-serif; direction: ltr; cursor: pointer;\n  }.nf-host .row-date-picker{\n    position: absolute; inset: 0; width: 100%; height: 100%;\n    opacity: 0; cursor: pointer; border: none; padding: 0;\n  }.nf-host .day-unit{\n    display: flex; flex-direction: column; align-items: center; justify-content: center;\n    gap: 2px; min-height: 40px; padding: 4px 6px; border: 1px solid var(--border);\n    border-radius: 8px; background: var(--bg-soft);\n  }.nf-host .day-unit-name{\n    font-size: 12px; font-weight: 800; line-height: 1.2; color: var(--primary-dark);\n  }.nf-host .day-unit-date{\n    font-size: 10px; font-weight: 700; line-height: 1.2; color: var(--text-secondary);\n    direction: ltr; font-family: 'Tajawal', sans-serif;\n  }.nf-host .calc-box{\n    background: linear-gradient(180deg, #FAFAFA 0%, #F5F0F1 100%);\n    border: 2px solid var(--border); border-radius: var(--radius);\n    padding: 16px; margin-bottom: 16px; box-shadow: var(--shadow-sm);\n  }.nf-host .calc-box .calc-row{\n    display: flex; justify-content: space-between; align-items: center;\n    padding: 10px 0; border-bottom: 1px dashed var(--border); gap: 12px;\n  }.nf-host .calc-box .calc-row:last-child{ border-bottom: none; }.nf-host .calc-box .calc-row .lbl{\n    font-size: 14px; font-weight: 700; flex: 1; color: var(--text-secondary);\n  }.nf-host .calc-box .calc-row .val-box{\n    background: var(--bg); border: 2px solid var(--border); border-radius: 10px;\n    padding: 8px 16px; min-width: 140px; text-align: center;\n    font-family: 'Tajawal', sans-serif; font-size: 15px; font-weight: 800;\n    color: var(--text); box-shadow: inset 0 1px 3px rgba(0,0,0,0.04);\n  }.nf-host .calc-box .calc-row.total{\n    font-size: 16px; font-weight: 900; border-top: 2px solid var(--primary-light);\n    margin-top: 6px; padding-top: 12px;\n  }.nf-host .highlight-red{ color: #E53935 !important; }.nf-host .highlight-green{ color: #43A047 !important; }.nf-host .highlight-blue{ color: #1E88E5 !important; }.nf-host .actions-bar{\n    display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;\n    margin-top: 20px; padding-top: 16px; border-top: 2px solid var(--border);\n  }.nf-host .actions-bar .nf-btn{ font-size: 13px; padding: 11px 4px; border-radius: 10px; }@media (max-width: 600px){.nf-host .header-info{ grid-template-columns: 1fr; gap: 8px; padding: 12px; }}@media (max-width: 480px){.nf-host .nf-app{ margin: 0; border-radius: 0; min-height: 100%; }.nf-host .nf-screen{ padding: 12px 14px; }.nf-host .form-row{ grid-template-columns: 1fr; gap: 10px; }.nf-host .calc-box .calc-row{ flex-direction: column; align-items: stretch; gap: 6px; padding: 8px 0; }.nf-host .calc-box .calc-row .lbl{ font-size: 13px; text-align: center; }.nf-host .calc-box .calc-row .val-box{ width: 100%; min-width: unset; }.nf-host .actions-bar{ grid-template-columns: 1fr; }.nf-host .nf-topbar .title{ font-size: 17px; }}.nf-host.nf-native{--accent:var(--primary);--accent-light:var(--primary-light);--blue:var(--primary);--blue-dark:var(--primary-dark);--bg-soft:var(--bg2,var(--bg));--bg-card:var(--bg);--text-secondary:var(--text2,var(--text));--text-muted:var(--muted,#64748b);--border:var(--line,#e2e8f0);--border-light:var(--line,#e2e8f0);background:var(--bg);color:var(--text);font-family:var(--app-font,\"Tajawal\",sans-serif)}.nf-host.nf-native .nf-app{background:var(--bg);height:auto!important;max-height:none!important;overflow:visible!important;max-width:1100px}.nf-host.nf-native .nf-topbar{display:none!important}.nf-host.nf-native .nf-screen{animation:none!important}.nf-host.nf-native{min-height:100%;height:auto}",html:"<div class=\"nf-app\">\n\n  <div class=\"nf-topbar\">\n    <div class=\"spacer\"></div>\n    <div class=\"title\" id=\"topbar-title\">إضافة فلتر اسبوعي</div>\n    <div class=\"spacer\"></div>\n  </div>\n\n  <!-- ═══════════ SCREEN: ADD ═══════════ -->\n  <div class=\"nf-screen active\" id=\"screen-add\">\n    <h2 style=\"text-align:center;margin-bottom:20px;font-size:20px;font-weight:900;\">إضافة فلتر اسبوعي</h2>\n\n    <div class=\"form-group\">\n      <label>اسم الفلتر</label>\n      <input type=\"text\" id=\"f-name\" placeholder=\"أدخل اسم الفلتر\">\n    </div>\n\n    <div class=\"form-row\">\n      <div class=\"form-group\">\n        <label>من تاريخ</label>\n        <div class=\"date-field\">\n          <input type=\"text\" class=\"date-text\" id=\"f-from-text\" placeholder=\"dd/mm/yyyy\"\n                 data-nf-onchange=\"applyTypedDate('f-from')\">\n          <div class=\"date-btn\">📆\n            <input type=\"date\" id=\"f-from\"\n                   data-nf-onchange=\"document.getElementById('f-from-text').value = fmtDate(this.value)\">\n          </div>\n        </div>\n      </div>\n\n      <div class=\"form-group\">\n        <label>إلى تاريخ</label>\n        <div class=\"date-field\">\n          <input type=\"text\" class=\"date-text\" id=\"f-to-text\" placeholder=\"dd/mm/yyyy\"\n                 data-nf-onchange=\"applyTypedDate('f-to')\">\n          <div class=\"date-btn\">📆\n            <input type=\"date\" id=\"f-to\"\n                   data-nf-onchange=\"document.getElementById('f-to-text').value = fmtDate(this.value)\">\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div style=\"display:flex;gap:10px;margin-top:24px;\">\n      <button class=\"nf-btn nf-btn-primary\" style=\"flex:1\" data-nf-onclick=\"saveAndOpenInvoice()\">حفظ وفتح الفلتر</button>\n      <button class=\"nf-btn btn-secondary\" style=\"flex:1\" data-nf-onclick=\"resetForm()\">إلغاء</button>\n    </div>\n  </div>\n\n  <!-- ═══════════ SCREEN: EDIT ═══════════ -->\n  <div class=\"nf-screen\" id=\"screen-edit\">\n\n    <!-- ═══ ترويسة الجدول ═══ -->\n    <div class=\"header-info\" id=\"edit-header\">\n      <div class=\"item\"><b>الاسم</b><span id=\"h-name\">-</span></div>\n      <div class=\"item\"><b>من تاريخ</b><span id=\"h-from\">-</span></div>\n      <div class=\"item\"><b>إلى تاريخ</b><span id=\"h-to\">-</span></div>\n    </div>\n\n    <!-- الجدول الأول -->\n    <div class=\"nf-section-header\">عمود الكميه</div>\n    <div class=\"nf-table-wrapper\">\n      <table class=\"data-table\">\n        <thead>\n          <tr>\n            <th aria-label=\"\"></th>\n            <th>الكميه</th>\n            <th>نقد</th>\n            <th>دين</th>\n            <th>خرج</th>\n            <th>الباقي</th>\n          </tr>\n        </thead>\n        <tbody id=\"qty-body\"></tbody>\n      </table>\n    </div>\n\n    <!-- الجدول الثاني -->\n    <div class=\"nf-section-header\">عمود البيع </div>\n    <div class=\"nf-table-wrapper\">\n      <table class=\"data-table\">\n        <thead>\n          <tr>\n            <th aria-label=\"\">اليوم</th>\n            <th>نقد الباقي</th>\n            <th>مسلم فلوس</th>\n            <th>مسلم أسبوع</th>\n            <th>السحب فلوس</th>\n            <th>= جملة يومية</th>\n          </tr>\n        </thead>\n        <tbody id=\"sales-body\"></tbody>\n      </table>\n    </div>\n\n    <!-- الجدول الثالث -->\n    <div class=\"nf-section-header\">العملات</div>\n    <div class=\"nf-table-wrapper\">\n      <table class=\"data-table\">\n        <thead>\n          <tr>\n            <th rowspan=\"2\" aria-label=\"\"></th>\n            <th rowspan=\"2\">يمني<br><small>صرفها</small></th>\n            <th colspan=\"2\">سعودي</th>\n            <th colspan=\"2\">عماني</th>\n            <th colspan=\"2\">درهم</th>\n            <th rowspan=\"2\">جملة يومية</th>\n          </tr>\n          <tr>\n            <th>المبلغ</th><th>صرفها</th>\n            <th>المبلغ</th><th>صرفها</th>\n            <th>المبلغ</th><th>صرفها</th>\n          </tr>\n        </thead>\n        <tbody id=\"money-body\"></tbody>\n      </table>\n    </div>\n\n    <!-- التجميع النهائي -->\n    <div class=\"nf-section-header\">التجميل النهائي</div>\n    <div class=\"calc-box\">\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي نقد الباقي)</span>\n        <div class=\"val-box\" id=\"rec-sales-cash\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي مسلم فلوس</span>\n        <div class=\"val-box\" id=\"rec-sales-weekly\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي مسلم أسبوع</span>\n        <div class=\"val-box\" id=\"rec-sales-wsales\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي السحب فلوس</span>\n        <div class=\"val-box\" id=\"rec-sales-prev\">0</div>\n      </div>\n      <div class=\"calc-row total\">\n        <span class=\"lbl\">إجمالي جملة جدول فلوس البيع والمسلم</span>\n        <div class=\"val-box highlight-blue\" id=\"rec-sales-total\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي العملة اليمنية</span>\n        <div class=\"val-box\" id=\"rec-money-yemeni\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي صرف السعودي</span>\n        <div class=\"val-box\" id=\"rec-money-saudi\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي صرف العماني</span>\n        <div class=\"val-box\" id=\"rec-money-omani\">0</div>\n      </div>\n      <div class=\"calc-row\">\n        <span class=\"lbl\">إجمالي صرف الدرهم</span>\n        <div class=\"val-box\" id=\"rec-money-dirham\">0</div>\n      </div>\n      <div class=\"calc-row total\">\n        <span class=\"lbl\">إجمالي جدول اين الفلوس</span>\n        <div class=\"val-box highlight-green\" id=\"rec-money-total\">0</div>\n      </div>\n      <div class=\"calc-row total\" id=\"rec-diff-row\">\n        <span class=\"lbl\">الفارق (يجب أن يكون صفر)</span>\n        <div class=\"val-box\" id=\"rec-diff\">0</div>\n      </div>\n    </div>\n\n    <!-- أزرار التحكم -->\n    <div class=\"actions-bar\">\n      <button class=\"nf-btn btn-secondary\" data-nf-onclick=\"backToAdd()\">← رجوع</button>\n      <button class=\"nf-btn nf-btn-primary\" data-nf-onclick=\"saveWeeklyStructure()\">💾 حفظ الجدول</button>\n      <button class=\"nf-btn btn-danger\" data-nf-onclick=\"clearInvoice()\">مسح</button>\n    </div>\n  </div>\n\n</div>",run:function(document,window,parent,setTimeout,clearTimeout,setInterval,clearInterval,__nf){

// ═══════════════════════════════════════════════════════
// أدوات مساعدة
// ═══════════════════════════════════════════════════════
function toEnDigits(str) {
  return String(str).replace(/[\u0660-\u0669]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584 + 48));
}
function dayNameOnly(day) {
  return String(day || '').replace(/\s*[\u0660-\u06690-9]+-\s*[\u0660-\u06690-9]+\s*$/, '').trim();
}
function blockArabicNums(el) { el.value = toEnDigits(el.value); }
function numVal(v) {
  if (v === '' || v === null || v === undefined) return 0;
  const n = parseFloat(toEnDigits(String(v)).replace(/,/g, ''));
  return isNaN(n) ? 0 : n;
}
function fmt(n) {
  if (n === 0 || n === '' || n === null || n === undefined) return '0';
  const num = typeof n === 'number' ? n : parseFloat(n);
  if (isNaN(num)) return '0';
  return toEnDigits(num.toLocaleString('en-US', { maximumFractionDigits: 3 }));
}
function setVal(id, t) { const e = document.getElementById(id); if (e) e.value = t; }
function setTxt(id, t) { const e = document.getElementById(id); if (e) e.textContent = t; }

// ═══════════════════════════════════════════════════════
// أدوات التاريخ (رقمي فقط: dd/mm/yyyy)
// ═══════════════════════════════════════════════════════
function fmtDate(iso) {
  if (!iso) return '';
  const p = String(iso).split('-');
  if (p.length !== 3) return '';
  return toEnDigits(`${p[2]}/${p[1]}/${p[0]}`);
}
function parseNumericDate(str) {
  let s = toEnDigits(String(str || '')).trim().replace(/[\/\-\.]/g, ' ').replace(/\s+/g, ' ');
  const p = s.split(' ');
  if (p.length !== 3) return '';
  let d, m, y;
  if (p[0].length === 4) { y = +p[0]; m = +p[1]; d = +p[2]; }
  else { d = +p[0]; m = +p[1]; y = +p[2]; }
  if (!y || !m || !d) return '';
  if (y < 100) y += 2000;
  if (y < 1900 || m < 1 || m > 12 || d < 1 || d > 31) return '';
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
function applyTypedDate(baseId) {
  const txt = document.getElementById(baseId + '-text');
  const hid = document.getElementById(baseId);
  const iso = parseNumericDate(txt.value);
  if (iso) { hid.value = iso; txt.value = fmtDate(iso); }
  else { hid.value = ''; txt.value = ''; }
}

// ═══════════════════════════════════════════════════════
// منع نسخ النصوص من الجداول
// ═══════════════════════════════════════════════════════
['copy', 'cut', 'contextmenu', 'dragstart'].forEach(evt => {
  document.addEventListener(evt, function (e) {
    if (e.target.closest && e.target.closest('.data-table')) {
      e.preventDefault();
      return false;
    }
  });
});

// ═══════════════════════════════════════════════════════
// أيام الأسبوع
// ═══════════════════════════════════════════════════════
const WEEK_DAYS = [
  'السبت', 'الأحد', 'الإثنين', 'الثلاثاء',
  'الأربعاء', 'الخميس', 'الجمعة', 'السبت لحقه'
];

let currentInvoice = null;

function localISODate(d) { return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function buildWeekSlots(from,to){
  const start=from?new Date(from+'T12:00:00'):new Date();
  const end=to?new Date(to+'T12:00:00'):new Date(start);
  if(!from) return WEEK_DAYS.map((day,i)=>({day,date:''}));
  if(end<start) return [];
  const days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const out=[]; const d=new Date(start);
  while(d<=end && out.length<8){ out.push({day:days[d.getDay()],date:localISODate(d)}); d.setDate(d.getDate()+1); }
  return out;
}
function newInvoiceData(from='',to='') {
  const slots=buildWeekSlots(from,to);
  return {
    qtyRows: slots.map(x => ({ ...x, qty: '', cash: '', debt: '', expense: '' })),
    salesRows: slots.map(x => ({ ...x, cash: '', saleGross: '', outAmt: '', weeklyAmt: '', weeklyNote: '', weeklySalesAmt: '', weeklySalesNote: '', prevAmt: '', prevNote: '' })),
    moneyRows: slots.map(x => ({ ...x, yemeni: '', saudiAmt: '', saudiExch: '', omaniAmt: '', omaniExch: '', dirhamAmt: '', dirhamExch: '' }))
  };
}

// ═══════════════════════════════════════════════════════
// التنقل بين الشاشات
// ═══════════════════════════════════════════════════════
function showScreen(id) {
  document.querySelectorAll('.nf-screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  const t = document.getElementById('topbar-title');
  if (id === 'screen-add') {
    t.textContent = 'إضافة فلتر اسبوعي';
  } else {
    t.textContent = (currentInvoice && currentInvoice.name) ? currentInvoice.name : 'فلتر أسبوعي';
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ═══════════════════════════════════════════════════════
// حفظ وفتح الفلتر
// ═══════════════════════════════════════════════════════
function saveAndOpenInvoice() {
  const name = document.getElementById('f-name').value.trim();
  const from = document.getElementById('f-from').value;
  const to   = document.getElementById('f-to').value;

  if (!name) { alert('الرجاء إدخال اسم الفلتر'); document.getElementById('f-name').focus(); return; }

  if(from && to && to < from){ alert('تاريخ النهاية يجب أن يكون بعد تاريخ البداية'); return; }
  currentInvoice = { id: String(Date.now()), name, fromDate: from, toDate: to, ...newInvoiceData(from,to) };
  // إرسال اسم الفلتر إلى التطبيق الرئيسي ليظهر ضمن قائمة الفلاتر في إضافة الفاتورة.
  // حفظ تعريف الفلتر أولاً؛ حفظ الهيكل الكامل يتم بزر حفظ الجدول.
  try { window.parent.postMessage({type:'WEEKLY_FILTER_DRAFT', filter:{id:currentInvoice.id, name, fromDate:from, toDate:to}}, '*'); } catch(e) {}

  // تعبئة ترويسة الجدول
  setTxt('h-name', currentInvoice.name || '-');
  setTxt('h-from', fmtDate(currentInvoice.fromDate) || '-');
  setTxt('h-to',   fmtDate(currentInvoice.toDate)   || '-');

  renderQtyTable();
  renderSalesTable();
  renderMoneyTable();
  recalcAll();
  showScreen('screen-edit');
}

function resetForm() {
  document.querySelectorAll('#screen-add input').forEach(i => i.value = '');
}


window.addEventListener('message',function(event){
  const msg=event.data;if(!msg||msg.type!=='LOAD_WEEKLY_FILTER'||!msg.filter)return;
  const f=msg.filter;
  document.getElementById('f-name').value=f.name||'';
  document.getElementById('f-from').value=f.fromDate||'';document.getElementById('f-to').value=f.toDate||'';
  document.getElementById('f-from-text').value=fmtDate(f.fromDate||'');document.getElementById('f-to-text').value=fmtDate(f.toDate||'');
  currentInvoice=Object.assign({},newInvoiceData(f.fromDate||'',f.toDate||''),f);
  currentInvoice.qtyRows=Array.isArray(f.qtyRows)?f.qtyRows:currentInvoice.qtyRows;
  currentInvoice.salesRows=Array.isArray(f.salesRows)?f.salesRows:currentInvoice.salesRows;
  currentInvoice.moneyRows=Array.isArray(f.moneyRows)?f.moneyRows:currentInvoice.moneyRows;
  setTxt('h-name',currentInvoice.name||'-');setTxt('h-from',fmtDate(currentInvoice.fromDate)||'-');setTxt('h-to',fmtDate(currentInvoice.toDate)||'-');
  renderQtyTable();renderSalesTable();renderMoneyTable();recalcAll();showScreen('screen-edit');
});
function saveWeeklyStructure(){
  if(!currentInvoice){alert('افتح الفلتر أولاً');return;}
  const payload={...currentInvoice, savedAt:Date.now()};
  try{window.parent.postMessage({type:'WEEKLY_FILTER_SAVE',filter:payload},'*');}catch(e){}
  alert('تم حفظ الفلتر الأسبوعي مع هيكله');
}

function backToAdd() { showScreen('screen-add'); }

function clearInvoice() {
  if (!confirm('هل أنت متأكد من مسح بيانات هذا الفلتر؟')) return;
  currentInvoice = null;
  resetForm();
  showScreen('screen-add');
}

// ═══════════════════════════════════════════════════════
// خلية التاريخ الرقمي داخل الجداول
// ═══════════════════════════════════════════════════════
// خانة واحدة تجمع اسم اليوم والتاريخ (بدل خليتين منفصلتين)
function dayUnitHTML(day, iso) {
  const name = dayNameOnly(day);
  const date = fmtDate(iso);
  return `<div class="day-unit"><span class="day-unit-name">${name}</span><span class="day-unit-date">${date}</span></div>`;
}
function dateCellHTML(i, kind, value) {
  const fn = kind === 'qty' ? 'updateQty' : (kind === 'sales' ? 'updateSales' : 'updateMoney');
  return `
    <div class="row-date">
      <input type="text" class="row-date-text" value="${fmtDate(value)}"
             placeholder="📆" readonly tabindex="-1">
      <input type="date" class="row-date-picker" value="${value}"
             disabled aria-label="تاريخ محدد من نطاق الفلتر">
    </div>`;
}

// ═══════════════════════════════════════════════════════
// الجدول الأول: عمود الكميه
// ═══════════════════════════════════════════════════════
function renderQtyTable() {
  const tbody = document.getElementById('qty-body');
  tbody.innerHTML = '';
  currentInvoice.qtyRows.forEach((r, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="day-col">
        ${dayUnitHTML(r.day, r.date)}
      </td>
      <td><input type="text" value="${r.qty}"     readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.cash}"    readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.debt}"    readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.expense}" readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" id="q-rem-${i}" readonly class="readonly" style="font-weight:800;"></td>
    `;
    tbody.appendChild(tr);
  });

  const tr = document.createElement('tr');
  tr.className = 'total-row';
  tr.innerHTML = `
    <td style="font-weight:900;">الجملة</td>
    <td id="q-tot-qty"></td>
    <td id="q-tot-cash"></td>
    <td id="q-tot-debt"></td>
    <td id="q-tot-exp"></td>
    <td id="q-tot-rem" style="font-weight:900;"></td>
  `;
  tbody.appendChild(tr);
}

// ═══════════════════════════════════════════════════════
// الجدول الثاني: عمود البيع
// ═══════════════════════════════════════════════════════
function renderSalesTable() {
  const tbody = document.getElementById('sales-body');
  tbody.innerHTML = '';
  currentInvoice.salesRows.forEach((r, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="day-col">
        ${dayUnitHTML(r.day, r.date)}
      </td>
      <td><input type="text" value="${r.cash}" readonly inputmode="none" title="تعبأ البيانات من الفواتير" aria-label="نقد الباقي"></td>
      <td>
        <input type="text" value="${r.weeklyAmt}" placeholder="المبلغ" readonly inputmode="none" title="تعبأ البيانات من الفواتير" aria-label="مسلم فلوس">
        <input type="text" value="${r.weeklyNote}" placeholder="ملاحظة" data-nf-oninput="updateSales(${i},'weeklyNote',this.value)" aria-label="ملاحظة المسلم" style="font-size:11px;color:#7B6B6B;">
      </td>
      <td>
        <input type="text" value="${r.weeklySalesAmt || ''}" placeholder="المبلغ" readonly inputmode="none" title="تعبأ البيانات من الفواتير" aria-label="مسلم أسبوع">
        <input type="text" value="${r.weeklySalesNote || ''}" placeholder="ملاحظة" data-nf-oninput="updateSales(${i},'weeklySalesNote',this.value)" aria-label="ملاحظة مسلم أسبوع" style="font-size:11px;color:#7B6B6B;">
      </td>
      <td>
        <input type="text" value="${r.prevAmt}" placeholder="المبلغ" readonly inputmode="none" title="تعبأ البيانات من الفواتير" aria-label="السحب فلوس">
        <input type="text" value="${r.prevNote}" placeholder="ملاحظة" data-nf-oninput="updateSales(${i},'prevNote',this.value)" aria-label="ملاحظة السحب" style="font-size:11px;color:#7B6B6B;">
      </td>
      <td><input type="text" id="s-tot-${i}" readonly class="readonly" style="font-weight:800;"></td>
    `;
    tbody.appendChild(tr);
  });

  const tr = document.createElement('tr');
  tr.className = 'total-row';
  tr.innerHTML = `
    <td style="font-weight:900;">الجملة</td>
    <td id="s-tot-cash"></td>
    <td id="s-tot-weekly"></td>
    <td id="s-tot-wsales"></td>
    <td id="s-tot-prev"></td>
    <td id="s-tot-all" style="font-weight:900;"></td>
  `;
  tbody.appendChild(tr);
}

// ═══════════════════════════════════════════════════════
// الجدول الثالث: العملات
// ═══════════════════════════════════════════════════════
function renderMoneyTable() {
  const tbody = document.getElementById('money-body');
  tbody.innerHTML = '';
  currentInvoice.moneyRows.forEach((r, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="day-col">
        ${dayUnitHTML(r.day, r.date)}
      </td>
      <td><input type="text" value="${r.yemeni}"     readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.saudiAmt}"   readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.saudiExch}"  readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.omaniAmt}"   readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.omaniExch}"  readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.dirhamAmt || ''}" readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" value="${r.dirhamExch || ''}" readonly inputmode="none" title="تعبأ البيانات من الفواتير"></td>
      <td><input type="text" id="m-tot-${i}" readonly class="readonly" style="font-weight:800;"></td>
    `;
    tbody.appendChild(tr);
  });

  const tr = document.createElement('tr');
  tr.className = 'total-row';
  tr.innerHTML = `
    <td style="font-weight:900;">الجملة</td>
    <td id="m-tot-yemeni"></td>
    <td id="m-tot-saudi-amt"></td>
    <td id="m-tot-saudi-exch"></td>
    <td id="m-tot-omani-amt"></td>
    <td id="m-tot-omani-exch"></td>
    <td id="m-tot-dirham-amt"></td>
    <td id="m-tot-dirham-exch"></td>
    <td id="m-tot-all" style="font-weight:900;"></td>
  `;
  tbody.appendChild(tr);
}

// ═══════════════════════════════════════════════════════
// تحديث الصفوف
// ═══════════════════════════════════════════════════════
function updateQty(i, f, v)   { currentInvoice.qtyRows[i][f]   = v; recalcQty(); }
function updateSales(i, f, v) { currentInvoice.salesRows[i][f] = v; recalcSales(); recalcAll(); }
function updateMoney(i, f, v) { currentInvoice.moneyRows[i][f] = v; recalcMoney(); recalcAll(); }

// ═══════════════════════════════════════════════════════
// الحسابات
// ═══════════════════════════════════════════════════════
function recalcQty() {
  if (!currentInvoice) return null;
  let tQ = 0, tC = 0, tD = 0, tE = 0;
  let cumulativeRem = 0;
  currentInvoice.qtyRows.forEach((r, i) => {
    const q = numVal(r.qty), c = numVal(r.cash), d = numVal(r.debt), e = numVal(r.expense);
    cumulativeRem = cumulativeRem + q - c - d - e;
    tQ += q; tC += c; tD += d; tE += e;
    setVal(`q-rem-${i}`, fmt(cumulativeRem));
  });
  setTxt('q-tot-qty', fmt(tQ));
  setTxt('q-tot-cash', fmt(tC));
  setTxt('q-tot-debt', fmt(tD));
  setTxt('q-tot-exp', fmt(tE));
  setTxt('q-tot-rem', fmt(cumulativeRem));
  return { tQ, tC, tD, tE, tR: cumulativeRem };
}

function recalcSales() {
  if (!currentInvoice) return null;
  let tC = 0, tW = 0, tWS = 0, tP = 0, tAll = 0;
  currentInvoice.salesRows.forEach((r, i) => {
    const c = numVal(r.cash), w = numVal(r.weeklyAmt), ws = numVal(r.weeklySalesAmt), p = numVal(r.prevAmt);
    const tot = c + w + ws - p;
    tC += c; tW += w; tWS += ws; tP += p; tAll += tot;
    setVal(`s-tot-${i}`, fmt(tot));
  });
  setTxt('s-tot-cash', fmt(tC));
  setTxt('s-tot-weekly', fmt(tW));
  setTxt('s-tot-wsales', fmt(tWS));
  setTxt('s-tot-prev', fmt(tP));
  setTxt('s-tot-all', fmt(tAll));
  return { tC, tW, tWS, tP, tAll };
}

function recalcMoney() {
  if (!currentInvoice) return null;
  let tY = 0, tSAmt = 0, tSExch = 0, tOAmt = 0, tOExch = 0, tDAmt = 0, tDExch = 0, tAll = 0;
  currentInvoice.moneyRows.forEach((r, i) => {
    const y  = numVal(r.yemeni);
    const sa = numVal(r.saudiAmt), se = numVal(r.saudiExch);
    const oa = numVal(r.omaniAmt), oe = numVal(r.omaniExch);
    const da = numVal(r.dirhamAmt), de = numVal(r.dirhamExch);
    const tot = y + se + oe + de;
    tY += y; tSAmt += sa; tSExch += se; tOAmt += oa; tOExch += oe; tDAmt += da; tDExch += de; tAll += tot;
    setVal(`m-tot-${i}`, fmt(tot));
  });
  setTxt('m-tot-yemeni', fmt(tY));
  setTxt('m-tot-saudi-amt', fmt(tSAmt));
  setTxt('m-tot-saudi-exch', fmt(tSExch));
  setTxt('m-tot-omani-amt', fmt(tOAmt));
  setTxt('m-tot-omani-exch', fmt(tOExch));
  setTxt('m-tot-dirham-amt', fmt(tDAmt));
  setTxt('m-tot-dirham-exch', fmt(tDExch));
  setTxt('m-tot-all', fmt(tAll));
  return { tY, tSAmt, tSExch, tOAmt, tOExch, tDAmt, tDExch, tAll };
}

function recalcAll() {
  if (!currentInvoice) return;
  recalcQty();
  const s = recalcSales() || { tC: 0, tW: 0, tWS: 0, tP: 0, tAll: 0 };
  const m = recalcMoney() || { tY: 0, tSExch: 0, tOExch: 0, tDExch: 0, tAll: 0 };

  setTxt('rec-sales-cash', fmt(s.tC));
  setTxt('rec-sales-weekly', fmt(s.tW));
  setTxt('rec-sales-wsales', fmt(s.tWS));
  setTxt('rec-sales-prev', fmt(s.tP));
  setTxt('rec-sales-total', fmt(s.tAll));

  setTxt('rec-money-yemeni', fmt(m.tY));
  setTxt('rec-money-saudi', fmt(m.tSExch));
  setTxt('rec-money-omani', fmt(m.tOExch));
  setTxt('rec-money-dirham', fmt(m.tDExch));
  setTxt('rec-money-total', fmt(m.tAll));

  const diff = s.tAll - m.tAll;
  const diffEl = document.getElementById('rec-diff');
  const diffRow = document.getElementById('rec-diff-row');

  if (diff === 0) {
    diffEl.textContent = '0';
    diffEl.className = 'val-box highlight-green';
    diffRow.className = 'calc-row total';
  } else {
    diffEl.textContent = fmt(Math.abs(diff));
    diffEl.className = diff > 0 ? 'val-box highlight-blue' : 'val-box highlight-red';
    diffRow.className = 'calc-row total highlight-red';
  }
}

/* ═══ طباعة A4 بنفس تصميم الجداول ═══ */
var __PRINT_CSS = `
@page { size: A4; margin: 10mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Tajawal', Arial, Tahoma, sans-serif; color: #1A1A2E; background: #fff;
  font-size: 11px; line-height: 1.4; direction: rtl;
  -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.pdoc { width: 100%; }
.doc-head { text-align: center; border-bottom: 2px solid #6B1A2F; padding-bottom: 6px; margin-bottom: 8px; }
.nf-doc-title { font-size: 18px; font-weight: 900; color: #4A1520; }
.doc-sub { font-size: 13px; font-weight: 700; color: #6B1A2F; margin-top: 2px; }
.header-info { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-bottom: 8px; }
.header-info .item { border: 1px solid #E8D8DD; border-radius: 6px; background: #F5F0F1;
  padding: 5px 4px; text-align: center; font-size: 10px; color: #7B6B6B; font-weight: 600; }
.header-info .item b { display: block; font-size: 9px; color: #9E8E8E; margin-bottom: 2px; }
.header-info .item span { font-size: 12px; font-weight: 800; color: #1A1A2E; }
.sec { background: #6B1A2F; color: #fff; text-align: center; padding: 5px; border-radius: 4px;
  font-size: 12px; font-weight: 900; margin: 8px 0 4px; break-after: avoid; page-break-after: avoid; }
.tw { margin-bottom: 6px; }
.data-table { width: 100%; border-collapse: collapse; font-size: 10.5px; }
.data-table thead { display: table-header-group; }
.data-table tr { break-inside: avoid; page-break-inside: avoid; }
.data-table th, .data-table td { border: 1px solid #E8D8DD; padding: 4px 3px; text-align: center;
  vertical-align: middle; font-weight: 600; color: #1A1A2E; background: #fff; }
.data-table th { background: #6B1A2F; color: #fff; font-weight: 800; font-size: 10px; border-color: #6B1A2F; }
.data-table .day-col { background: #F5F0F1; font-weight: 800; color: #4A1520; }
.data-table .total-row td { background: #F5E1E7; font-weight: 900; color: #4A1520; border-top: 2px solid #6B1A2F; }
.pv { display: block; background: transparent !important; border: 0; line-height: 1.3; padding: 0; }
.calc-box { border: 1px solid #E8D8DD; border-radius: 6px; padding: 4px 10px; margin-top: 4px; break-inside: avoid; page-break-inside: avoid; }
.calc-row { display: flex; justify-content: space-between; align-items: center; gap: 10px;
  padding: 4px 0; border-bottom: 1px dashed #E8D8DD; }
.calc-row:last-child { border-bottom: 0; }
.calc-row .lbl { font-size: 11px; font-weight: 700; color: #7B6B6B; flex: 1; }
.calc-row .val-box { min-width: 110px; text-align: center; font-weight: 800; font-size: 12px;
  border: 1px solid #E8D8DD; border-radius: 4px; padding: 2px 8px; color: #1A1A2E; }
.calc-row.total { font-weight: 900; border-top: 2px solid #F5E1E7; margin-top: 3px; padding-top: 6px; }
.highlight-red { color: #E53935 !important; }
.highlight-green { color: #43A047 !important; }
.highlight-blue { color: #1E88E5 !important; }
`;
function __pEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
// نسخة ثابتة من العنصر: الحقول والأزرار (أزرار التقويم) تُحذف أو تتحول إلى نص
function __staticCopy(el) {
  var c = el.cloneNode(true);
  var src = el.querySelectorAll('input,textarea,select');
  var dst = c.querySelectorAll('input,textarea,select');
  Array.prototype.forEach.call(dst, function (node, i) {
    var s = src[i];
    var v = (s && s.type !== 'date' && !s.classList.contains('row-date-picker') && !s.classList.contains('dx-native')) ? String(s.value || '').trim() : '';
    if (!v) { if (node.parentNode) node.parentNode.removeChild(node); return; }
    var sp = document.createElement('span');
    sp.className = 'pv';
    var st = node.getAttribute('style');
    if (st) sp.setAttribute('style', st);
    sp.textContent = v;
    node.parentNode.replaceChild(sp, node);
  });
  Array.prototype.forEach.call(c.querySelectorAll('button,.dx-btn'), function (n) { if (n.parentNode) n.parentNode.removeChild(n); });
  Array.prototype.forEach.call(c.querySelectorAll('[id]'), function (n) { n.removeAttribute('id'); });
  return c;
}
// جسم المستند لفلتر واحد (بدون غلاف)، ليُستخدم في طباعة الفلتر الواحد وطباعة عدة فلاتر
window.__weeklyPrintBody = function () {
  var g = function (id) { var e = document.getElementById(id); return e ? e.textContent.trim() : ''; };
  var name = g('h-name') || (currentInvoice && currentInvoice.name) || '';
  var parts = '<div class="doc-head"><div class="nf-doc-title">الفلتر الأسبوعي</div><div class="doc-sub">' + __pEsc(name) + '</div></div>';
  var head = document.getElementById('edit-header');
  if (head) parts += __staticCopy(head).outerHTML;
  var nodes = document.querySelectorAll('#screen-edit > .nf-section-header, #screen-edit > .nf-table-wrapper, #screen-edit > .calc-box');
  Array.prototype.forEach.call(nodes, function (el) {
    if (el.classList.contains('nf-section-header')) parts += '<div class="sec">' + __pEsc(el.textContent.trim()) + '</div>';
    else if (el.classList.contains('nf-table-wrapper')) parts += '<div class="tw">' + __staticCopy(el.querySelector('table')).outerHTML + '</div>';
    else parts += __staticCopy(el).outerHTML;
  });
  return parts;
};
// مستند كامل لفلتر واحد
window.__buildWeeklyPrintHtml = function () {
  var name = (document.getElementById('h-name') || {}).textContent || (currentInvoice && currentInvoice.name) || '';
  return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">' +
    '<title>' + __pEsc('الفلتر الأسبوعي' + (name ? ' - ' + name : '')) + '</title>' +
    '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap">' +
    '<style>' + __PRINT_CSS + '</style></head><body><div class="pdoc">' + window.__weeklyPrintBody() + '</div></body></html>';
};

/* exports: global functions of the former iframe page */
try{window.toEnDigits=toEnDigits}catch(_e){}
try{window.dayNameOnly=dayNameOnly}catch(_e){}
try{window.blockArabicNums=blockArabicNums}catch(_e){}
try{window.numVal=numVal}catch(_e){}
try{window.fmt=fmt}catch(_e){}
try{window.setVal=setVal}catch(_e){}
try{window.setTxt=setTxt}catch(_e){}
try{window.fmtDate=fmtDate}catch(_e){}
try{window.parseNumericDate=parseNumericDate}catch(_e){}
try{window.applyTypedDate=applyTypedDate}catch(_e){}
try{window.localISODate=localISODate}catch(_e){}
try{window.buildWeekSlots=buildWeekSlots}catch(_e){}
try{window.newInvoiceData=newInvoiceData}catch(_e){}
try{window.showScreen=showScreen}catch(_e){}
try{window.saveAndOpenInvoice=saveAndOpenInvoice}catch(_e){}
try{window.resetForm=resetForm}catch(_e){}
try{window.saveWeeklyStructure=saveWeeklyStructure}catch(_e){}
try{window.backToAdd=backToAdd}catch(_e){}
try{window.clearInvoice=clearInvoice}catch(_e){}
try{window.dateCellHTML=dateCellHTML}catch(_e){}
try{window.renderQtyTable=renderQtyTable}catch(_e){}
try{window.renderSalesTable=renderSalesTable}catch(_e){}
try{window.renderMoneyTable=renderMoneyTable}catch(_e){}
try{window.updateQty=updateQty}catch(_e){}
try{window.updateSales=updateSales}catch(_e){}
try{window.updateMoney=updateMoney}catch(_e){}
try{window.recalcQty=recalcQty}catch(_e){}
try{window.recalcSales=recalcSales}catch(_e){}
try{window.recalcMoney=recalcMoney}catch(_e){}
try{window.recalcAll=recalcAll}catch(_e){}
try{window.__pEsc=__pEsc}catch(_e){}
try{window.__staticCopy=__staticCopy}catch(_e){}
try{window.__PRINT_CSS=__PRINT_CSS}catch(_e){}

__nf.setEval(function(__code,event){return eval(__code)});
}};

var EV={click:'click',change:'change',input:'input',keyup:'keyup',keydown:'keydown',keypress:'keypress',submit:'submit',dblclick:'dblclick',blur:'focusout',focus:'focusin'};
function cssEsc(s){return window.CSS&&CSS.escape?CSS.escape(s):String(s).replace(/([^\w-])/g,'\\$1')}
function ensureCss(name){var id='nf-css-'+name;if(document.getElementById(id))return;var s=document.createElement('style');s.id=id;s.textContent=DEFS[name].css;document.head.appendChild(s)}

/* mount(name, container, onMessage) -> {el, post(msg), destroy()} */
NF.mount=function(name,container,onMessage){
  var def=DEFS[name];if(!def)throw new Error('unknown native form: '+name);
  var D=document,W=window;
  ensureCss(name);
  var host=D.createElement('div');host.className='nf-host nf-native nf-'+name;host.innerHTML=def.html;
  var head=D.createElement('div'),store=Object.create(null),inbox=[],timers=[],tracked=[],alive=true,evalFn=null,inst;
  function dispatch(msg){inbox.slice().forEach(function(fn){try{fn({data:msg,source:parentShim,origin:W.location.origin})}catch(e){console.error(e)}})}
  var docShim=new Proxy(D,{get:function(t,k){
    switch(k){
      case 'getElementById':return function(id){return host.querySelector('#'+cssEsc(id))};
      case 'querySelector':return function(s){return host.querySelector(s)};
      case 'querySelectorAll':return function(s){return host.querySelectorAll(s)};
      case 'getElementsByClassName':return function(s){return host.getElementsByClassName(s)};
      case 'getElementsByTagName':return function(s){return host.getElementsByTagName(s)};
      case 'body':case 'documentElement':return host;
      case 'head':return head;
      case 'addEventListener':return function(){return host.addEventListener.apply(host,arguments)};
      case 'removeEventListener':return function(){return host.removeEventListener.apply(host,arguments)};
    }
    var v=t[k];return typeof v==='function'?v.bind(t):v},
    set:function(t,k,v){t[k]=v;return true}});
  var parentShim=new Proxy({},{get:function(t,k){
    if(k==='postMessage')return function(m){if(alive&&onMessage)onMessage(m,inst)};
    var v=W[k];return typeof v==='function'&&!/^[A-Z]/.test(String(k))?v.bind(W):v}});
  var winShim=new Proxy(store,{
    has:function(t,k){return k in t},
    get:function(t,k){
      if(k in t)return t[k];
      switch(k){
        case 'window':case 'self':return winShim;
        case 'parent':case 'top':return parentShim;
        case 'document':return docShim;
        case 'eval':return function(code){return evalFn?evalFn.call(winShim,String(code),undefined):undefined};
        case 'postMessage':return function(m){W.setTimeout(function(){if(alive)dispatch(m)},0)};
        case 'addEventListener':return function(type,fn,opt){
          if(type==='message'){inbox.push(fn)}
          else if(type==='load'||type==='DOMContentLoaded'){timers.push(W.setTimeout(function(){if(alive)fn.call(winShim,{type:type})},0))}
          else{tracked.push([type,fn,opt]);W.addEventListener(type,fn,opt)}};
        case 'removeEventListener':return function(type,fn,opt){
          if(type==='message'){inbox=inbox.filter(function(x){return x!==fn})}else W.removeEventListener(type,fn,opt)};
      }
      var v=W[k];return typeof v==='function'&&!/^[A-Z]/.test(String(k))?v.bind(W):v},
    set:function(t,k,v){t[k]=v;return true}});
  function st(fn,ms){var id=W.setTimeout(function(){if(alive)fn.apply(null,[].slice.call(arguments,2))},ms);timers.push(id);return id}
  function si(fn,ms){var id=W.setInterval(function(){if(alive)fn()},ms);timers.push(id);return id}
  /* inline on* handlers are rewritten to data-nf-on*; run them here, with the form's own scope */
  var delegated=[];
  Object.keys(EV).forEach(function(k){
    var h=function(ev){
      if(!evalFn)return;var attr='data-nf-on'+k,el=ev.target;
      while(el&&el.nodeType===1){
        if(el.hasAttribute&&el.hasAttribute(attr)){var r;try{r=evalFn.call(el,el.getAttribute(attr),ev)}catch(e){console.error(e)}
          if(r===false)ev.preventDefault();if(ev.cancelBubble)break}
        if(el===host)break;el=el.parentNode}
    };
    host.addEventListener(EV[k],h);delegated.push([EV[k],h]);
  });
  container.appendChild(host);
  def.run(docShim,winShim,parentShim,st,function(i){W.clearTimeout(i)},si,function(i){W.clearInterval(i)},{setEval:function(f){evalFn=f}});
  inst={el:host,win:winShim,doc:docShim,
    post:function(msg){W.setTimeout(function(){if(alive)dispatch(msg)},0)},
    destroy:function(){alive=false;timers.forEach(function(i){W.clearTimeout(i);W.clearInterval(i)});tracked.forEach(function(a){W.removeEventListener(a[0],a[1],a[2])});inbox=[];if(host.parentNode)host.parentNode.removeChild(host)}};
  return inst;
};

/* printFrame(inst) -> object shaped like an iframe ({contentDocument, contentWindow}) holding a standalone snapshot of the
   form (values baked in) so the app's PDF / print pipeline can treat it exactly like the former frame document. */
NF.printFrame=function(inst){
  var D=document,d=D.implementation.createHTMLDocument('');
  var cls=inst.el.className,m=/nf-(\w+)/.exec(cls.replace('nf-host','').replace('nf-native',''));
  var def=DEFS[m?m[1]:''];
  d.documentElement.setAttribute('dir','rtl');d.documentElement.setAttribute('lang','ar');
  var meta=d.createElement('meta');meta.setAttribute('charset','utf-8');d.head.appendChild(meta);
  var st=d.createElement('style');st.textContent=(def?def.css:'')+'body{margin:0}';d.head.appendChild(st);
  var cl=inst.el.cloneNode(true);
  var a=inst.el.querySelectorAll('input,textarea,select'),b=cl.querySelectorAll('input,textarea,select');
  Array.prototype.forEach.call(a,function(el,i){var c=b[i];if(!c)return;
    if(el.tagName==='TEXTAREA')c.textContent=el.value;
    else if(el.tagName==='SELECT'){Array.prototype.forEach.call(c.options,function(o,k){if(el.options[k]&&el.options[k].selected)o.setAttribute('selected','selected');else o.removeAttribute('selected')})}
    else if(el.type==='checkbox'||el.type==='radio'){if(el.checked)c.setAttribute('checked','checked');else c.removeAttribute('checked')}
    else c.setAttribute('value',el.value)});
  var cs=getComputedStyle(D.documentElement),vars=['--primary','--primary-dark','--primary-light','--bg','--bg2','--text','--text2','--muted','--line','--radius'],sty=cl.getAttribute('style')||'';
  vars.forEach(function(v){var x=(cs.getPropertyValue(v)||'').trim();if(x)sty+=';'+v+':'+x});
  cl.setAttribute('style',sty);
  d.body.appendChild(cl);
  return {contentDocument:d,contentWindow:{focus:function(){},print:function(){var h='<!doctype html>'+d.documentElement.outerHTML;if(window.__printHtmlInFrame)window.__printHtmlInFrame(h);else window.print()}}};
};
})();

/* ===== BEGIN private accounts module ===== */
/* الحسابات الخصوصية — صفحة من داخل التطبيق الرئيسي.
   - تُحفظ في data.privateAccounts (داخل بيانات التطبيق نفسها) ولا تختلط بحسابات الصرافة.
   - تدخل تلقائياً في النسخ الاحتياطي والاستعادة وGoogle Drive لأنها جزء من data.
   - تستخدم عملات التطبيق، وسلة المحذوفات، وإعدادات الطباعة، والرسائل والواتساب.
   - التنسيق مدمج في css/style.css. */
(function () {
  'use strict';

  var S = { tsort: 'date', tasc: true, view: 'home', fid: null, aid: null, cur: '', from: '', to: '', sort: 'name', asc: true, mode: 'month', prev: false };
  var host = null;

  /* ---------- أدوات عامة ---------- */
  function E(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function today() { return ymd(new Date()); }
  function monthStart(v) { return v.slice(0, 8) + '01'; }
  function shift(v, m) {
    var q = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ''); if (!q) return v;
    var f = new Date(+q[1], +q[2] - 1 + m, 1);
    var last = new Date(f.getFullYear(), f.getMonth() + 1, 0).getDate();
    return ymd(new Date(f.getFullYear(), f.getMonth(), Math.min(+q[3], last)));
  }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }); }
  function uid(p) { return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  /* ---------- التخزين: داخل بيانات التطبيق الرئيسية ---------- */
  function store() {
    if (!data.privateAccounts || !Array.isArray(data.privateAccounts.folders) ||
        !Array.isArray(data.privateAccounts.accounts) || !Array.isArray(data.privateAccounts.txs)) {
      data.privateAccounts = { folders: [], accounts: [], txs: [] };
    }
    return data.privateAccounts;
  }

  /* ---------- العملات: من إعدادات التطبيق ---------- */
  function curList() {
    var l = ((data.settings && data.settings.currencies) || []).filter(function (c) { return c && c.name; })
      .map(function (c) { return { n: c.name, s: c.symbol || c.name, def: !!c.isDefault }; });
    if (!l.length) l = [{ n: 'ريال يمني', s: 'ر.ي', def: true }];
    return l;
  }
  function defCur() { var l = curList(); return (l.find(function (c) { return c.def; }) || l[0]).n; }
  function symOf(n) { var c = curList().find(function (x) { return x.n === n; }); return c ? c.s : n; }
  var ALL = '*';
  function ensureCur() { if (S.cur !== ALL && (!S.cur || !curList().some(function (c) { return c.n === S.cur; }))) S.cur = defCur(); }
  function isAll() { return S.cur === ALL; }
  function curMatch(t) { return isAll() || t.cur === S.cur; }
  function usedCurs(pred) {
    var seen = {}; store().txs.forEach(function (t) { if (!pred || pred(t)) seen[t.cur] = 1; });
    var l = curList().map(function (c) { return c.n; }).filter(function (n) { return seen[n]; });
    Object.keys(seen).forEach(function (n) { if (l.indexOf(n) < 0) l.push(n); });
    return l;
  }
  function curKeys(pred) { return isAll() ? usedCurs(pred) : [S.cur]; }

  /* ---------- الحسابات ----------
     الرصيد = مجموع «عليه» − مجموع «له». الموجب: الحساب مدين لنا، والسالب: علينا له. */
  function net(aid, c, pred) {
    var st = store(), n = 0;
    st.txs.forEach(function (t) { if (t.acc === aid && t.cur === c && pred(t)) n += (t.type === 'عليه' ? 1 : -1) * num(t.amount); });
    return n;
  }
  function balAt(aid, c, to) { return net(aid, c, function (t) { return !to || t.date <= to; }); }
  function balText(b) {
    if (Math.abs(b) < 1e-9) return 'متعادل';
    return b > 0 ? 'عليه ' + fmt(b) : 'له ' + fmt(-b);
  }
  function statusHtml(b, sym) {
    var cls = Math.abs(b) < 1e-9 ? 'pa-zero' : b > 0 ? 'pa-pos' : 'pa-neg';
    return '<span class="' + cls + '">' + E(balText(b) + (sym ? ' ' + sym : '')) + '</span>';
  }
  function statusFor(accs, to) {
    if (!isAll()) return statusHtml(accs.reduce(function (s, a) { return s + balAt(a.id, S.cur, to); }, 0));
    var parts = [];
    usedCurs().forEach(function (c) {
      var n = accs.reduce(function (s, a) { return s + balAt(a.id, c, to); }, 0);
      if (Math.abs(n) > 1e-9) parts.push(statusHtml(n, symOf(c)));
    });
    return parts.length ? parts.join('<br>') : statusHtml(0);
  }
  function range() {
    var to = S.to || today();
    var from = S.mode === 'all' ? '' : S.mode === 'year' ? to.slice(0, 4) + '-01-01' : (S.from || monthStart(to));
    return { from: from, to: to };
  }
  function lastDate(aid) {
    var to = S.to || today(), last = '';
    store().txs.forEach(function (t) { if (t.acc === aid && curMatch(t) && t.date <= to && t.date > last) last = t.date; });
    return last;
  }

  /* ---------- عناصر الواجهة ---------- */
  function head(title, backAct, right) {
    return '<div class="pa-head"><button type="button" class="pa-ib" data-act="' + backAct + '" aria-label="رجوع">›</button>' +
      '<b>' + E(title) + '</b><span class="pa-right">' + (right || '') + '</span></div>';
  }
  function curRow() {
    return '<div class="pa-bar"><select class="pa-cur" data-act="cur" aria-label="العملة"><option value="' + ALL + '"' + (isAll() ? ' selected' : '') + '>كل العملات</option>' + curList().map(function (c) {
      return '<option value="' + E(c.n) + '"' + (c.n === S.cur ? ' selected' : '') + '>' + E(c.n) + '</option>';
    }).join('') + '</select><button type="button" class="pa-mcur" data-act="curs">إدارة العملات</button></div>';
  }
  /* شريط التاريخ: نفس شكل وتركيب شريط صفحات المراقب (date-range-unified) ليتبع نفس التنسيق والثيم */
  function dateBar() {
    return '<div class="date-bar date-range-unified pa-db"><button type="button" class="db-arrow" data-act="dp" aria-label="الفترة السابقة">←</button>' +
      '<div class="db-field"><input type="date" data-act="from" value="' + E(S.from) + '" aria-label="تاريخ البداية"></div>' +
      '<span class="db-sep">إلى</span>' +
      '<div class="db-field"><input type="date" data-act="to" value="' + E(S.to) + '" aria-label="تاريخ النهاية"></div>' +
      '<button type="button" class="db-arrow" data-act="dn" aria-label="الفترة التالية">→</button></div>';
  }

  function radio(n, opts, v) {
    return '<div class="pa-radios">' + opts.map(function (o) {
      return '<label><input type="radio" name="' + n + '" value="' + o[0] + '"' + (o[0] === v ? ' checked' : '') + '> ' + E(o[1]) + '</label>';
    }).join('') + '</div>';
  }
  function fld(label, input) { return '<div class="field"><label>' + E(label) + '</label>' + input + '</div>'; }
  function checked(ov, n) { var r = ov.querySelector('input[name="' + n + '"]:checked'); return r ? r.value : ''; }

  /* مبلغ المجلد: «لكم» أخضر و«عليكم» أحمر، بالعملة المختارة (أو سطر لكل عملة عند «كل العملات») */
  function folderAmounts(accs, to) {
    var keys = isAll() ? usedCurs() : [S.cur], out = [];
    keys.forEach(function (c) {
      var n = accs.reduce(function (s, a) { return s + balAt(a.id, c, to); }, 0);
      if (Math.abs(n) < 1e-9) { if (!isAll()) out.push('<span class="pa-zero">متعادل ' + E(symOf(c)) + '</span>'); return; }
      out.push('<span class="' + (n > 0 ? 'pa-pos' : 'pa-neg') + '">' + (n > 0 ? 'لكم ' : 'عليكم ') + fmt(Math.abs(n)) + ' ' + E(symOf(c)) + '</span>');
    });
    return out.length ? out.join('<br>') : '<span class="pa-zero">متعادل</span>';
  }

  /* ---------- الشاشات ---------- */
  function viewHome(st) {
    var to = S.to || today();
    var gs = st.folders.slice().sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
    var cards = gs.map(function (g) {
      var accs = st.accounts.filter(function (a) { return a.fid === g.id; });
      return '<div class="pa-card" data-act="fol" data-id="' + E(g.id) + '">' +
        '<span class="pa-ico">👥</span><div class="pa-fm"><b>' + E(g.name) + '</b></div>' +
        '<div class="pa-fb pa-famt">' + folderAmounts(accs, to) + '</div></div>';
    }).join('');
    return head('الحسابات الخصوصية', 'close') +
      '<div class="pa-tools"><button type="button" data-act="nf">إضافة مجلد</button>' +
      '<button type="button" data-act="stat">الإحصائيات</button>' +
      '<button type="button" data-act="qs">البحث السريع</button></div>' +
      '<div class="pa-scroll pa-grid">' + (cards || '<p class="pa-empty">لا توجد مجلدات بعد — اضغط ＋ لإضافة مجلد</p>') + '</div>' +
      '<button type="button" class="pa-fab" data-act="nf" aria-label="إضافة مجلد">＋</button>';
  }

  function viewFolder(st) {
    var g = st.folders.find(function (f) { return f.id === S.fid; });
    if (!g) { S.view = 'home'; return viewHome(st); }
    var to = S.to || today();
    var rows = st.accounts.filter(function (a) { return a.fid === g.id; }).map(function (a) {
      var b = isAll() ? usedCurs().reduce(function (s, c) { return s + Math.abs(balAt(a.id, c, to)); }, 0) : balAt(a.id, S.cur, to);
      return { a: a, b: b, html: statusFor([a], to), last: lastDate(a.id) };
    });
    rows.sort(function (p, q) {
      var r = S.sort === 'bal' ? Math.abs(p.b) - Math.abs(q.b)
        : S.sort === 'date' ? (p.last || '').localeCompare(q.last || '')
        : p.a.name.localeCompare(q.a.name, 'ar');
      return S.asc ? r : -r;
    });
    var owedUs = 0, weOwe = 0, zero = 0, oMap = {}, wMap = {};
    rows.forEach(function (r) {
      if (!isAll()) { if (r.b > 1e-9) owedUs += r.b; else if (r.b < -1e-9) weOwe -= r.b; else zero++; return; }
      var any = false;
      usedCurs().forEach(function (c) {
        var b = balAt(r.a.id, c, to);
        if (b > 1e-9) { oMap[c] = (oMap[c] || 0) + b; any = true; } else if (b < -1e-9) { wMap[c] = (wMap[c] || 0) - b; any = true; }
      });
      if (!any) zero++;
    });
    var mapHtml = function (m) {
      var k = Object.keys(m); if (!k.length) return '<b>0</b>';
      return k.map(function (c) { return '<b>' + fmt(m[c]) + ' <small>' + E(symOf(c)) + '</small></b>'; }).join('');
    };
    var list = rows.map(function (r) {
      return '<div class="person pa-acc" data-act="acc" data-id="' + E(r.a.id) + '"><span class="pa-av">' + E(String(r.a.name || '?').trim().charAt(0) || '?') + '</span>' +
        '<div class="pa-fm"><b>' + E(r.a.name) + '</b><small>' + E(r.a.ph || '') + (r.last ? ' · آخر حركة ' + E(r.last) : '') + '</small></div>' +
        '<div class="pa-fb">' + r.html + '</div></div>';
    }).join('');
    var sel = '<select class="pa-sortsel" data-act="sortsel" aria-label="ترتيب حسب">' +
      [['name', 'الاسم'], ['bal', 'الرصيد'], ['date', 'التاريخ']].map(function (o) {
        return '<option value="' + o[0] + '"' + (S.sort === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
      }).join('') + '</select>';
    return head(g.name, 'back', '<button type="button" class="pa-ib" data-act="efo" data-id="' + E(g.id) + '" aria-label="تعديل المجلد">✏️</button>') +
      curRow() +
      '<div class="pa-sum">' +
        '<div class="pa-card pa-red"><small>الإجمالي عليكم</small>' + (isAll() ? mapHtml(wMap) : '<b>' + fmt(weOwe) + '</b><small>' + E(symOf(S.cur)) + '</small>') + '</div>' +
        '<div class="pa-card pa-green"><small>الإجمالي لكم</small>' + (isAll() ? mapHtml(oMap) : '<b>' + fmt(owedUs) + '</b><small>' + E(symOf(S.cur)) + '</small>') + '</div>' +
        '<div class="pa-card"><small>لا يوجد رصيد</small><b>' + zero + '</b><small>حساب</small></div>' +
      '</div>' +
      '<div class="pa-sortbar"><span>ترتيب حسب:</span>' + sel +
        '<button type="button" class="pa-dir' + (S.asc ? ' on' : '') + '" data-act="dir" data-v="asc">↑ تصاعدي</button>' +
        '<button type="button" class="pa-dir' + (!S.asc ? ' on' : '') + '" data-act="dir" data-v="desc">↓ تنازلي</button></div>' +
      dateBar() +
      '<div class="pa-scroll">' + (list || '<p class="pa-empty">لا توجد حسابات في هذا المجلد</p>') + '</div>' +
      '<button type="button" class="pa-fab" data-act="na" aria-label="إضافة حساب">＋</button>';
  }

  /* أزرار المعاملة: عرض/إضافة صورة، مشاركة، طباعة، تعديل، حذف */
  function txButtons(t) {
    var id = E(t.id);
    function b(act, ico, label, cls) {
      return '<button type="button" class="pa-tb' + (cls || '') + '" data-act="' + act + '" data-id="' + id + '" title="' + label + '" aria-label="' + label + '">' + ico + '</button>';
    }
    return '<div class="pa-txbtns">' + b('timg', '📷', 'الصورة المرفقة أو إضافتها', t.img ? ' has-img' : '') + b('tshare', '📤', 'إرسال المعاملة') +
      b('tprint', '🖨️', 'طباعة المعاملة') + b('tedit', '✏️', 'تعديل المعاملة') + b('tdel', '🗑️', 'حذف المعاملة') + '</div>';
  }

  function viewAccount(st) {
    var a = st.accounts.find(function (x) { return x.id === S.aid; });
    if (!a) { S.view = 'folder'; return viewFolder(st); }
    var r = range();
    var keys = curKeys(function (t) { return t.acc === a.id; });
    var sym = function (c) { return isAll() ? ' ' + symOf(c) : ''; };
    var run = {}, owe = {}, have = {}, opening = {};
    keys.forEach(function (c) {
      opening[c] = r.from ? net(a.id, c, function (t) { return t.date < r.from; }) : 0;
      run[c] = opening[c]; owe[c] = 0; have[c] = 0;
    });
    var list = st.txs.filter(function (t) {
      return t.acc === a.id && curMatch(t) && (!r.from || t.date >= r.from) && t.date <= r.to;
    }).sort(function (x, y) { return String(x.date).localeCompare(String(y.date)); });

    var body = '', items = [];
    list.forEach(function (t) {
      var s = t.type === 'عليه' ? 1 : -1, amt = num(t.amount), c = t.cur;
      if (run[c] === undefined) { run[c] = 0; owe[c] = 0; have[c] = 0; opening[c] = 0; if (keys.indexOf(c) < 0) keys.push(c); }
      run[c] += s * amt;
      if (s > 0) owe[c] += amt; else have[c] += amt;
      items.push({ t: t, s: s, amt: amt, run: run[c] });
    });
    items.forEach(function (x, i) { x.i = i; });
    items.sort(function (p, q) {
      var r = S.tsort === 'amt' ? p.amt - q.amt : S.tsort === 'type' ? (p.s - q.s) || (p.i - q.i) : p.i - q.i;
      return S.tasc ? r : -r;
    });
    var openTxt = keys.map(function (c) { return fmt(opening[c]) + sym(c); }).join(' | ');
    var prevRow = S.prev && S.tsort === 'date' ? '<div class="pa-tr pa-prev"><span></span><span></span><span class="pa-det">رصيد سابق</span><span class="pa-run">' + openTxt + '</span></div>' : '';
    if (prevRow && S.tasc) body += prevRow;
    items.forEach(function (x) {
      var t = x.t, s = x.s;
      body += '<div class="pa-tr"><span class="' + (s > 0 ? 'pa-pos' : 'pa-neg') + '">' + E(t.type) + '</span>' +
        '<span class="pa-amt"><b>' + fmt(x.amt) + sym(t.cur) + '</b><small>' + E(t.date) + '</small></span>' +
        '<span class="pa-det">' + E((t.lines || []).join(' • ')) + (t.img ? ' 📷' : '') + '</span>' +
        '<span class="pa-run">' + fmt(x.run) + sym(t.cur) + '</span>' + txButtons(t) + '</div>';
    });
    if (prevRow && !S.tasc) body += prevRow;
    var sumTxt = function (m) { return keys.map(function (c) { return fmt(m[c] || 0) + sym(c); }).join(' | ') || '0'; };
    var runTxt = keys.map(function (c) { return balText(run[c] || 0) + sym(c); }).join(' | ') || 'متعادل';
    var balNow = Math.max.apply(null, [-Infinity].concat(keys.map(function (c) { return balAt(a.id, c, r.to); })));
    var banner = a.capOn && balNow > num(a.cap) ? '<div class="pa-banner">⚠️ تجاوز سقف المديونية (' + fmt(a.cap) + ')</div>' : '';
    var modeBtn = function (k, l) { return '<button type="button" class="' + (S.mode === k ? 'on' : '') + '" data-act="mode" data-v="' + k + '">' + l + '</button>'; };
    var acts = '<button type="button" class="pa-ib" data-act="xfer" data-id="' + E(a.id) + '" aria-label="قيد إلى حساب" title="قيد إلى حساب">↔</button>' +
      '<button type="button" class="pa-ib" data-act="print" data-id="' + E(a.id) + '" aria-label="طباعة" title="طباعة">🖨️</button>' +
      '<button type="button" class="pa-ib" data-act="auth" data-id="' + E(a.id) + '" aria-label="مصادقة" title="مصادقة">📝</button>';

    return head(a.name, 'back', acts) +
      banner + curRow() +
      '<div class="pa-sortbar"><span>ترتيب حسب:</span>' +
        '<select class="pa-sortsel" data-act="tsortsel" aria-label="ترتيب حسب">' +
        [['date', 'التاريخ'], ['amt', 'المبلغ'], ['type', 'النوع']].map(function (o) {
          return '<option value="' + o[0] + '"' + (S.tsort === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
        }).join('') + '</select>' +
        '<button type="button" class="pa-dir' + (S.tasc ? ' on' : '') + '" data-act="tdir" data-v="asc">↑ تصاعدي</button>' +
        '<button type="button" class="pa-dir' + (!S.tasc ? ' on' : '') + '" data-act="tdir" data-v="desc">↓ تنازلي</button></div>' +
      '<div class="pa-modebar">' + modeBtn('month', 'شهري') + modeBtn('all', 'الكل') + modeBtn('year', 'سنوي') +
        '<label class="pa-prevchk"><input type="checkbox" data-act="prev"' + (S.prev ? ' checked' : '') + '> رصيد سابق</label></div>' +
      dateBar() +
      '<div class="pa-th"><span>النوع</span><span>المبلغ</span><span>التفاصيل</span><span>الرصيد</span></div>' +
      '<div class="pa-scroll">' + (body || '<p class="pa-empty">لا توجد حركات في هذه الفترة</p>') + '</div>' +
      '<div class="pa-foot"><span>عليه: ' + E(sumTxt(owe)) + '</span><span>له: ' + E(sumTxt(have)) + '</span><span>الرصيد: ' + E(runTxt) + '</span></div>' +
      '<button type="button" class="pa-fab pa-fab-up" data-act="nt" aria-label="إضافة معاملة">＋</button>';
  }

  /* ---------- النوافذ (بفئات التطبيق .overlay و.sheet) ---------- */
  function dialog(title, body, onOk, onMount) {
    var ov = document.createElement('div');
    ov.className = 'overlay show pa-ov';
    ov.innerHTML = '<div class="sheet"><h2>' + E(title) + '</h2><div class="pa-form">' + body + '</div>' +
      '<div class="pa-actions"><button type="button" class="btn secondary" data-x>إلغاء</button>' +
      (onOk ? '<button type="button" class="btn primary" data-ok>💾 حفظ</button>' : '') + '</div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', function (e) {
      if (e.target === ov || e.target.closest('[data-x]')) { ov.remove(); return; }
      if (onOk && e.target.closest('[data-ok]')) { if (onOk(ov) !== false) ov.remove(); }
    });
    if (onMount) onMount(ov);
    return ov;
  }

  function folderDialog(id) {
    var st = store(), g = id ? st.folders.find(function (x) { return x.id === id; }) : null;
    var body = fld('اسم المجلد', '<input id="pfN" value="' + E(g ? g.name : '') + '">') +
      fld('ترتيب المجلد', '<input id="pfO" type="number" value="' + (g ? (g.order || 0) : st.folders.length + 1) + '">') +
      (g ? '<button type="button" class="btn danger" data-del>🗑 حذف المجلد</button>' : '');
    dialog(g ? 'تعديل مجلد' : '📁 إضافة/تعديل مجلد', body, function (ov) {
      var n = ov.querySelector('#pfN').value.trim();
      if (!n) { toast('أدخل اسم المجلد'); return false; }
      var s2 = store();
      if (g) {
        var x = s2.folders.find(function (z) { return z.id === id; });
        if (x) { x.name = n; x.order = num(ov.querySelector('#pfO').value); }
      } else {
        s2.folders.push({ id: uid('f'), name: n, order: num(ov.querySelector('#pfO').value) || s2.folders.length + 1 });
      }
      save(); render();
    }, function (ov) {
      var del = ov.querySelector('[data-del]');
      if (!del) return;
      del.addEventListener('click', function () {
        var s3 = store();
        if (s3.accounts.some(function (a) { return a.fid === id; })) { toast('انقل حسابات هذا المجلد أو احذفها أولاً'); return; }
        ov.remove();
        customConfirm('نقل المجلد إلى سلة المحذوفات؟', function () {
          var s4 = store(), f = s4.folders.find(function (z) { return z.id === id; });
          if (!f) return;
          s4.folders = s4.folders.filter(function (z) { return z.id !== id; });
          S.view = 'home';
          addToTrash(f, 'paFolder', f.name, null);
          render();
        }, null, { title: 'حذف المجلد', icon: '🗑️', danger: true, confirmText: 'حذف' });
      });
    });
  }

  function accountDialog(id) {
    var st = store(), a = id ? (st.accounts.find(function (x) { return x.id === id; }) || {}) : {};
    var fid = a.fid || S.fid;
    var defTime = (data.settings && data.settings.paTiming) || 'confirm';
    var defSend = (data.settings && data.settings.sendMethod) || 'whatsapp';
    var body = fld('الاسم', '<input id="paN" placeholder="ادخل الاسم" value="' + E(a.name || '') + '">') +
      fld('رقم الهاتف', '<div class="pa-row"><input id="paP" inputmode="tel" placeholder="اختر رقم الهاتف من الأسماء" value="' + E(a.ph || '') + '"><button type="button" class="pa-pickbtn" data-pick aria-label="جهات الاتصال">👥</button></div>') +
      '<label class="pa-sw"><span>إضافة سقف مديونية</span><input type="checkbox" id="paCapOn"' + (a.capOn ? ' checked' : '') + '></label>' +
      '<div id="paCapWrap" style="display:' + (a.capOn ? 'block' : 'none') + '">' + fld('مبلغ السقف', '<input id="paCap" type="number" inputmode="decimal" value="' + (a.cap || '') + '">') + '</div>' +
      '<div class="field"><label>طريقة إرسال الرسائل</label>' + radio('paSend', [['whatsapp', 'واتساب'], ['sms', 'SMS']], a.send || defSend) + '</div>' +
      '<div class="field"><label>إرسال الرسائل</label>' + radio('paTime', [['auto', 'تلقائي'], ['confirm', 'بعد التأكيد'], ['never', 'لا ترسل']], a.time || defTime) + '</div>';
    dialog(id ? 'تعديل الحساب' : '👥 إضافة حساب جديد', body, function (ov) {
      var n = ov.querySelector('#paN').value.trim();
      if (!n) { toast('أدخل الاسم'); return false; }
      var capOn = ov.querySelector('#paCapOn').checked, cap = num(ov.querySelector('#paCap').value);
      if (capOn && !(cap > 0)) { toast('أدخل سقفاً أكبر من صفر'); return false; }
      var s2 = store();
      if (s2.accounts.some(function (x) { return x.fid === fid && x.name === n && x.id !== id; })) { toast('يوجد حساب بنفس الاسم في هذا المجلد'); return false; }
      var x = id ? s2.accounts.find(function (z) { return z.id === id; }) : null;
      if (!x) { x = { id: uid('a'), fid: fid }; s2.accounts.push(x); }
      x.name = n;
      x.ph = ov.querySelector('#paP').value.trim();
      x.capOn = capOn;
      x.cap = capOn ? cap : 0;
      x.send = checked(ov, 'paSend') || defSend;
      x.time = checked(ov, 'paTime') || defTime;
      save(); render();
    }, function (ov) {
      ov.querySelector('#paCapOn').addEventListener('change', function () {
        ov.querySelector('#paCapWrap').style.display = this.checked ? 'block' : 'none';
      });
      ov.addEventListener('click', async function (e) {
        if (!e.target.closest('[data-pick]')) return;
        try {
          if (navigator.contacts && navigator.contacts.select) {
            var r = await navigator.contacts.select(['name', 'tel'], { multiple: false });
            var c = r && r[0]; if (!c) return;
            var nm = [].concat(c.name || [])[0], tl = [].concat(c.tel || [])[0];
            if (nm && !ov.querySelector('#paN').value.trim()) ov.querySelector('#paN').value = nm;
            if (tl) ov.querySelector('#paP').value = tl;
          } else {
            toast('اختيار جهات الاتصال غير مدعوم في هذا المتصفح');
          }
        } catch (err) { /* أُلغي الاختيار */ }
      });
    });
  }

  /* ---------- نافذة «سند جديد» — نسخة من نافذة السند في صندوق الحسابات ---------- */
  var DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  function shrinkImage(file, done) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, 1280 / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        done(c.toDataURL('image/jpeg', 0.8));
      };
      im.onerror = function () { done(r.result); };
      im.src = r.result;
    };
    r.readAsDataURL(file);
  }

  function txDialog(editId, pickImage) {
    var accId = S.aid;
    if (!store().accounts.some(function (x) { return x.id === accId; })) return;
    var tx = editId ? store().txs.find(function (x) { return x.id === editId; }) : null;
    if (editId && !tx) return;
    var now = new Date(), when = tx ? { date: tx.date, time: tx.time || '00:00' } : { date: today(), time: now.toTimeString().slice(0, 5) };
    var img = tx ? (tx.img || '') : '', cur0 = tx ? tx.cur : (isAll() ? defCur() : S.cur);
    var ov = document.createElement('div');
    ov.id = 'paVoucher';
    ov.className = 'overlay show pa-ov';
    ov.innerHTML =
      '<div class="voucher-modal">' +
        '<div class="voucher-header">' +
          '<div class="vh-right"><div class="vh-title">' + (tx ? 'تعديل سند' : 'سند جديد') + '</div></div>' +
          '<div class="vh-datetime" data-v="dt" title="اضغط لتعديل التاريخ والوقت"><div id="pvDay"></div><div id="pvTime"></div><div id="pvDate"></div></div>' +
          '<button type="button" class="vh-settings" data-v="set">⚙</button>' +
        '</div>' +
        '<div class="voucher-balance-bar"><div>الرصيد <span id="pvLbl">له</span>: <span id="pvVal">0</span> <span id="pvSym"></span></div></div>' +
        '<div class="voucher-hint">أدخل المبلغ</div>' +
        '<div class="voucher-row">' +
          '<select id="pvCur" class="v-currency">' + curList().map(function (c) {
            return '<option value="' + E(c.n) + '"' + (c.n === cur0 ? ' selected' : '') + '>' + E(c.n) + ' (' + E(c.s) + ')</option>';
          }).join('') + '</select>' +
          '<input id="pvAmount" type="number" min="0" step="0.01" inputmode="decimal" class="v-input" data-voice-amount="1">' +
          '<button type="button" class="v-mic" data-v="mic-a">🎙</button>' +
          '<button type="button" class="v-calc" data-v="calc" title="الحاسبة" aria-label="فتح حاسبة مبلغ السند">🧮</button>' +
        '</div>' +
        '<div class="voucher-sub-hint" id="pvHint">صفر محلي</div>' +
        '<div class="voucher-row voucher-note-row">' +
          '<button type="button" class="v-mic" data-v="mic-n" title="إملاء صوتي">🎙</button>' +
          '<textarea id="pvNote" class="v-input v-note-input pvLine" rows="2" placeholder="اكتب البيان ويمكنك إضافة عدة سطور"></textarea>' +
          '<button type="button" class="v-camera" data-v="cam" title="إرفاق صورة">📷</button>' +
        '</div>' +
        '<div id="pvNoteExtra"></div>' +
        '<div class="voucher-note-tools"><button type="button" data-v="addl">＋ إضافة سطر</button><span>يمكنك كتابة أكثر من سطر في البيان</span></div>' +
        '<div class="voucher-image-preview" id="pvImg"><input type="file" id="pvImgIn" accept="image/*" style="display:none"></div>' +
        '<div class="voucher-type">' +
          '<label class="v-type-option"><input type="radio" name="pvType" value="له"' + (tx && tx.type === 'له' ? ' checked' : '') + '><span class="v-radio"></span><span class="v-type-label green">لـه</span></label>' +
          '<label class="v-type-option"><input type="radio" name="pvType" value="عليه"' + (tx && tx.type === 'له' ? '' : ' checked') + '><span class="v-radio"></span><span class="v-type-label red">عليه</span></label>' +
          '<button type="button" class="v-help" data-v="help">🔴 شرح</button>' +
        '</div>' +
        '<div class="voucher-actions">' +
          '<button type="button" class="v-btn-cancel" data-v="x">إلغاء</button>' +
          '<button type="button" class="v-btn-save" data-v="ok">حفظ</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(ov);

    var $ = function (id) { return ov.querySelector('#' + id); };
    function close() { window.__vcTarget = null; ov.remove(); }
    function showWhen() {
      var d = new Date(when.date + 'T' + when.time);
      $('pvDay').textContent = DAYS[d.getDay()];
      $('pvTime').textContent = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      $('pvDate').textContent = d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate();
    }
    function showBal() {
      var c = $('pvCur').value, b = balAt(accId, c, null);
      $('pvLbl').textContent = b >= 0 ? 'عليه' : 'له';
      $('pvVal').textContent = fmt(Math.abs(b));
      $('pvSym').textContent = symOf(c);
    }
    function lines() {
      var out = [];
      [].forEach.call(ov.querySelectorAll('.pvLine'), function (t) {
        String(t.value).split('\n').forEach(function (l) { l = l.trim(); if (l) out.push(l); });
      });
      return out;
    }
    function pickWhen() {
      dialog('📅 تعديل التاريخ والوقت',
        fld('التاريخ', '<input type="date" id="pvDtD" value="' + E(when.date) + '">') +
        fld('الوقت', '<input type="time" id="pvDtT" value="' + E(when.time) + '">'),
        function (p) {
          var d = p.querySelector('#pvDtD').value;
          if (!d) { toast('الرجاء اختيار التاريخ'); return false; }
          when.date = d; when.time = p.querySelector('#pvDtT').value || '00:00';
          showWhen(); toast('تم تحديث التاريخ والوقت');
        });
    }
    function submit() {
      var amt = num($('pvAmount').value);
      if (!(amt > 0)) { toast('أدخل المبلغ'); return; }
      var c = $('pvCur').value, r = ov.querySelector('input[name="pvType"]:checked'), type = r ? r.value : 'عليه';
      var s2 = store(), acc = s2.accounts.find(function (x) { return x.id === accId; });
      if (!acc) { toast('الحساب غير موجود'); return; }
      var nb = net(acc.id, c, function (t) { return t.id !== editId; }) + (type === 'عليه' ? amt : -amt);
      if (acc.capOn && nb > num(acc.cap) && !confirm('المعاملة تتجاوز سقف المديونية. متابعة؟')) return;
      var cur = editId ? s2.txs.find(function (t) { return t.id === editId; }) : null;
      if (cur) { cur.cur = c; cur.date = when.date; cur.time = when.time; cur.amount = amt; cur.type = type; cur.lines = lines(); cur.img = img; }
      else s2.txs.push({ id: uid('t'), acc: acc.id, cur: c, date: when.date, time: when.time, amount: amt, type: type, lines: lines(), img: img });
      save(); close(); render();
      if (cur) toast('تم التعديل');
    }

    ov.addEventListener('click', function (e) {
      if (e.target === ov) { close(); return; }
      var b = e.target.closest('[data-v]');
      if (!b) return;
      switch (b.getAttribute('data-v')) {
        case 'x': close(); break;
        case 'ok': submit(); break;
        case 'dt': pickWhen(); break;
        case 'set': toast('الإعدادات'); break;
        case 'help': toast('عليه = دين، له = سداد'); break;
        case 'mic-a': if (typeof window.voiceInput === 'function') window.voiceInput('pvAmount'); break;
        case 'mic-n': if (typeof window.voiceInput === 'function') window.voiceInput('pvNote'); break;
        case 'calc':
          window.__vcTarget = 'pvAmount';
          if (typeof window.openVoucherCalculator === 'function') window.openVoucherCalculator();
          break;
        case 'cam': $('pvImgIn').click(); break;
        case 'addl':
          var row = document.createElement('div');
          row.className = 'voucher-row voucher-note-row';
          row.innerHTML = '<textarea class="v-input v-note-input pvLine" rows="2" placeholder="بيان جديد"></textarea>' +
            '<button type="button" data-v="rm" style="border:1px solid #dc2626;background:#fee2e2;color:#b91c1c;border-radius:7px;padding:5px 10px;font-size:12px;font-weight:800;white-space:nowrap">حذف</button>';
          $('pvNoteExtra').appendChild(row);
          row.querySelector('textarea').focus();
          break;
        case 'rm': b.closest('.voucher-row').remove(); break;
      }
    });
    $('pvCur').addEventListener('change', showBal);
    function showImg(url) {
      var box = $('pvImg'), old = box.querySelector('img');
      if (old) old.remove();
      if (!url) { box.classList.remove('has-image'); return; }
      var im = document.createElement('img');
      im.src = url; im.alt = 'صورة السند';
      box.classList.add('has-image');
      box.appendChild(im);
    }
    $('pvImgIn').addEventListener('change', function () {
      var f = this.files && this.files[0];
      if (!f) return;
      shrinkImage(f, function (url) { img = url; showImg(url); });
    });
    if (tx) {
      $('pvAmount').value = tx.amount;
      var ls = tx.lines || [];
      $('pvNote').value = ls[0] || '';
      ls.slice(1).forEach(function (l) { ov.querySelector('[data-v="addl"]').click(); var t = $('pvNoteExtra').lastElementChild.querySelector('textarea'); t.value = l; t.blur(); });
      showImg(img);
    }
    showWhen(); showBal();
    if (pickImage) $('pvImgIn').click();
  }

  function statsDialog() {
    var st = store(), t = today(), curs = [];
    st.txs.forEach(function (x) { if (curs.indexOf(x.cur) < 0) curs.push(x.cur); });
    var lines = curs.map(function (c) {
      var owedUs = 0, weOwe = 0;
      st.accounts.forEach(function (a) { var b = balAt(a.id, c, t); if (b > 1e-9) owedUs += b; else weOwe -= b; });
      return '<div class="pa-card pa-stat"><b>' + E(c) + '</b><div class="pa-pos">الإجمالي لكم: ' + fmt(owedUs) + '</div><div class="pa-neg">الإجمالي عليكم: ' + fmt(weOwe) + '</div></div>';
    }).join('');
    dialog('📊 الإحصائيات', '<div class="pa-card pa-stat"><b>' + st.folders.length + ' مجلد — ' + st.accounts.length + ' حساب</b></div>' +
      (lines || '<p class="pa-empty">لا توجد حركات بعد</p>'));
  }

  function searchDialog() {
    dialog('🔍 البحث السريع', '<input id="paQ" placeholder="اسم الحساب أو رقم الهاتف"><div id="paQR"></div>', null, function (ov) {
      var inp = ov.querySelector('#paQ'), res = ov.querySelector('#paQR');
      inp.addEventListener('input', function () {
        var q = inp.value.trim().toLowerCase();
        res.innerHTML = q ? (store().accounts.filter(function (a) {
          return (a.name || '').toLowerCase().indexOf(q) > -1 || (a.ph || '').indexOf(q) > -1;
        }).map(function (a) {
          return '<div class="person pa-acc" data-open="' + E(a.id) + '"><span class="pa-av">' + E(String(a.name || '?').charAt(0)) + '</span><div class="pa-fm"><b>' + E(a.name) + '</b><small>' + E(a.ph || '') + '</small></div></div>';
        }).join('') || '<p class="pa-empty">لا توجد نتائج</p>') : '';
      });
      ov.addEventListener('click', function (e) {
        var r = e.target.closest('[data-open]'); if (!r) return;
        var a = store().accounts.find(function (x) { return x.id === r.getAttribute('data-open'); });
        if (!a) return;
        S.fid = a.fid; S.aid = a.id; S.view = 'account';
        ov.remove(); render();
      });
      inp.focus();
    });
  }

  /* ---------- طباعة الكشف وإرسال الرسالة (عبر خدمات التطبيق) ---------- */
  function statementText(a) {
    var r = range(), opening = r.from ? net(a.id, S.cur, function (t) { return t.date < r.from; }) : 0, run = opening;
    var list = store().txs.filter(function (t) {
      return t.acc === a.id && t.cur === S.cur && (!r.from || t.date >= r.from) && t.date <= r.to;
    }).sort(function (x, y) { return String(x.date).localeCompare(String(y.date)); });
    var rows = list.map(function (t) {
      var s = t.type === 'عليه' ? 1 : -1; run += s * num(t.amount);
      return { date: t.date, type: t.type, amt: num(t.amount), det: (t.lines || []).join(' • '), run: run };
    });
    return { rows: rows, opening: opening, end: run, range: r };
  }
  function printStatement(a, auth) {
    if (isAll()) { toast('اختر عملة محددة للطباعة'); return; }
    var s = statementText(a);
    /* الطباعة عبر قالب التطبيق (PV2) ليتبع إعدادات الطباعة: الترويسة والختم والتوقيع */
    if (window.PV2 && typeof PV2.statement === 'function') {
      var ng = 0, ps = 0, run = s.opening;
      var rows = s.rows.map(function (r) {
        if (r.type === 'عليه') ng += r.amt; else ps += r.amt;
        return '<tr><td>' + E(r.date) + '</td><td>' + E(r.det) + '</td><td>' + (r.type === 'عليه' ? fmt(r.amt) : '') + '</td><td>' + (r.type !== 'عليه' ? fmt(r.amt) : '') + '</td><td>' + fmt(r.run) + '</td></tr>';
      }).join('');
      var sub = '<div class="pv-meta">الفترة: ' + E(s.range.from || 'البداية') + ' — ' + E(s.range.to) + (a.ph ? ' &nbsp;|&nbsp; الهاتف: ' + E(a.ph) : '') + '</div>';
      /* PV2: الرصيد الموجب = لكم، وهنا الموجب = عليه، لذا نعكس الإشارة */
      PV2.statement({ title: auth ? 'مصادقة حساب' : 'كشف حساب', name: a.name, auth: !!auth, rows: rows, sub: sub,
        ng: ng + (s.opening > 0 ? s.opening : 0), ps: ps + (s.opening < 0 ? -s.opening : 0), run: -s.end, unit: S.cur });
      return;
    }
    toast('الطباعة غير متاحة');
  }
  function whatsappStatement(a) {
    if (!a.ph) { toast('أدخل رقم الهاتف أولاً'); return; }
    if (isAll()) { toast('اختر عملة محددة للإرسال'); return; }
    var s = statementText(a);
    var text = 'كشف حساب: ' + a.name + ' (' + S.cur + ')\n' + s.rows.map(function (r) {
      return r.date + ' ' + r.type + ' ' + fmt(r.amt) + (r.det ? ' — ' + r.det : '');
    }).join('\n') + '\nالرصيد: ' + balText(s.end);
    if (a.send === 'sms') { location.href = 'sms:' + String(a.ph).replace(/[^0-9+]/g, '') + '?body=' + encodeURIComponent(text); return; }
    if (typeof openWhatsApp === 'function') openWhatsApp(a.ph, text);
  }

  /* ---------- إدارة العملات: اختيار العملة المعروضة أو كل العملات ---------- */
  function currencyDialog() {
    var opts = [[ALL, 'كل العملات']].concat(curList().map(function (c) { return [c.n, c.n + ' (' + c.s + ')']; }));
    var body = '<div class="field"><label>العملة المعروضة</label>' + radio('paCurSel', opts, S.cur) + '</div>' +
      '<button type="button" class="btn secondary" data-editcur>⚙ تعديل قائمة العملات</button>';
    dialog('💱 إدارة العملات', body, function (ov) {
      var v = checked(ov, 'paCurSel'); if (v) S.cur = v;
      render();
    }, function (ov) {
      var ok = ov.querySelector('[data-ok]'); if (ok) ok.textContent = '💾 تطبيق';
      var eb = ov.querySelector('[data-editcur]');
      if (eb) eb.addEventListener('click', function () { ov.remove(); if (typeof openSettingsPage === 'function') openSettingsPage('currencies'); });
    });
  }

  /* ---------- قيد إلى حساب: قيدان متقابلان بين حسابين خصوصيين ---------- */
  function transferDialog(id) {
    var st = store(), a = st.accounts.find(function (x) { return x.id === id; });
    if (!a) return;
    var others = st.accounts.filter(function (x) { return x.id !== a.id; });
    if (!others.length) { toast('لا يوجد حساب آخر للقيد إليه'); return; }
    var fname = function (fid) { var g = st.folders.find(function (f) { return f.id === fid; }); return g ? g.name : ''; };
    var opts = others.map(function (x) {
      var f = x.fid !== a.fid ? ' — ' + fname(x.fid) : '';
      return '<option value="' + E(x.id) + '">' + E(x.name + f) + '</option>';
    }).join('');
    var curs = curList().map(function (c) {
      return '<option value="' + E(c.n) + '"' + (c.n === (isAll() ? defCur() : S.cur) ? ' selected' : '') + '>' + E(c.n) + ' (' + E(c.s) + ')</option>';
    }).join('');
    var body = '<div class="pa-xfrom">من: <b>' + E(a.name) + '</b></div>' +
      fld('إلى الحساب', '<select id="pxT">' + opts + '</select>') +
      fld('المبلغ', '<input id="pxA" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0">') +
      fld('العملة', '<select id="pxC">' + curs + '</select>') +
      '<div class="field"><label>القيد على الحساب الحالي</label>' + radio('pxType', [['عليه', 'عليه'], ['له', 'له']], 'عليه') + '</div>' +
      fld('البيان', '<input id="pxN" placeholder="قيد بين الحسابات">');
    dialog('↔ قيد إلى حساب', body, function (ov) {
      var amt = num(ov.querySelector('#pxA').value);
      if (!(amt > 0)) { toast('أدخل مبلغاً صحيحاً'); return false; }
      var s2 = store(), tg = s2.accounts.find(function (x) { return x.id === ov.querySelector('#pxT').value; });
      var src = s2.accounts.find(function (x) { return x.id === a.id; });
      if (!tg || !src) { toast('اختر الحساب الآخر'); return false; }
      var c = ov.querySelector('#pxC').value, type = checked(ov, 'pxType') || 'عليه';
      var note = ov.querySelector('#pxN').value.trim() || 'قيد بين الحسابات';
      var now = new Date(), d = today(), tm = now.toTimeString().slice(0, 5);
      s2.txs.push({ id: uid('t'), acc: src.id, cur: c, date: d, time: tm, amount: amt, type: type, lines: [note + ' (إلى ' + tg.name + ')'], img: '', xfer: true });
      s2.txs.push({ id: uid('t'), acc: tg.id, cur: c, date: d, time: tm, amount: amt, type: type === 'عليه' ? 'له' : 'عليه', lines: [note + ' (من ' + src.name + ')'], img: '', xfer: true });
      if (S.cur !== ALL) S.cur = c;
      save(); render();
      toast('تم القيد بين ' + src.name + ' و' + tg.name);
    }, function (ov) { var ok = ov.querySelector('[data-ok]'); if (ok) ok.textContent = '💾 حفظ القيد'; });
  }

  /* ---------- الحذف (يمر عبر سلة المحذوفات) ---------- */
  function deleteAccount(id) {
    var a = store().accounts.find(function (x) { return x.id === id; });
    if (!a) return;
    customConfirm('نقل الحساب وكل معاملاته إلى سلة المحذوفات؟', function () {
      var s2 = store();
      var txs = s2.txs.filter(function (t) { return t.acc === id; });
      s2.accounts = s2.accounts.filter(function (x) { return x.id !== id; });
      s2.txs = s2.txs.filter(function (t) { return t.acc !== id; });
      S.view = 'folder';
      addToTrash({ account: a, txs: txs }, 'paAccount', a.name, a.fid);
      render();
    }, null, { title: 'حذف الحساب', icon: '🗑️', danger: true, confirmText: 'حذف' });
  }
  function findTx(id) { return store().txs.find(function (t) { return t.id === id; }); }
  /* رصيد الحساب بعد هذه المعاملة (بنفس ترتيب كشف الحساب) */
  function balAfter(t) {
    var run = 0, list = store().txs.filter(function (x) { return x.acc === t.acc && x.cur === t.cur; })
      .sort(function (x, y) { return String(x.date).localeCompare(String(y.date)); });
    for (var i = 0; i < list.length; i++) { run += (list[i].type === 'عليه' ? 1 : -1) * num(list[i].amount); if (list[i].id === t.id) break; }
    return run;
  }
  function txText(t) {
    var a = store().accounts.find(function (x) { return x.id === t.acc; }) || {};
    return ['سند: ' + (a.name || ''), 'النوع: ' + t.type, 'المبلغ: ' + fmt(t.amount) + ' ' + symOf(t.cur), 'التاريخ: ' + t.date + (t.time ? ' ' + t.time : '')]
      .concat((t.lines || []).length ? ['البيان: ' + t.lines.join(' • ')] : [])
      .concat(['الرصيد: ' + balText(balAfter(t))]).join('\n');
  }
  function printTx(id) {
    var t = findTx(id); if (!t) return;
    var a = store().accounts.find(function (x) { return x.id === t.acc; }) || {};
    var html = (a.ph ? '<p>الهاتف: ' + E(a.ph) + '</p>' : '') +
      '<table><tr><th>التاريخ</th><th>النوع</th><th>المبلغ</th><th>التفاصيل</th><th>الرصيد</th></tr><tr><td>' + E(t.date + (t.time ? ' ' + t.time : '')) + '</td><td>' + E(t.type) + '</td><td>' +
      fmt(t.amount) + ' ' + E(symOf(t.cur)) + '</td><td>' + (t.lines || []).map(E).join('<br>') + '</td><td>' + E(balText(balAfter(t))) + '</td></tr></table>' +
      (t.img ? '<p><img src="' + t.img + '" style="max-width:100%;max-height:420px"></p>' : '');
    if (typeof printDoc === 'function') printDoc('سند: ' + (a.name || ''), html);
    else toast('الطباعة غير متاحة');
  }
  function dataToFile(url, name) {
    return fetch(url).then(function (r) { return r.blob(); }).then(function (b) { return new File([b], name, { type: b.type || 'image/jpeg' }); });
  }
  function shareImageFile(url, name) {
    dataToFile(url, name).then(function (f) {
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f] }).catch(function () {});
      else if (window.SANative && SANative.shareImage) SANative.shareImage(url, name, 'صورة مرفقة بالمعاملة');
      else if (window.AndroidBackup && AndroidBackup.shareImage) AndroidBackup.shareImage(url, name, 'صورة مرفقة بالمعاملة');
      else toast('ميزة مشاركة الصور غير متاحة');
    });
  }
  function shareTx(id) {
    var t = findTx(id); if (!t) return;
    var a = store().accounts.find(function (x) { return x.id === t.acc; }) || {}, text = txText(t);
    var ov = dialog('📤 إرسال المعاملة',
      '<button type="button" class="btn secondary" data-s="text">📝 مشاركة كنص</button>' +
      (a.ph ? '<button type="button" class="btn primary" data-s="wa">💬 إرسال واتساب</button>' : '') +
      (t.img ? '<button type="button" class="btn secondary" data-s="img">📷 الصورة المرفقة</button>' : ''), null,
      function (o) {
        o.addEventListener('click', function (e) {
          var b = e.target.closest('[data-s]'); if (!b) return;
          var k = b.getAttribute('data-s');
          if (k === 'text') {
            if (navigator.share) navigator.share({ title: 'سند', text: text }).catch(function () {});
            else if (navigator.clipboard) { navigator.clipboard.writeText(text); toast('تم النسخ'); }
          } else if (k === 'wa') { if (typeof openWhatsApp === 'function') openWhatsApp(a.ph, text); }
          else if (k === 'img') shareImageFile(t.img, 'صورة-سند.jpg');
          o.remove();
        });
      });
    return ov;
  }
  /* عارض الصورة المرفقة: حفظ، مشاركة، استبدال، حذف */
  function txImage(id) {
    var t = findTx(id); if (!t) return;
    if (!t.img) { txDialog(id, true); return; }
    var v = document.createElement('div');
    v.className = 'image-viewer show pa-iv';
    v.innerHTML = '<button type="button" class="iv-close" data-i="x">✕</button><img alt="">' +
      '<div class="iv-tools"><button type="button" data-i="save">💾</button><button type="button" data-i="share">🔗</button>' +
      '<button type="button" data-i="rep">🔄</button><button type="button" data-i="del">🗑</button></div>';
    v.querySelector('img').src = t.img;
    document.body.appendChild(v);
    v.addEventListener('click', function (e) {
      var b = e.target.closest('[data-i]'), cur = findTx(id);
      if (!b || !cur) { if (e.target === v) v.remove(); return; }
      var k = b.getAttribute('data-i');
      if (k === 'x') v.remove();
      else if (k === 'share') shareImageFile(cur.img, 'صورة-سند.jpg');
      else if (k === 'save') {
        try {
          if (window.SANative && SANative.saveImageToGallery) { SANative.saveImageToGallery(cur.img, 'صورة-سند.jpg'); toast('⏳ جارٍ حفظ الصورة في الاستوديو'); }
          else if (window.AndroidBackup && AndroidBackup.saveImageToGallery) { AndroidBackup.saveImageToGallery(cur.img, 'صورة-سند.jpg'); toast('⏳ جارٍ حفظ الصورة في الاستوديو'); }
          else { var an = document.createElement('a'); an.href = cur.img; an.download = 'صورة-سند.jpg'; an.click(); }
        } catch (err) { toast('تعذر حفظ الصورة'); }
      } else if (k === 'rep') {
        var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*';
        inp.onchange = function () {
          var f = inp.files && inp.files[0]; if (!f) return;
          shrinkImage(f, function (url) { var c2 = findTx(id); if (c2) { c2.img = url; save(); v.querySelector('img').src = url; render(); toast('تم الاستبدال'); } });
        };
        inp.click();
      } else if (k === 'del') {
        customConfirm('حذف الصورة؟', function () { var c3 = findTx(id); if (c3) { c3.img = ''; save(); v.remove(); render(); toast('تم الحذف'); } },
          null, { title: 'حذف صورة', icon: '📷', danger: true, confirmText: 'حذف' });
      }
    });
  }

  function deleteTx(id) {
    customConfirm('حذف هذه المعاملة؟', function () {
      var s2 = store();
      s2.txs = s2.txs.filter(function (t) { return t.id !== id; });
      save(); render();
    }, null, { title: 'حذف المعاملة', icon: '🗑️', danger: true, confirmText: 'حذف' });
  }

  /* استعادة من سلة المحذوفات: تستدعيها دالة الاستعادة في التطبيق الرئيسي */
  window.privateAccountsRestore = function (t) {
    var s2 = store();
    if (t.type === 'paFolder') {
      if (!s2.folders.some(function (f) { return f.id === t.data.id; })) s2.folders.push(t.data);
      return true;
    }
    if (t.type === 'paAccount') {
      var acc = t.data.account;
      if (!s2.folders.some(function (f) { return f.id === acc.fid; })) return false;
      if (!s2.accounts.some(function (a) { return a.id === acc.id; })) s2.accounts.push(acc);
      (t.data.txs || []).forEach(function (x) { if (!s2.txs.some(function (y) { return y.id === x.id; })) s2.txs.push(x); });
      return true;
    }
    return false;
  };

  /* ---------- الأحداث ---------- */
  function act(a, id, v) {
    var st = store();
    switch (a) {
      case 'close': if (typeof showHome === 'function') showHome(); return;
      case 'back': S.view = S.view === 'account' ? 'folder' : 'home'; break;
      case 'curs': currencyDialog(); return;
      case 'nf': folderDialog(); return;
      case 'efo': folderDialog(id); return;
      case 'stat': statsDialog(); return;
      case 'qs': searchDialog(); return;
      case 'na': accountDialog(); return;
      case 'ea': accountDialog(id); return;
      case 'da': deleteAccount(id); return;
      case 'print': var pa = st.accounts.find(function (x) { return x.id === id; }); if (pa) printStatement(pa); return;
      case 'xfer': transferDialog(id); return;
      case 'auth': var au = st.accounts.find(function (x) { return x.id === id; }); if (au) printStatement(au, true); return;
      case 'wa': var wa = st.accounts.find(function (x) { return x.id === id; }); if (wa) whatsappStatement(wa); return;
      case 'nt': if (S.aid) txDialog(); return;
      case 'tedit': txDialog(id); return;
      case 'tdel': deleteTx(id); return;
      case 'tprint': printTx(id); return;
      case 'tshare': shareTx(id); return;
      case 'timg': txImage(id); return;
      case 'fol': S.fid = id; S.view = 'folder'; break;
      case 'acc':
        var ac = st.accounts.find(function (x) { return x.id === id; });
        if (ac) S.fid = ac.fid;
        S.aid = id; S.view = 'account'; break;
      case 'dp': S.from = shift(S.from || monthStart(today()), -1); S.to = shift(S.to || today(), -1); break;
      case 'dn': S.from = shift(S.from || monthStart(today()), 1); S.to = shift(S.to || today(), 1); break;
      case 'dir': S.asc = v === 'asc'; break;
      case 'tdir': S.tasc = v === 'asc'; break;
      case 'mode': S.mode = v; break;
      default: return;
    }
    render();
  }

  function onClick(e) {
    var b = e.target.closest('[data-act]');
    if (!b) return;
    act(b.getAttribute('data-act'), b.getAttribute('data-id'), b.getAttribute('data-v'));
  }
  function onChange(e) {
    var t = e.target, a = t.getAttribute && t.getAttribute('data-act');
    if (!a) return;
    if (a === 'cur') S.cur = t.value;
    else if (a === 'sortsel') S.sort = t.value;
    else if (a === 'tsortsel') S.tsort = t.value;
    else if (a === 'from') S.from = t.value;
    else if (a === 'to') S.to = t.value;
    else if (a === 'prev') S.prev = t.checked;
    else return;
    render();
  }

  function save() { if (typeof window.save === 'function') window.save(); }
  function toast(m) { if (typeof window.toast === 'function') window.toast(m); else alert(m); }
  function addToTrash(item, type, name, parentId) { if (typeof window.addToTrash === 'function') window.addToTrash(item, type, name, parentId); }
  function customConfirm(msg, ok, cancel, opts) {
    if (typeof window.customConfirm === 'function') window.customConfirm(msg, ok, cancel, opts);
    else if (confirm(msg) && ok) ok();
  }

  function render() {
    if (!host) return;
    ensureCur();
    var st = store(), html;
    if (S.view === 'folder') html = viewFolder(st);
    else if (S.view === 'account') html = viewAccount(st);
    else html = viewHome(st);
    var old = host.querySelector('.pa-scroll'), keep = old && S._v === S.view ? old.scrollTop : 0;
    S._v = S.view;
    host.innerHTML = '<div class="pa-wrap">' + html + '</div>';
    var sc = host.querySelector('.pa-scroll');
    if (sc && keep) sc.scrollTop = keep;
    fit();
  }
  /* تثبيت الصفحة بين ترويسة التطبيق والشريط السفلي، فلا تتحرك إلا قائمة الحركات */
  function fit() {
    var pg = document.getElementById('privateAccountsPage');
    if (!pg) return;
    var top = document.querySelector('header.top'), nav = document.getElementById('globalBottomNav');
    var t = top ? Math.round(top.getBoundingClientRect().bottom) : 0;
    var b = nav && nav.offsetHeight ? nav.offsetHeight : 58;
    pg.style.setProperty('--pa-top', Math.max(t, 0) + 'px');
    pg.style.setProperty('--pa-nav', b + 'px');
  }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', fit);

  /* ---------- الصفحة داخل التطبيق ---------- */
  window.showPrivateAccountsPage = function () {
    host = document.getElementById('paHost');
    if (!host) return;
    if (typeof window.tab === 'function') window.tab('privateAccountsPage', true);
    var h = document.getElementById('headerTitle');
    if (h) h.textContent = 'الحسابات الخصوصية';
    var fab = document.querySelector('.fab');
    if (fab) fab.style.display = 'none';
    try { if (typeof window.clearNav === 'function') window.clearNav(); } catch (e) { /* لا شيء */ }
    if (!host.dataset.bound) {
      host.addEventListener('click', onClick);
      host.addEventListener('change', onChange);
      host.dataset.bound = '1';
    }
    if (!S.from) S.from = monthStart(today());
    if (!S.to) S.to = today();
    S.view = 'home'; S.fid = null; S.aid = null;
    render();
  };

  /* ---------- قسم الإعدادات المرتبط ---------- */
  window.paSetTiming = function (v) { data.settings.paTiming = v; save(); toast('تم حفظ الإعداد'); };
  window.paSettingsHTML = function () {
    var s = data.settings || {};
    var tm = s.paTiming || 'confirm';
    var cur = curList().find(function (c) { return c.def; }) || curList()[0];
    var link = function (page, label) { return '<button type="button" class="settingsItem" onclick="openSettingsPage(\'' + page + '\')"><span class="siText"><b>' + E(label) + '</b></span><span class="arrow">‹</span></button>'; };
    return '<div class="settingsCard"><h3>إعدادات الحسابات الخصوصية</h3>' +
      '<div class="field"><label>إرسال الرسائل الافتراضي للحسابات الجديدة</label>' +
      '<div class="pa-radios">' + [['auto', 'تلقائي'], ['confirm', 'بعد التأكيد'], ['never', 'لا ترسل']].map(function (o) {
        return '<label><input type="radio" name="paTimingDef" value="' + o[0] + '"' + (o[0] === tm ? ' checked' : '') + ' onchange="paSetTiming(this.value)"> ' + o[1] + '</label>';
      }).join('') + '</div></div>' +
      '<p class="pa-note">العملة الافتراضية: ' + E(cur ? cur.n : '') + ' — الحسابات الخصوصية تُحفظ مع بيانات التطبيق، وتدخل في النسخ الاحتياطي وGoogle Drive تلقائياً.</p></div>' +
      '<div class="settingsMenu">' +
        link('currencies', 'العملات') + link('messages', 'الرسائل والواتس') + link('printing', 'إعدادات الطباعة') +
        link('trash', 'سلة المحذوفات') + link('appearance', 'الخلفية والإطارات والأزرار') + link('backup', 'النسخ الاحتياطي والاستعادة') +
      '</div>';
  };
})();
