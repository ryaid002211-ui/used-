/* buyer scope helpers (must load first) */
window.invScope=window.invScope||'home';
window.__inScope=function(f){return !!(f&&f.scope==='buyer')===(window.invScope==='buyer')};
/* source script: inline */
(function(){function go(){var e=document.getElementById('lazy-fonts-css');if(!e)return;window.__sharedFontsCss=e.textContent;var st=document.createElement('style');st.textContent=e.textContent;document.head.appendChild(st);e.remove();}
if(document.readyState==='complete')setTimeout(go,50);else window.addEventListener('load',function(){if(window.requestIdleCallback)requestIdleCallback(go,{timeout:300});else setTimeout(go,200);});})();

/* source script: print-reference-main-script */
const KEY='detailed_register_v1';
function safeStorageGet(key,fallback=null){try{const value=localStorage.getItem(key);return value===null?fallback:value;}catch(err){console.warn('تعذر قراءة التخزين المحلي:',key,err);return fallback;}}
function safeStorageSet(key,value){try{localStorage.setItem(key,value);return true;}catch(err){console.error('تعذر حفظ التخزين المحلي:',key,err);return false;}}
function loadMainData(){
  const raw=safeStorageGet(KEY,null);
  if(raw===null)return {people:[],folders:[],settings:{}};
  try{
    const parsed=JSON.parse(raw);
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw new Error('Invalid data root');
    if(!Array.isArray(parsed.people)||!Array.isArray(parsed.folders)||!parsed.settings||typeof parsed.settings!=='object'){
      throw new Error('Invalid data structure');
    }
    return parsed;
  }catch(err){
    console.error('تعذر قراءة بيانات التطبيق المحفوظة؛ تم الاحتفاظ بها دون استبدالها.',err);
    try{safeStorageSet(KEY+'_corrupt_backup_'+Date.now(),raw);}catch(_){}
    return {people:[],folders:[],settings:{},_loadWarning:true};
  }
}
let data=loadMainData();
if(data._loadWarning){setTimeout(()=>{if(typeof toast==='function')toast('تعذر قراءة البيانات المحفوظة. احتُفظ بنسخة منها؛ لا تحفظ بيانات جديدة قبل استعادتها.');},300);} 

if(!data.folders)data.folders=[];
if(!data.people)data.people=[];
data.people.forEach(function(p){if(!p.scope)p.scope=p.folderId?'folder':'accounts';});
if(!data.folders.length){data.folders.push({id:'default-accounts',name:'حسابات',image:'',note:'',order:1,openingEnabled:false,createdAt:Date.now()});save();}
data.settings=Object.assign({dark:false,color:'#1e40af',font:'tajawal',fontSize:'medium',currency:'ر.ي',pdfBalance:true,printToggles:[true,true,true,true],multiCurrency:false,viewMode:'list',folderViewOnly:true,profileNameAr:'',profileNameEn:'',profileAddressAr:'',profileAddressEn:'',profileContacts:'',profileContactsEn:'',useFullHeader:false,logoSize:1,signSize:1,stampSize:1,headerFont:'tajawal',headerFontSize:12,headerLineHeight:1.3,logoData:'',stampData:'',signData:'',lang:'ar',msgIntro:'',msgEnd:'',payEnd:'الرجاء سرعة سداد ماعليكم مع كامل الشكر والاحترام',msgFormatDebt:'عليكم',msgFormatPay:'الرصيد لك',sendMethod:'whatsapp',sendWhen:'confirm',globalMessageSettings:true,sendDest:'phone',wa:'business',waType:'business',countryCode:'+967',lineKey:'empty',waNotifType:'text',doc:'image',docFormat:'image',docType:'notice',imageQuality:'sd',imageSize:1.0,printMethod:'pdf',paper:'a4',printerType:'other',stampMode:'sign',printColor:'#a5b4fc',printFont:'tajawal',printFontSize:2,printLineHeight:1.2,invoiceHeaderRows:4,quoteHeaderRows:4,showAccountNote:false,showPhone:false,showVoucherNumber:false,addNoteOnStatement:false,showHeaderData:true,repeatHeader:true,showPrintDate:true,showPrintTime:true,stampSettings:{vouchers:'sign',invoices:'sign',statement:'sign',balance:'sign',quotes:'sign'},currencies:[{name:'ريال يمني',symbol:'ر.ي',sellRate:1,buyRate:1,fraction:1,isDefault:true,subUnit:'فلس'},{name:'ريال سعودي',symbol:'ر.س',sellRate:1,buyRate:1,fraction:1,isDefault:false,subUnit:'هللة'},{name:'ريال عماني',symbol:'ر.ع',sellRate:1,buyRate:1,fraction:1,isDefault:false,subUnit:'بيسة'},{name:'درهم إماراتي',symbol:'د.إ',sellRate:1,buyRate:1,fraction:1,isDefault:false,subUnit:'فلس'},{name:'دولار أمريكي',symbol:'$',sellRate:1,buyRate:1,fraction:1,isDefault:false,subUnit:'سنت'}],trash:[],activation:{activated:false,activatedAt:null,activationCode:null,freeLimit:250,devWhatsApp:'967773544574'},gdriveBackup:{connected:false,email:'',backupEmail:'',emailJsKey:'',lastDataBackup:0,lastDocsBackup:0,dataEnabled:true,dataInterval:'6h',docsEnabled:false,docsInterval:'daily',wifiOnly:true,alertOnClose:true,emailBackground:false,backupOnExit:false,accessToken:null,tokenExpiry:0,backupHistory:[]},backup:{dataEnabled:true,dataInterval:'6h',lastDataBackup:0,docsEnabled:false,docsInterval:'daily',wifiOnly:true,lastDocsBackup:0,googleEmail:'',googleConnected:false,cloudDest:'drive',emailBackup:false,namePrefix:'',alertOnClose:false,emailBackground:true},appLock:{enabled:false,pin:'',biometric:false,autoLock:'1m',lastUnlock:0}},data.settings||{});
if(!Array.isArray(data.settings.currencies))data.settings.currencies=[];
if(!data.settings.activation)data.settings.activation={activated:false,activatedAt:null,activationCode:null,freeLimit:250,devWhatsApp:'967773544574'};
if(!data.settings.gdriveBackup)data.settings.gdriveBackup={connected:false,email:'',backupEmail:'',emailJsKey:'',lastDataBackup:0,lastDocsBackup:0,dataEnabled:true,dataInterval:'6h',docsEnabled:false,docsInterval:'daily',wifiOnly:true,alertOnClose:true,emailBackground:false,accessToken:null,tokenExpiry:0,backupHistory:[]};
if(!data.settings.stampSettings)data.settings.stampSettings={vouchers:'sign',invoices:'sign',statement:'sign',balance:'sign',quotes:'sign'};

let selected=null,editPersonId=null,opType='debt';
let currentFolderId=null,editFolderId=null,currentFolderImage='';
let currentFolderCurrency=null;
let selectionMode=false,selectedIds=new Set();
let longPressTimer=null,longPressTriggered=false;
let folderLongPressTimer=null,folderLongPressTriggered=false;
let moveOrCopy='move';
let currentOpId=null,currentOpImage=null;
let ivCurrentOpId=null;
let currencyEditIndex=-1;
let opSelectionMode=false;
let selectedOpIds=new Set();
let opLongPressTimer=null,opLongPressTriggered=false;
let dateFilter={from:null,to:null};
let unlockAttempts={};
let opTransferMode='move';
let tempOpDate=null,tempOpTime=null;
let _exitPending=false;

if(!window._folderSortType) window._folderSortType = 'date';
if(!window._folderSortOrder) window._folderSortOrder = 'asc';
if(!window._detailSortOrder) window._detailSortOrder = 'asc';

function save(){
  try{
    const serialized=JSON.stringify(data);
    if(window.__lastSaved===serialized)return true;
    const ok=safeStorageSet(KEY,serialized);
    if(ok)window.__lastSaved=serialized;
    if(!ok){if(typeof toast==='function')toast('تعذر الحفظ؛ قد تكون مساحة التخزين ممتلئة. صدّر نسخة احتياطية.');return false;}
    return true;
  }catch(err){console.error('فشل حفظ بيانات التطبيق',err);if(typeof toast==='function')toast('تعذر حفظ البيانات. تحقق من مساحة التخزين.');return false;}
}
function fmt(n){return new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n||0)}
function money(n){return fmt(n)+' '+(data.settings.currency||'')}
function toast(t){let x=document.getElementById('toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),1800)}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function escNl(s){return esc(s).replace(/\n/g,'<br>')}
function closeModal(id){document.getElementById(id).classList.remove('show')}
function toggleSwitch(id){document.getElementById(id).classList.toggle('on')}
function toggleSwitchSetting(key,btn){data.settings[key]=!data.settings[key];btn.classList.toggle('on',data.settings[key]);save();}

function getDeviceId(){
  let deviceId=localStorage.getItem('detailed_app_device_id');
  if(!deviceId){
    const raw=[navigator.userAgent,navigator.language,screen.colorDepth,screen.width+'x'+screen.height,new Date().getTimezoneOffset(),Math.random().toString(36).substring(2,15)].join('|');
    let hash=0;
    for(let i=0;i<raw.length;i++){hash=((hash<<5)-hash)+raw.charCodeAt(i);hash=hash&hash;}
    deviceId='DEV-'+Math.abs(hash).toString(36).toUpperCase().padStart(8,'0');
    localStorage.setItem('detailed_app_device_id',deviceId);
  }
  return deviceId;
}
function getTotalVouchersCount(){return data.people.reduce((sum,p)=>sum+(p.ops?.length||0),0);}
function isAppActivated(){return !!data.settings.activation?.activated;}
function hasExceededFreeLimit(){return false;}

function applyThemeColors(color){
  const hex=color.replace('#','');
  const r=parseInt(hex.substr(0,2),16),g=parseInt(hex.substr(2,2),16),b=parseInt(hex.substr(4,2),16);
  document.documentElement.style.setProperty('--primary',color);
  document.querySelectorAll('meta[name="theme-color"]').forEach(m=>m.setAttribute('content',data.settings.dark?'#0f172a':color));
  document.documentElement.style.setProperty('--primary-rgb',`${r},${g},${b}`);
  const dk=(v,a=0.3)=>Math.max(0,Math.floor(v*(1-a)));
  document.documentElement.style.setProperty('--primary-dark',`#${dk(r).toString(16).padStart(2,'0')}${dk(g).toString(16).padStart(2,'0')}${dk(b).toString(16).padStart(2,'0')}`);
  const lt=(v,a=0.85)=>Math.min(255,Math.floor(v+(255-v)*a));
  document.documentElement.style.setProperty('--primary-light',`rgba(${lt(r)},${lt(g)},${lt(b)},0.15)`);
  data.settings.color=color;save();if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();
}
function setAppColor(c){applyThemeColors(c);openSettingsPage('language');toast('تم تغيير اللون ✅');}
function applyFont(f){const map={default:"'Honor Sans',sans-serif",cairo:"'Cairo',sans-serif",tajawal:"'Tajawal',sans-serif",almarai:"'Almarai',sans-serif",ibm:"'IBM Plex Sans Arabic',sans-serif"};const ff=map[f]||map['default'];document.documentElement.style.setProperty('--app-font',ff);document.body.style.fontFamily=ff;data.settings.font=f;save();if(typeof applyFontWeight==='function')applyFontWeight(data.settings.fontWeight||'medium');if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();}
function setFont(f){applyFont(f);toast('تم تغيير الخط ✅');}
function applyFontWeight(weight){const map={light:300,medium:500,bold:800};const chosen=map[weight]===undefined?'medium':weight;data.settings.fontWeight=chosen;document.documentElement.style.setProperty('--app-font-weight',String(map[chosen]));save();if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();}
function setFontWeight(weight){applyFontWeight(weight);toast(weight==='light'?'وزن الخط: نحيف':weight==='bold'?'وزن الخط: عريض':'وزن الخط: متوسط');}
function setFontSize(size){data.settings.fontSize=size;document.body.classList.remove('font-small','font-medium','font-large');document.body.classList.add('font-'+size);const sizes={small:'14px',medium:'16px',large:'18px'};document.documentElement.style.setProperty('--base-font-size',sizes[size]||'16px');save();if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();toast(size==='small'?'حجم صغير':size==='large'?'حجم كبير':'حجم وسط');}
function setTheme(d){data.settings.dark=!!d;document.body.classList.toggle('dark',!!d);document.documentElement.style.colorScheme=d?'dark':'light';document.querySelectorAll('meta[name="theme-color"]').forEach(m=>m.setAttribute('content',d?'#0f172a':(data.settings.color||'#1e40af')));save();if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();toast(d?'🌙 الوضع الداكن':'☀️ الوضع الفاتح');}
function setLang(l){data.settings.lang=(l==='en'?'en':'ar');save();if(window.__applyGlobalAppPreferences)window.__applyGlobalAppPreferences();toast(data.settings.lang==='en'?'Language changed':'تم تغيير اللغة');}
function setViewMode(m){
  data.settings.viewMode=(m==='grid'?'grid':'list');
  save();
  const box=document.getElementById('currentView');
  if(box){
    box.classList.remove('view-list','view-grid');
    if(currentFolderId===null) box.classList.add('view-'+data.settings.viewMode);
  }
  renderCurrentView();
  toast(data.settings.viewMode==='grid'?'عرض المجلدات: شبكة ▦':'عرض المجلدات: قائمة 📋');
}

/* ============================================================
   نظام التنقل + منع الخروج
   ============================================================ */
let navStack=[];

function pushNav(type,id=null,meta={}){
  navStack.push({type,id,meta});
  guardHistory();
}
function popNav(){return navStack.pop()||null;}
function peekNav(){return navStack[navStack.length-1]||null;}
function clearNav(){navStack=[];guardHistory();}

/* ===== الطباعة عبر الطابعة: طباعة داخل نفس الصفحة بدون نافذة منبثقة حتى يبقى المستخدم في الصفحة السابقة ===== */
(function(){
  if(window.__printShimInstalled)return;window.__printShimInstalled=true;
  var nativeOpen=window.open;
  window.__printGuardUntil=0;
  window.__printGuard=function(ms){window.__printGuardUntil=Math.max(window.__printGuardUntil||0,Date.now()+(ms||3000));};
  function after(){window.__printGuardUntil=Date.now()+2000;}
  window.addEventListener('afterprint',after);
  document.addEventListener('visibilitychange',function(){if(!document.hidden&&Date.now()<(window.__printGuardUntil||0)+60000&&window.__printActive)after();});
  window.__printHtmlInFrame=function(html){
    html=String(html||'').replace(/<script[^>]*>[\s\S]*?<\/script>/gi,function(m){return /print\s*\(/.test(m)?'':m;});
    var old=document.getElementById('__printFrame');if(old)old.remove();
    var fr=document.createElement('iframe');fr.id='__printFrame';
    fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none';
    document.body.appendChild(fr);
    var d=fr.contentWindow.document;d.open();d.write(html);d.close();
    window.__printActive=true;window.__printGuard(8000);
    setTimeout(function(){
      try{fr.contentWindow.addEventListener('afterprint',after);}catch(e){}
      try{fr.contentWindow.focus();fr.contentWindow.print();}catch(e){try{window.print();}catch(_){}}
    },450);
    setTimeout(function(){window.__printActive=false;try{fr.remove();}catch(e){}},180000);
  };
  window.open=function(url,target,features){
    var blank=(url===''||url==null||url==='about:blank')&&(!target||target==='_blank');
    if(!blank)return nativeOpen.apply(window,arguments);
    var buf='',timer=null;
    function schedule(){clearTimeout(timer);timer=setTimeout(function(){if(buf){var h=buf;buf='';window.__printHtmlInFrame(h);}},60);}
    var fake={closed:false,
      document:{title:'',open:function(){buf='';return this;},write:function(h){buf+=h;},writeln:function(h){buf+=h+'\n';},close:schedule},
      focus:function(){},blur:function(){},print:schedule,close:function(){fake.closed=true;},
      location:{href:'about:blank'}};
    return fake;
  };
})();

let handlingPopState=false;
let popStateGuarded=false;
function guardHistory(){
  /* أثناء popstate قد تستدعي دوال الصفحة clearNav/guardHistory مرة ثانية؛
     نحتاج حالة حراسة واحدة فقط حتى لا يتضخم سجل المتصفح. */
  if(handlingPopState){
    if(popStateGuarded)return;
    popStateGuarded=true;
  }
  try{
    history.pushState({guard:Date.now()},'',location.href);
  }catch(e){}
}

guardHistory();
guardHistory();

window.addEventListener('popstate',function(e){
  handlingPopState=true;
  popStateGuarded=false;
  try{guardHistory();navigateBack();}
  finally{handlingPopState=false;popStateGuarded=false;}
});

document.addEventListener('backbutton',function(e){
  e.preventDefault();
  e.stopPropagation();
  navigateBack();
},false);

if(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App){
  try{window.Capacitor.Plugins.App.addListener('backButton',()=>navigateBack());}catch(e){}
}

/* لا نطلب إذن مغادرة التطبيق عند فتح SMS/WhatsApp للإرسال التلقائي.
   زر الرجوع في الهاتف هو المسؤول عن مغادرة التطبيق. */

let pageTransitionDirection='forward';
function navigateBack(){
  if(Date.now()<(window.__printGuardUntil||0))return;
  const openOverlay=document.querySelector('.overlay.show');
  if(openOverlay){openOverlay.classList.remove('show');return;}

  const iv=document.getElementById('imageViewer');
  if(iv&&iv.classList.contains('show')){closeImageViewer();return;}

  const sm=document.getElementById('sideMenuOverlay');
  if(sm&&sm.classList.contains('show')){closeSideMenu();return;}

  if(opSelectionMode){closeOpToolbar();return;}

  if(selectionMode){cancelSelection();return;}

  const pm=document.getElementById('printMenu');
  if(pm){closePrintMenu();return;}

  if(document.querySelector('#buyTransferSheet.on')&&window.bpSheetBack){window.bpSheetBack();return;}
  const _sp=document.querySelector('#buyTransferPage.on,#buyYearPage.on');
  if(navStack.length===0&&_sp&&typeof showPurchasePage==='function'){showPurchasePage();return;}
  const _pp=document.getElementById('buyerPage');
  if(navStack.length===0&&_pp&&_pp.classList.contains('on')&&typeof showHome==='function'){showHome();return;}

  /* أي صفحة/قسم غير الصفحة الرئيسية يرجع إلى الرئيسية أولًا، ولا يطلب الخروج النهائي.
     لذلك يظهر تأكيد الخروج فقط عند الضغط على الرجوع والهاتف على الصفحة الرئيسية نفسها. */
  const homeSection=document.getElementById('home');
  if(navStack.length===0&&homeSection&&!homeSection.classList.contains('on')&&typeof showHome==='function'){
    showHome();
    return;
  }
  if(navStack.length===0){showExitConfirm();return;}
  const layer=popNav();
  pageTransitionDirection='back';
  handleLayerBack(layer);
  setTimeout(()=>{pageTransitionDirection='forward';},400);
}

function handleLayerBack(layer){
  if(!layer){
    const homeSection=document.getElementById('home');
    if(homeSection&&homeSection.classList.contains('on'))showExitConfirm();
    else if(typeof showHome==='function')showHome();
    return;
  }
  switch(layer.type){
    case 'detail':{
      const prev=peekNav();
      if(prev&&prev.type==='folder'){
        currentFolderId=prev.id;
        returnToFolderView();
      }else if(prev&&prev.type==='settingsPage'&&prev.id==='allAccounts'){
        tab('settings',true);
        openSettingsPage('allAccounts',true);
      }else{
        showHome();
      }
      return;
    }
    case 'folder':{closeFolder();return;}
    case 'settingsPage':{
      closeSettingsPage();
      if(navStack.length&&peekNav()&&peekNav().type==='settings'){
        tab('settings',true);
      }else{
        clearNav();tab('settings');
      }
      const title=document.getElementById('headerTitle');if(title)title.textContent='الإعدادات';
      return;
    }
    case 'settings':{showHome();return;}
    default:showHome();
  }
}

function _navOpenFolder(folderId){pushNav('folder',folderId);}
function _navOpenDetail(personId,source='folder'){pushNav('detail',personId,{source});}
function _navOpenSettings(){pushNav('settings');}
function _navOpenSettingsPage(page){pushNav('settingsPage',page);}

/* ============================================================
   التنقل بين الأقسام
   ============================================================ */
function tab(id,skipNav=false){
  document.body.classList.toggle('settings-fullscreen',id==='settings');
  document.body.classList.toggle('statement-view',id==='detail');
  const nextSection=document.getElementById(id);
  const currentSection=document.querySelector('.section.on');
  document.querySelectorAll('.section').forEach(x=>{
    x.classList.remove('on','page-enter-forward','page-enter-back');
  });
  if(nextSection){
    nextSection.classList.add('on');
    if(currentSection!==nextSection){
      const enterClass=pageTransitionDirection==='back'?'page-enter-back':'page-enter-forward';
      nextSection.classList.add(enterClass);
      setTimeout(()=>nextSection.classList.remove(enterClass),420);
    }
  }
  if(id==='invoices')renderCurrentView();
  if(id==='settings'&&!skipNav){_navOpenSettings();}
  const fab=document.querySelector('.fab');
  if(fab)fab.style.display=(id==='settings')?'none':'grid';
  window.scrollTo(0,0);
}
function showHome(){
  window.invScope='home';
  currentFolderId=null;
  currentFolderCurrency=null;
  tab('home',true);
  renderCurrentView();
  document.getElementById('headerTitle').textContent='الاداري برو';
  const bb=document.querySelector('.bottom-bar');
  if(bb)bb.style.display='flex';
  clearNav();
}
function showInvoices(keepScope){
  if(keepScope!==true)window.invScope='home';
  currentFolderId=null;currentFolderCurrency=null;
  tab('invoices',true);
  document.getElementById('headerTitle').textContent='الفواتير';
  const bb=document.querySelector('.bottom-bar');if(bb)bb.style.display='flex';
  clearNav();renderCurrentView();
}

/* ============================================================
   قائمة جانبية
   ============================================================ */
function openSideMenu(){
  const modal=document.getElementById('sideMenuOverlay');
  if(modal&&modal.classList.contains('show'))closeSideMenu();
  const panel=document.getElementById('settings'),sub=document.getElementById('settingsSub');
  if(panel&&panel.classList.contains('on')&&sub&&!sub.classList.contains('on'))return;
  clearNav();
  tab('settings');
  const title=document.getElementById('headerTitle');if(title)title.textContent='الإعدادات';
  const bottom=document.querySelector('.bottom-bar');if(bottom)bottom.style.display='none';
  window.scrollTo(0,0);
}
function closeSideMenu(){
  const modal=document.getElementById('sideMenuOverlay');
  if(modal){modal.classList.remove('show');document.body.style.overflow='';setTimeout(()=>modal.remove(),300);}
  const fab=document.querySelector('.fab');
  if(fab)fab.style.display='grid';
}
function sideMenuGo(page){closeSideMenu();setTimeout(()=>{tab('settings',true);openSettingsPage(page);},300);}
function sideMenuGoAllAccounts(){closeSideMenu();setTimeout(()=>{tab('settings',true);openAllAccountsPage();},300);}
function showSettingsActionModal(title,html){
  let m=document.getElementById('settingsActionModal');if(!m){m=document.createElement('div');m.id='settingsActionModal';m.style.cssText='position:fixed;inset:0;z-index:25000;background:rgba(7,20,38,.68);display:flex;align-items:center;justify-content:center;padding:12px;font-family:Tahoma,Arial,sans-serif;box-sizing:border-box';m.onclick=e=>{if(e.target===m)m.remove()};document.body.appendChild(m)}
  m.innerHTML='<div style="position:relative;z-index:25001;background:var(--card,#fff);color:var(--text,#172033);width:100%;max-width:560px;max-height:82vh;overflow:auto;border-radius:20px;padding:18px;box-shadow:0 18px 50px #0008;box-sizing:border-box"><div style="display:flex;align-items:center;justify-content:space-between;gap:12px"><h3 style="margin:0 0 12px;font-size:17px">'+escapeSettingsHtml(title)+'</h3><button onclick="document.getElementById(\'settingsActionModal\').remove()" style="border:0;border-radius:10px;padding:8px 12px;font-size:20px">×</button></div><div class="settings-action-content">'+html+'</div></div>';
}
function escapeSettingsHtml(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function downloadAppBackup(){
  const backup=buildFullBackup();
  const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='smart-admin-backup-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function restoreAppBackup(event){const f=event.target.files&&event.target.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{try{const b=JSON.parse(rd.result);if(!b||typeof b!=='object'||!b.localStorage)throw new Error('bad backup');if(!confirm('ستتم إضافة أو استبدال مفاتيح التخزين الموجودة في النسخة. هل تريد المتابعة؟'))return;applyFullBackup(b);}catch(e){alert('تعذرت قراءة النسخة الاحتياطية.')}finally{event.target.value=''}};rd.readAsText(f)}
async function shareAppBackup(){try{const backup={app:'SmartAdmin',version:1,createdAt:new Date().toISOString(),localStorage:{}};for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);backup.localStorage[k]=localStorage.getItem(k)}if(typeof data!=='undefined'){try{backup.appData=JSON.parse(JSON.stringify(data))}catch(e){}}const file=new File([JSON.stringify(backup,null,2)],'smart-admin-backup.json',{type:'application/json'});if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title:'نسخة احتياطية للتطبيق',files:[file]})}else if(navigator.share){await navigator.share({title:'مشاركة التطبيق',text:location.href,url:location.href})}else if(navigator.clipboard){await navigator.clipboard.writeText(location.href);alert('تم نسخ رابط التطبيق.')}else{downloadAppBackup()}}catch(e){}}
function saveSettingsSchedule(){localStorage.setItem('backupSchedule',JSON.stringify({freq:document.getElementById('settingsScheduleFreq').value,time:document.getElementById('settingsScheduleTime').value,enabled:true}));alert('تم حفظ تفضيل التذكير على هذا الجهاز.');document.getElementById('settingsActionModal')?.remove()}
function saveSettingsUrl(inputId,key){const el=document.getElementById(inputId);const v=el?el.value.trim():'';if(!/^https?:\/\//i.test(v)){alert('أدخل رابطًا صحيحًا يبدأ بـ https://');return}localStorage.setItem(key,v);window.open(v,'_blank','noopener');document.getElementById('settingsActionModal')?.remove()}
function saveSettingsContact(){const el=document.getElementById('settingsSupportEmail');const v=el?el.value.trim():'';if(v&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)){alert('أدخل بريدًا صحيحًا.');return}localStorage.setItem('settingsSupportEmail',v);alert('تم حفظ بريد التواصل.');}
function emailSettingsSupport(){const e=document.getElementById('settingsSupportEmail')?.value.trim()||'';if(!e){alert('أدخل بريد الدعم أولًا.');return}localStorage.setItem('settingsSupportEmail',e);location.href='mailto:'+e}
function sideMenuWipe(){closeSideMenu();setTimeout(()=>{confirmWipeAll();},300);}

/* ============================================================
   عرض المجلدات والحسابات
   ============================================================ */
function changeFolderSortType(type){
  window._folderSortType=type;
  renderCurrentView();
  const names={date:'📅 التاريخ',amount:'💰 المبلغ',name:'🔤 الأبجدية'};
  toast(`تم الترتيب حسب: ${names[type]}`);
}
function changeFolderSortOrder(order){
  window._folderSortOrder=order;
  renderCurrentView();
  toast(order==='asc'?'↑ ترتيب تصاعدي':'↓ ترتيب تنازلي');
}

function renderCurrentView(){
  const fab=document.querySelector('.fab');
  const detailVisible=!!(document.getElementById('detail')&&document.getElementById('detail').classList.contains('on')&&selected);
  if(fab) fab.style.display='grid';
  const box=document.getElementById('currentView');
  const bc=document.getElementById('breadcrumb');
  const statsRoot=document.getElementById('invoiceStatsRoot');
  const mode='grid'; // العرض الموحد للمجلدات الرئيسية: ثلاثة مجلدات في كل صف
  box.classList.remove('view-list','view-grid');
  if(currentFolderId===null) box.classList.add('view-'+mode);

  if(currentFolderId===null){
    statsRoot.style.display='block';
    bc.style.display='none';
    let folders=data.folders.slice().sort(window.__cmpFolder||((a,b)=>(a.order||0)-(b.order||0))).filter(f=>window.__inScope(f)).filter(f=>window.__specOkFolder?window.__specOkFolder(f):true);
    if(!folders.length){
      box.innerHTML='';
      return;
    }
    box.innerHTML=folders.map(f=>{
      return `<div class="folder-card-v2" onclick="handleFolderClick(event,'${f.id}')" onpointerdown="startFolderLongPress(event,'${f.id}')" onpointerup="cancelFolderLongPress()" onpointerleave="cancelFolderLongPress()">
        ${f.locked?'<div class="folder-lock-badge">🔒</div>':''}
        <div class="folder-card-icon">${f.image?`<img src="${f.image}">`:'<div class="folder-card-icon-default">👥</div>'}</div>
        <div style="flex:1;min-width:0;text-align:right">
          <div class="folder-card-name">🗓️ ${esc(f.name)}</div>
          ${f.startDate&&f.endDate?`<div class="folder-card-date-range">من ${esc(f.startDate)} إلى ${esc(f.endDate)}</div>`:''}
        </div>
      </div>`;
    }).join('');
    return;
  }

  statsRoot.style.display='none';
  bc.style.display='none';
  const folder=data.folders.find(f=>f.id===currentFolderId);
  const folderPeople=data.people.filter(p=>p.folderId===currentFolderId);

  const currencies=data.settings.currencies||[];
  const defaultCurr=currencies.find(c=>c.isDefault)||currencies[0]||{symbol:'ر.ي',name:'محلي'};
  if(!currentFolderCurrency) currentFolderCurrency=defaultCurr.symbol;
  if(!currencies.some(c=>c.symbol===currentFolderCurrency)){
    currentFolderCurrency=defaultCurr.symbol;
  }
  const activeCurrency=currentFolderCurrency;

  const usedCurrencies=new Set();
  folderPeople.forEach(p=>{
    (p.ops||[]).forEach(o=>{
      usedCurrencies.add(o.currency||data.settings.currency||'ر.ي');
    });
  });
  usedCurrencies.add(defaultCurr.symbol);
  const currencyList=Array.from(usedCurrencies);

  const filteredByDate=folderPeople.filter(p=>{
    // الحساب الجديد يظهر مباشرة حتى لو لم تتم إضافة أي عملية له بعد.
    // الحسابات التي لديها عمليات تُفلتر حسب العملة والفترة المحددة.
    if(!p.ops || p.ops.length===0) return true;
    const hasCurrency=(p.ops||[]).some(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency);
    if(!hasCurrency) return false;
    if(!dateFilter.from&&!dateFilter.to) return true;
    return p.ops.some(o=>
      (o.currency||data.settings.currency||'ر.ي')===activeCurrency &&
      o.date>=dateFilter.from && o.date<=dateFilter.to
    );
  });

  let totalDebt=0,totalPay=0;
  folderPeople.forEach(p=>{
    (p.ops||[]).forEach(o=>{
      if((o.currency||data.settings.currency||'ر.ي')!==activeCurrency) return;
      if(o.date<dateFilter.from||o.date>dateFilter.to) return;
      if(o.type==='debt') totalDebt+=o.amount; else totalPay+=o.amount;
    });
  });
  const totalBal=totalDebt-totalPay;

  const sortType=window._folderSortType||'date';
  const sortOrder=window._folderSortOrder||'asc';
  filteredByDate.sort((a,b)=>{
    let comparison=0;
    if(sortType==='date'){
      const aOps=(a.ops||[]).filter(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency);
      const bOps=(b.ops||[]).filter(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency);
      const aLast=aOps.length?Math.max(...aOps.map(o=>new Date(o.date).getTime())):0;
      const bLast=bOps.length?Math.max(...bOps.map(o=>new Date(o.date).getTime())):0;
      comparison=aLast-bLast;
    }else if(sortType==='amount'){
      const aB=Math.abs((a.ops||[]).filter(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency)
        .reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0));
      const bB=Math.abs((b.ops||[]).filter(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency)
        .reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0));
      comparison=aB-bB;
    }else if(sortType==='name'){
      comparison=a.name.localeCompare(b.name,'ar');
    }
    return sortOrder==='asc'?comparison:-comparison;
  });

  const currencyTabsHTML=currencyList.map(sym=>{
    const isActive=sym===activeCurrency;
    const currInfo=currencies.find(c=>c.symbol===sym)||{name:sym,symbol:sym};
    const count=folderPeople.filter(p=>
      (p.ops||[]).some(o=>(o.currency||data.settings.currency||'ر.ي')===sym)
    ).length;
    return `<button onclick="switchFolderCurrency('${sym}')" style="flex:none;padding:8px 14px;border-radius:10px;border:2px solid ${isActive?'#fff':'rgba(255,255,255,.3)'};background:${isActive?'#fff':'rgba(255,255,255,.15)'};color:${isActive?'var(--primary)':'#fff'};font-size:12px;font-weight:900;white-space:nowrap;cursor:pointer;display:flex;align-items:center;gap:6px">
      ${esc(currInfo.name)} (${esc(sym)})
      <span style="background:${isActive?'var(--primary)':'rgba(255,255,255,.25)'};color:#fff;border-radius:50%;width:20px;height:20px;display:grid;place-items:center;font-size:10px;font-weight:900">${count}</span>
    </button>`;
  }).join('');

  const invoiceCardsHTML = (data.settings.invoiceSettings?.showInFolders!==false && folder && Array.isArray(folder.invoices) && folder.invoices.length)
    ? `<section style="margin:10px 0;border:2px solid var(--primary);border-radius:12px;overflow:hidden;background:#fff;padding-bottom:10px">
        <div style="background:linear-gradient(135deg,var(--primary-dark),var(--primary));color:#fff;padding:8px 10px;font-size:13px;font-weight:900">🧾 فواتير هذا المجلد (${folder.invoices.length})</div>
        ${folder.invoices.slice().filter(inv=>window.__specOkInv?window.__specOkInv(inv,folder):true).sort(window.__cmpInv||((a,b)=>(b.updatedAt||b.createdAt||0)-(a.updatedAt||a.createdAt||0))).map(inv=>`<button type="button" data-invoice-id="${esc(inv.id)}" data-folder-id="${esc(folder.id)}" onpointerdown="startInvoiceLongPress(event,'${inv.id}','${folder.id}')" onpointerup="cancelInvoiceLongPress()" onpointerleave="cancelInvoiceLongPress()" onpointercancel="cancelInvoiceLongPress()" onclick="handleInvoiceCardClick(event,'${inv.id}','${folder.id}')" style="display:flex;width:calc(100% - 20px);margin:10px 10px 0;align-items:center;gap:8px;text-align:right;border:1px solid var(--line);border-radius:12px;background:#fff;padding:12px 10px;box-shadow:0 1px 4px rgba(15,23,42,.08);cursor:pointer;font-family:inherit;touch-action:pan-y">
          <span style="font-size:22px">🧾</span><span style="flex:1;min-width:0"><b style="display:block;color:var(--primary);font-size:13px">${esc(inv.initSeller||'فاتورة بدون اسم')}</b><small style="display:block;color:var(--text2);font-size:11px">${esc(inv.initDate||'')} ${inv.initNo?` · رقم الجدول ${esc(inv.initNo)}`:''}${inv.initPlace?` · ${esc(inv.initPlace)}`:''}</small></span><span style="color:var(--primary);font-weight:900">فتح ←</span>
        </button>`).join('')}
      </section>` : '';
  box.innerHTML=`
    <div style="display:flex;gap:8px;align-items:center;margin:10px 0;flex-wrap:nowrap;background:#fff;border:2px solid var(--primary);border-radius:12px;padding:0 8px;height:40px;min-height:40px;max-height:40px;box-sizing:border-box;overflow:hidden">
      <div style="flex:1;min-width:120px;display:flex;align-items:center;gap:6px">
        <span style="font-size:12px;color:var(--muted);font-weight:700;white-space:nowrap">ترتيب حسب:</span>
        <select onchange="changeFolderSortType(this.value)" style="flex:1;border:1px solid var(--line);background:#fff;font-size:12px;font-weight:800;color:var(--primary);outline:none;text-align:center;padding:6px;border-radius:8px">
          <option value="date" ${sortType==='date'?'selected':''}>📅 التاريخ</option>
          <option value="amount" ${sortType==='amount'?'selected':''}>💰 المبلغ</option>
          <option value="name" ${sortType==='name'?'selected':''}>🔤 الأبجدية</option>
        </select>
      </div>
      <div style="display:flex;gap:4px;background:#f1f5f9;border-radius:10px;padding:4px">
        <button onclick="changeFolderSortOrder('asc')" style="padding:6px 12px;border-radius:8px;font-size:11px;font-weight:900;border:0;cursor:pointer;background:${sortOrder==='asc'?'var(--primary)':'transparent'};color:${sortOrder==='asc'?'#fff':'var(--text)'}">↑ تصاعدي</button>
        <button onclick="changeFolderSortOrder('desc')" style="padding:6px 12px;border-radius:8px;font-size:11px;font-weight:900;border:0;cursor:pointer;background:${sortOrder==='desc'?'var(--primary)':'transparent'};color:${sortOrder==='desc'?'#fff':'var(--text)'}">↓ تنازلي</button>
      </div>
    </div>

    <div class="date-bar date-range-unified">
      <button class="db-arrow" onclick="shiftFolderDate(-1)">→</button>
      <div class="db-field"><input type="date" value="${dateFilter.from||''}" onchange="setFolderDateFilter(this.value,null)"></div>
      <span class="db-sep">إلى</span>
      <div class="db-field"><input type="date" value="${dateFilter.to||''}" onchange="setFolderDateFilter(null,this.value)"></div>
      <button class="db-arrow" onclick="shiftFolderDate(1)">←</button>
    </div>

    ${invoiceCardsHTML}
    <div style="margin-top:8px">
      ${filteredByDate.length?filteredByDate.map(p=>{
        let pDebt=0,pPay=0;
        (p.ops||[]).forEach(o=>{
          if((o.currency||data.settings.currency||'ر.ي')!==activeCurrency) return;
          if(o.date<dateFilter.from||o.date>dateFilter.to) return;
          if(o.type==='debt') pDebt+=o.amount; else pPay+=o.amount;
        });
        const pBal=pDebt-pPay;
        const balLabel=pBal>0?'عليه':pBal<0?'له':'متعادل';
        const balClass=pBal>0?'positive':pBal<0?'negative':'zero';
        const isSel=selectedIds.has(p.id);
        const currOps=(p.ops||[]).filter(o=>(o.currency||data.settings.currency||'ر.ي')===activeCurrency);
        const lastDate=currOps.length?currOps[currOps.length-1].date:'';
        return `<div class="person ${selectionMode?'selecting':''} ${isSel?'selected':''}" data-id="${p.id}" onpointerdown="startLongPress(event,'${p.id}')" onpointerup="cancelLongPress()" onpointerleave="cancelLongPress()" onclick="handlePersonClick(event,'${p.id}')">
          ${selectionMode?'<div class="check-box">✓</div>':''}
          <div class="avatar">${esc(p.name[0]||'؟')}</div>
          <div class="pmain">
            <div class="pname">${p.important?'⭐ ':''}${esc(p.name)}</div>
            <div style="font-size:11px;color:var(--muted);margin-top:2px">${lastDate?'📅 '+lastDate:'لا حركات'} · 💱 ${esc(activeCurrency)}</div>
          </div>
          <div class="balance ${balClass}"><small>${balLabel}</small>${fmt(Math.abs(pBal))} ${esc(activeCurrency)}</div>
        </div>`;
      }).join(''):``}
    </div>`;
}

function switchFolderCurrency(symbol){
  currentFolderCurrency=symbol;
  renderCurrentView();
  const c=(data.settings.currencies||[]).find(x=>x.symbol===symbol);
  toast(`💱 ${c?c.name:symbol} (${symbol})`);
}

function initDateFilter(){
  const today=new Date();
  const startOfYear=new Date(today.getFullYear(),0,1);
  dateFilter.from=startOfYear.toISOString().slice(0,10);
  dateFilter.to=today.toISOString().slice(0,10);
}
function renderFolderDateViewStable(){
  var oldBar=document.querySelector('#currentView .date-range-unified')||document.querySelector('.date-bar.date-range-unified');
  var oldTop=oldBar?oldBar.getBoundingClientRect().top:null;
  var root=document.scrollingElement||document.documentElement,oldY=window.scrollY||root.scrollTop||0;
  var parents=[],node=oldBar&&oldBar.parentElement;
  while(node&&node!==document.body){var cs=window.getComputedStyle(node);if(/auto|scroll/.test(cs.overflowY)&&node.scrollHeight>node.clientHeight)parents.push([node,node.scrollTop]);node=node.parentElement;}
  renderCurrentView();
  if(window.__refreshDatePickers)window.__refreshDatePickers();
  requestAnimationFrame(function(){
    parents.forEach(function(x){if(x[0].isConnected)x[0].scrollTop=x[1]});
    var next=document.querySelector('#currentView .date-range-unified')||document.querySelector('.date-bar.date-range-unified');
    if(oldTop!==null&&next){var delta=next.getBoundingClientRect().top-oldTop;if(Math.abs(delta)>1)window.scrollBy(0,delta);}
    else window.scrollTo(0,oldY);
  });
}
function setFolderDateFilter(from,to){if(from)dateFilter.from=from;if(to)dateFilter.to=to;renderFolderDateViewStable();}
function shiftFolderDate(d){
  const from=new Date(dateFilter.from),to=new Date(dateFilter.to);
  const diffDays=Math.round((to-from)/(24*60*60*1000))+1;
  const shift=diffDays*d;
  from.setDate(from.getDate()+shift);to.setDate(to.getDate()+shift);
  dateFilter.from=from.toISOString().slice(0,10);
  dateFilter.to=to.toISOString().slice(0,10);
  renderFolderDateViewStable();
}

function openFolder(id){
  currentFolderId=id;
  currentFolderCurrency=null;
  initDateFilter();
  const folder=data.folders.find(f=>f.id===id);
  document.getElementById('headerTitle').textContent=folder?.name||'';
  const bb=document.querySelector('.bottom-bar');
  if(bb)bb.style.display='none';
  _navOpenFolder(id);
  renderCurrentView();
}
function closeFolder(){
  currentFolderId=null;
  currentFolderCurrency=null;
  document.getElementById('headerTitle').textContent='الاداري برو';
  const bb=document.querySelector('.bottom-bar');
  if(bb)bb.style.display='flex';
  clearNav();
  renderCurrentView();
}
function returnToFolderView(){
  const folder=data.folders.find(f=>f.id===currentFolderId);
  document.querySelectorAll('.section').forEach(x=>x.classList.remove('on'));
  document.getElementById('invoices').classList.add('on');
  document.getElementById('headerTitle').textContent=folder?.name||'الفواتير';
  const bb=document.querySelector('.bottom-bar');
  if(bb)bb.style.display='none';
  const fab=document.querySelector('.fab');
  if(fab)fab.style.display='grid';
  renderCurrentView();
  window.scrollTo(0,0);
}

function openFolderAdd(){editFolderId=null;currentFolderImage='';document.getElementById('folderModalTitle').textContent='🗓️ إضافة أسبوع جديد';document.getElementById('folderName').value='';document.getElementById('folderStartDate').value='';document.getElementById('folderEndDate').value='';document.getElementById('folderOrder').value=data.folders.length+1;document.getElementById('folderImgPreview').innerHTML='📷';document.getElementById('folderModal').classList.add('show');}
function openFolderEdit(id){editFolderId=id;const f=data.folders.find(x=>x.id===id);if(!f)return;currentFolderImage=f.image||'';document.getElementById('folderModalTitle').textContent='✏️ تعديل الأسبوع';document.getElementById('folderName').value=f.name||'';document.getElementById('folderStartDate').value=f.startDate||'';document.getElementById('folderEndDate').value=f.endDate||'';document.getElementById('folderOrder').value=f.order||1;document.getElementById('folderImgPreview').innerHTML=f.image?`<img src="${f.image}" style="max-height:80px">`:'📷';document.getElementById('folderModal').classList.add('show');}
/* تصغير الصور قبل حفظها: صور الأسابيع والخلفية تُعاد كتابتها بحجم مناسب للشاشة، فتخف الحمولة المحفوظة وتقل تكلفة كل حفظ */
function shrinkImageDataUrl(src,maxSide,quality){
  return new Promise(function(resolve){
    if(typeof src!=='string'||!/^data:image\/(jpeg|jpg|png|webp);/i.test(src))return resolve(src);
    const img=new Image();
    img.onload=function(){
      try{
        const k=Math.min(1,maxSide/Math.max(img.naturalWidth||1,img.naturalHeight||1));
        if(k>=1&&/^data:image\/jpe?g;/i.test(src))return resolve(src); // جاهزة الحجم: لا تُعاد ترميزها
        const c=document.createElement('canvas');
        c.width=Math.max(1,Math.round((img.naturalWidth||1)*k));
        c.height=Math.max(1,Math.round((img.naturalHeight||1)*k));
        const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0,c.width,c.height);
        const out=c.toDataURL('image/jpeg',quality);
        resolve(out.length<src.length?out:src);
      }catch(e){resolve(src);}
    };
    img.onerror=function(){resolve(src);};
    img.src=src;
  });
}
/* تصغير الصور المحفوظة سابقًا مرة واحدة عند الفتح (صور أكبر من ~250KB فقط) */
async function shrinkStoredImages(){
  let changed=false;
  const big=function(v){return typeof v==='string'&&v.length>250000&&/^data:image\//i.test(v);};
  for(const f of (data.folders||[])){
    if(big(f.image)){const small=await shrinkImageDataUrl(f.image,800,0.8);if(small.length<f.image.length){f.image=small;changed=true;}}
  }
  const a=data.settings&&data.settings.appearance;
  if(a&&big(a.backgroundData)){const small=await shrinkImageDataUrl(a.backgroundData,1440,0.8);if(small.length<a.backgroundData.length){a.backgroundData=small;changed=true;}}
  if(changed){save();applyAppearanceSettings();}
}
window.addEventListener('load',function(){setTimeout(function(){shrinkStoredImages().catch(function(){});},1500);});
function previewFolderImage(input){const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=async()=>{const small=await shrinkImageDataUrl(r.result,800,0.82);currentFolderImage=small;document.getElementById('folderImgPreview').innerHTML=`<img src="${small}" style="max-height:80px">`;};r.readAsDataURL(f);}
/* إنشاء/تحديث الفلتر الأسبوعي (والتفصيل اليومي) لأي أسبوع من تاريخ بدايته إلى نهايته — أسبوع أو أقل أو أكثر */
function ensureWeeklyFilterForFolder(folder){
  if(!folder||!folder.startDate||!folder.endDate||folder.startDate>folder.endDate)return;
  const name=String(folder.name||'').trim(),startDate=folder.startDate,endDate=folder.endDate;
  const filters=getSavedWeeklyFilters();
  const existing=filters.find(x=>String(x.sourceFolderId||'')===String(folder.id))||filters.find(x=>String(x.name||'').trim()===name);
  const dayNames=['السبت','الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];
  const dates=[];for(let d=new Date(startDate+'T12:00:00');d<=new Date(endDate+'T12:00:00');d.setDate(d.getDate()+1)){dates.push({date:d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'),day:dayNames[(d.getDay()+1)%7]});}
  const makeRows=key=>{const prior=Array.isArray(existing&&existing[key])?existing[key]:[];return dates.map(day=>{const saved=prior.find(r=>r.date===day.date);return Object.assign({day:day.day,date:day.date},saved||{});});};
  saveWeeklyFilterFromEntry(Object.assign({},existing||{},{id:String(existing&&existing.id||folder.id),name,fromDate:startDate,toDate:endDate,qtyRows:makeRows('qtyRows'),salesRows:makeRows('salesRows'),moneyRows:makeRows('moneyRows'),sourceFolderId:folder.id}));
}
/* أسابيع الشرائي القديمة التي لا فلتر لها: تُنشأ لها الفلاتر مرة واحدة عند الفتح */
window.addEventListener('load',function(){setTimeout(function(){try{
  const fl=getSavedWeeklyFilters();let any=false;
  (data.folders||[]).forEach(function(f){if(f&&f.scope==='buyer'&&f.startDate&&f.endDate&&!fl.some(x=>String(x.sourceFolderId||'')===String(f.id))){ensureWeeklyFilterForFolder(f);any=true}});
  if(any)save();
}catch(e){}},2000)});
function saveFolder(){
  const name=document.getElementById('folderName').value.trim();
  const startDate=document.getElementById('folderStartDate').value;
  const endDate=document.getElementById('folderEndDate').value;
  if(!name){toast('اسم الأسبوع مطلوب');return}
  if(!startDate||!endDate){toast('أدخل تاريخ بداية الأسبوع ونهايته');return}
  if(startDate>endDate){toast('تاريخ البداية يجب أن يسبق تاريخ النهاية');return}
  const note='',order=parseInt(document.getElementById('folderOrder').value)||0;
  let folder,created=!editFolderId;
  if(editFolderId){folder=data.folders.find(x=>x.id===editFolderId);if(!folder)return;Object.assign(folder,{name,note,order,image:currentFolderImage,startDate,endDate});}
  else{folder={id:Date.now().toString(),name,note,order,image:currentFolderImage,startDate,endDate,createdAt:Date.now()};if(window.invScope==='buyer')folder.scope='buyer';data.folders.push(folder);}
  const __isBuyerWeek=folder.scope==='buyer';
  ensureWeeklyFilterForFolder(folder);
  if(__isBuyerWeek&&window.bpEnsureWeek)window.bpEnsureWeek(folder);
  save();closeModal('folderModal');
  if(created&&!document.getElementById('invoices').classList.contains('on'))showInvoices(true);else renderCurrentView();
  toast('تم حفظ الأسبوع وإنشاء جدول الفلتر الأسبوعي');
}
function deleteFolder(id){
  const count=data.people.filter(p=>p.folderId===id).length;
  if(count>0){
    customConfirm(`هذا المجلد يحتوي على ${count} حساب. هل تريد المتابعة؟`,()=>{data.people.filter(p=>p.folderId===id).forEach(p=>addToTrash(p,'person',p.name));data.people=data.people.filter(p=>p.folderId!==id);const doomed=data.folders.find(f=>String(f.id)===String(id));if(doomed)addToTrash(doomed,'folder',doomed.name);data.folders=data.folders.filter(f=>String(f.id)!==String(id));save();renderCurrentView();toast('نُقل المجلد إلى سلة المحذوفات');},null,{title:'حذف مجلد',icon:'⚠️',danger:true,confirmText:'حذف'});
    return;
  }
  customConfirm('نقل هذا المجلد إلى سلة المحذوفات؟',()=>{const doomed=data.folders.find(f=>String(f.id)===String(id));if(doomed)addToTrash(doomed,'folder',doomed.name);data.folders=data.folders.filter(f=>String(f.id)!==String(id));save();renderCurrentView();toast('نُقل المجلد إلى السلة');},null,{title:'حذف مجلد',icon:'🗑️',danger:true,confirmText:'حذف'});
}
function startFolderLongPress(e,id){folderLongPressTriggered=false;if(folderLongPressTimer)clearTimeout(folderLongPressTimer);folderLongPressTimer=setTimeout(()=>{folderLongPressTriggered=true;if(navigator.vibrate)navigator.vibrate(30);openFolderMenu(id);},550);}
function cancelFolderLongPress(){if(folderLongPressTimer){clearTimeout(folderLongPressTimer);folderLongPressTimer=null;}}
function handleFolderClick(e,id){if(folderLongPressTriggered){folderLongPressTriggered=false;if(e){e.preventDefault();e.stopPropagation();}return;}const folder=data.folders.find(f=>f.id===id);if(folder&&folder.locked){openFolderUnlock(id);return;}openFolder(id);}

function openFolderMenu(id){
  const folder=data.folders.find(f=>f.id===id);if(!folder)return;
  let modal=document.getElementById('folderMenuModal');
  if(!modal){modal=document.createElement('div');modal.id='folderMenuModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}
  const isLocked=!!folder.locked;
  modal.innerHTML=`<div class="sheet" style="max-width:400px"><h2 style="text-align:center;margin-bottom:20px">${folder.image?`<img src="${folder.image}" style="width:60px;height:60px;border-radius:50%;object-fit:cover;display:block;margin:0 auto 10px">`:'📁'}<div>${esc(folder.name)}</div></h2><button onclick="editFolderFromMenu('${id}')" style="width:100%;display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid var(--line);border-radius:12px;margin-bottom:10px;font-size:15px;font-weight:700;cursor:pointer"><span style="font-size:22px">✏️</span><span style="flex:1;text-align:right">تعديل المجلد</span></button><button onclick="deleteFolderFromMenu('${id}')" style="width:100%;display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid var(--red);border-radius:12px;margin-bottom:10px;color:var(--red);font-size:15px;font-weight:700;cursor:pointer"><span style="font-size:22px">🗑️</span><span style="flex:1;text-align:right">مسح المجلد</span></button><button onclick="openFolderLock('${id}')" style="width:100%;display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid var(--primary);border-radius:12px;color:var(--primary);font-size:15px;font-weight:700;cursor:pointer"><span style="font-size:22px">${isLocked?'🔓':'🔒'}</span><span style="flex:1;text-align:right">${isLocked?'إزالة/تغيير القفل':'قفل المجلد'}</span></button><button class="btn secondary" style="width:100%;margin-top:12px" onclick="closeModal('folderMenuModal')">إلغاء</button></div>`;
  modal.classList.add('show');
}
function editFolderFromMenu(id){closeModal('folderMenuModal');setTimeout(()=>openFolderEdit(id),200);}
function deleteFolderFromMenu(id){closeModal('folderMenuModal');setTimeout(()=>deleteFolder(id),200);}
function openFolderLock(id){closeModal('folderMenuModal');const folder=data.folders.find(f=>f.id===id);if(!folder)return;if(folder.locked){openUnlockOptions(id);}else{openSetLockPassword(id);}}
function openSetLockPassword(id){let modal=document.getElementById('lockPasswordModal');if(!modal){modal=document.createElement('div');modal.id='lockPasswordModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:400px"><h2 style="text-align:center">🔒 قفل المجلد</h2><div class="field"><label>الرمز السري</label><input type="password" id="lockPass1" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div><div class="field"><label>تأكيد الرمز</label><input type="password" id="lockPass2" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px"><button class="btn secondary" onclick="closeModal('lockPasswordModal')">إلغاء</button><button class="btn primary" onclick="setLockPassword('${id}')">🔒 قفل</button></div></div>`;modal.classList.add('show');}
function setLockPassword(id){const p1=document.getElementById('lockPass1').value;const p2=document.getElementById('lockPass2').value;if(!p1||p1.length<4){toast('الرمز 4 أرقام على الأقل');return}if(p1!==p2){toast('الرمزين غير متطابقين');return}const folder=data.folders.find(f=>f.id===id);if(folder){folder.locked=true;folder.password=btoa(p1);save();closeModal('lockPasswordModal');renderCurrentView();toast('🔒 تم القفل');}}
function openUnlockOptions(id){let modal=document.getElementById('unlockModal');if(!modal){modal=document.createElement('div');modal.id='unlockModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:400px"><h2 style="text-align:center">🔒 المجلد مقفل</h2><div class="field"><label>أدخل الرمز الحالي</label><input type="password" id="verifyPass" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div><div style="display:grid;gap:10px;margin-top:16px"><button class="btn primary" onclick="verifyAndUnlock('${id}')">🔓 إزالة القفل</button><button class="btn secondary" onclick="verifyAndChangePass('${id}')">🔄 تغيير الرمز</button><button class="btn secondary" onclick="closeModal('unlockModal')">إلغاء</button></div></div>`;modal.classList.add('show');}
function verifyAndUnlock(id){const pass=document.getElementById('verifyPass').value;const folder=data.folders.find(f=>f.id===id);if(!folder||btoa(pass)!==folder.password){toast('رمز خطأ');return}folder.locked=false;delete folder.password;save();closeModal('unlockModal');renderCurrentView();toast('🔓 تم إزالة القفل');}
function verifyAndChangePass(id){const pass=document.getElementById('verifyPass').value;const folder=data.folders.find(f=>f.id===id);if(!folder||btoa(pass)!==folder.password){toast('رمز خطأ');return}closeModal('unlockModal');setTimeout(()=>{folder.locked=false;delete folder.password;save();openSetLockPassword(id);},300);}
function openFolderUnlock(id){const folder=data.folders.find(f=>f.id===id);if(!folder)return;let modal=document.getElementById('enterPassModal');if(!modal){modal=document.createElement('div');modal.id='enterPassModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:360px"><h2 style="text-align:center">${folder.image?`<img src="${folder.image}" style="width:60px;height:60px;border-radius:50%;object-fit:cover;display:block;margin:0 auto 10px">`:'📁'}<div>${esc(folder.name)}</div><div style="font-size:14px;color:var(--muted);margin-top:8px">🔒 مقفل</div></h2><div class="field"><label style="text-align:center;display:block">أدخل الرمز السري</label><input type="password" id="enterPassInput" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:28px;letter-spacing:10px"></div><div id="passError" style="color:var(--red);text-align:center;font-size:13px;margin:8px 0;display:none"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px"><button class="btn secondary" onclick="closeModal('enterPassModal')">إلغاء</button><button class="btn primary" onclick="tryEnterFolder('${id}')">🔓 فتح</button></div></div>`;modal.classList.add('show');setTimeout(()=>document.getElementById('enterPassInput')?.focus(),200);}
function tryEnterFolder(id){const pass=document.getElementById('enterPassInput').value;const folder=data.folders.find(f=>f.id===id);if(!folder)return;if(btoa(pass)===folder.password){unlockAttempts[id]=0;closeModal('enterPassModal');openFolder(id);}else{unlockAttempts[id]=(unlockAttempts[id]||0)+1;if(unlockAttempts[id]>=3){document.getElementById('passError').style.display='block';document.getElementById('passError').textContent='محاولات كثيرة. انتظر 30 ثانية.';setTimeout(()=>{unlockAttempts[id]=0;document.getElementById('passError').style.display='none';},30000);}else{document.getElementById('passError').style.display='block';document.getElementById('passError').textContent=`رمز خطأ. (${3-unlockAttempts[id]} متبقية)`;}const inp=document.getElementById('enterPassInput');if(inp){inp.value='';inp.focus();}}}

function arabicSpokenAmountToDigits(text){
  const digitMap={'\u0660':'0','\u0661':'1','\u0662':'2','\u0663':'3','\u0664':'4','\u0665':'5','\u0666':'6','\u0667':'7','\u0668':'8','\u0669':'9','\u06f0':'0','\u06f1':'1','\u06f2':'2','\u06f3':'3','\u06f4':'4','\u06f5':'5','\u06f6':'6','\u06f7':'7','\u06f8':'8','\u06f9':'9'};
  text=String(text||'').replace(/[\u0660-\u0669\u06f0-\u06f9]/g,ch=>digitMap[ch]).replace(/[٬،]/g,'').replace(/فاصلة|الفاصله|عشرية/g,' فاصلة ');
  const direct=text.match(/-?\d+(?:[.]\d+)?/);
  if(direct)return direct[0];
  const words=text.replace(/[ـ،.!؟]/g,' ').trim().split(/\s+/).filter(Boolean);
  const ones={'صفر':0,'واحد':1,'واحدة':1,'واحده':1,'اثنين':2,'اثنان':2,'اثنتين':2,'اثنتان':2,'ثلاثة':3,'ثلاثه':3,'ثلاث':3,'أربعة':4,'اربعة':4,'أربع':4,'اربع':4,'خمسة':5,'خمسه':5,'خمس':5,'ستة':6,'سته':6,'ست':6,'سبعة':7,'سبعه':7,'سبع':7,'ثمانية':8,'ثمانيه':8,'ثمان':8,'تسعة':9,'تسعه':9,'تسع':9};
  const teens={'عشرة':10,'عشره':10,'أحد عشر':11,'احد عشر':11,'اثنا عشر':12,'اثني عشر':12,'ثلاثة عشر':13,'أربعة عشر':14,'خمسة عشر':15,'ستة عشر':16,'سبعة عشر':17,'ثمانية عشر':18,'تسعة عشر':19};
  const tens={'عشرين':20,'عشرون':20,'ثلاثين':30,'ثلاثون':30,'أربعين':40,'اربعين':40,'أربعون':40,'اربعون':40,'خمسين':50,'خمسون':50,'ستين':60,'ستون':60,'سبعين':70,'سبعون':70,'ثمانين':80,'ثمانون':80,'تسعين':90,'تسعون':90};
  const normalized=words.join(' ').replace(/\s+/g,' ');
  for(const [phrase,val] of Object.entries(teens)) if(normalized.includes(phrase)) return String(val);
  let total=0, group=0, recognized=false;
  for(const w of words){
    if(w==='و'||w==='ريال'||w==='ريالاً'||w==='ريالات'||w==='ريالين'||w==='يمني'||w==='يمنية'||w==='فقط'||w==='مبلغ')continue;
    if(Object.prototype.hasOwnProperty.call(ones,w)){group+=ones[w];recognized=true;continue}
    if(Object.prototype.hasOwnProperty.call(tens,w)){group+=tens[w];recognized=true;continue}
    if(w==='مئة'||w==='مائه'||w==='مائة'||w==='مئةً'){group=(group||1)*100;recognized=true;continue}
    if(w==='مئتين'||w==='مائتين'){group=(group||1)*200;recognized=true;continue}
    if(w==='ألف'||w==='الف'||w==='ألفاً'||w==='آلاف'){total+=(group||1)*1000;group=0;recognized=true;continue}
    if(w==='مليون'){total+=(group||1)*1000000;group=0;recognized=true;continue}
  }
  if(recognized)return String(total+group);
  return '';
}
function voiceInput(id){
  const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!Speech){toast('الإدخال الصوتي غير متاح في هذا المتصفح');return}
  const r=new Speech();r.lang='ar-SA';r.interimResults=false;r.maxAlternatives=3;
  r.onresult=e=>{
    const el=document.getElementById(id);if(!el)return;
    const spoken=e.results[0][0].transcript||'';
    if(id==='opAmount'||el.dataset.voiceAmount==='1'){
      const amount=arabicSpokenAmountToDigits(spoken);
      if(amount!==''&&Number.isFinite(Number(amount))){el.value=amount;el.dispatchEvent(new Event('input',{bubbles:true}));if(typeof updateVoucherBalance==='function')updateVoucherBalance();}
      else toast('لم أتعرف على المبلغ؛ قل الرقم بوضوح');
    }else{el.value=spoken;el.dispatchEvent(new Event('input',{bubbles:true}));}
  };
  r.onerror=()=>toast('تعذر استخدام الميكروفون');
  r.start();
}


/* ============================================================
   تفاصيل الحساب
   ============================================================ */
/* واجهة الحساب الداخلية أزيلت بناءً على طلب المستخدم.
   قائمة الحسابات والبيانات والسندات محفوظة؛ لا نحذف أي بيانات من التخزين. */
function openDetail(id,fromSource=null){
  selected=id;
  const source=fromSource||(currentFolderId!==null?'folder':'home');
  _navOpenDetail(id,source);

  const p=data.people.find(x=>x.id===id);if(!p)return;
  const defaultCurr=(data.settings.currencies||[]).find(c=>c.isDefault)||(data.settings.currencies||[])[0]||{symbol:'ر.ي',name:'ريال يمني'};
  const defaultSymbol=defaultCurr.symbol;
  // اعرض جميع العملات المعرفة في الإعدادات، حتى العملات التي لم تسجل لها حركة بعد.
  // وأضف أي عملة قديمة موجودة في السندات لكنها لم تعد ضمن قائمة الإعدادات.
  const uniqueCurrencies=new Set((data.settings.currencies||[]).map(c=>c.symbol).filter(Boolean));
  uniqueCurrencies.add(defaultSymbol);
  p.ops.forEach(o=>{const c=o.currency||data.settings.currency||'ر.ي';uniqueCurrencies.add(c);});
  const usedCurrencies=Array.from(uniqueCurrencies);
  window._detailCurrencies=usedCurrencies;
  window._detailDefaultCurrency=defaultSymbol;

  if(window._pendingDetailCurrency&&usedCurrencies.includes(window._pendingDetailCurrency)){
    window._detailActiveCurrency=window._pendingDetailCurrency;
    window._pendingDetailCurrency=null;
  }
  if(!window._detailActiveCurrency||!usedCurrencies.includes(window._detailActiveCurrency)){
    window._detailActiveCurrency=defaultSymbol;
  }
  const activeCurrency=window._detailActiveCurrency;
  const activeOps=p.ops.filter(o=>(o.currency||data.settings.currency)===activeCurrency);
  let totalDebt=activeOps.filter(o=>o.type==='debt').reduce((s,o)=>s+o.amount,0);
  let totalPay=activeOps.filter(o=>o.type==='pay').reduce((s,o)=>s+o.amount,0);
  let bal=totalDebt-totalPay;

  const now=new Date();
  const today=now.toISOString().slice(0,10);
  const startOfYear=new Date(now.getFullYear(),0,1).toISOString().slice(0,10);
  let runBal=0;const opsSorted=activeOps.slice().sort((a,b)=>a.date.localeCompare(b.date));
  const runMap={};opsSorted.forEach(o=>{runBal+=o.type==='debt'?o.amount:-o.amount;runMap[o.id]=runBal;});
  const title=(p.important?'مهم: ':'')+p.name;

  const currencyTabsHTML=usedCurrencies.map(sym=>{
    const isActive=sym===activeCurrency;
    const currInfo=(data.settings.currencies||[]).find(c=>c.symbol===sym)||{name:sym,symbol:sym};
    const count=p.ops.filter(o=>(o.currency||data.settings.currency)===sym).length;
    return `<button onclick="switchDetailCurrency('${sym}')" style="flex:none;padding:10px 16px;border-radius:12px;border:2px solid ${isActive?'#fff':'rgba(255,255,255,.3)'};background:${isActive?'#fff':'rgba(255,255,255,.15)'};color:${isActive?'var(--primary)':'#fff'};font-size:13px;font-weight:900;white-space:nowrap;cursor:pointer;display:flex;align-items:center;gap:6px">${esc(currInfo.name)} (${esc(sym)})<span style="background:${isActive?'var(--primary)':'rgba(255,255,255,.25)'};color:#fff;border-radius:50%;width:22px;height:22px;display:grid;place-items:center;font-size:11px;font-weight:900">${count}</span></button>`;
  }).join('');

  document.getElementById('detailBox').innerHTML=`
    <div class="statement-header">
      <button class="sh-btn detail-back-btn" onclick="navigateBack()" aria-label="رجوع" title="رجوع">→</button>
      <div class="sh-name">${esc(title)}</div>
      <div class="sh-actions">
        <button class="sh-btn" onclick="openAccountTransferDialog()" title="قيد إلى حساب" style="min-width:125px;font-size:12px;font-weight:900">↔ قيد إلى حساب</button>
        <button class="sh-btn" onclick="openPrintMenu(event)">🖨</button>
        <button class="sh-btn" onclick="toast('فلترة')">▼</button>
      </div>
    </div>
    <button class="currency-row" type="button" onclick="openCurrencySelector()" aria-label="اختيار العملة">
      <span class="currency-arrow">▾</span>
      <span class="currency-current">${esc(((data.settings.currencies||[]).find(c=>c.symbol===activeCurrency)||{name:activeCurrency}).name)}</span>
      <span class="currency-label">العملة</span>
    </button>
    <div class="filter-bar">
      <span style="color:#dc2626;font-weight:900;font-size:13px">▼</span>
      <label class="fb-item"><input type="radio" name="period" value="monthly" checked onchange="renderDetailOps()"> شهري</label>
      <label class="fb-item"><input type="radio" name="period" value="all" onchange="renderDetailOps()"> الكل</label>
      <label class="fb-item"><input type="radio" name="period" value="yearly" onchange="renderDetailOps()"> سنوي</label>
      <label class="fb-item"><input type="checkbox" id="prevOnly" onchange="renderDetailOps()"> رصيد سابق</label>
    </div>
    <div class="date-bar date-range-unified">
      <button class="db-arrow" onclick="shiftDetailDate(-1)">→</button>
      <div class="db-field"><input type="date" id="detailFrom" value="${startOfYear}" onchange="renderDetailOps()"></div>
      <span class="db-sep">إلى</span>
      <div class="db-field"><input type="date" id="detailTo" value="${today}" onchange="renderDetailOps()"></div>
      <button class="db-arrow" onclick="shiftDetailDate(1)">←</button>
    </div>
    <div class="statement-scroll" role="region" aria-label="حركات كشف الحساب" tabindex="0">
      <table class="statement-table">
        <thead><tr><th>النوع</th><th>المبلغ</th><th>التفاصيل</th><th>الرصيد</th></tr></thead>
        <tbody id="detailOpsBody"></tbody>
      </table>
    </div>
    <div class="statement-footer">
      <div style="display:flex;align-items:center;gap:4px">عليه: <b style="color:#fca5a5">${fmt(totalDebt)}</b></div>
      <div style="display:flex;align-items:center;gap:4px">له: <b style="color:#86efac">${fmt(totalPay)}</b></div>
      <div style="display:flex;align-items:center;gap:4px">الرصيد ${bal>=0?'عليه':'له'}: <b style="color:#fcd34d">${fmt(Math.abs(bal))}</b></div>
    </div>`;
  window._detailRunMap=runMap;
  window._detailPerson=p;
  tab('detail',true);
  renderDetailOps();
  document.getElementById('headerTitle').textContent=title;
  const bb=document.querySelector('.bottom-bar');if(bb)bb.style.display='none';
  const fab=document.querySelector('.fab');if(fab)fab.style.display='grid';
}
function switchDetailCurrency(symbol){window._detailActiveCurrency=symbol;const p=window._detailPerson;if(!p)return;openDetail(p.id);}

function openCurrencySelector(){
  const p=window._detailPerson;
  if(!p)return;
  const usedCurrencies=window._detailCurrencies||[];
  const activeCurrency=window._detailActiveCurrency;
  let modal=document.getElementById('currencySelectorModal');
  if(!modal){modal=document.createElement('div');modal.id='currencySelectorModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}
  const currencyList=usedCurrencies.map(sym=>{
    const isActive=sym===activeCurrency;
    const currInfo=(data.settings.currencies||[]).find(c=>c.symbol===sym)||{name:sym,symbol:sym};
    const ops=p.ops.filter(o=>(o.currency||data.settings.currency)===sym);
    const debt=ops.filter(o=>o.type==='debt').reduce((s,o)=>s+o.amount,0);
    const pay=ops.filter(o=>o.type==='pay').reduce((s,o)=>s+o.amount,0);
    const bal=debt-pay;
    const balLabel=bal>0?'عليه':bal<0?'له':'متعادل';
    const balColor=bal>0?'#dc2626':bal<0?'#16a34a':'#64748b';
    return `<button onclick="selectCurrencyFromModal('${sym}')" style="width:100%;display:flex;align-items:center;gap:12px;padding:14px;background:${isActive?'linear-gradient(135deg,var(--primary-light),rgba(var(--primary-rgb),.08))':'#fff'};border:2px solid ${isActive?'var(--primary)':'var(--line)'};border-radius:14px;margin-bottom:10px;cursor:pointer;text-align:right">
      <div style="width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--purple));color:#fff;display:grid;place-items:center;font-size:20px;font-weight:900;flex:none">${esc(sym.substring(0,2))}</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px"><b style="font-size:15px;color:var(--primary);font-weight:900">${esc(currInfo.name)}</b>${isActive?'<span style="background:var(--primary);color:#fff;font-size:10px;padding:2px 8px;border-radius:10px;font-weight:900">✓ الحالية</span>':''}</div>
        <div style="font-size:11px;color:var(--muted);font-weight:700">${ops.length} حركة · عليه: ${fmt(debt)} · له: ${fmt(pay)}</div>
      </div>
      <div style="text-align:left;flex:none">
        <div style="font-size:10px;color:var(--muted);font-weight:700">${balLabel}</div>
        <div style="font-size:15px;color:${balColor};font-weight:900">${fmt(Math.abs(bal))}</div>
      </div>
    </button>`;
  }).join('');
  modal.innerHTML=`<div class="sheet" style="max-width:460px"><h2 style="text-align:center;margin-bottom:8px">💱 حساب العملة</h2><div style="max-height:60vh;overflow:auto">${currencyList}</div><button class="btn secondary" style="width:100%;margin-top:12px" onclick="closeModal('currencySelectorModal')">إلغاء</button></div>`;
  modal.classList.add('show');
}
function selectCurrencyFromModal(symbol){closeModal('currencySelectorModal');window._detailActiveCurrency=symbol;const p=window._detailPerson;if(!p)return;openDetail(p.id);}

function renderDetailOps(){
  const p=window._detailPerson;if(!p)return;
  const body=document.getElementById('detailOpsBody');if(!body)return;
  const runMap=window._detailRunMap||{};
  const activeCurrency=window._detailActiveCurrency||data.settings.currency||'ر.ي';
  const from=document.getElementById('detailFrom')?.value;
  const to=document.getElementById('detailTo')?.value;
  const sortOrder=document.getElementById('detailSortOrder')?.value||window._detailSortOrder||'asc';
  window._detailSortOrder=sortOrder;
  let ops=p.ops.filter(o=>(o.currency||data.settings.currency)===activeCurrency);
  ops=ops.slice().sort((a,b)=>sortOrder==='asc'?a.date.localeCompare(b.date):b.date.localeCompare(a.date));
  if(from)ops=ops.filter(o=>o.date>=from);
  if(to)ops=ops.filter(o=>o.date<=to);
  if(!ops.length){body.innerHTML='';return;}
  body.innerHTML=ops.map(o=>{
    const isDebt=o.type==='debt';
    const isSel=selectedOpIds.has(o.id);
    const balanceVal=runMap[o.id]||0;
    const balanceColor=balanceVal>0?'#dc2626':(balanceVal<0?'#16a34a':'#64748b');
    return `<tr class="${isSel?'op-selected':''}" onpointerdown="startOpLongPress(event,'${o.id}')" onpointerup="cancelOpLongPress()" onpointerleave="cancelOpLongPress()" onclick="handleOpClick(event,'${o.id}')">
      <td class="td-type ${isDebt?'debt':'pay'}">${isDebt?'عليه':'له'}</td>
      <td class="td-amount ${isDebt?'debt':'pay'}"><div class="amount-value">${fmt(o.amount)}</div><div class="td-date">${o.date}</div></td>
      <td class="td-detail"><div class="detail-content"><div class="td-note">${escNl((o.note||'').trim())}</div>${!opSelectionMode?`<div class="row-tools"><button title="تعديل السند" aria-label="تعديل السند" onclick="event.stopPropagation();editOp('${o.id}')">✎</button><button class="pdf-tool" title="عرض وطباعة السند" aria-label="عرض وطباعة السند" onclick="event.stopPropagation();printVoucher('${o.id}')">PDF</button><button title="مشاركة السند" aria-label="مشاركة السند" onclick="event.stopPropagation();shareOp('${o.id}')"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="3" fill="currentColor"/><circle cx="6" cy="12" r="3" fill="currentColor"/><circle cx="18" cy="19" r="3" fill="currentColor"/><path d="M8.7 10.7 15.2 6.4M8.7 13.3l6.5 4.3" stroke="currentColor" stroke-width="2.3" fill="none"/></svg></button><button class="camera-tool ${o.image?'has-image':''}" title="الصورة المرفقة أو إضافتها" aria-label="الصورة المرفقة أو إضافتها" onclick="event.stopPropagation();openOpImageAction('${o.id}')"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h3l1.5-2h7L17 7h3a1 1 0 0 1 1 1v11H3V8a1 1 0 0 1 1-1Z" fill="currentColor"/><circle cx="12" cy="13" r="4" fill="#fff"/><circle cx="12" cy="13" r="2" fill="currentColor"/></svg></button></div>`:''}</div></td>
      <td class="td-balance" style="color:${balanceColor}">${fmt(Math.abs(balanceVal))}</td>
    </tr>`;
  }).join('');
}
function shiftDetailDate(d){const f=document.getElementById('detailFrom'),t=document.getElementById('detailTo');if(!f||!t)return;const from=new Date(f.value),to=new Date(t.value);const diff=Math.round((to-from)/(24*60*60*1000))+1;const shift=diff*d;from.setDate(from.getDate()+shift);to.setDate(to.getDate()+shift);f.value=from.toISOString().slice(0,10);t.value=to.toISOString().slice(0,10);renderDetailOps();}

function startOpLongPress(e,id){if(opSelectionMode)return;opLongPressTriggered=false;if(opLongPressTimer)clearTimeout(opLongPressTimer);opLongPressTimer=setTimeout(()=>{opLongPressTriggered=true;enterOpSelectionMode(id);},550);}
function cancelOpLongPress(){if(opLongPressTimer){clearTimeout(opLongPressTimer);opLongPressTimer=null;}}
function enterOpSelectionMode(id){opSelectionMode=true;selectedOpIds.clear();selectedOpIds.add(id);if(navigator.vibrate)navigator.vibrate(30);showOpToolbar();updateOpToolbarUI();renderDetailOps();}
function handleOpClick(e,id){if(opLongPressTriggered){opLongPressTriggered=false;if(e){e.preventDefault();e.stopPropagation();}return;}if(opSelectionMode){if(e){e.preventDefault();e.stopPropagation();}toggleOpSelection(id);}}
function toggleOpSelection(id){if(selectedOpIds.has(id))selectedOpIds.delete(id);else selectedOpIds.add(id);if(selectedOpIds.size===0){closeOpToolbar();return;}updateOpToolbarUI();renderDetailOps();}
function showOpToolbar(){let tb=document.getElementById('opToolbar');if(!tb){tb=document.createElement('div');tb.id='opToolbar';tb.className='op-toolbar';document.body.appendChild(tb);}tb.innerHTML=`<div class="op-toolbar-info"><button class="op-toolbar-close" onclick="closeOpToolbar()">✕</button><span id="opSelectedCount">0</span> محدد</div><div class="op-toolbar-actions"><button onclick="selectAllOps()" id="opSelectAllBtn" class="op-tb-btn"><span>☐</span><span>إلغاء</span></button><button onclick="openOpMoveDialog()" class="op-tb-btn"><span>↔</span><span>نقل</span></button><button onclick="openOpCopyDialog()" class="op-tb-btn"><span>📋</span><span>نسخ</span></button><button onclick="sendSelectedOps()" class="op-tb-btn"><span>📤</span><span>إرسال</span></button><button onclick="deleteSelectedOps()" class="op-tb-btn op-tb-del"><span>🗑</span><span>مسح</span></button></div>`;tb.classList.add('show');}
function closeOpToolbar(){opSelectionMode=false;selectedOpIds.clear();const tb=document.getElementById('opToolbar');if(tb)tb.classList.remove('show');renderDetailOps();}
function updateOpToolbarUI(){const el=document.getElementById('opSelectedCount');if(el)el.textContent=selectedOpIds.size;const p=window._detailPerson;const btn=document.getElementById('opSelectAllBtn');if(btn&&p){const icon=(selectedOpIds.size===p.ops.length)?'☑':'☐';const text=(selectedOpIds.size===p.ops.length)?'إلغاء':'الكل';btn.innerHTML=`<span>${icon}</span><span>${text}</span>`;}}
function selectAllOps(){const p=window._detailPerson;if(!p)return;if(selectedOpIds.size===p.ops.length)selectedOpIds.clear();else p.ops.forEach(o=>selectedOpIds.add(o.id));if(selectedOpIds.size===0){closeOpToolbar();return;}updateOpToolbarUI();renderDetailOps();}
function openOpMoveDialog(){openOpTransferDialog('move');}
function openOpCopyDialog(){openOpTransferDialog('copy');}
function openOpTransferDialog(mode){opTransferMode=mode;const title=mode==='move'?'📦 نقل السند':'📋 نسخ السند';let modal=document.getElementById('opTransferModal');if(!modal){modal=document.createElement('div');modal.id='opTransferModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}const currentId=window._detailPerson.id;const folders=data.folders.map(f=>{const people=data.people.filter(p=>p.folderId===f.id&&p.id!==currentId);if(!people.length)return '';return `<div style="margin-bottom:14px"><div style="font-size:13px;font-weight:900;color:var(--primary);margin-bottom:6px">📁 ${esc(f.name)}</div>${people.map(p=>`<div onclick="performOpTransfer('${p.id}')" style="display:flex;align-items:center;gap:10px;padding:10px;background:#fff;border:1.5px solid var(--line);border-radius:10px;margin:5px 0;cursor:pointer"><div class="avatar" style="width:36px;height:36px;font-size:14px">${esc(p.name[0]||'؟')}</div><div style="flex:1;text-align:right"><div style="font-weight:800;font-size:13px">${esc(p.name)}</div><div style="font-size:10px;color:var(--muted)">${p.ops.length} سند</div></div></div>`).join('')}</div>`;}).join('');modal.innerHTML=`<div class="sheet" style="max-width:460px"><h2>${title}</h2><div style="max-height:50vh;overflow:auto">${folders}</div><button class="btn secondary" style="width:100%;margin-top:12px" onclick="closeModal('opTransferModal')">إلغاء</button></div>`;modal.classList.add('show');}
function performOpTransfer(targetId){const src=window._detailPerson;const tgt=data.people.find(p=>p.id===targetId);if(!src||!tgt){toast('خطأ');return;}const ids=Array.from(selectedOpIds);let count=0;ids.forEach(id=>{const op=src.ops.find(o=>o.id===id);if(!op)return;if(opTransferMode==='move'){tgt.ops.push({...op,id:Date.now().toString()+Math.random().toString(36).slice(2,6)});src.ops=src.ops.filter(o=>o.id!==id);}else{tgt.ops.push({...op,id:Date.now().toString()+Math.random().toString(36).slice(2,6)});}count++;});save();closeModal('opTransferModal');closeOpToolbar();openDetail(src.id);toast(opTransferMode==='move'?`نقل ${count}`:`نسخ ${count}`);}
function sendSelectedOps(){
  if(selectedOpIds.size===0){toast('لم تحدد');return;}
  const p=window._detailPerson;
  const ops=p.ops.filter(o=>selectedOpIds.has(o.id));
  if(ops.length===1){
    const op=ops[0];
    const bal=p.ops.reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);
    showShareChoice(p,op.type,op.amount,{date:op.date,note:op.note,balance:bal},op.image);
  }else{
    let text=`كشف مختصر - ${p.name}\n\n`;
    ops.forEach((o,i)=>{text+=`${i+1}. ${o.type==='debt'?'عليه':'له'}: ${fmt(o.amount)} - ${o.note||'-'}\n`;});
    const method=p.messageMethod||data.settings.sendMethod||'sms';
    if(method==='whatsapp'){
      let phone=(p.phone||'').replace(/[^0-9+]/g,'');
      const cc=(data.settings.countryCode||'').trim();
      if(phone&&cc&&!phone.startsWith('+')&&!phone.startsWith(cc.replace('+',''))) phone=cc+phone;
      openWhatsApp(phone,text,data.settings.waType||'business');
    } else {
      if(navigator.share)navigator.share({title:'سندات',text}).catch(()=>{});
      else{navigator.clipboard.writeText(text);toast('تم النسخ');}
    }
    closeOpToolbar();
  }
}
function deleteSelectedOps(){if(selectedOpIds.size===0){toast('لم تحدد');return;}customConfirm(`نقل ${selectedOpIds.size} سند إلى السلة؟`,()=>{const p=window._detailPerson;const ids=Array.from(selectedOpIds);ids.forEach(id=>{const op=p.ops.find(o=>o.id===id);if(op)addToTrash(op,'op',`${op.type==='debt'?'دين':'سداد'} - ${money(op.amount)}`,p.id);});p.ops=p.ops.filter(o=>!selectedOpIds.has(o.id));save();closeOpToolbar();openDetail(p.id);toast(`نقل ${ids.length} للسلة`);},null,{title:'نقل للسلة',icon:'🗑️',danger:true,confirmText:'نقل'});}

/* ============================================================
   تحديد الحسابات
   ============================================================ */
function startLongPress(e,id){if(selectionMode)return;longPressTriggered=false;cancelLongPress();longPressTimer=setTimeout(()=>{longPressTriggered=true;enterSelectionMode(id);},550);}
function cancelLongPress(){if(longPressTimer){clearTimeout(longPressTimer);longPressTimer=null;}}
function enterSelectionMode(id){selectionMode=true;selectedIds.clear();selectedIds.add(id);if(navigator.vibrate)navigator.vibrate(30);document.getElementById('selectionBar').classList.add('show');updateSelectionUI();renderCurrentView();}
function handlePersonClick(e,id){
  if(longPressTriggered){longPressTriggered=false;if(e){e.preventDefault();e.stopPropagation();}return;}
  if(selectionMode){if(e){e.preventDefault();e.stopPropagation();}toggleSelection(id);}
  else{
    window._pendingDetailCurrency=currentFolderCurrency;
    openDetail(id);
  }
}
function toggleSelection(id){if(selectedIds.has(id))selectedIds.delete(id);else selectedIds.add(id);if(selectedIds.size===0){cancelSelection();return;}updateSelectionUI();renderCurrentView();}
function selectAll(){const list=data.people.filter(p=>p.folderId===currentFolderId);if(selectedIds.size===list.length)selectedIds.clear();else list.forEach(p=>selectedIds.add(p.id));if(selectedIds.size===0){cancelSelection();return;}updateSelectionUI();renderCurrentView();}
function cancelSelection(){selectionMode=false;selectedIds.clear();document.getElementById('selectionBar').classList.remove('show');renderCurrentView();}
function updateSelectionUI(){document.getElementById('selectedCount').textContent=selectedIds.size;}
function editSelected(){toast('تمت إزالة واجهة تعديل الحسابات');}
function deleteSelected(){customConfirm(`حذف ${selectedIds.size} حساب؟`,()=>{const ids=Array.from(selectedIds);ids.forEach(id=>{const p=data.people.find(x=>x.id===id);if(p)addToTrash(p,'person',p.name);});data.people=data.people.filter(p=>!selectedIds.has(p.id));save();cancelSelection();toast(`حذف ${ids.length}`);},null,{title:'حذف حسابات',icon:'⚠️',danger:true,confirmText:'حذف'});}
function openMoveDialog(){openTransferDialog('move');}
function openCopyDialog(){openTransferDialog('copy');}
function openTransferDialog(mode){moveOrCopy=mode;const title=mode==='move'?'📦 نقل الحسابات':'📋 نسخ الحسابات';let modal=document.getElementById('transferModal');if(!modal){modal=document.createElement('div');modal.id='transferModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}const folders=data.folders.map(f=>{const count=data.people.filter(p=>p.folderId===f.id).length;const dis=(mode==='move'&&f.id===currentFolderId)?'style="opacity:.5;pointer-events:none"':'';return `<div ${dis} onclick="performTransfer('${f.id}')" style="display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid var(--line);border-radius:13px;margin:8px 0;cursor:pointer"><div style="width:40px;height:40px;border-radius:11px;background:linear-gradient(135deg,var(--primary),var(--purple));color:#fff;display:grid;place-items:center;overflow:hidden">${f.image?`<img src="${f.image}" style="width:100%;height:100%;object-fit:cover">`:'📁'}</div><div style="flex:1;text-align:right"><div style="font-weight:800;font-size:14px">${esc(f.name)}</div><div style="font-size:11px;color:var(--muted)">${count} حساب</div></div></div>`;}).join('');modal.innerHTML=`<div class="sheet" style="max-width:460px"><h2>${title}</h2>${folders}</div>`;modal.classList.add('show');}
function performTransfer(targetId){const ids=Array.from(selectedIds);if(moveOrCopy==='move'){ids.forEach(id=>{const p=data.people.find(x=>x.id===id);if(p)p.folderId=targetId;});toast(`نقل ${ids.length}`);}else{const copies=[];ids.forEach(id=>{const p=data.people.find(x=>x.id===id);if(p){const np=JSON.parse(JSON.stringify(p));np.id=Date.now().toString()+Math.random().toString(36).slice(2,6);np.name=p.name+' (نسخة)';np.folderId=targetId;np.ops=p.ops.map(o=>({...o,id:Date.now().toString()+Math.random().toString(36).slice(2,6)}));copies.push(np);}});data.people.unshift(...copies);toast(`نسخ ${ids.length}`);}save();closeModal('transferModal');cancelSelection();}

/* ============================================================
   السندات
   ============================================================ */
function updateVoucherDateTimeDisplay(){const targetDate=tempOpDate||new Date().toISOString().slice(0,10);const targetTime=tempOpTime||new Date().toTimeString().slice(0,5);const d=new Date(targetDate+'T'+targetTime);const days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];document.getElementById('vhDay').textContent=days[d.getDay()];document.getElementById('vhTime').textContent=d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});document.getElementById('vhDate').textContent=`${d.getFullYear()}/${d.getMonth()+1}/${d.getDate()}`;}
function updateVoucherDateTime(){if(tempOpDate||tempOpTime){updateVoucherDateTimeDisplay();return;}const now=new Date();const days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];document.getElementById('vhDay').textContent=days[now.getDay()];document.getElementById('vhTime').textContent=now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});document.getElementById('vhDate').textContent=`${now.getFullYear()}/${now.getMonth()+1}/${now.getDate()}`;}
function openDateTimePicker(){const now=new Date();const currentDate=tempOpDate||now.toISOString().slice(0,10);const currentTime=tempOpTime||now.toTimeString().slice(0,5);let modal=document.getElementById('dateTimeModal');if(!modal){modal=document.createElement('div');modal.id='dateTimeModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:400px"><h2 style="text-align:center">📅 تعديل التاريخ والوقت</h2><div class="field"><label>التاريخ</label><input type="date" id="dtDate" class="smallInput" value="${currentDate}"></div><div class="field"><label>الوقت</label><input type="time" id="dtTime" class="smallInput" value="${currentTime}"></div><div class="actions"><button class="btn secondary" onclick="closeModal('dateTimeModal')">إلغاء</button><button class="btn primary" onclick="saveDateTime()">💾 حفظ</button></div></div>`;modal.classList.add('show');}
function saveDateTime(){const dateVal=document.getElementById('dtDate').value;const timeVal=document.getElementById('dtTime').value;if(!dateVal){toast('الرجاء اختيار التاريخ');return;}tempOpDate=dateVal;tempOpTime=timeVal||'00:00';updateVoucherDateTimeDisplay();closeModal('dateTimeModal');toast('تم تحديث التاريخ والوقت');}
function openAccountTransferDialog(){
  const source=data.people.find(x=>x.id===selected)||window._detailPerson;
  if(!source){toast('اختر حساباً أولاً');return;}
  const others=data.people.filter(x=>x.id!==source.id);
  let modal=document.getElementById('accountTransferModal');
  if(!modal){
    modal=document.createElement('div');
    modal.id='accountTransferModal';
    modal.className='overlay';
    modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};
    document.body.appendChild(modal);
  }
  const currency=(window._detailActiveCurrency||data.settings.currency||'ر.ي');
  const options=others.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  modal.innerHTML=`<div class="sheet" style="max-width:460px">
    <h2 style="text-align:center;color:var(--primary);margin-bottom:6px">↔ قيد إلى حساب</h2>
    <div style="text-align:center;font-size:12px;color:var(--muted);margin-bottom:16px">من: <b>${esc(source.name)}</b></div>
    <div class="field"><label>إلى الحساب</label><select id="transferTarget" class="smallInput" style="width:100%;padding:12px;border:2px solid var(--line);border-radius:10px;background:#fff">${options}</select></div>
    <div class="field"><label>المبلغ</label><input id="transferAmount" class="smallInput" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0"></div>
    <div class="field"><label>العملة</label><select id="transferCurrency" class="smallInput" style="width:100%;padding:12px;border:2px solid var(--line);border-radius:10px;background:#fff">${(data.settings.currencies||[{symbol:currency,name:currency}]).map(c=>`<option value="${esc(c.symbol)}" ${c.symbol===currency?'selected':''}>${esc(c.name||c.symbol)} (${esc(c.symbol)})</option>`).join('')}</select></div>
    <div class="field"><label>القيد على الحساب الحالي</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><button id="transferDebtBtn" class="btn danger" type="button" onclick="setAccountTransferType('debt')">عليه</button><button id="transferPayBtn" class="btn secondary" type="button" onclick="setAccountTransferType('pay')">له</button></div></div>
    <div class="field"><label>البيان</label><input id="transferNote" class="smallInput" type="text" placeholder="قيد بين الحسابات"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px"><button class="btn secondary" onclick="closeModal('accountTransferModal')">إلغاء</button><button class="btn primary" onclick="saveAccountTransfer()">حفظ القيد</button></div>
  </div>`;
  window._accountTransferType='debt';
  modal.classList.add('show');
  setAccountTransferType('debt');
}
function setAccountTransferType(type){
  window._accountTransferType=type;
  const d=document.getElementById('transferDebtBtn'), p=document.getElementById('transferPayBtn');
  if(!d||!p)return;
  d.className='btn '+(type==='debt'?'danger':'secondary');
  p.className='btn '+(type==='pay'?'primary':'secondary');
}
function saveAccountTransfer(){
  const source=data.people.find(x=>x.id===selected)||window._detailPerson;
  const targetId=document.getElementById('transferTarget')?.value;
  const target=data.people.find(x=>x.id===targetId);
  const amount=Number(document.getElementById('transferAmount')?.value||0);
  const currency=document.getElementById('transferCurrency')?.value||data.settings.currency||'ر.ي';
  const note=(document.getElementById('transferNote')?.value||'قيد بين الحسابات').trim();
  const type=window._accountTransferType||'debt';
  if(!source||!target){toast('اختر الحساب الآخر');return;}
  if(!amount||amount<=0){toast('أدخل مبلغاً صحيحاً');return;}
  const now=new Date();
  const date=now.toISOString().slice(0,10);
  const id1=Date.now().toString()+Math.random().toString(36).slice(2,7);
  const id2=Date.now().toString()+Math.random().toString(36).slice(2,7);
  source.ops=source.ops||[];target.ops=target.ops||[];
  source.ops.push({id:id1,type,amount,date,note,currency,linkedAccountId:target.id,linkedAccountName:target.name,transfer:true,createdAt:Date.now()});
  target.ops.push({id:id2,type:type==='debt'?'pay':'debt',amount,date,note,currency,linkedAccountId:source.id,linkedAccountName:source.name,transfer:true,createdAt:Date.now()});
  save();
  closeModal('accountTransferModal');
  window._detailActiveCurrency=currency;
  openDetail(source.id);
  toast(`تم القيد بين ${source.name} و${target.name}`);
}

function openOp(type='debt'){opType=type;currentOpId=null;currentOpImage=null;tempOpDate=null;tempOpTime=null;const p=data.people.find(x=>x.id===selected);if(!p)return;document.getElementById('voucherTitle').textContent='سند جديد';document.getElementById('opAmount').value='';document.getElementById('opNote').value='';setOpNotes('');document.getElementById('opImagePreview').innerHTML='<input type="file" id="opImageInput" accept="image/*" style="display:none" onchange="previewOpImage(this)">';setOp(type);updateVoucherDateTime();fillCurrencyDropdown();const currSel=document.getElementById('vCurrency');if(currSel&&window._detailActiveCurrency)currSel.value=window._detailActiveCurrency;updateVoucherBalance();document.getElementById('opModal').classList.toggle('debt-simple',type==='debt');document.getElementById('opModal').classList.add('show');}
function fillCurrencyDropdown(){const sel=document.getElementById('vCurrency');if(!sel)return;sel.innerHTML=(data.settings.currencies||[]).map(c=>`<option value="${esc(c.symbol)}" ${c.isDefault?'selected':''}>${esc(c.name)} (${esc(c.symbol)})</option>`).join('');}
function updateVoucherBalance(){const p=data.people.find(x=>x.id===selected);if(!p)return;const selectedCurrency=document.getElementById('vCurrency')?.value||data.settings.currency||'ر.ي';const bal=p.ops.filter(o=>(o.currency||data.settings.currency)===selectedCurrency).reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);document.getElementById('vbbLabel').textContent=bal>=0?'عليه':'له';document.getElementById('vbbValue').textContent=fmt(Math.abs(bal));document.getElementById('vbbCurrency').textContent=selectedCurrency;}
function previewOpImage(input){const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{currentOpImage=r.result;const box=document.getElementById('opImagePreview');box.classList.add('has-image');box.innerHTML=`<img src="${r.result}" alt="صورة السند"><input type="file" id="opImageInput" accept="image/*" style="display:none" onchange="previewOpImage(this)">`;};r.readAsDataURL(f);}
function setOp(type){opType=type;document.querySelectorAll('input[name="opTypeRadio"]').forEach(r=>{r.checked=(r.value===type);});}


function opNoteExtraHost(){
  let host=document.getElementById('opNoteExtra');
  if(host)return host;
  const row=document.getElementById('opNote')?.closest('.voucher-note-row');
  if(!row)return null;
  host=document.createElement('div');host.id='opNoteExtra';
  host.addEventListener('click',e=>{const btn=e.target.closest&&e.target.closest('.opNoteRemove');if(btn){e.preventDefault();btn.closest('.opNoteExtraRow').remove();}});
  row.insertAdjacentElement('afterend',host);
  return host;
}
function addOpNoteLine(){
  const host=opNoteExtraHost();if(!host)return;
  const box=document.createElement('div');
  box.className='voucher-row voucher-note-row opNoteExtraRow';
  box.innerHTML='<textarea class="v-input v-note-input opNoteExtraInput" rows="2" placeholder="بيان جديد"></textarea><button type="button" class="opNoteRemove" style="border:1px solid #dc2626;background:#fee2e2;color:#b91c1c;border-radius:7px;padding:5px 10px;font-size:12px;font-weight:800;white-space:nowrap">حذف</button>';
  host.appendChild(box);
  box.querySelector('textarea').focus();
}
function collectOpNotes(){
  const parts=[document.getElementById('opNote')?.value||''];
  document.querySelectorAll('#opNoteExtra .opNoteExtraInput').forEach(t=>parts.push(t.value));
  return parts.map(x=>x.trim()).filter(Boolean).join('\n');
}
function setOpNotes(note){
  const lines=String(note||'').split('\n');
  const first=document.getElementById('opNote');if(first)first.value=lines[0]||'';
  const host=opNoteExtraHost();if(!host)return;
  host.innerHTML='';
  lines.slice(1).forEach(line=>{addOpNoteLine();const ta=host.lastElementChild.querySelector('textarea');ta.value=line;ta.blur();});
}

function saveOp(){
  const amount=Number(document.getElementById('opAmount').value);
  const note=collectOpNotes();
  const date=tempOpDate||new Date().toISOString().slice(0,10);
  const selectedCurrency=document.getElementById('vCurrency')?.value||data.settings.currency||'ر.ي';
  if(!amount||amount<0){toast('أدخل المبلغ');return}
  const p=data.people.find(x=>x.id===selected);if(!p){toast('خطأ');return}

  // كل سند يحتفظ بالعملة التي اختارها المستخدم؛ لا نفرض العملة الافتراضية
  // ولا نجعل حفظ السند مشروطاً بزر تفعيل تعدد العملات.
  const effectiveCurrency=selectedCurrency;

  // سقف المديونية: يمنع إضافة دين جديد إذا تجاوز صافي مديونية الحساب الحد المحدد،
  // ويحسب العمليات بعملة السند نفسها حتى لا نجمع عملات مختلفة دون تحويل.
  if(opType==='debt' && p.limitEnabled){
    const ceiling=Number(p.limitAmount||0);
    if(!(ceiling>0)){toast('سقف المديونية مفعّل لكن لم يُحدد مبلغ صحيح');return}
    const currentDebt=p.ops
      .filter(o=>(o.currency||data.settings.currency)===effectiveCurrency && (!currentOpId || o.id!==currentOpId))
      .reduce((sum,o)=>sum+(o.type==='debt'?Number(o.amount||0):-Number(o.amount||0)),0);
    if(currentDebt+amount>ceiling){
      const remaining=Math.max(0,ceiling-currentDebt);
      toast(`تم رفض الدين: سقف المديونية ${fmt(ceiling)} ${effectiveCurrency}، والمتبقي ${fmt(remaining)} ${effectiveCurrency}`);
      return;
    }
  }

  if(currentOpId){
    const op=p.ops.find(o=>o.id===currentOpId);
    if(op){
      op.amount=amount;op.note=note;op.type=opType;
      op.image=currentOpImage||'';op.date=date;op.currency=effectiveCurrency;
    }
    currentOpId=null;window._detailActiveCurrency=effectiveCurrency;save();closeModal('opModal');openDetail(selected);toast('تم التعديل');
  } else {
    p.ops.push({
      id:Date.now().toString(),type:opType,amount,date,note,
      image:currentOpImage||'',currency:effectiveCurrency,createdAt:Date.now()
    });
    const newBalance=p.ops.filter(o=>(o.currency||data.settings.currency)===effectiveCurrency)
      .reduce((sum,o)=>sum+(o.type==='debt'?o.amount:-o.amount),0);
    window._detailActiveCurrency=effectiveCurrency;
    window._pendingDetailCurrency=effectiveCurrency;
    save();closeModal('opModal');openDetail(selected);

    if(opType==='pay'&&newBalance<0){
      toast(`✅ تم — الرصيد الآن "له" ${fmt(Math.abs(newBalance))} ${effectiveCurrency}`);
    } else if(opType==='pay'&&newBalance===0){
      toast('✅ تم — الرصيد متعادل');
    } else {
      toast('تم الحفظ');
    }

    const sendMode=p.messageSend||data.settings.sendWhen||'never';
    if(sendMode==='auto'){
      setTimeout(()=>sendTransaction(p,opType,amount,{date,note,balance:newBalance,currency:effectiveCurrency,image:currentOpImage||''}),600);
    } else if(sendMode==='confirm'){
      setTimeout(()=>confirmSendMessage(p,opType,amount,{date,note,balance:newBalance,currency:effectiveCurrency,image:currentOpImage||''}),300);
    }
  }
}
function confirmSendMessage(person,type,amount,extra){
  let modal=document.getElementById('confirmSendModal');
  if(!modal){modal=document.createElement('div');modal.id='confirmSendModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}
  const text=buildMessageText(person,type,amount,extra);
  const effectiveMethod=data.settings.sendMethod||person.messageMethod||'whatsapp';
  const method=effectiveMethod==='whatsapp'?'واتساب':'SMS';
  modal.innerHTML=`<div class="sheet" style="max-width:480px"><h2 style="text-align:center">📤 تأكيد إرسال الرسالة</h2><div style="background:#f8fafc;border:1px solid var(--line);border-radius:12px;padding:14px;margin:14px 0;font-size:13px;line-height:1.7;white-space:pre-wrap;max-height:40vh;overflow:auto">${esc(text)}</div><div style="text-align:center;font-size:13px;color:var(--muted);margin-bottom:14px">سيتم الإرسال عبر: <b>${method}</b> إلى <b>${esc(person.phone||'لا يوجد رقم')}</b></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><button class="btn secondary" onclick="closeModal('confirmSendModal')">إلغاء</button><button class="btn primary" onclick="doSendNow()">📤 إرسال الآن</button></div></div>`;
  modal.classList.add('show');
  window._pendingSend={person,type,amount,extra};
}
function doSendNow(){const pending=window._pendingSend;if(pending){sendTransaction(pending.person,pending.type,pending.amount,pending.extra);}closeModal('confirmSendModal');window._pendingSend=null;}

function editOp(opId){const p=data.people.find(x=>x.id===selected);if(!p)return;const op=p.ops.find(o=>o.id===opId);if(!op)return;currentOpId=opId;currentOpImage=op.image||null;opType=op.type;tempOpDate=op.date;tempOpTime=null;document.getElementById('voucherTitle').textContent='تعديل سند';document.getElementById('opAmount').value=op.amount;document.getElementById('opNote').value=op.note||'';setOpNotes(op.note||'');updateVoucherDateTime();fillCurrencyDropdown();const currSel=document.getElementById('vCurrency');if(currSel&&op.currency)currSel.value=op.currency;updateVoucherBalance();setOp(op.type);if(op.image){document.getElementById('opImagePreview').innerHTML=`<img src="${op.image}"><input type="file" id="opImageInput" accept="image/*" style="display:none" onchange="previewOpImage(this)">`;}else{document.getElementById('opImagePreview').innerHTML='<input type="file" id="opImageInput" accept="image/*" style="display:none" onchange="previewOpImage(this)">';}document.getElementById('opModal').classList.add('show');}

function openOpImageAction(opId){const p=data.people.find(x=>x.id===selected);const op=p&&p.ops.find(x=>x.id===opId);if(!op)return;if(op.image){viewOpImage(opId);return;}editOp(opId);setTimeout(()=>{const input=document.getElementById('opImageInput');if(input)input.click();},180);}
function viewOpImage(opId){const p=data.people.find(x=>x.id===selected);if(!p)return;const op=p.ops.find(o=>o.id===opId);if(!op)return;if(!op.image){toast('لا صورة');return;}ivCurrentOpId=opId;document.getElementById('imageViewerSrc').src=op.image;document.getElementById('imageViewer').classList.add('show');}
function closeImageViewer(){document.getElementById('imageViewer').classList.remove('show');ivCurrentOpId=null;}
function ivSave(){const img=document.getElementById('imageViewerSrc');const src=img&&img.src;if(!src)return;const name=`صورة-معاملة-${ivCurrentOpId||Date.now()}.png`;try{if(window.SANative&&SANative.saveImageToGallery)SANative.saveImageToGallery(src,name);else if(window.AndroidBackup&&AndroidBackup.saveImageToGallery)AndroidBackup.saveImageToGallery(src,name);else{toast('ميزة الحفظ في الاستوديو غير متاحة');return;}toast('⏳ جارٍ حفظ الصورة في الاستوديو');}catch(e){toast('تعذر حفظ الصورة');}}
function ivShare(){const img=document.getElementById('imageViewerSrc');const src=img&&img.src;if(!src)return;const name=`صورة-معاملة-${ivCurrentOpId||Date.now()}.png`;try{if(window.SANative&&SANative.shareImage)SANative.shareImage(src,name,'صورة مرفقة بالمعاملة');else if(window.AndroidBackup&&AndroidBackup.shareImage)AndroidBackup.shareImage(src,name,'صورة مرفقة بالمعاملة');else toast('ميزة مشاركة الصور غير متاحة');}catch(e){toast('تعذرت مشاركة الصورة');}}
function ivReplace(){const input=document.createElement('input');input.type='file';input.accept='image/*';input.onchange=()=>{const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const p=data.people.find(x=>x.id===selected);const op=p&&p.ops.find(o=>o.id===ivCurrentOpId);if(op){op.image=r.result;save();document.getElementById('imageViewerSrc').src=r.result;openDetail(selected);toast('تم الاستبدال');}};r.readAsDataURL(f);};input.click();}
function ivDelete(){customConfirm('حذف الصورة؟',()=>{const p=data.people.find(x=>x.id===selected);const op=p&&p.ops.find(o=>o.id===ivCurrentOpId);if(op){op.image='';save();closeImageViewer();openDetail(selected);toast('تم الحذف');}},null,{title:'حذف صورة',icon:'📷',danger:true,confirmText:'حذف'});}

/* ============================================================
   مشاركة
   ============================================================ */
function shareOp(opId){const p=data.people.find(x=>x.id===selected);if(!p)return;const op=p.ops.find(o=>o.id===opId);if(!op)return;const bal=p.ops.reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);showShareChoice(p,op.type,op.amount,{date:op.date,note:op.note,balance:bal},op.image);}
function showShareChoice(person,type,amount,extra,opImage){let modal=document.getElementById('shareChoiceModal');if(!modal){modal=document.createElement('div');modal.id='shareChoiceModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}window._shareData={person,type,amount,extra,opImage};modal.innerHTML=`<div class="sheet"><h2>📤 مشاركة</h2><div style="display:grid;gap:10px"><button class="btn secondary" onclick="shareAsText()">📝 مشاركة كنص</button><button class="btn primary" onclick="shareAsImage()">🖼️ مشاركة كصورة</button>${opImage?'<button class="btn secondary" onclick="shareOriginalImage()">📷 الصورة المرفقة</button>':''}<button class="btn secondary" onclick="closeModal('shareChoiceModal')">إلغاء</button></div></div>`;modal.classList.add('show');}
function shareAsText(){const {person,type,amount,extra}=window._shareData;const text=buildMessageText(person,type,amount,extra);if(navigator.share)navigator.share({title:'سند',text}).catch(()=>{});else{navigator.clipboard.writeText(text);toast('تم النسخ');}closeModal('shareChoiceModal');}
async function shareAsImage(){const {person,type,amount,extra}=window._shareData;toast('جاري إنشاء الصورة...');try{const img=await generateReceiptImage(person,type,amount,extra);fetch(img).then(r=>r.blob()).then(blob=>{const file=new File([blob],`سند-${person.name}.png`,{type:'image/png'});if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){navigator.share({files:[file]});}else{const a=document.createElement('a');a.href=img;a.download=`سند-${person.name}.png`;a.click();toast('تم الحفظ');}});}catch(e){toast('حدث خطأ');}closeModal('shareChoiceModal');}
function shareOriginalImage(){const {opImage,person}=window._shareData;if(!opImage)return;fetch(opImage).then(r=>r.blob()).then(blob=>{const file=new File([blob],`صورة-${person.name}.png`,{type:blob.type});if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]}))navigator.share({files:[file]});});closeModal('shareChoiceModal');}

/* ============================================================
   بناء نص الرسالة
   ============================================================ */
function buildMessageText(person,type='account_created',amount=0,extra={}){
  const s=data.settings;
  const currency=extra.currency||s.currency||'';
  const date=extra.date||new Date().toISOString().slice(0,10);
  const balance=extra.balance||0;
  // مطابقة تنسيق رسالة المعاملة مع T.html
  const intro=s.msgIntro||'';
  const end=s.msgEnd||'';
  const payEnd=s.payEnd||'';
  const fmtDebt=s.msgFormatDebt||'عليكم';
  const fmtPay=s.msgFormatPay||'الرصيد لك';
  const amountLabel=type==='debt'?fmtDebt:type==='pay'?fmtPay:'';
  const balanceLabel=balance>=0?fmtDebt:fmtPay;
  const balanceValue=Math.abs(balance);
  const bayan=(extra.note||'').trim();
  const line='ـــــــــــــــــــــــــــــــــــــــــــــــــــــ';
  let text='';
  if(intro)text+=intro+'\n\n';
  text+=`اسم الحساب: ${person.name}\n\n`;
  text+=`التاريخ: ${date}\n${line}\n`;
  if(amount>0&&amountLabel){text+=`${amountLabel} ${fmt(amount)} ${currency}\n${line}\n`;}
  if(bayan)text+=`البيان: ${bayan}\n${line}\n`;
  const balanceTitle=type==='debt'?'الرصيد الكامل':'الرصيد الباقي';
  text+=`${balanceTitle}: ${balanceLabel} ${fmt(balanceValue)} ${currency}`;
  if(type==='debt'&&payEnd)text+=`\n\n${payEnd}`;
  if(end)text+=`\n\n${end}\n${line}`;
  return text;
}

/* ============================================================
   إرسال + واتساب
   ============================================================ */
function sendTransaction(person,type='account_created',amount=0,extra={}){
  if(!person)return;
  const s=data.settings;
  // طريقة الإرسال تُدار من الإعدادات؛ توقيت الإرسال يبقى اختيارًا خاصًا بالحساب.
  // إعداد الحساب الشخصي له الأولوية مثل T.html، وإعداد التطبيق هو البديل.
  const method=person.messageMethod||s.sendMethod||'whatsapp';
  const when=person.messageSend||s.sendWhen||'confirm';
  if(when==='never')return;
  if(extra.balance===undefined) extra.balance=person.ops.reduce((sum,o)=>sum+(o.type==='debt'?o.amount:-o.amount),0);
  const text=buildMessageText(person,type,amount,extra);

  let phone=(person.phone||'').replace(/[^0-9+]/g,'');
  const cc=(s.countryCode||'').trim();
  if(phone&&cc&&!phone.startsWith('+')){
    if(!phone.startsWith(cc.replace('+',''))) phone=cc+phone;
  }
  if(!phone){toast('لا يوجد رقم');return;}

  const lineKey=s.lineKey||'empty';
  if(lineKey==='zero'&&!phone.startsWith('0')) phone='0'+phone;
  if(lineKey==='country'&&cc&&!phone.startsWith(cc)) phone=cc+phone;

  // احتفظ بخيارات واتساب كما هي في T.html بما فيها اختيار التطبيق الآخر.
  const waType=s.waType||'business';
  sendConfiguredMessage(person,phone,text,extra,method,waType);
}

function sendConfiguredMessage(person,phone,text,extra,method,waType){
  const s=data.settings||{},image=extra&&extra.image;
  if(s.messageContent==='image'&&method==='whatsapp'&&image&&navigator.share){
    fetch(image).then(r=>r.blob()).then(blob=>{
      const type=blob.type||'image/jpeg',ext=type.indexOf('png')>=0?'png':type.indexOf('webp')>=0?'webp':'jpg';
      const file=new File([blob],`صورة-${person.name||'الحساب'}.${ext}`,{type});
      if(navigator.canShare&&navigator.canShare({files:[file]})){
        navigator.share({files:[file],title:'رسالة الحساب',text}).catch(e=>{if(e&&e.name!=='AbortError')openWhatsApp(phone,text,waType)});
      }else{toast('تعذرت مشاركة الصورة؛ سيتم فتح الرسالة النصية');openWhatsApp(phone,text,waType)}
    }).catch(()=>{toast('تعذر تجهيز الصورة؛ سيتم فتح الرسالة النصية');openWhatsApp(phone,text,waType)});
    return;
  }
  if(s.messageContent==='image'&&image&&method==='whatsapp'&&!navigator.share)toast('مشاركة الصور غير مدعومة هنا؛ سيتم فتح الرسالة النصية');
  if(s.messageContent==='image'&&!image)toast('لا توجد صورة مرفقة؛ سيتم إرسال النص');
  if(s.messageContent==='image'&&method!=='whatsapp')toast('إرسال الصورة متاح عبر قائمة المشاركة؛ سيتم إرسال النص عبر SMS');
  if(method==='whatsapp')openWhatsApp(phone,text,waType);
  else window.location.href=`sms:${phone}?body=${encodeURIComponent(text)}`;
}

function launchWhatsAppTarget(phone,encodedText,waType){
  const cleanPhone=String(phone||"").replace(/[^0-9]/g,"");
  let text="";
  try{text=decodeURIComponent(encodedText||"");}catch(e){text=String(encodedText||"");}
  if(!cleanPhone)return;
  if(window.AndroidBridge&&typeof window.AndroidBridge.openWhatsApp==="function"){
    window.AndroidBridge.openWhatsApp(cleanPhone,text,waType==="green"?"green":"business");
    return;
  }
  window.location.href="https://wa.me/"+cleanPhone+"?text="+encodeURIComponent(text);
}
function openWhatsApp(phone,text,waType='business'){
  const cleanPhone=String(phone).replace(/[^0-9]/g,'');
  if(waType!=='other'&&window.AndroidBridge&&typeof window.AndroidBridge.openWhatsApp==='function'){
    try{window.AndroidBridge.openWhatsApp(cleanPhone,String(text||''),waType==='green'?'green':'business');return;}
    catch(e){console.warn('Native WhatsApp launch failed; using web fallback',e);}
  }
  const encodedText=encodeURIComponent(text);
  if(waType==='green'){
    launchWhatsAppTarget(cleanPhone,encodedText,'green');
  } else if(waType==='business'){
    launchWhatsAppTarget(cleanPhone,encodedText,'business');
  } else if(waType==='other'){
    showWhatsAppChoice(cleanPhone,encodedText);
  } else {
    launchWhatsAppTarget(cleanPhone,encodedText,'business');
  }
}

function showWhatsAppChoice(phone,encodedText){
  let modal=document.getElementById('waChoiceModal');
  if(!modal){modal=document.createElement('div');modal.id='waChoiceModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}
  modal.innerHTML=`<div class="sheet" style="max-width:420px">
    <h2 style="text-align:center">اختر تطبيق الإرسال</h2>
    
    <p style="text-align:center;font-size:12px;color:var(--muted);margin-bottom:14px">رقم المستلم: <b dir="ltr">${esc(phone)}</b></p>
    <div style="display:grid;gap:10px">
      <button onclick="doOpenWA('green','${phone}','${encodedText}')" style="display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid #25D366;border-radius:12px;cursor:pointer">
        <div style="width:44px;height:44px;border-radius:50%;background:#25D366;color:#fff;display:grid;place-items:center;font-size:22px">💬</div>
        <div style="flex:1;text-align:right"><div style="font-size:15px;font-weight:900;color:#128A3D">واتساب العادي (الأخضر)</div><div style="font-size:11px;color:#64748b;margin-top:4px">WhatsApp Messenger</div></div>
      </button>
      <button onclick="doOpenWA('business','${phone}','${encodedText}')" style="display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid #128C7E;border-radius:12px;cursor:pointer">
        <div style="width:44px;height:44px;border-radius:50%;background:#128C7E;color:#fff;display:grid;place-items:center;font-size:22px">💼</div>
        <div style="flex:1;text-align:right"><div style="font-size:15px;font-weight:900;color:#128C7E">واتساب الأعمال</div><div style="font-size:11px;color:#64748b;margin-top:4px">WhatsApp Business</div></div>
      </button>

    </div>
    <button class="btn secondary" style="width:100%;margin-top:14px" onclick="closeModal('waChoiceModal')">إلغاء</button>
  </div>`;
  modal.classList.add('show');
}
function doOpenWA(type,phone,encodedText){
  closeModal('waChoiceModal');
  const cleanPhone=String(phone).replace(/[^0-9]/g,'');
  const isAndroid=/android/i.test(navigator.userAgent);
  const isIOS=/iphone|ipad|ipod/i.test(navigator.userAgent);
  if(type==='green'){
    launchWhatsAppTarget(cleanPhone,encodedText,'green');
  } else if(type==='business'){
    launchWhatsAppTarget(cleanPhone,encodedText,'business');
  } else {
    window.open(`https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`,'_blank');
  }
}

/* ============================================================
   إحصائيات وبحث
   ============================================================ */
function openStatsModal(){let modal=document.getElementById('statsModal');if(!modal){modal=document.createElement('div');modal.id='statsModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}const ops=data.people.flatMap(p=>p.ops);const debt=ops.filter(o=>o.type==='debt').reduce((s,o)=>s+o.amount,0);const pay=ops.filter(o=>o.type==='pay').reduce((s,o)=>s+o.amount,0);modal.innerHTML=`<div class="sheet"><h2>💰 الإحصائيات</h2><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div style="border:2px solid var(--primary);border-radius:14px;padding:14px;text-align:center"><b>${data.folders.length}</b><span style="font-size:11px;color:var(--muted);display:block">مجلدات</span></div><div style="border:2px solid var(--primary);border-radius:14px;padding:14px;text-align:center"><b>${data.people.length}</b><span style="font-size:11px;color:var(--muted);display:block">حسابات</span></div><div style="border:2px solid var(--red);border-radius:14px;padding:14px;text-align:center"><b style="color:var(--red)">${money(debt)}</b><span style="font-size:11px;color:var(--muted);display:block">ديون</span></div><div style="border:2px solid var(--green);border-radius:14px;padding:14px;text-align:center"><b style="color:var(--green)">${money(pay)}</b><span style="font-size:11px;color:var(--muted);display:block">تسديد</span></div></div><button class="btn secondary" style="width:100%;margin-top:14px" onclick="closeModal('statsModal')">إغلاق</button></div>`;modal.classList.add('show');}

function openQuickSearch(){let modal=document.getElementById('quickSearchModal');if(!modal){modal=document.createElement('div');modal.id='quickSearchModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet"><h2>🔍 بحث سريع</h2><div class="field"><input id="quickSearchInput" class="smallInput" placeholder="ابحث..." oninput="doQuickSearch(this.value)"></div><div id="quickSearchResults"><div style="text-align:center;padding:20px;color:var(--muted);font-size:13px">اكتب للبحث...</div></div></div>`;modal.classList.add('show');setTimeout(()=>document.getElementById('quickSearchInput')?.focus(),200);}
function doQuickSearch(q){q=(q||'').trim().toLowerCase();const results=document.getElementById('quickSearchResults');if(!q){results.innerHTML='<div style="text-align:center;padding:20px;color:var(--muted)">اكتب للبحث...</div>';return;}const list=data.people.filter(p=>p.name.toLowerCase().includes(q));if(!list.length){results.innerHTML='';return;}results.innerHTML=list.map(p=>{const bal=p.ops.reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);const f=data.folders.find(x=>x.id===p.folderId);return `<div class="person" onclick="closeModal('quickSearchModal');openDetail('${p.id}','search')"><div class="avatar">${esc(p.name[0]||'؟')}</div><div class="pmain"><div class="pname">${esc(p.name)}</div><div style="font-size:11px;color:var(--muted)">${f?'📁 '+esc(f.name):''}</div></div><div class="balance ${bal>0?'positive':bal<0?'negative':'zero'}"><small>المتبقي</small>${fmt(Math.abs(bal))}</div></div>`;}).join('');}

/* ============================================================
   زر الرجوع
   ============================================================ */
function handleBackButton(){if(window.SANav){SANav.back('.section',function(e){return e.classList.contains('on')},function(){navigateBack();});}else{navigateBack();}return true;}

/* ============================================================
   تأكيد الخروج — العودة إلى index.html في المجلد الرئيسي
   ============================================================ */
function showExitConfirm(){
  // تذكير النسخ الاحتياطي يظهر فقط عند محاولة الخروج من الصفحة الرئيسية admin.html.
  // لا يشترط اتصال Google Drive لعرض التذكير؛ اختيار النسخ يستدعي خدمة النسخ المتاحة.
  customConfirm('هل تريد إنشاء نسخة احتياطية قبل الخروج من التطبيق؟',
    ()=>startExitBackup(),()=>{_exitPending=false;},
    {title:'تذكير النسخ الاحتياطي',icon:'☁️',confirmText:'نسخ احتياطي ثم خروج',cancelText:'البقاء في التطبيق'});
}
function doExitApp(){
  _exitPending=true;
  if(window.AndroidBridge&&typeof AndroidBridge.exitApp==='function'){AndroidBridge.exitApp();}
  else{window.location.replace('about:blank');}
}
let _exitBackupTimer=null;
function startExitBackup(){
  _exitPending=true;
  if(_exitBackupTimer)clearTimeout(_exitBackupTimer);
  try{
    save();
    const payload=buildCloudBackupPayload();
    const filename=generateBackupFilename('RYD').replace(/\\.json$/i,'.back');
    const bridge=window.AndroidBackup;
    if(bridge&&typeof bridge.startExitBackup==='function'){
      // Android obtains Drive authorization, starts a foreground upload service,
      // then closes the app. The persistent notification reports completion.
      bridge.startExitBackup(payload,filename);
      toast('سيبدأ رفع النسخة في الخلفية بعد تأكيد صلاحية Google');
      return;
    }
    if(bridge&&typeof bridge.backupToGoogleDrive==='function'){
      bridge.backupToGoogleDrive(payload,filename);
      toast('خدمة الرفع المستمر بعد إغلاق التطبيق غير متاحة في هذا الإصدار');
      return;
    }
    localStorage.setItem('smartadmin_exit_backup_local',payload);
    localStorage.setItem('smartadmin_exit_backup_time',String(Date.now()));
    customAlert('لا تتوفر خدمة النسخ السحابي في التطبيق المضيف. تم حفظ نسخة احتياطية محلية على الجهاز قبل الخروج.',{title:'نسخة محلية محفوظة',icon:'📦'});
    setTimeout(doExitApp,900);
  }catch(e){
    console.error('Exit backup failed',e);
    customAlert('تعذر إنشاء النسخة الاحتياطية. سيتم إغلاق التطبيق دون رفع نسخة.',{title:'تعذر النسخ الاحتياطي',icon:'⚠️'});
    setTimeout(doExitApp,1400);
  }
}

function fabAction(){
  const detailSection=document.getElementById('detail');
  if(detailSection&&detailSection.classList.contains('on')&&selected){openOp('debt');return;}
  if(currentFolderId===null){openFolderAdd();return;}
  openFolderInvoice(null);
}

/* ============================================================
   الإعدادات
   ============================================================ */
function openSettingsPage(page,skipNav=false){
  if(!skipNav){_navOpenSettingsPage(page);}
  const settingsHome=document.getElementById('settingsHome');
  const settingsSub=document.getElementById('settingsSub');
  settingsHome.classList.remove('on','page-enter-forward','page-enter-back');
  settingsSub.classList.remove('page-enter-forward','page-enter-back');
  settingsSub.classList.add('on',pageTransitionDirection==='back'?'page-enter-back':'page-enter-forward');
  setTimeout(()=>settingsSub.classList.remove('page-enter-forward','page-enter-back'),420);
  const t={salesTypes:['أنواع البيع',''],privateAccounts:['الحسابات الخصوصية','إعدادات مرتبطة بالحسابات الخصوصية'],profile:['الملف الشخصي','بيانات صاحب التطبيق'],language:['اللغة ومظهر التطبيق','تخصيص اللغة والمظهر والخط'],appLock:['قفل التطبيق','حماية التطبيق'],permissions:['الأذونات','إدارة الصلاحيات'],trash:['سلة المحذوفات','إدارة العناصر المحذوفة'],messages:['الرسائل والواتساب','تخصيص الرسائل'],printing:['إعدادات الطباعة','PDF والورق'],currencies:['العملات','إدارة العملات'],invoices:['إعدادات الفواتير','الفواتير جزء من بيانات التطبيق وتُحفظ داخل المجلد المحدد'],backup:['النسخ الاحتياطي والاستعادة','الهاتف، Telegram والملفات'],gdriveBackup:['النسخ الاحتياطي لجوجل درايف','حساب Google + جدولة تلقائية'],tutorial:['شرح التطبيق على اليوتيوب','رابط فيديو الشرح'],terms:['شروط الخدمة','النص المعتمد لشروط استخدام التطبيق'],privacy:['سياسة الخصوصية','النص المعتمد لسياسة البيانات'],contact:['تواصل معنا','واتساب أو بريد الدعم'],share:['مشاركة التطبيق','إرسال رابط التطبيق'],about:['عن التطبيق','معلومات التطبيق والمطور'],allAccounts:['كل الحسابات','عرض الكل']}[page]||['الإعدادات',''];
  document.getElementById('subTitle').textContent=t[0];
  document.getElementById('subDesc').textContent=t[1];
  document.getElementById('subContent').innerHTML=renderSettingsPage(page);
}
function closeSettingsPage(){
  const sub=document.getElementById('settingsSub'),home=document.getElementById('settingsHome');
  if(sub)sub.classList.remove('on','page-enter-forward','page-enter-back');
  if(home){home.classList.remove('page-enter-forward','page-enter-back');home.classList.add('on','page-enter-back');setTimeout(()=>home.classList.remove('page-enter-back'),420);}
  if(typeof peekNav==='function'&&typeof popNav==='function'){const top=peekNav();if(top&&top.type==='settingsPage')popNav();}
}

function saveSettingsLegalText(page){
  const el=document.getElementById('settingsLegalText');if(!el)return;
  const key=page==='terms'?'serviceTermsText':'privacyPolicyText';data.settings[key]=el.value.trim();save();toast('تم حفظ النص');openSettingsPage(page,true);
}
function saveSettingsYoutubeLink(){
  const el=document.getElementById('settingsYoutubeUrl'),v=el?el.value.trim():'';
  if(v&&!/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(v)){alert('أدخل رابط YouTube صحيحًا يبدأ بـ https://');return}
  localStorage.setItem('settingsTutorialYoutubeUrl',v);toast('تم حفظ رابط الشرح');
}
function openSettingsYoutubeLink(){
  const v=localStorage.getItem('settingsTutorialYoutubeUrl')||'';
  window.open(v||'https://www.youtube.com/results?search_query='+encodeURIComponent('شرح تطبيق الاداري برو'),'_blank','noopener');
}
function saveSettingsContactDetails(){
  const p=(document.getElementById('settingsSupportPhoneInput')||{}).value||'',phone=p.replace(/[^0-9]/g,'');
  const e=(document.getElementById('settingsSupportEmail')||{}).value.trim();
  if(phone.length<8){alert('أدخل رقم واتساب صحيحًا مع رمز الدولة.');return}
  if(e&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)){alert('أدخل بريدًا إلكترونيًا صحيحًا.');return}
  localStorage.setItem('settingsSupportPhone',phone);localStorage.setItem('settingsSupportEmail',e);toast('تم حفظ بيانات التواصل');
}
function openSettingsContactWhatsApp(){
  const phone=(localStorage.getItem('settingsSupportPhone')||((data.settings.activation||{}).devWhatsApp)||'967773544574').replace(/[^0-9]/g,'');
  if(phone)window.open('https://wa.me/'+phone,'_blank','noopener');
}
async function shareApplication(){
  const payload={title:document.title||'الاداري برو',text:'شارك تطبيق الاداري برو',url:location.href};
  try{if(navigator.share){await navigator.share(payload);return}if(navigator.clipboard){await navigator.clipboard.writeText(location.href);toast('تم نسخ رابط التطبيق');return}prompt('انسخ رابط التطبيق',location.href)}catch(e){if(e&&e.name!=='AbortError')toast('تعذرت مشاركة الرابط')}
}


const DESIGN_TYPES=[['neumorphism','Neumorphism'],['glassmorphism','Glassmorphism'],['skeuomorphism','Skeuomorphism'],['material3','Material Design 3'],['flat','Flat Design'],['fluent','Fluent Design'],['bento','Bento Grid'],['luxury','Luxury UI'],['neobrutalism','Neobrutalism'],['minimal','Minimal UI'],['ui3d','3D UI'],['futuristic','Futuristic UI'],['classic','Classic UI'],['editorial','Editorial UI'],['hybrid','Hybrid UI']];
function getDesignType(a){a=a||((typeof data!=='undefined'&&data.settings&&data.settings.appearance)||{});const t=a.designType;if(t&&DESIGN_TYPES.some(function(x){return x[0]===t}))return t;return a.visualStyle==='classic'?'classic':'glassmorphism'}
function applyDesignToDoc(doc){try{if(!doc||!doc.body)return;const t=getDesignType();doc.body.classList.toggle('glass-classic',t==='glassmorphism');if(t==='glassmorphism'||t==='classic')doc.body.removeAttribute('data-design');else doc.body.setAttribute('data-design',t)}catch(e){}}
function setDesignType(t){if(!DESIGN_TYPES.some(function(x){return x[0]===t}))return;data.settings.appearance=data.settings.appearance||{};data.settings.appearance.designType=t;data.settings.appearance.visualStyle=(t==='glassmorphism')?'glassClassic':'classic';save();applyAppearanceSettings();try{document.querySelectorAll('iframe').forEach(function(fr){applyDesignToDoc(fr.contentDocument)})}catch(e){}if(typeof toast==='function')toast('تم تغيير نوع التصميم')}
function applyButtonRadiusToDoc(doc,radius){
  if(!doc||!doc.documentElement)return;
  const selector='button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],.btn';
  doc.__currentButtonShapeRadius=radius;
  function setOne(el){if(el&&el.nodeType===1&&el.matches&&el.matches(selector))el.style.setProperty('border-radius',doc.__currentButtonShapeRadius,'important');}
  function setTree(root){setOne(root);if(root&&root.querySelectorAll)root.querySelectorAll(selector).forEach(setOne);}
  try{doc.querySelectorAll(selector).forEach(setOne);}catch(e){}
  if(!doc.__buttonShapeObserver&&doc.defaultView&&doc.defaultView.MutationObserver){
    const obs=new doc.defaultView.MutationObserver(function(records){records.forEach(function(r){r.addedNodes.forEach(setTree);});});
    try{obs.observe(doc.documentElement,{childList:true,subtree:true});doc.__buttonShapeObserver=obs;}catch(e){}
  }
}
function getAccessibleFrameColor(hex){
  const m=String(hex||'').match(/^#([0-9a-f]{6})$/i);
  if(!m)return '#111827';
  const n=parseInt(m[1],16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;
  const linear=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};
  const luminance=0.2126*linear(r)+0.7152*linear(g)+0.0722*linear(b);
  // أبيض للثيمات الداكنة، وأسود للثيمات الفاتحة لضمان تباين واضح على الأشرطة والبطاقات.
  return luminance<0.42?'#FFFFFF':'#111827';
}
function applyAppearanceSettings(){
  const a=data.settings.appearance||{};
  const frameEnabled=a.frameEnabled!==false;
  document.documentElement.classList.toggle('app-frames-disabled',!frameEnabled);
  if(!window.__frameToggleObserver&&typeof MutationObserver==='function'){
    window.__frameToggleObserver=new MutationObserver(function(records){var found=false;records.forEach(function(rec){Array.prototype.forEach.call(rec.addedNodes,function(n){if(n&&n.nodeType===1&&(n.tagName==='IFRAME'||(n.querySelector&&n.querySelector('iframe'))))found=true;});});if(found)setTimeout(function(){applyAppearanceSettings();},0);});
    window.__frameToggleObserver.observe(document.documentElement,{childList:true,subtree:true});
  }
  const glassClassic=getDesignType(a)==='glassmorphism';
  applyDesignToDoc(document);
  const colorMap={gold:'#b08a36',silver:'#8b929b',copper:'#a76542'};
  const widthMap={thin:'1px',medium:'2px',thick:'3px'};
  const buttonRadiusMap={classic:'8px',rounded:'14px',simple:'3px'};
  const frameRadiusMap={square:'0px',soft:'6px',rounded:'14px',round:'24px',pill:'999px',circle:'50%'};
  const frameStyleMap={solid:'solid',dashed:'dashed',dotted:'dotted',double:'double',groove:'groove',ridge:'ridge',inset:'inset',outset:'outset'};
  const rawColor=String(a.frameColor||'gold');
  const activeThemeColor=/^#[0-9a-f]{6}$/i.test(String(data.settings&&data.settings.color||''))?String(data.settings.color):'#1e40af';
  const frameColor=rawColor==='theme'?getAccessibleFrameColor(activeThemeColor):(/^#[0-9a-f]{6}$/i.test(rawColor)?rawColor:(colorMap[rawColor]||colorMap.gold));
  const frameColorEnabled=a.frameColorEnabled!==false,frameShapeEnabled=a.frameShapeEnabled!==false,frameStyleEnabled=a.frameStyleEnabled!==false,frameThicknessEnabled=a.frameThicknessEnabled!==false;
  const appliedFrameColor=frameColorEnabled?frameColor:activeThemeColor;
  const frameRadius=frameShapeEnabled?(frameRadiusMap[a.frameShape]||frameRadiusMap.rounded):'14px';
  const frameWidth=frameThicknessEnabled?(widthMap[a.frameThickness]||widthMap.thin):widthMap.thin;
  const frameStyle=frameStyleEnabled?(frameStyleMap[a.frameStyle]||'solid'):'solid';
  document.documentElement.style.setProperty('--primary-contrast',getAccessibleFrameColor(activeThemeColor));
  document.documentElement.style.setProperty('--custom-frame-color',appliedFrameColor);
  document.documentElement.style.setProperty('--custom-frame-width',frameWidth);
  document.documentElement.style.setProperty('--custom-frame-radius',frameRadius);
  document.documentElement.style.setProperty('--custom-frame-style',frameStyle);
  document.documentElement.style.setProperty('--custom-button-radius',buttonRadiusMap[a.buttonShape]||buttonRadiusMap.classic);
  document.documentElement.style.setProperty('--custom-shadow',a.shadows===false?'none':'0 3px 10px rgba(0,0,0,.16)');
  document.body.classList.toggle('custom-shadows-off',a.shadows===false);
  document.documentElement.style.setProperty('--custom-background-image',a.backgroundData?`url("${a.backgroundData}")`:'none');
  document.documentElement.style.setProperty('--custom-background-opacity',String((a.backgroundOpacity??100)/100));
  // نطاق موحّد لكل العناصر التي قد تحمل إطاراً: البطاقات والحقول والأزرار والأشرطة.
  // استخدام selectors عامة هنا يضمن شمول العناصر التي تُنشأ لاحقاً من JavaScript أيضاً.
  const frameTargets='.settingsCard,.person,.folder-card-v2,.folder-card,.folder-card-icon,.card,.panel,.sheet,.tsC,.tsBox,.purchase-card,.modal,.modal-content,.account-card,.transaction-card,.invoice-card,button,input[type=button],input[type=submit],input[type=reset],[role=button],.btn,.quick-btn-new,.primary,.secondary,.danger,.action-btn,.btn-primary,.fab,.top,.bottom-bar,.selection-bar,.op-toolbar,.statement-header,.filter-bar,.date-bar,.statement-footer,.currency-row,[class$="-bar"],[class$="Bar"],.bar,.toolbar,.action-bar,.header,.footer,.navbar,.tabbar,.page-header,.app-header,.section-header,.totals-bar,.summary-bar,.filterbar,.ui-appbar,.subTop,.voucher-header,.settings-header,.settings-titlebar,#homeClock .clock-item:not(#clockTasfeerBtn),#fullFilterPage .dfC,#fullFilterPage .dfS>div,#tsPage .tsC,#tsPage .tsF,#tsPage .tsF .ic,#tsPage .tsFund,.accounts-icon,.account-icon,.program-icon.accounts,[class*="account"][class*="icon"]';
  const frameOffSelectors='.settingsCard,.person,.folder-card-v2,.folder-card,.folder-card-icon,.card,.panel,.sheet,.tsC,.tsBox,.purchase-card,.modal,.modal-content,.account-card,.transaction-card,.invoice-card,button,input[type=button],input[type=submit],input[type=reset],[role=button],.btn,.quick-btn-new,.primary,.secondary,.danger,.action-btn,.btn-primary,.fab,.top,.bottom-bar,.selection-bar,.op-toolbar,.statement-header,.filter-bar,.date-bar,.statement-footer,.currency-row,[class$="-bar"],[class$="Bar"],.bar,.toolbar,.action-bar,.header,.footer,.navbar,.tabbar,.page-header,.app-header,.section-header,.totals-bar,.summary-bar,.filterbar,.ui-appbar,.subTop,.voucher-header,.settings-header,.settings-titlebar,#homeClock .clock-item:not(#clockTasfeerBtn),#fullFilterPage .dfC,#fullFilterPage .dfS>div,#tsPage .tsC,#tsPage .tsF,#tsPage .tsF .ic,#tsPage .tsFund,.accounts-icon,.account-icon,.program-icon.accounts,[class*="account"][class*="icon"]';
  const frameOffSelectorList=frameOffSelectors.split(',').map(function(sel){return 'html.app-frames-disabled body '+sel}).join(',');
  const frameOffCss=frameOffSelectorList+'{border:0!important;border-width:0!important;border-style:none!important;border-color:transparent!important;border-image:none!important;outline:none!important;box-shadow:none!important}html.app-frames-disabled iframe{border:0!important;border-width:0!important;border-style:none!important;border-color:transparent!important;border-image:none!important;outline:none!important;box-shadow:none!important}';
  const frameGlobalCss=frameTargets+'{border-color:var(--custom-frame-color)!important;border-width:var(--custom-frame-width)!important;border-style:var(--custom-frame-style)!important}';
  function syncFrameOffStyle(doc){if(!doc||!doc.documentElement)return;var st=doc.getElementById('global-app-frame-disabled-css');if(!st){st=doc.createElement('style');st.id='global-app-frame-disabled-css';(doc.head||doc.documentElement).appendChild(st)}st.textContent=frameGlobalCss+' '+frameOffCss;doc.documentElement.classList.toggle('app-frames-disabled',!frameEnabled);}
  syncFrameOffStyle(document);
  document.querySelectorAll(frameTargets).forEach(el=>{if(!frameEnabled){el.style.setProperty('border','none','important');el.style.setProperty('outline','none','important');return}el.style.removeProperty('border');el.style.removeProperty('outline');el.style.setProperty('border-radius',frameRadius,'important');el.style.setProperty('border-color',appliedFrameColor,'important');el.style.setProperty('border-width',frameWidth,'important');el.style.setProperty('border-style',frameStyle,'important');el.style.setProperty('transition','none','important');});
  document.querySelectorAll('iframe').forEach(fr=>{
    if(!fr.__globalFrameToggleBound){fr.__globalFrameToggleBound=true;fr.addEventListener('load',function(){try{applyAppearanceSettings()}catch(e){}});}
    if(frameEnabled){fr.style.removeProperty('border');fr.style.removeProperty('outline');fr.style.setProperty('border-radius',frameRadius,'important');fr.style.setProperty('border-color',appliedFrameColor,'important');fr.style.setProperty('border-width',frameWidth,'important');fr.style.setProperty('border-style',frameStyle,'important');}
    else{fr.style.setProperty('border','none','important');fr.style.setProperty('outline','none','important');}
    try{const d=fr.contentDocument;if(!d||!d.documentElement)return;syncFrameOffStyle(d);applyDesignToDoc(d);const r=d.documentElement.style;r.setProperty('--custom-frame-color',appliedFrameColor);r.setProperty('--custom-frame-width',frameWidth);r.setProperty('--custom-frame-radius',frameRadius);r.setProperty('--custom-frame-style',frameStyle);r.setProperty('--custom-button-radius',buttonRadiusMap[a.buttonShape]||buttonRadiusMap.classic);r.setProperty('--custom-shadow',a.shadows===false?'none':'0 3px 10px rgba(0,0,0,.16)');r.setProperty('--custom-background-image',a.backgroundData?`url("${a.backgroundData}")`:'none');r.setProperty('--custom-background-opacity',String((a.backgroundOpacity??100)/100));d.querySelectorAll(frameTargets).forEach(el=>{if(!frameEnabled){el.style.setProperty('border','none','important');el.style.setProperty('outline','none','important');return}el.style.removeProperty('border');el.style.removeProperty('outline');el.style.setProperty('border-radius',frameRadius,'important');el.style.setProperty('border-color',appliedFrameColor,'important');el.style.setProperty('border-width',frameWidth,'important');el.style.setProperty('border-style',frameStyle,'important');el.style.setProperty('transition','none','important');});}catch(e){}
  });
  const activeButtonRadius=buttonRadiusMap[a.buttonShape]||buttonRadiusMap.classic;
  applyButtonRadiusToDoc(document,activeButtonRadius);
  document.querySelectorAll('iframe').forEach(fr=>{try{applyButtonRadiusToDoc(fr.contentDocument,activeButtonRadius);}catch(e){}});
  const picker=document.getElementById('appearanceFrameColorPicker');if(picker&&/^#[0-9a-f]{6}$/i.test(frameColor))picker.value=frameColor;
  const valueLabel=document.getElementById('appearanceFrameColorValue');if(valueLabel)valueLabel.textContent=frameColor;
  const themeFrameOption=document.getElementById('appearanceThemeFrameOption');if(themeFrameOption){themeFrameOption.classList.toggle('active',rawColor==='theme');themeFrameOption.setAttribute('aria-pressed',String(rawColor==='theme'));}
  const themeFramePreview=document.getElementById('appearanceThemeFramePreview');if(themeFramePreview)themeFramePreview.style.background=activeThemeColor;
  const themeFrameHex=document.getElementById('appearanceThemeFrameHex');if(themeFrameHex)themeFrameHex.textContent=activeThemeColor;
  updateFrameToggleButtons(a);
  if(typeof window.__applyGlobalAppPreferences==='function')window.__applyGlobalAppPreferences();
}
function updateFrameToggleButtons(a){
  const keys=['frameEnabled','frameColorEnabled','frameShapeEnabled','frameStyleEnabled','frameThicknessEnabled'];
  keys.forEach(function(key){const btn=document.getElementById('frameToggle-'+key);if(!btn)return;const enabled=!a||a[key]!==false;btn.classList.toggle('is-on',enabled);btn.classList.toggle('is-off',!enabled);btn.setAttribute('aria-checked',String(enabled));const state=btn.querySelector('.frame-toggle-state');if(state)state.textContent=enabled?'مفعل':'متوقف';});
}
function toggleFrameSetting(key){
  const allowed=['frameEnabled','frameColorEnabled','frameShapeEnabled','frameStyleEnabled','frameThicknessEnabled'];if(!allowed.includes(key))return;
  data.settings.appearance=data.settings.appearance||{};const a=data.settings.appearance;a[key]=a[key]===false;save();applyAppearanceSettings();
}
function setAppearanceOption(key,value){
  data.settings.appearance=data.settings.appearance||{};
  data.settings.appearance[key]=value;
  save();applyAppearanceSettings();
}
function setAppearanceOpacity(value){data.settings.appearance=data.settings.appearance||{};data.settings.appearance.backgroundOpacity=Number(value);const label=document.getElementById('appearanceOpacityLabel');if(label)label.textContent=value+'%';applyAppearanceSettings();save();}
function uploadAppearanceBackground(input){const file=input.files&&input.files[0];if(!file)return;if(!file.type.startsWith('image/')){toast('اختر ملف صورة صالحًا');return}if(file.size>5*1024*1024){toast('حجم الصورة كبير؛ اختر صورة أقل من 5 ميجابايت');input.value='';return}const reader=new FileReader();reader.onload=async()=>{const small=await shrinkImageDataUrl(reader.result,1440,0.8);data.settings.appearance=data.settings.appearance||{};data.settings.appearance.backgroundData=small;save();applyAppearanceSettings();openSettingsPage('appearance',true);toast('تم تطبيق الخلفية');};reader.onerror=()=>toast('تعذر قراءة الصورة');reader.readAsDataURL(file);}
function clearAppearanceBackground(){if(data.settings.appearance){delete data.settings.appearance.backgroundData;save();}applyAppearanceSettings();openSettingsPage('appearance',true);toast('تمت إزالة الخلفية المخصصة');}

function renderSettingsPage(page){
  if(page==='appearance'){
    const a=data.settings.appearance||(data.settings.appearance={frameColor:'gold',frameEnabled:true,buttonShape:'classic',shadows:true,frameThickness:'thin',backgroundOpacity:100,frameShape:'rounded',frameStyle:'solid'});
    const colorMap={gold:'#b08a36',silver:'#8b929b',copper:'#a76542'};
    const rawColor=String(a.frameColor||'gold');
    const activeThemeColor=/^#[0-9a-f]{6}$/i.test(String(data.settings.color||''))?String(data.settings.color):'#1e40af';
    const frameColorNow=rawColor==='theme'?getAccessibleFrameColor(activeThemeColor):(/^#[0-9a-f]{6}$/i.test(rawColor)?rawColor:(colorMap[rawColor]||colorMap.gold));
    const frameShapeNow=a.frameShape||'rounded',frameStyleNow=a.frameStyle||'solid';
    const visualStyleNow=a.visualStyle||'glassClassic',designNow=getDesignType(a);
    const frameMasterEnabled=a.frameEnabled!==false;
    const frameMasterToggleMarkup=`<div class="frame-option-toggle-row frame-master-toggle"><b>إطار التطبيق</b><button type="button" id="frameToggle-frameEnabled" class="frame-option-switch ${frameMasterEnabled?'is-on':'is-off'}" role="switch" aria-checked="${frameMasterEnabled}" onclick="toggleFrameSetting('frameEnabled')"><span class="frame-option-knob"></span><span class="frame-toggle-state">${frameMasterEnabled?'مفعل':'متوقف'}</span></button></div>`;
    const frameToggleMarkup=[['frameColorEnabled','لون الإطار'],['frameShapeEnabled','شكل الإطار'],['frameStyleEnabled','نمط خط الإطار'],['frameThicknessEnabled','سمك الإطار']].map(function(item){const key=item[0],label=item[1],enabled=a[key]!==false;return '<div class="frame-option-toggle-row"><b>'+label+'</b><button type="button" id="frameToggle-'+key+'" class="frame-option-switch '+(enabled?'is-on':'is-off')+'" role="switch" aria-checked="'+enabled+'" onclick="toggleFrameSetting(\''+key+'\')"><span class="frame-option-knob"></span><span class="frame-toggle-state">'+(enabled?'مفعل':'متوقف')+'</span></button></div>';}).join('');
    const shapeChoices=[['square','مربع','0px'],['soft','زوايا خفيفة','6px'],['rounded','مستدير','14px'],['round','دائري الزوايا','24px'],['pill','كبسولي','999px'],['circle','دائري','50%']];
    const lineChoices=[['solid','متصل'],['dashed','متقطع'],['dotted','منقّط'],['double','مزدوج'],['groove','محفور'],['ridge','بارز'],['inset','داخلي'],['outset','خارجي']];
    const palette=[['#FFFFFF','الأبيض'],['#000000','الأسود'],['#D3D3D3','الرمادي الفاتح'],['#2F4F4F','الفحمي'],['#F5F5DC','البيج'],['#A52A2A','البني'],['#000080','الكحلي'],['#4169E1','الأزرق الملكي'],['#87CEEB','السماوي'],['#F0FFFF','اللازوردي'],['#50C878','الزمردي'],['#98FF98','النعناعي'],['#808000','الزيتي'],['#00FF00','الليموني'],['#800000','العنابي'],['#DC143C','القرمزي'],['#FF7F50','المرجاني'],['#E0115F','الياقوتي'],['#FF00FF','الفوشيا'],['#E6E6FA','اللافندر'],['#FFB6C1','الوردي الفاتح'],['#FFD700','الذهبي'],['#FFDB58','الخردلي'],['#FFDAB9','المشمشي'],['#FFBF00','الكهرماني'],['#00FFFF','السيان / أكوا'],['#D2691E','الشوكولاتة'],['#F0E68C','الكاكي'],['#FA8072','السلموني'],['#FFFFF0','العاجي'],['#40E0D0','التركوازي'],['#DDA0DD','البرقوقي'],['#DA70D6','الأوركيد']];
    const radiusMap={square:'0px',soft:'6px',rounded:'14px',round:'24px',pill:'999px',circle:'50%'};
    return `<div class="settingsCard frame-toggle-panel"><h3>تفعيل خيارات الإطار</h3>${frameMasterToggleMarkup}<div class="frame-option-toggle-grid">${frameToggleMarkup}</div></div><div class="settingsCard glass-style-setting"><h3>💠 نوع التصميم</h3><div class="radioGroup design-type-group">${DESIGN_TYPES.map(c=>`<label class="radioLabel"><input type="radio" name="appearanceDesignType" value="${c[0]}" ${designNow===c[0]?'checked':''} onchange="setDesignType('${c[0]}')"> <span dir="ltr">${c[1]}</span></label>`).join('')}</div></div><div class="settingsCard"><h3>🖼️ الخلفية</h3><div class="optionRow"><button class="btn primary" onclick="document.getElementById('appearanceBackgroundFile').click()">اختيار صورة من الجهاز</button><button class="btn secondary" onclick="clearAppearanceBackground()">إزالة الصورة</button><input id="appearanceBackgroundFile" type="file" accept="image/*" hidden onchange="uploadAppearanceBackground(this)"></div><label style="display:block;margin-top:12px">درجة وضوح الخلفية: <b id="appearanceOpacityLabel">${a.backgroundOpacity??100}%</b></label><input style="width:100%" type="range" min="10" max="100" step="5" value="${a.backgroundOpacity??100}" oninput="setAppearanceOpacity(this.value)"></div>
    <div class="settingsCard"><h3>🏅 لون الإطار</h3><div class="appearance-color-picker"><input id="appearanceFrameColorPicker" type="color" value="${frameColorNow}" aria-label="اختر لون الإطار" onchange="setAppearanceOption('frameColor',this.value)"><div><b>اختر أي لون</b><span id="appearanceFrameColorValue" style="display:block;font-size:12px;color:var(--muted);direction:ltr;text-align:right">${frameColorNow}</span></div></div><button type="button" id="appearanceThemeFrameOption" class="appearance-theme-frame-option ${rawColor==='theme'?'active':''}" aria-pressed="${rawColor==='theme'}" onclick="setAppearanceOption('frameColor','theme')"><span id="appearanceThemeFramePreview" class="appearance-theme-frame-preview" style="background:${activeThemeColor}"></span><span class="appearance-theme-frame-copy"><b>لون الثيم المستخدم</b><small>يتغير تلقائيًا مع الثيم</small></span><span id="appearanceThemeFrameHex" class="appearance-theme-frame-hex">${activeThemeColor}</span></button><div class="appearance-palette">${palette.map(c=>`<button type="button" class="appearance-swatch" style="background:${c[0]}" title="${c[1]}" aria-label="${c[1]}" onclick="setAppearanceOption('frameColor','${c[0]}')"></button>`).join('')}</div></div>
    <div class="settingsCard"><h3>▢ شكل الإطار</h3><div class="appearance-shapes">${shapeChoices.map(c=>`<label class="appearance-choice"><input type="radio" name="appearanceFrameShape" value="${c[0]}" ${frameShapeNow===c[0]?'checked':''} onchange="setAppearanceOption('frameShape','${c[0]}')"><span class="appearance-shape-preview" style="border-radius:${c[2]}"></span><span>${c[1]}</span></label>`).join('')}</div></div>
    <div class="settingsCard"><h3>▤ نمط خط الإطار</h3><div class="appearance-line-styles">${lineChoices.map(c=>`<label class="appearance-choice"><input type="radio" name="appearanceFrameStyle" value="${c[0]}" ${frameStyleNow===c[0]?'checked':''} onchange="setAppearanceOption('frameStyle','${c[0]}')"><span class="appearance-line-preview" style="border-bottom-style:${c[0]}"></span><span>${c[1]}</span></label>`).join('')}</div></div>
    <div class="settingsCard"><h3>🔘 شكل الأزرار</h3><div class="radioGroup">${[['classic','كلاسيكي مزخرف'],['rounded','مستطيل بحواف دائرية'],['simple','بسيط']].map(c=>`<label class="radioLabel"><input type="radio" name="appearanceButtonShape" value="${c[0]}" ${a.buttonShape===c[0]?'checked':''} onchange="setAppearanceOption('buttonShape','${c[0]}')"> ${c[1]}</label>`).join('')}</div></div>
    <div class="settingsCard"><h3>🌫️ الظلال</h3><div class="radioGroup"><label class="radioLabel"><input type="radio" name="appearanceShadows" ${a.shadows!==false?'checked':''} onchange="setAppearanceOption('shadows',true)"> تشغيل</label><label class="radioLabel"><input type="radio" name="appearanceShadows" ${a.shadows===false?'checked':''} onchange="setAppearanceOption('shadows',false)"> إيقاف</label></div></div>
    <div class="settingsCard"><h3>📐 سمك الإطار</h3><div class="radioGroup">${[['thin','رفيع'],['medium','متوسط'],['thick','سميك']].map(c=>`<label class="radioLabel"><input type="radio" name="appearanceFrameThickness" value="${c[0]}" ${(a.frameThickness||'thin')===c[0]?'checked':''} onchange="setAppearanceOption('frameThickness','${c[0]}')"> ${c[1]}</label>`).join('')}</div></div>`;
  }
  if(page==='salesTypes')return '';
  if(page==='profile')return `<div class="settingsCard"><div class="field"><label>الإسم بالعربية</label><input class="smallInput" id="profileNameAr" value="${esc(data.settings.profileNameAr||'')}" placeholder="رياض اليافعي"></div><div class="field"><label>الإسم بالإنجليزية</label><input class="smallInput" id="profileNameEn" value="${esc(data.settings.profileNameEn||'')}" dir="ltr"></div><div class="field"><label>العنوان بالعربية</label><textarea class="smallInput" id="profileAddressAr" rows="2">${esc(data.settings.profileAddressAr||'')}</textarea></div><div class="field"><label>العنوان بالإنجليزية</label><textarea class="smallInput" id="profileAddressEn" rows="2" dir="ltr">${esc(data.settings.profileAddressEn||'')}</textarea></div><div class="field"><label>أرقام التواصل</label><textarea class="smallInput" id="profileContacts" rows="2">${esc(data.settings.profileContacts||'')}</textarea></div><div class="field"><label>أرقام التواصل (إنجليزي)</label><textarea class="smallInput" id="profileContactsEn" rows="2" dir="ltr">${esc(data.settings.profileContactsEn||'')}</textarea></div></div><div class="settingsCard"><h3>عرض المجلدات فقط</h3><div class="optionRow" style="align-items:flex-start"><div style="flex:1"><b>طريقة عرض المجلدات</b></div><div class="radioGroup" style="justify-content:flex-end"><label class="radioLabel"><input type="radio" name="folderViewMode" value="list" ${(data.settings.viewMode||'list')==='list'?'checked':''} onchange="setViewMode('list')"> 📋 قائمة</label><label class="radioLabel"><input type="radio" name="folderViewMode" value="grid" ${data.settings.viewMode==='grid'?'checked':''} onchange="setViewMode('grid')"> ▦ شبكة</label></div></div></div><div class="settingsCard"><div class="optionRow" style="align-items:flex-start"><div style="flex:1"><b style="font-size:15px">استخدام ترويسة جاهزة</b></div><button class="switch ${data.settings.useFullHeader?'on':''}" onclick="toggleFullHeader(this)"><i></i></button></div></div><div class="settingsCard"><h3>اختر الشعار</h3><div style="display:flex;align-items:center;gap:12px"><div style="width:70px;height:70px;border:2px dashed var(--line);border-radius:12px;display:grid;place-items:center;overflow:hidden;background:var(--bg2)">${data.settings.logoData?`<img src="${data.settings.logoData}" style="width:100%;height:100%;object-fit:contain">`:'<span style="font-size:24px">🖼️</span>'}</div><div style="flex:1;display:flex;gap:8px"><button class="btn primary" style="padding:8px 16px;font-size:13px;flex:1" onclick="document.getElementById('logoUpload').click()">📤 رفع</button><button class="btn danger" style="padding:8px 12px;font-size:13px" onclick="deleteLogo()">🗑</button></div><input type="file" id="logoUpload" accept="image/*" style="display:none" onchange="uploadImage('logoData',this)"></div></div><div class="settingsCard"><h3>اختر الختم</h3><div style="display:flex;align-items:center;gap:12px"><div style="width:70px;height:70px;border:2px dashed var(--line);border-radius:12px;display:grid;place-items:center;overflow:hidden;background:var(--bg2)">${data.settings.stampData?`<img src="${data.settings.stampData}" style="width:100%;height:100%;object-fit:contain">`:'<span style="font-size:24px">🔖</span>'}</div><div style="flex:1;display:flex;gap:8px"><button class="btn primary" style="padding:8px 16px;font-size:13px;flex:1" onclick="document.getElementById('stampUpload').click()">📤 رفع</button><button class="btn danger" style="padding:8px 12px;font-size:13px" onclick="deleteStamp()">🗑</button></div><input type="file" id="stampUpload" accept="image/*" style="display:none" onchange="uploadImage('stampData',this)"></div></div><div class="settingsCard"><h3>إضافة التوقيع</h3><div style="display:flex;align-items:center;gap:12px"><div style="width:70px;height:70px;border:2px dashed var(--line);border-radius:12px;display:grid;place-items:center;overflow:hidden;background:var(--bg2)">${data.settings.signData?`<img src="${data.settings.signData}" style="width:100%;height:100%;object-fit:contain">`:'<span style="font-size:24px">✍️</span>'}</div><div style="flex:1;display:flex;gap:8px"><button class="btn primary" style="padding:8px 16px;font-size:13px;flex:1" onclick="document.getElementById('signUpload').click()">📤 رفع</button><button class="btn danger" style="padding:8px 12px;font-size:13px" onclick="deleteSign()">🗑</button></div><input type="file" id="signUpload" accept="image/*" style="display:none" onchange="uploadImage('signData',this)"></div></div><button class="btn primary" style="width:100%;margin-top:14px;padding:14px;font-size:15px" onclick="saveProfileFull()">💾 حفظ الملف الشخصي</button>`;

  if(page==='language')return `<div class="settingsCard"><h3>اللغة</h3>${[['ar','العربية'],['en','English']].map(l=>`<div class="optionRow"><span>${l[1]}</span><input type="radio" name="lang" value="${l[0]}" ${(data.settings.lang||'ar')===l[0]?'checked':''} onchange="setLang('${l[0]}')"></div>`).join('')}</div><div class="settingsCard"><h3>مظهر التطبيق</h3><div class="radioGroup"><label class="radioLabel"><input type="radio" name="theme" value="light" ${!data.settings.dark?'checked':''} onchange="setTheme(false)"> ☀️ فاتح</label><label class="radioLabel"><input type="radio" name="theme" value="dark" ${data.settings.dark?'checked':''} onchange="setTheme(true)"> 🌙 داكن</label></div></div><div class="settingsCard"><h3>أوزان الخط</h3><div class="radioGroup"><label class="radioLabel"><input type="radio" name="fontWeight" value="light" ${((data.settings.fontWeight||'medium')==='light')?'checked':''} onchange="setFontWeight('light')"> نحيف</label><label class="radioLabel"><input type="radio" name="fontWeight" value="medium" ${((data.settings.fontWeight||'medium')==='medium')?'checked':''} onchange="setFontWeight('medium')"> متوسط</label><label class="radioLabel"><input type="radio" name="fontWeight" value="bold" ${((data.settings.fontWeight||'medium')==='bold')?'checked':''} onchange="setFontWeight('bold')"> عريض</label></div></div><div class="settingsCard"><h3>نوع الخط</h3>${[['default','Honor Sans (خط النظام)'],['cairo','كايرو (Cairo)'],['tajawal','تجوال (Tajawal)'],['almarai','المراعي (Almarai)'],['ibm','IBM Plex']].map(f=>`<label class="radioLabel" style="margin-bottom:8px;display:flex"><input type="radio" name="font" value="${f[0]}" ${(data.settings.font||'tajawal')===f[0]?'checked':''} onchange="setFont('${f[0]}')"> ${f[1]}</label>`).join('')}</div><div class="settingsCard"><h3>لون الثيم</h3><div style="display:flex;gap:10px;overflow-x:auto;padding:4px 0 10px">${[['#FFFFFF','الأبيض'],['#000000','الأسود'],['#D3D3D3','الرمادي الفاتح'],['#2F4F4F','الفحمي'],['#F5F5DC','البيج'],['#A52A2A','البني'],['#000080','الكحلي'],['#4169E1','الأزرق الملكي'],['#87CEEB','السماوي'],['#F0FFFF','اللازوردي'],['#50C878','الزمردي'],['#98FF98','النعناعي'],['#808000','الزيتي'],['#00FF00','الليموني'],['#800000','العنابي'],['#DC143C','القرمزي'],['#FF7F50','المرجاني'],['#E0115F','الياقوتي'],['#FF00FF','الفوشيا'],['#E6E6FA','اللافندر'],['#FFB6C1','الوردي الفاتح'],['#FFD700','الذهبي'],['#FFDB58','الخردلي'],['#FFDAB9','المشمشي'],['#FFBF00','الكهرماني'],['#00FFFF','السيان / أكوا'],['#D2691E','الشوكولاتة'],['#F0E68C','الكاكي'],['#FA8072','السلموني'],['#FFFFF0','العاجي'],['#40E0D0','التركوازي'],['#DDA0DD','البرقوقي'],['#DA70D6','الأوركيد']].map(c=>`<button onclick="setAppColor('${c[0]}')" style="min-width:76px;border:2px solid ${data.settings.color===c[0]?'var(--primary)':'var(--line)'};border-radius:12px;padding:8px;background:#fff"><div style="height:38px;width:46px;margin:auto;border-radius:8px;background:${c[0]}"></div><small style="font-size:11px;margin-top:4px;display:block">${c[1]}</small></button>`).join('')}</div></div>`;

  if(page==='appLock'){
    const hasPin=!!data.settings.appLock?.pin;
    const hasBio=!!data.settings.appLock?.biometric;
    const enabled=!!data.settings.appLock?.enabled;
    const autoLock=data.settings.appLock?.autoLock||'1m';
    const bioSupported=!!window.PublicKeyCredential;
    return `
    <div class="settingsCard"><div class="optionRow"><div><b>🔒 تفعيل قفل التطبيق</b></div><button class="switch ${enabled?'on':''}" onclick="toggleAppLock(this)"><i></i></button></div></div>
    <div class="settingsCard"><h3>🔢 قفل برمز سري</h3>
      <div class="optionRow"><div><b>${hasPin?'✅ رمز مُعين':'❌ لم يتم تعيين'}</b></div>
        <button class="btn ${hasPin?'secondary':'primary'}" style="padding:8px 16px;font-size:13px" onclick="${hasPin?'changePin()':'setPin()'}">${hasPin?'🔄 تغيير':'🔢 تعيين'}</button></div>
      ${hasPin?'<div class="optionRow"><b>🗑 حذف الرمز</b><button class="btn danger" style="padding:8px 16px;font-size:13px" onclick="removePin()">حذف</button></div>':''}
    </div>
    <div class="settingsCard"><h3>👆 فتح بالبصمة</h3>
      <div class="optionRow">
        <div><b>${bioSupported?(hasBio?'✅ مفعلة':'⚪ غير مفعلة'):'⚠️ غير مدعومة'}</b></div>
        ${bioSupported?`<button class="btn ${hasBio?'secondary':'primary'}" style="padding:8px 16px;font-size:13px" onclick="toggleBiometric()">${hasBio?'🔄 إعادة':'👆 تفعيل'}</button>`:''}
      </div>
    </div>
    <div class="settingsCard"><h3>⏱️ القفل التلقائي</h3>
      <div class="radioGroup">${[['0','فوري'],['30s','30 ثانية'],['1m','دقيقة'],['5m','5 دقائق'],['15m','15 دقيقة']].map(([v,l])=>`<label class="radioLabel"><input type="radio" name="autoLock" value="${v}" ${autoLock===v?'checked':''} onchange="setAutoLock('${v}')"> ${l}</label>`).join('')}</div>
    </div>`;
  }

  if(page==='invoices'){
    const cfg=data.settings.invoiceSettings||(data.settings.invoiceSettings={showInFolders:true,longPressActions:true});
    return `<div class="settingsCard"><h3>🧾 ربط الفواتير بالتطبيق</h3>
      <div class="optionRow"><div style="flex:1"><b>عرض الفواتير داخل المجلد</b><small style="display:block;color:var(--muted);font-size:11px;margin-top:4px">إظهار قائمة الفواتير المحفوظة عند فتح المجلد</small></div><button class="switch ${cfg.showInFolders!==false?'on':''}" onclick="setInvoiceSetting('showInFolders',this)"><i></i></button></div>
      <div class="optionRow"><div style="flex:1"><b>الضغط المطوّل على الفاتورة</b><small style="display:block;color:var(--muted);font-size:11px;margin-top:4px">إظهار خيارات فتح/تعديل أو حذف الفاتورة</small></div><button class="switch ${cfg.longPressActions!==false?'on':''}" onclick="setInvoiceSetting('longPressActions',this)"><i></i></button></div>
      <button class="btn primary" style="width:100%;margin-top:10px;padding:11px" onclick="openInvoiceFromSettings()">＋ إضافة فاتورة إلى مجلد</button>
    </div>`;
  }

  if(page==='privateAccounts')return window.paSettingsHTML();
  if(page==='permissions')return renderPermissionsPage();

  if(page==='trash')return `<div class="settingsCard"><h3>سلة المحذوفات (${(data.settings.trash||[]).length})</h3><button class="btn danger" style="width:100%;margin-bottom:10px" onclick="emptyTrash()">🗑️ إفراغ السلة نهائيًا</button>${(data.settings.trash&&data.settings.trash.length)?data.settings.trash.map((t,i)=>`<div class="optionRow"><div style="min-width:0"><b>${({'person':'👤','op':'💳','folder':'📁','invoice':'🧾','weeklyFilter':'🗓️','detail':'📋','clockEntry':'🕒'}[t.type]||'📄')} ${esc(t.name)}</b><small style="display:block;color:var(--muted);font-size:11px">${t.deletedAt||''}</small></div><div style="display:flex;gap:5px"><button class="btn secondary" style="padding:6px 10px;font-size:12px" onclick="restoreFromTrash(${i})">استعادة</button><button class="btn danger" style="padding:6px 10px;font-size:12px" onclick="deleteFromTrash(${i})">حذف</button></div></div>`).join(''):'<div style="text-align:center;padding:25px;color:var(--muted)">السلة فارغة</div>'}</div>`;

  if(page==='messages'){
    const s=data.settings;
    return `
    <div style="background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;padding:14px 16px;border-radius:14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:10px">
      <div style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:900">✏️ تخصيص نماذج الرسائل</div>
      <button style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.18);color:#fff;font-size:16px;border:1px solid rgba(255,255,255,.25);display:grid;place-items:center" onclick="shareMessagesTemplate()">↗</button>
    </div>
    <div class="settingsCard">
      <h3>⚙️ إعدادات الإرسال العامة</h3>
      <div class="field"><label>طريقة الإرسال الافتراضية</label>
        <div class="radioGroup">
          <label class="radioLabel"><input type="radio" name="sendMethod" value="whatsapp" ${(s.sendMethod||'whatsapp')==='whatsapp'?'checked':''} onchange="saveMsgSetting('sendMethod','whatsapp')"> واتساب</label>
          <label class="radioLabel"><input type="radio" name="sendMethod" value="sms" ${s.sendMethod==='sms'?'checked':''} onchange="saveMsgSetting('sendMethod','sms')"> SMS</label>
        </div>
      </div>
      <div class="field"><label>توقيت الإرسال</label>
        <div class="radioGroup">
          <label class="radioLabel"><input type="radio" name="sendWhen" value="auto" ${(s.sendWhen||'confirm')==='auto'?'checked':''} onchange="saveMsgSetting('sendWhen','auto')"> تلقائي عند حفظ السند</label>
          <label class="radioLabel"><input type="radio" name="sendWhen" value="confirm" ${(s.sendWhen||'confirm')==='confirm'?'checked':''} onchange="saveMsgSetting('sendWhen','confirm')"> بعد التأكيد</label>
          <label class="radioLabel"><input type="radio" name="sendWhen" value="never" ${s.sendWhen==='never'?'checked':''} onchange="saveMsgSetting('sendWhen','never')"> إيقاف الإرسال</label>
        </div>
      </div>
      <div class="optionRow">
        <div><b>تطبيق الإعدادات العامة على جميع الحسابات</b><small style="display:block;color:var(--muted);margin-top:4px">عند التفعيل، طريقة الإرسال وتوقيته من هذه الصفحة هما المعتمدان لكل الحسابات.</small></div>
        <button class="switch ${(s.globalMessageSettings!==false)?'on':''}" onclick="toggleGlobalMessageSettings(this)"><i></i></button>
      </div>
    </div>
    <div class="settingsCard">
      <h3>📝 مقدمة الرسالة وخاتمتها</h3>
      <div class="optionRow"><div><b>تفعيل مقدمة الرسالة</b></div><button class="switch ${s.msgIntroEnabled!==false?'on':''}" onclick="toggleMessageFeature('msgIntroEnabled',this)"><i></i></button></div>
      <div class="field"><label>مقدمة الرسالة</label><input class="smallInput" id="msgIntro" value="${esc(s.msgIntro||'')}"></div>
      <div class="optionRow"><div><b>تفعيل خاتمة الرسالة</b></div><button class="switch ${s.msgEndEnabled!==false?'on':''}" onclick="toggleMessageFeature('msgEndEnabled',this)"><i></i></button></div>
      <div class="field"><label>خاتمة الرسالة</label><input class="smallInput" id="msgEnd" value="${esc(s.msgEnd||'')}"></div>
      <div class="field"><label>ختام طلب السداد</label><input class="smallInput" id="payEnd" value="${esc(s.payEnd||'')}"></div>
    </div>
    <div class="settingsCard">
      <h3>✍️ صيغة الرسائل</h3>
      <div class="field"><label>صيغة (عليه)</label><input class="smallInput" id="msgFormatDebt" value="${esc(s.msgFormatDebt||'عليكم')}"></div>
      <div class="field"><label>صيغة (له)</label><input class="smallInput" id="msgFormatPay" value="${esc(s.msgFormatPay||'الرصيد لك')}"></div>
      <div class="field"><label>صيغة الرصيد في الرسالة</label><div class="radioGroup">
        <label class="radioLabel"><input type="radio" name="messageFormat" value="both" ${(s.messageFormat||'both')==='both'?'checked':''} onchange="saveMsgSetting('messageFormat','both')"> حسب الرصيد (لكم أو عليكم)</label>
        <label class="radioLabel"><input type="radio" name="messageFormat" value="pay" ${s.messageFormat==='pay'?'checked':''} onchange="saveMsgSetting('messageFormat','pay')"> لكم فقط</label>
        <label class="radioLabel"><input type="radio" name="messageFormat" value="debt" ${s.messageFormat==='debt'?'checked':''} onchange="saveMsgSetting('messageFormat','debt')"> عليكم فقط</label>
      </div></div>
    </div>
    <div class="settingsCard">
      <h3>📨 محتوى الرسالة</h3>
      <div class="radioGroup">
        <label class="radioLabel"><input type="radio" name="messageContent" value="text" ${(s.messageContent||'text')==='text'?'checked':''} onchange="saveMsgSetting('messageContent','text')"> رسالة نصية</label>
        <label class="radioLabel"><input type="radio" name="messageContent" value="image" ${s.messageContent==='image'?'checked':''} onchange="saveMsgSetting('messageContent','image')"> صورة المعاملة (إن وُجدت)</label>
      </div>
    </div>
    <div class="settingsCard">
      <h3>📨 إرسال الرسائل النصية</h3>
      <div class="radioGroup" style="justify-content:space-around">
        <label class="radioLabel"><input type="radio" name="sendDest" value="phone" ${(s.sendDest||'phone')==='phone'?'checked':''} onchange="saveMsgSetting('sendDest','phone')"> إلى رقم الجوال</label>
        <label class="radioLabel"><input type="radio" name="sendDest" value="other" ${s.sendDest==='other'?'checked':''} onchange="saveMsgSetting('sendDest','other')"> مشاركة أخرى</label>
      </div>
    </div>
    <div class="settingsCard">
      <h3>💬 نوع الواتساب المستخدم</h3>
      <div class="radioGroup" style="justify-content:space-around">
        <label class="radioLabel"><input type="radio" name="waType" value="green" ${s.waType==='green'?'checked':''} onchange="saveMsgSetting('waType','green')"> 💬 واتساب الأخضر</label>
        <label class="radioLabel"><input type="radio" name="waType" value="business" ${(s.waType||'business')!=='green'?'checked':''} onchange="saveMsgSetting('waType','business')"> 💼 واتساب الأعمال</label>
      </div>
    </div>
    <div class="settingsCard">
      <h3>🌍 مفتاح الدولة</h3>
      <input class="smallInput" id="countryCode" value="${esc(s.countryCode||'+967')}" placeholder="+967" style="direction:ltr;text-align:left;letter-spacing:1px">
    </div>
    <div class="settingsCard">
      <h3>🔢 مفتاح الخط للرسائل النصية</h3>
      <div class="radioGroup" style="justify-content:space-around">
        <label class="radioLabel"><input type="radio" name="lineKey" value="empty" ${(s.lineKey||'empty')==='empty'?'checked':''} onchange="saveMsgSetting('lineKey','empty')"> فارغ</label>
        <label class="radioLabel"><input type="radio" name="lineKey" value="zero" ${s.lineKey==='zero'?'checked':''} onchange="saveMsgSetting('lineKey','zero')"> صفر</label>
        <label class="radioLabel"><input type="radio" name="lineKey" value="country" ${s.lineKey==='country'?'checked':''} onchange="saveMsgSetting('lineKey','country')"> مطابق للدولة</label>
      </div>
    </div>
    <div class="settingsCard">
      <h3>📐 حجم الصورة</h3>
      <div style="display:flex;align-items:center;justify-content:center;gap:24px;padding:10px 0">
        <button class="btn primary" style="width:52px;height:52px;font-size:26px;padding:0;border-radius:14px" onclick="changeImageSize(-0.1)">−</button>
        <div id="imageSizeValue" style="font-size:24px;font-weight:900;min-width:90px;text-align:center;color:var(--primary)">${(s.imageSize||1.0).toFixed(1)}</div>
        <button class="btn primary" style="width:52px;height:52px;font-size:26px;padding:0;border-radius:14px" onclick="changeImageSize(0.1)">+</button>
      </div>
    </div>
    <button class="btn primary" style="width:100%;padding:15px;font-size:16px;margin-top:14px;border-radius:14px" onclick="saveMessagesFull()">💾 حفظ الإعدادات</button>
    `;
  }

  if(page==='printing'){
    const s=data.settings;
    const lx=!!(s.lux&&s.lux.on);const lxNote=lx?'<div style="font-size:12px;font-weight:800;color:#b45309;margin:0 0 8px">معطّل: الطباعة المرفهة مفعّلة وهي المسؤولة عن الألوان وشكل الورقة</div>':'';const lxOff=lx?'opacity:.45;pointer-events:none;':'';
    const stampOpts=[{v:'sign',l:'التوقيع'},{v:'stamp',l:'الختم'},{v:'all',l:'الكل'},{v:'none',l:'لا شيء'}];
    const stampRow=(key,label)=>{
      const cur=(s.stampSettings&&s.stampSettings[key])||'sign';
      return `<div class="settingsCard"><h3>${label}</h3><div class="radioGroup" style="justify-content:space-around">
        ${stampOpts.map(o=>`<label class="radioLabel"><input type="radio" name="stamp_${key}" value="${o.v}" ${cur===o.v?'checked':''} onchange="setStampSetting('${key}','${o.v}')"> ${o.l}</label>`).join('')}
      </div></div>`;
    };
    const toggleRow=(key,label)=>{
      const val=!!s[key];
      return `<div class="settingsCard" style="padding:12px 16px"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><b style="font-size:15px">${label}</b><button class="switch ${val?'on':''}" onclick="togglePrintSetting('${key}',this)"><i></i></button></div></div>`;
    };
    return `
      <div class="settingsCard"><h3>طريقة الطباعة</h3><div class="radioGroup" style="justify-content:space-around">
        <label class="radioLabel"><input type="radio" name="printMethod" value="printer" ${(s.printMethod||'pdf')==='printer'?'checked':''} onchange="saveMsgSetting('printMethod','printer')"> إلى الطابعة</label>
        <label class="radioLabel"><input type="radio" name="printMethod" value="pdf" ${(s.printMethod||'pdf')==='pdf'?'checked':''} onchange="saveMsgSetting('printMethod','pdf')"> إلى pdf</label>
      </div></div>
      <div class="settingsCard"><h3>ورق الكشوفات والمصادقة</h3><div class="radioGroup" style="justify-content:space-around">
        ${[['a4','A4'],['a3','A3'],['58','58mm'],['80','80mm']].map(o=>`<label class="radioLabel"><input type="radio" name="paperStatement" value="${o[0]}" ${((s.paperStatement||s.paper||'a4')===o[0])?'checked':''} onchange="saveMsgSetting('paperStatement','${o[0]}')"> ${o[1]}</label>`).join('')}
      </div></div>
      <div class="settingsCard"><h3>ورق السندات</h3><div class="radioGroup" style="justify-content:space-around">
        ${[['a5','A5'],['a4','A4'],['a3','A3'],['58','58mm'],['80','80mm']].map(o=>`<label class="radioLabel"><input type="radio" name="paperVoucher" value="${o[0]}" ${((s.paperVoucher||s.paper||'a4')===o[0])?'checked':''} onchange="saveMsgSetting('paperVoucher','${o[0]}')"> ${o[1]}</label>`).join('')}
      </div></div>
      <div class="settingsCard"><h3>ترتيب سندات جملة البيع النهائية</h3>
        <div class="radioGroup" style="justify-content:space-around;margin-bottom:10px">
          ${[['name','الأبجدي'],['amount','المبلغ'],['date','التاريخ']].map(o=>`<label class="radioLabel"><input type="radio" name="saleSortBy" value="${o[0]}" ${((s.saleSortBy||'date')===o[0])?'checked':''} onchange="saveMsgSetting('saleSortBy','${o[0]}')"> ${o[1]}</label>`).join('')}
        </div>
        <div class="radioGroup" style="justify-content:space-around">
          ${[['asc','تصاعدي'],['desc','تنازلي']].map(o=>`<label class="radioLabel"><input type="radio" name="saleSortDir" value="${o[0]}" ${((s.saleSortDir||'asc')===o[0])?'checked':''} onchange="saveMsgSetting('saleSortDir','${o[0]}')"> ${o[1]}</label>`).join('')}
        </div>
      </div>
      <div class="settingsCard" style="${lxOff}"><h3>ألوان الطباعة</h3>${lxNote}
        <div class="radioGroup" style="justify-content:space-around;margin-bottom:12px">
          <label class="radioLabel"><input type="radio" name="printColorMode" value="color" ${lx?'disabled':''} ${(s.printColorMode||'color')==='color'?'checked':''} onchange="saveMsgSetting('printColorMode','color')"> ملونة</label>
          <label class="radioLabel"><input type="radio" name="printColorMode" value="gray" ${lx?'disabled':''} ${s.printColorMode==='gray'?'checked':''} onchange="saveMsgSetting('printColorMode','gray')"> تدرج رمادي</label>
          <label class="radioLabel"><input type="radio" name="printColorMode" value="bw" ${lx?'disabled':''} ${s.printColorMode==='bw'?'checked':''} onchange="saveMsgSetting('printColorMode','bw')"> أبيض وأسود</label>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><b style="font-size:14px">اللون الأساسي للطباعة</b><input type="color" ${lx?'disabled':''} value="${s.printColor||'#6B1A2F'}" onchange="saveMsgSetting('printColor',this.value)" style="width:80px;height:40px;border:2px solid var(--line);border-radius:10px;background:#fff"></div>
        
      </div>
      <div class="settingsCard"><h3>خط الطباعة (PDF)</h3>
        <select class="smallInput" style="width:100%" onchange="saveMsgSetting('printFont',this.value)">
          ${[['cairo','القاهرة (Cairo)'],['honor','Honor Sans'],['arial','Arial'],['tahoma','Tahoma'],['times','Times New Roman']].map(o=>`<option value="${o[0]}" ${(['cairo','honor','arial','tahoma','times'].includes(s.printFont)?s.printFont:'cairo')===o[0]?'selected':''}>${o[1]}</option>`).join('')}
        </select>
      </div>
      <div class="settingsCard"><h3>حجم الخط في الطباعة</h3><div class="radioGroup" style="justify-content:space-around">
        ${[[85,'صغير'],[100,'متوسط'],[115,'كبير'],[130,'كبير جدًا']].map(o=>`<label class="radioLabel"><input type="radio" name="printFontScale" value="${o[0]}" ${(Number(s.printFontScale)||100)===o[0]?'checked':''} onchange="saveMsgSetting('printFontScale',${o[0]})"> ${o[1]}</label>`).join('')}
      </div></div>
      <div class="settingsCard" style="${lxOff}">${lxNote}<div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><b style="font-size:14px">لون النص في الطباعة</b><input type="color" ${lx?'disabled':''} value="${s.printTextColor||'#111111'}" onchange="saveMsgSetting('printTextColor',this.value)" style="width:80px;height:40px;border:2px solid var(--line);border-radius:10px;background:#fff"></div></div>
      ${window.__currencyStmtCard?window.__currencyStmtCard():''}
      ${window.__luxuryPrintCard?window.__luxuryPrintCard():''}
      ${toggleRow('showHeaderData','عرض بيانات رأس الصفحة')}
      ${toggleRow('repeatHeader','تكرار الترويسة')}
      ${toggleRow('showPrintDate','عرض تاريخ الطباعة')}
      ${toggleRow('showPrintTime','عرض الوقت في الطباعة')}
      ${stampRow('vouchers','عرض الختم والتوقيع على السندات')}
      ${stampRow('invoices','عرض الختم والتوقيع على الفواتير')}
      ${stampRow('statement','عرض الختم والتوقيع على كشف الحساب')}
      ${stampRow('balance','عرض الختم والتوقيع على المصادقة')}
      ${toggleRow('showAccountNote','عرض ملاحظة الحساب في الطباعة')}
      ${toggleRow('showPhone','عرض رقم جوال الحساب')}
      ${toggleRow('addNoteOnStatement','إضافة ملاحظة أسفل كشف الحساب')}
    `;
  }

  if(page==='currencies')return `<div class="currency-toggle-card"><b>تفعيل ميزة تعدد العملات</b><button class="switch ${data.settings.multiCurrency?'on':''}" onclick="toggleSwitchSetting('multiCurrency',this)"><i></i></button></div>${(data.settings.currencies||[]).map((c,i)=>`<div class="currency-card"><div class="cc-num">${i+1}</div><div class="cc-info"><div class="cc-name">${esc(c.name)} ${c.isDefault?'⭐':''}</div><div class="cc-details">رمز: ${esc(c.symbol)} | تجزئة: ${esc(c.subUnit||'-')}</div></div><div class="cc-actions"><button onclick="openCurrencyForm(${i})">✏️</button><button onclick="currencyMenu(${i})">☰</button></div><div class="cc-icon">$</div></div>`).join('')}<div style="text-align:center;margin-top:16px"><button onclick="openCurrencyForm(-1)" style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--orange),var(--orange-dark));color:#fff;font-size:26px;border:0">+</button></div>`;


  if(page==='gdriveBackup'){
    const backup=data.settings.gdriveBackup||(data.settings.gdriveBackup={connected:false,email:'',dataEnabled:true,dataInterval:'24h',imagesBackupEnabled:false,imagesInterval:'daily',wifiOnly:false,backupOnExit:false,backupHistory:[]});
    const isConnected=!!backup.connected, history=Array.isArray(backup.backupHistory)?backup.backupHistory:[];
    const row=(key,label,desc='')=>`<div class="optionRow" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 4px;border-bottom:1px solid var(--line)"><span><b>${label}</b>${desc?`<br><small style="color:var(--muted)">${desc}</small>`:''}</span><button class="switch ${backup[key]?'on':''}" onclick="toggleGdriveBackup('${key}',this)"><i></i></button></div>`;
    const radios=(key,values,label)=>`<div style="padding:12px 0;border-bottom:1px solid var(--line)"><b style="display:block;margin-bottom:8px">${label}</b>${values.map(([v,l])=>`<label class="radioLabel" style="display:flex;align-items:center;gap:8px;padding:8px;border:1px solid var(--line);border-radius:9px;margin:5px 0;cursor:pointer"><input type="radio" name="${key}" value="${v}" ${backup[key]===v?'checked':''} onchange="setGdriveInterval('${key}','${v}')"><span>${l}</span></label>`).join('')}</div>`;
    return `<div class="settingsCard"><h3>☁️ حساب Google Drive</h3><div style="background:var(--bg);border-radius:12px;padding:14px;text-align:center;margin-bottom:12px"><div style="font-size:32px;margin-bottom:7px">${isConnected?'✅':'☁️'}</div><div style="font-weight:900">${isConnected?'تم تسجيل الحساب محليًا':'لم يتم الاتصال بخدمة Google Drive'}</div><div style="font-size:12px;color:var(--muted);direction:ltr;margin-top:5px">${isConnected?esc(backup.email||''): 'الاتصال الفعلي يتطلب تكامل Google OAuth داخل التطبيق'}</div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button class="btn primary" onclick="connectGdrive()">🔗 الاتصال بحساب Google</button><button class="btn danger" onclick="disconnectGdrive()">تسجيل الخروج</button></div></div>
    <div class="settingsCard"><h3>⚙️ إعدادات النسخ الاحتياطي</h3>${row('backupOnExit','النسخ الاحتياطي عند الخروج','ينبهك قبل الخروج ويطلب من خدمة Android إكمال الرفع في الخلفية')}${row('dataEnabled','النسخ المجدول للبيانات')}${radios('dataInterval',[['6h','كل 6 ساعات'],['12h','كل 12 ساعة'],['24h','يومي'],['7d','أسبوعي']],'تكرار نسخ البيانات')}${row('imagesBackupEnabled','تضمين الصور والمرفقات')}${radios('imagesInterval',[['daily','يومي'],['weekly','أسبوعي'],['monthly','شهري']],'تكرار نسخ الصور')}${row('wifiOnly','استخدام Wi-Fi فقط')}<button class="btn primary" style="width:100%;padding:13px;margin-top:12px" onclick="backupNowAll()">☁️ نسخ احتياطي الآن</button><button class="btn secondary" style="width:100%;padding:13px;margin-top:8px" onclick="restoreFromGoogleDrive()">♻️ استعادة من Google Drive</button><button class="btn secondary" style="width:100%;padding:13px;margin-top:8px" onclick="openBackupList()">📋 عرض النسخ الموجودة على Google Drive</button><button class="btn secondary" style="width:100%;padding:13px;margin-top:8px" onclick="saveGdriveSettings()">حفظ الإعدادات</button><input id="gdriveRestoreInput" type="file" accept=".json,application/json" style="display:none" onchange="restoreAppBackup(event)"></div>
    <div class="settingsCard"><h3>📋 سجل النسخ الاحتياطي</h3>${history.length?history.map(h=>`<div style="padding:9px 0;border-bottom:1px solid var(--line);font-size:12px"><b>${esc(h.filename||'نسخة احتياطية')}</b><br><span style="color:var(--muted)">${esc(h.date?new Date(h.date).toLocaleString('ar-u-nu-latn'): '')} · ${h.size?Math.round(h.size/1024)+' KB':''}</span></div>`).join(''):''}<button class="btn secondary" style="width:100%;margin-top:10px" onclick="renderGdriveHistory()">تحديث السجل</button></div>`;
  }
  if(page==='activation')return '';

  if(page==='backup'){
    return `<div class="settingsCard"><h3>📦 النسخ الاحتياطي على الهاتف والملفات</h3><button class="btn primary" style="width:100%;padding:13px;margin:6px 0" onclick="downloadAppBackup()">⬇️ تنزيل نسخة احتياطية إلى الهاتف</button><button class="btn secondary" style="width:100%;padding:13px;margin:6px 0" onclick="document.getElementById('settingsRestoreFile').click()">♻️ استعادة من ملف على الهاتف</button><button class="btn secondary" style="width:100%;padding:13px;margin:6px 0" onclick="shareBackup()">📤 مشاركة ملف النسخة الاحتياطية</button><button class="btn secondary" style="width:100%;padding:13px;margin:6px 0" onclick="backupToTelegram()">✈️ تنزيل نسخة وفتح Telegram للمشاركة</button><input id="settingsRestoreFile" type="file" accept=".json,application/json" style="display:none" onchange="restoreAppBackup(event)"></div>`;
  }
  if(page==='tutorial'){
    const url=localStorage.getItem('settingsTutorialYoutubeUrl')||'';
    return `<div class="settingsCard"><h3>▶️ شرح التطبيق على YouTube</h3><div class="field"><label>رابط فيديو الشرح</label><input class="smallInput" id="settingsYoutubeUrl" value="${esc(url)}" dir="ltr" placeholder="https://www.youtube.com/watch?v=..."></div><button class="btn primary" style="width:100%;margin:5px 0" onclick="saveSettingsYoutubeLink()">حفظ الرابط</button><button class="btn secondary" style="width:100%;margin:5px 0" onclick="openSettingsYoutubeLink()">فتح الشرح / البحث على YouTube</button></div>`;
  }
  if(page==='terms'||page==='privacy'){
    const terms=page==='terms',key=terms?'serviceTermsText':'privacyPolicyText',label=terms?'شروط الخدمة':'سياسة الخصوصية',value=data.settings[key]||'';
    return `<div class="settingsCard"><h3>${terms?'📄':'🔐'} ${label}</h3><div class="field"><label>النص</label><textarea class="smallInput" id="settingsLegalText" rows="12" placeholder="اكتب النص المعتمد هنا">${esc(value)}</textarea></div><button class="btn primary" style="width:100%" onclick="saveSettingsLegalText('${page}')">حفظ ${label}</button></div>`;
  }
  if(page==='contact'){
    const supportPhone=localStorage.getItem('settingsSupportPhone')||((data.settings.activation||{}).devWhatsApp||'967773544574');
    const supportEmail=localStorage.getItem('settingsSupportEmail')||'';
    return `<div class="settingsCard"><h3>📞 تواصل معنا</h3><div class="field"><label>رقم واتساب مع رمز الدولة</label><input class="smallInput" id="settingsSupportPhoneInput" value="${esc(supportPhone)}" inputmode="tel" dir="ltr"></div><div class="field"><label>البريد الإلكتروني للدعم (اختياري)</label><input class="smallInput" id="settingsSupportEmail" value="${esc(supportEmail)}" type="email" dir="ltr"></div><button class="btn primary" style="width:100%;margin-bottom:8px" onclick="saveSettingsContactDetails()">حفظ بيانات التواصل</button><button class="btn secondary" style="width:100%;margin-bottom:8px" onclick="openSettingsContactWhatsApp()">فتح واتساب</button><button class="btn secondary" style="width:100%" onclick="emailSettingsSupport()">إرسال بريد إلكتروني</button></div>`;
  }
  if(page==='share'){
    return `<div class="settingsCard" style="text-align:center"><h3>↗️ مشاركة التطبيق</h3><button class="btn primary" style="width:100%;padding:14px" onclick="shareApplication()">مشاركة رابط التطبيق</button></div>`;
  }

  if(page==='about')return `<div class="settingsCard" style="text-align:center;background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;border:0;padding:24px 16px"><div style="font-size:64px;margin-bottom:12px">📊</div><h2 style="font-size:22px;font-weight:900;margin:0 0 6px">الاداري برو</h2><p style="font-size:13px;opacity:.85;margin:0">Smart Admin Pro</p><div style="margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.2);font-size:13px;font-weight:700">الإصدار 3.3.78</div></div><div class="settingsCard"><h3>👨‍💻 المطوّر</h3><div style="display:flex;align-items:center;gap:14px;padding:10px 0"><div style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--purple));color:#fff;display:grid;place-items:center;font-size:28px">👨‍💻</div><div><div style="font-size:16px;font-weight:900;color:var(--primary)">رياض اليافعي</div><div style="font-size:12px;color:var(--muted);margin-top:4px">مهندس برمجيات</div></div></div></div><div class="settingsCard"><h3>📞 للتواصل</h3><a href="https://wa.me/967773544574" target="_blank" style="display:flex;align-items:center;gap:12px;padding:14px;background:#fff;border:2px solid #25D366;border-radius:12px;margin-bottom:10px;text-decoration:none;color:inherit"><div style="width:44px;height:44px;border-radius:50%;background:#25D366;color:#fff;display:grid;place-items:center;font-size:22px">💬</div><div style="font-size:14px;font-weight:900;color:#25D366">واتساب</div></a></div>`;

  if(page==='allAccounts'){setTimeout(renderAllAccountsPage,50);return '<div id="allAccountsContainer"></div>';}
  return '';
}

function renderPermissionsPage(){
  setTimeout(refreshPermissionsUI,50);
  return `<div style="background:#eff6ff;padding:12px;border-radius:12px;margin-bottom:14px;font-size:13px;color:#1e40af;display:flex;align-items:center;gap:8px"><span>💡</span><span style="flex:1">بعض الأذونات قد لا تكون مدعومة.</span><button onclick="refreshPermissionsUI()" style="background:#1e40af;color:#fff;border:0;border-radius:8px;padding:6px 10px;font-size:12px;font-weight:800">🔄</button></div><div id="permissionsList"><div style="text-align:center;padding:30px;color:#94a3b8">⏳ جاري القراءة...</div></div>`;
}
async function refreshPermissionsUI(){const c=document.getElementById('permissionsList');if(!c)return;try{c.innerHTML='<div style="text-align:center;padding:30px;color:#94a3b8">⏳</div>';const list=await getPermissionsList();c.innerHTML=list.map(p=>renderPermissionItem(p)).join('');}catch(e){c.innerHTML='<div style="text-align:center;padding:30px;color:#dc2626">❌ تعذّر</div>';}}
async function getPermissionsList(){const sup={mediaDevices:!!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia),notifications:'Notification' in window,speechRecognition:'webkitSpeechRecognition' in window||'SpeechRecognition' in window,webAuthn:!!(window.PublicKeyCredential&&navigator.credentials),share:!!navigator.share,vibrate:'vibrate' in navigator,geolocation:'geolocation' in navigator};
  const q=async(name)=>{try{const r=await navigator.permissions.query({name});return r.state;}catch(e){return 'prompt';}};
  return [
    {key:'camera',icon:'📷',name:'الكاميرا',description:'تصوير السندات',status:sup.mediaDevices?await q('camera'):'unavailable',canRequest:sup.mediaDevices},
    {key:'photos',icon:'🖼️',name:'الصور',description:'رفع صور',status:'granted',canRequest:false},
    {key:'microphone',icon:'🎙️',name:'الميكروفون',description:'الإدخال الصوتي',status:sup.speechRecognition?await q('microphone'):'unavailable',canRequest:sup.speechRecognition},
    {key:'notifications',icon:'🔔',name:'الإشعارات',description:'تنبيهات',status:sup.notifications?Notification.permission:'unavailable',canRequest:sup.notifications},
    {key:'location',icon:'📍',name:'الموقع',description:'موقع العملاء',status:sup.geolocation?await q('geolocation'):'unavailable',canRequest:sup.geolocation},
    {key:'storage',icon:'💾',name:'التخزين',description:'حفظ البيانات',status:'granted',canRequest:false},
    {key:'biometric',icon:'👆',name:'البصمة',description:'فتح بالبصمة',status:sup.webAuthn?'prompt':'unavailable',canRequest:sup.webAuthn},
    {key:'vibration',icon:'📳',name:'الاهتزاز',description:'اهتزاز',status:sup.vibrate?'granted':'unavailable',canRequest:false},
    {key:'share',icon:'🔗',name:'المشاركة',description:'مشاركة',status:sup.share?'granted':'unavailable',canRequest:false},
    {key:'internet',icon:'🌐',name:'الإنترنت',description:'النسخ السحابي',status:navigator.onLine?'granted':'prompt',canRequest:false}
  ];
}
function renderPermissionItem(p){const badge={granted:'<span style="color:#16a34a;font-size:12px;font-weight:900">✅ مسموح</span>',denied:'<span style="color:#dc2626;font-size:12px;font-weight:900">❌ مرفوض</span>',prompt:'<span style="color:#64748b;font-size:12px;font-weight:900">⚪ غير مفعّل</span>',unavailable:'<span style="color:#94a3b8;font-size:12px;font-weight:900">⚠️ غير مدعوم</span>'}[p.status]||'';const btn=(p.status==='prompt'||p.status==='denied')&&p.canRequest?`<button class="btn primary" style="padding:6px 12px;font-size:12px;margin-top:6px" onclick="requestPermission('${p.key}')">🔓 طلب</button>`:'';return `<div class="settingsCard" style="margin-bottom:10px;padding:14px"><div style="display:flex;align-items:flex-start;gap:12px"><div style="font-size:26px;flex:none">${p.icon}</div><div style="flex:1;min-width:0"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px"><b style="font-size:14px">${p.name}</b>${badge}</div><div style="font-size:11px;color:var(--muted)">${p.description}</div>${btn}</div></div></div>`;}
async function requestPermission(key){try{if(key==='camera'){const s=await navigator.mediaDevices.getUserMedia({video:true});s.getTracks().forEach(t=>t.stop());toast('✅');}else if(key==='microphone'){try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());toast('✅');}catch(e){toast('❌');}}else if(key==='notifications'){await Notification.requestPermission();}else if(key==='location'){navigator.geolocation.getCurrentPosition(()=>toast('✅'),()=>toast('❌'));}else if(key==='biometric'){if(window.PublicKeyCredential){const av=await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();toast(av?'✅':'⚠️');}}setTimeout(refreshPermissionsUI,1000);}catch(e){toast('❌');}}

function openAllAccountsPage(){openSettingsPage('allAccounts');renderAllAccountsPage();}
function isStandaloneAccount(p){return !!p&&p.scope==='accounts';}
function openStandaloneAccount(){openPerson(null,true);}
window._standaloneAccountMode=false;
function openPerson(id=null,standalone=false){
  window._standaloneAccountMode=!!standalone;
  editPersonId=id;
  let p=data.people.find(x=>x.id===id);
  document.getElementById('personTitle').textContent=p?'تعديل حساب':'إضافة حساب جديد';
  document.getElementById('pName').value=p?.name||'';
  document.getElementById('pPhone').value=p?.phone||'';
  document.getElementById('limitSwitch').classList.toggle('on',!!p?.limitEnabled);
  document.getElementById('pLimitAmount').value=p?.limitAmount??'';
  document.getElementById('limitAmountRow').style.display=p?.limitEnabled?'flex':'none';
  
  selectSend(p?.messageSend||data.settings.sendWhen||'confirm');
  document.getElementById('personModal').classList.add('show');
  window._newPersonFolderId=currentFolderId||(data.folders[0]&&data.folders[0].id);
}
function selectMessage(t){document.getElementById('smsChoice').classList.toggle('selected',t==='sms');document.getElementById('waChoice').classList.toggle('selected',t==='whatsapp');}
function selectSend(t){['auto','confirm','never'].forEach(x=>document.getElementById(x+'Choice').classList.toggle('selected',x===t));}
function currentChoice(ids){return ids.find(id=>document.getElementById(id).classList.contains('selected'));}

function savePerson(){
  const name=document.getElementById('pName').value.trim();
  if(!name){toast('الاسم مطلوب');return}
  const phone=document.getElementById('pPhone').value.trim();
  const limitEnabled=document.getElementById('limitSwitch').classList.contains('on');
  const limitAmount=Number(document.getElementById('pLimitAmount').value);
  if(limitEnabled&&(!Number.isFinite(limitAmount)||limitAmount<=0)){
    toast('أدخل مبلغ سقف المديونية أكبر من صفر');document.getElementById('pLimitAmount').focus();return;
  }
  const messageMethod=data.settings.sendMethod||'whatsapp';
  const messageSend=currentChoice(['autoChoice','confirmChoice','neverChoice']).replace('Choice','');
  let isNew=!editPersonId;let savedPerson=null;
  if(editPersonId){
    let p=data.people.find(x=>x.id===editPersonId);if(!p){toast('تعذر العثور على الحساب');return}
    Object.assign(p,{name,phone,limitEnabled,limitAmount:limitEnabled?limitAmount:0,messageMethod,messageSend});savedPerson=p;
  }else{
    const standalone=!!window._standaloneAccountMode;
    savedPerson={id:Date.now().toString(),name,phone,limitEnabled,limitAmount:limitEnabled?limitAmount:0,messageMethod,messageSend,scope:standalone?'accounts':'folder',folderId:standalone?'':(window._newPersonFolderId||currentFolderId||data.folders[0].id),ops:[],createdAt:Date.now()};
    data.people.unshift(savedPerson);
  }
  save();
  closeModal('personModal');
  if(isNew && currentFolderId===null && savedPerson.folderId){
    currentFolderId=savedPerson.folderId;
    currentFolderCurrency=null;
    initDateFilter();
    const folder=data.folders.find(f=>f.id===currentFolderId);
    if(folder) document.getElementById('headerTitle').textContent=folder.name||'';
    const searchBtn=document.querySelector('button[onclick="openQuickSearch()"]');
    if(searchBtn)searchBtn.style.display='none';
    const bb=document.querySelector('.bottom-bar');
    if(bb)bb.style.display='none';
    renderCurrentView();
  }else{renderCurrentView();}
  window._standaloneAccountMode=false;
  if(typeof renderAllAccountsPage==='function'&&document.getElementById('allAccountsContainer'))renderAllAccountsPage();
  toast('تم الحفظ وظهر الحساب مباشرة');
  if(isNew&&messageSend==='auto'&&phone)setTimeout(()=>typeof sendTransaction==='function'&&sendTransaction(savedPerson,'account_created'),600);
}


function renderAllAccountsPage(){const container=document.getElementById('allAccountsContainer');if(!container)return;const all=data.people.filter(isStandaloneAccount);container.innerHTML=`<button class="primary" style="width:100%;margin-bottom:10px" onclick="openStandaloneAccount()">＋ إضافة حساب</button><div class="field"><input class="smallInput" id="allAccSearch" placeholder="🔍 ابحث..." oninput="filterAllAccounts()"></div><div id="allAccList">${all.map(p=>{const f=data.folders.find(x=>x.id===p.folderId);const bal=p.ops.reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);return `<div class="person" onclick="openDetail('${p.id}','allAccounts')"><div class="avatar">${esc(p.name[0]||'؟')}</div><div class="pmain"><div class="pname">${p.important?'⭐ ':''}${esc(p.name)}</div><div style="font-size:11px;color:var(--muted)">${f?'📁 '+esc(f.name):''}</div></div><div class="balance ${bal>0?'positive':bal<0?'negative':'zero'}"><small>المتبقي</small>${fmt(Math.abs(bal))}</div></div>`;}).join('')}</div>`;}
function filterAllAccounts(){const q=(document.getElementById('allAccSearch').value||'').toLowerCase();const all=data.people.filter(p=>isStandaloneAccount(p)&&p.name.toLowerCase().includes(q));document.getElementById('allAccList').innerHTML=all.length?all.map(p=>{const f=data.folders.find(x=>x.id===p.folderId);const bal=p.ops.reduce((s,o)=>s+(o.type==='debt'?o.amount:-o.amount),0);return `<div class="person" onclick="openDetail('${p.id}','allAccounts')"><div class="avatar">${esc(p.name[0]||'؟')}</div><div class="pmain"><div class="pname">${esc(p.name)}</div><div style="font-size:11px;color:var(--muted)">${f?'📁 '+esc(f.name):''}</div></div><div class="balance ${bal>0?'positive':bal<0?'negative':'zero'}"><small>المتبقي</small>${fmt(Math.abs(bal))}</div></div>`;}).join(''):'';}

/* ============================================================
   العملات
   ============================================================ */
function openCurrencyForm(index){currencyEditIndex=index;const isEdit=index>=0;const c=isEdit?data.settings.currencies[index]:{name:'',symbol:'',sellRate:1,buyRate:1,fraction:1,subUnit:''};let modal=document.getElementById('currencyFormModal');if(!modal){modal=document.createElement('div');modal.id='currencyFormModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:520px"><h2 style="text-align:center">${isEdit?'تعديل عملة':'عملة جديدة'}</h2><button class="btn secondary" style="width:100%;margin-bottom:14px" onclick="openCurrencyList()">🌐 اختيار من القائمة</button><div class="field"><label>الاسم</label><input class="smallInput" id="curName" value="${esc(c.name)}"></div><div class="field"><label>الرمز</label><input class="smallInput" id="curSymbol" value="${esc(c.symbol)}"></div><div class="field"><label>التجزئة</label><input class="smallInput" id="curSub" value="${esc(c.subUnit||'')}"></div><div class="field"><label>سعر البيع</label><input class="smallInput" id="curSell" type="number" inputmode="decimal" step="any" value="${esc(c.sellRate==null?1:c.sellRate)}"></div><div class="field"><label>سعر الشراء</label><input class="smallInput" id="curBuy" type="number" inputmode="decimal" step="any" value="${esc(c.buyRate==null?1:c.buyRate)}"></div><div class="actions"><button class="btn secondary" onclick="closeModal('currencyFormModal')">إلغاء</button><button class="btn primary" onclick="saveCurrencyForm()">حفظ</button></div></div>`;modal.classList.add('show');}
function saveCurrencyForm(){const name=document.getElementById('curName').value.trim();const symbol=document.getElementById('curSymbol').value.trim();const subUnit=document.getElementById('curSub').value.trim();const sellRate=(+document.getElementById('curSell').value)>0?+document.getElementById('curSell').value:1;const buyRate=(+document.getElementById('curBuy').value)>0?+document.getElementById('curBuy').value:1;if(!name){toast('الاسم مطلوب');return;}if(currencyEditIndex>=0){Object.assign(data.settings.currencies[currencyEditIndex],{name,symbol,subUnit,sellRate,buyRate});toast('تم');}else{data.settings.currencies=data.settings.currencies||[];data.settings.currencies.push({name,symbol,sellRate,buyRate,fraction:1,subUnit,isDefault:data.settings.currencies.length===0});toast('تم');}save();closeModal('currencyFormModal');openSettingsPage('currencies',true);}
function currencyMenu(i){const c=data.settings.currencies[i];let modal=document.getElementById('currencyMenuModal');if(!modal){modal=document.createElement('div');modal.id='currencyMenuModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:400px"><h2>${esc(c.name)}</h2><button class="btn secondary" style="width:100%;margin-bottom:8px" onclick="setDefaultCurrency(${i})">⭐ تعيين كافتراضي</button><button class="btn danger" style="width:100%" onclick="deleteCurrency(${i})">🗑 حذف</button><button class="btn secondary" style="width:100%;margin-top:12px" onclick="closeModal('currencyMenuModal')">إلغاء</button></div>`;modal.classList.add('show');}
function setDefaultCurrency(i){data.settings.currencies.forEach((x,j)=>x.isDefault=(j===i));data.settings.currency=data.settings.currencies[i].symbol;save();closeModal('currencyMenuModal');openSettingsPage('currencies',true);toast('تم');}
function deleteCurrency(i){customConfirm('حذف هذه العملة؟',()=>{data.settings.currencies.splice(i,1);if(data.settings.currencies.length&&!data.settings.currencies.some(x=>x.isDefault))data.settings.currencies[0].isDefault=true;save();closeModal('currencyMenuModal');openSettingsPage('currencies',true);toast('تم');},null,{title:'حذف عملة',icon:'💰',danger:true,confirmText:'حذف'});}
function openCurrencyList(){let modal=document.getElementById('currencyListModal');if(!modal){modal=document.createElement('div');modal.id='currencyListModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet" style="max-width:520px"><h2>اختيار عملة</h2><div class="field"><input id="curListSearch" class="smallInput" placeholder="🔍" oninput="filterCurrencyList(this.value)"></div><div id="curListBody" style="max-height:50vh;overflow:auto"></div><button class="btn secondary" style="width:100%;margin-top:10px" onclick="closeModal('currencyListModal')">إلغاء</button></div>`;filterCurrencyList('');modal.classList.add('show');}
const WORLD_CURRENCIES=[{name:'ريال يمني',symbol:'ر.ي',subUnit:'فلس'},{name:'ريال سعودي',symbol:'ر.س',subUnit:'هللة'},{name:'دولار أمريكي',symbol:'$',subUnit:'سنت'},{name:'درهم إماراتي',symbol:'د.إ',subUnit:'فلس'},{name:'ريال عماني',symbol:'ر.ع',subUnit:'بيسة'},{name:'دينار كويتي',symbol:'د.ك',subUnit:'فلس'},{name:'ريال قطري',symbol:'ر.ق',subUnit:'درهم'},{name:'دينار بحريني',symbol:'د.ب',subUnit:'فلس'},{name:'جنيه مصري',symbol:'ج.م',subUnit:'قرش'},{name:'دينار أردني',symbol:'د.أ',subUnit:'قرش'},{name:'ليرة لبنانية',symbol:'ل.ل',subUnit:'قرش'},{name:'ليرة سورية',symbol:'ل.س',subUnit:'قرش'},{name:'دينار عراقي',symbol:'د.ع',subUnit:'فلس'},{name:'دينار ليبي',symbol:'د.ل',subUnit:'درهم'},{name:'دينار تونسي',symbol:'د.ت',subUnit:'مليم'},{name:'دينار جزائري',symbol:'د.ج',subUnit:'سنتيم'},{name:'درهم مغربي',symbol:'د.م',subUnit:'سنتيم'},{name:'جنيه سوداني',symbol:'ج.س',subUnit:'قرش'},{name:'يورو',symbol:'€',subUnit:'سنت'},{name:'جنيه إسترليني',symbol:'£',subUnit:'بنس'},{name:'ين ياباني',symbol:'¥',subUnit:'سن'},{name:'روبل روسي',symbol:'₽',subUnit:'كوبيك'},{name:'ليرة تركية',symbol:'₺',subUnit:'قروش'},{name:'روبية هندية',symbol:'₹',subUnit:'بيسة'},{name:'روبية باكستانية',symbol:'₨',subUnit:'بيسة'},{name:'فرنك سويسري',symbol:'CHF',subUnit:'سنتيم'}];
function filterCurrencyList(q){q=(q||'').toLowerCase();const filtered=WORLD_CURRENCIES.filter(c=>c.name.toLowerCase().includes(q)||c.symbol.toLowerCase().includes(q));document.getElementById('curListBody').innerHTML=filtered.map(c=>{const i=WORLD_CURRENCIES.indexOf(c);return `<div onclick="pickCurrency(${i})" style="display:flex;align-items:center;gap:10px;padding:12px;background:#fff;border:1px solid var(--line);border-radius:12px;margin:6px 0;cursor:pointer"><div style="width:44px;height:44px;border-radius:10px;background:#eff6ff;color:#1e40af;font-size:14px;font-weight:900;display:grid;place-items:center">${esc(c.symbol)}</div><div style="text-align:right"><div style="font-weight:800;font-size:14px">${esc(c.name)}</div><div style="font-size:11px;color:var(--muted)">${esc(c.subUnit)}</div></div></div>`;}).join('')||'';}
function pickCurrency(i){const c=WORLD_CURRENCIES[i];document.getElementById('curName').value=c.name;document.getElementById('curSymbol').value=c.symbol;document.getElementById('curSub').value=c.subUnit;closeModal('currencyListModal');toast('تم');}

/* ============================================================
   النسخ الاحتياطي
   ============================================================ */
function backupToPhone(){const blob=new Blob([JSON.stringify(buildFullBackup(),null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='سجل-الديون-'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(a.href);data.settings.backup.lastDataBackup=Date.now();save();toast('تم الحفظ ✅');}
function backupToTelegram(){const blob=new Blob([JSON.stringify(buildFullBackup(),null,2)],{type:'application/json'});const text=`نسخة احتياطية\nالتاريخ: ${new Date().toLocaleString('ar-u-nu-latn')}`;const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='نسخة.json';a.click();setTimeout(()=>{window.open('https://t.me/share/url?url='+encodeURIComponent(text),'_blank');},400);}
function shareBackup(){const blob=new Blob([JSON.stringify(buildFullBackup(),null,2)],{type:'application/json'});const file=new File([blob],'نسخة.json',{type:'application/json'});if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]}))navigator.share({files:[file]});else backupToPhone();}
function toggleGdriveBackup(key,btn){
  const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});
  b[key]=!b[key]; if(btn)btn.classList.toggle('on',!!b[key]); save();
}
function setGdriveInterval(key,val){const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});b[key]=val;save();openSettingsPage('gdriveBackup',true);toast('تم حفظ تكرار النسخ');}
function saveGdriveSettings(){save();syncNativeBackupSettings();toast('تم حفظ إعدادات النسخ الاحتياطي');}
/* إرسال إعدادات النسخ إلى الجانب الأصلي (WorkManager) حتى تعمل النسخة التلقائية من m.html أيضًا */
function syncNativeBackupSettings(){
  try{
    const g=(data.settings&&data.settings.gdriveBackup)||{};
    const map={'6h':'6h','12h':'12h','24h':'daily','7d':'weekly'};
    if(window.AndroidBackup&&typeof AndroidBackup.setDriveBackupSettings==='function')
      AndroidBackup.setDriveBackupSettings(g.dataEnabled!==false,map[g.dataInterval]||'6h',g.imagesBackupEnabled===true);
  }catch(e){}
}
/* الحمولة السحابية بصيغة النسخة الموحدة التي تقرأها الاستعادة وخدمة النسخ التلقائي */

/* توحيد النسخ الاحتياطي: جميع الصفحات تفتح إعدادات النسخ الرئيسية نفسها. */
window.openUnifiedDriveSettings = function () {
  location.href = '../admin.html?settings=gdriveBackup';
};

function buildCloudBackupPayload(){
  if(!(window.SmartAdminBackup&&typeof SmartAdminBackup.create==='function'))throw new Error('ملف النسخ الموحد غير محمّل');
  try { if (typeof save === 'function') save(); } catch(e) {}
  return JSON.stringify(SmartAdminBackup.create());
}
function connectGdrive(){
  const bridge=window.AndroidBackup;
  if(bridge&&typeof bridge.connectGoogleDrive==='function'){try{bridge.connectGoogleDrive();}catch(e){toast('تعذر بدء اتصال Google Drive');}return;}
  showSettingsActionModal('الاتصال بحساب Google','<p>هذه الصفحة لا تستطيع تسجيل الدخول إلى Google Drive بمجرد إدخال البريد. يلزم تكامل Google OAuth وواجهة Drive API داخل التطبيق المضيف.</p><div class="settings-action-buttons"><button onclick="window.open(\'https://drive.google.com/drive/my-drive\',\'_blank\',\'noopener\')">فتح Google Drive</button><button onclick="downloadAppBackup()">تنزيل نسخة محلية</button></div>');
}
function changeGdriveAccount(){connectGdrive();}
function disconnectGdrive(){
  const bridge=window.AndroidBackup;
  if(bridge&&typeof bridge.disconnectGoogleDrive==='function'){try{bridge.disconnectGoogleDrive();}catch(e){}}
  const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});b.connected=false;b.email='';save();openSettingsPage('gdriveBackup',true);toast('تم فصل حالة الحساب المحفوظة');
}
function saveBackupEmail(){const el=document.getElementById('backupEmail');if(!el)return;const email=el.value.trim();if(!email||!email.includes('@')){toast('البريد غير صالح');return;}data.settings.gdriveBackup.backupEmail=email;save();toast('تم حفظ البريد');}
function generateBackupFilename(prefix='SmartAdmin-Pro-Backup'){const now=new Date();return `${prefix}_${now.toISOString().slice(0,10)}_${now.toTimeString().slice(0,8).replace(/:/g,'-')}.json`;}
function _recordGdriveBackup(filename,size){const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});b.lastDataBackup=Date.now();b.backupHistory=b.backupHistory||[];b.backupHistory.unshift({filename,date:new Date().toISOString(),size});b.backupHistory=b.backupHistory.slice(0,30);save();}
function backupNowAll(){
  saveGdriveSettings(); const bridge=window.AndroidBackup; let payload; try{payload=buildCloudBackupPayload();}catch(e){toast('تعذر تجهيز النسخة: '+e.message);return;} const filename=generateBackupFilename();
  if(bridge&&typeof bridge.backupToGoogleDrive==='function'){try{bridge.backupToGoogleDrive(payload,filename);toast('تم إرسال طلب النسخ إلى خدمة AndroidBackup');return;}catch(e){toast('فشل إرسال طلب النسخ؛ سيتم تنزيل نسخة محلية');}}
  try{const blob=new Blob([payload],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);_recordGdriveBackup(filename,blob.size);openSettingsPage('gdriveBackup',true);toast('تم تنزيل نسخة احتياطية محلية. لم يتم رفعها إلى Google Drive.');}catch(e){console.error(e);toast('تعذر إنشاء النسخة الاحتياطية');}
}
function doGdriveDataBackup(){backupNowAll();}
function restoreFromGoogleDrive(){
  const bridge=window.AndroidBackup;
  if(bridge&&typeof bridge.restoreFromGoogleDrive==='function'){try{bridge.restoreFromGoogleDrive();return;}catch(e){toast('تعذر بدء الاستعادة من Google Drive');return;}}
  const input=document.getElementById('gdriveRestoreInput')||document.getElementById('restoreFile');
  if(input){input.click();return;}toast('الاستعادة السحابية تحتاج إلى تكامل Google Drive؛ يمكنك اختيار ملف نسخة JSON محفوظ على الجهاز.');
}
function openBackupList(){
  const bridge=window.AndroidBackup;
  if(bridge&&typeof bridge.listGoogleDriveBackups==='function'){try{bridge.listGoogleDriveBackups();return;}catch(e){toast('تعذر جلب قائمة النسخ');return;}}
  const h=(data.settings.gdriveBackup||{}).backupHistory||[];
  showSettingsActionModal('النسخ الاحتياطية','<p>لا يوجد اتصال فعلي بـ Google Drive من هذه النسخة. سجل النسخ المحلية:</p>'+(h.length?h.map(x=>'<p><b>'+escapeSettingsHtml(x.filename||'نسخة')+'</b><br>'+escapeSettingsHtml(x.date||'')+'</p>').join(''):'')+'<div class="settings-action-buttons"><button onclick="window.open(\'https://drive.google.com/drive/my-drive\',\'_blank\',\'noopener\')">فتح Google Drive</button></div>');
}
function renderGdriveHistory(){openSettingsPage('gdriveBackup',true);}

/* ردود الجسر الأصلي لعمليات Google Drive (تُستدعى من MainActivity) */
window.onGoogleDriveBackupSuccess=function(){
  const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});
  b.lastDataBackup=Date.now();save();toast('✅ تم رفع النسخة إلى Google Drive');
  if(_exitPending){if(_exitBackupTimer)clearTimeout(_exitBackupTimer);setTimeout(doExitApp,250);}
};
window.onGoogleDriveBackupFailed=function(reason){
  toast('❌ فشل رفع النسخة إلى Google Drive'+(reason?': '+reason:''));
  if(_exitPending){if(_exitBackupTimer)clearTimeout(_exitBackupTimer);setTimeout(doExitApp,500);}
};
window.onGoogleDriveListFailed=function(reason){toast('❌ '+(reason||'تعذر جلب النسخ من Google Drive'));};
window.showGoogleDriveBackups=function(raw){
  let files=[],folder='RYD';
  try{const x=typeof raw==='string'?JSON.parse(raw):raw;files=Array.isArray(x&&x.files)?x.files:[];folder=x.folderName||'RYD';}catch(e){}
  const fmtSize=n=>{const v=Number(n||0);return v>=1048576?(v/1048576).toFixed(2)+' MB':Math.max(1,Math.round(v/1024))+' KB';};
  const rows=files.length?files.map(f=>{
    const name=String(f.name||'نسخة.back');
    const date=f.createdTime||f.modifiedTime||'';
    const when=date?new Date(date).toLocaleString('ar-u-nu-latn'):'—';
    const size=fmtSize(f.size);
    const id=String(f.id||'');
    return '<div style="padding:12px 10px;margin:7px 0;border:1px solid var(--line);border-radius:9px;background:var(--bg2);font-size:12px;text-align:center">'+
      '<div style="font-weight:800;font-size:15px;overflow-wrap:anywhere">'+escapeSettingsHtml(name)+'</div>'+
      '<div style="margin-top:5px;color:var(--muted)">المجلد: '+escapeSettingsHtml(folder)+' · الامتداد: .back</div>'+
      '<div style="margin-top:4px;color:var(--muted)">التاريخ: '+escapeSettingsHtml(when)+' · الحجم: '+escapeSettingsHtml(size)+'</div>'+
      '<button class="btn secondary" style="margin-top:8px;padding:7px 18px" onclick="restoreDriveBackup(\''+escapeSettingsHtml(id)+'\')">استعادة النسخة</button></div>';
  }).join(''):'';
  showSettingsActionModal('النسخ الاحتياطية الأصلية — RYD','<div style="max-height:65vh;overflow:auto"><div style="text-align:center;padding:8px;color:var(--muted)">المجلد: '+escapeSettingsHtml(folder)+' · عدد النسخ: '+files.length+'</div>'+rows+'</div>');
};
window.restoreDriveBackup=function(id){
  if(!id)return;
  const bridge=window.AndroidBackup;
  if(bridge&&typeof bridge.restoreGoogleDriveFile==='function'){try{bridge.restoreGoogleDriveFile(String(id));toast('⏳ جاري الاستعادة...');return;}catch(e){}}
  toast('تعذر بدء الاستعادة من Google Drive');
};
window.applyRestoredBackup=function(raw){
  try{
    const x=typeof raw==='string'?JSON.parse(raw):raw;
    if(!x||x.format!=='smart-admin-unified-backup')throw new Error('صيغة النسخة غير معروفة');
    if(!confirm('سيتم استبدال بيانات كل صفحات التطبيق بمحتوى النسخة. هل تريد المتابعة؟'))return;
    restoreUnifiedBackup(x);
  }catch(e){toast('❌ '+e.message);}
};
function restoreUnifiedBackup(x){
  const n=SmartAdminBackup.restore(x);
  toast('تمت استعادة بيانات '+n+' عنصر من جميع صفحات التطبيق؛ سيُعاد تحميل التطبيق');
  setTimeout(()=>location.replace('admin.html'),900);
}
window.onGoogleDriveConnected=function(email){const b=data.settings.gdriveBackup||(data.settings.gdriveBackup={});b.connected=true;b.email=email||'';save();openSettingsPage('gdriveBackup',true);toast('تم ربط Google Drive');};
window.onGoogleDriveRestored=function(json){try{const x=typeof json==='string'?JSON.parse(json):json;if(!x||!Array.isArray(x.people)||!Array.isArray(x.folders)||!x.settings)throw new Error('invalid backup');const old=data;data=x;if(!save()){data=old;throw new Error('save failed');}renderCurrentView();openSettingsPage('gdriveBackup',true);toast('تمت الاستعادة بنجاح');}catch(e){toast('تعذر استعادة النسخة: الملف غير صالح');}};
/* ============================================================
   النسخ التلقائي المحلي: يحفظ في localStorage على هذا الجهاز فقط، وليس رفعاً إلى Google Drive.
   ============================================================ */
let _backupTimer=null;
function getIntervalMs(key){const map={'6h':6*3600*1000,'12h':12*3600*1000,'24h':24*3600*1000,'7d':7*24*3600*1000,'daily':24*3600*1000,'weekly':7*24*3600*1000};return map[key]||6*3600*1000;}
async function runAutoBackup(){
  const b=data.settings.gdriveBackup;
  if(!b||!b.connected||!b.dataEnabled)return;
  if(b.wifiOnly&&navigator.connection&&navigator.connection.type&&navigator.connection.type!=='wifi')return;
  const last=b.lastDataBackup||0;
  const interval=getIntervalMs(b.dataInterval||'6h');
  if(Date.now()-last<interval)return;
  try{
    const jsonData=JSON.stringify(data,null,2);
    localStorage.setItem('detailed_last_auto_backup',jsonData);
    localStorage.setItem('detailed_last_auto_backup_time',Date.now().toString());
    b.lastDataBackup=Date.now();
    b.backupHistory=b.backupHistory||[];
    b.backupHistory.unshift({filename:generateBackupFilename('Auto'),date:new Date().toISOString(),size:jsonData.length});
    b.backupHistory=b.backupHistory.slice(0,20);
    save();
  }catch(e){}
}
function startBackupScheduler(){if(_backupTimer)clearInterval(_backupTimer);_backupTimer=setInterval(runAutoBackup,30*60*1000);setTimeout(runAutoBackup,60*1000);}

/* ============================================================
   مسح البيانات والسلة
   ============================================================ */
function confirmWipeAll(){document.getElementById('wipeConfirm').value='';document.getElementById('wipeModal').classList.add('show');}
function doWipeAll(){const c=document.getElementById('wipeConfirm').value.trim();if(c!=='حذف'){toast('اكتب "حذف"');return;}['detailed_register_v1','m_detailed_register_v1','sale_app_data_v2','smartadmin_data_v1','bank_app_v11','smartadmin_weekly_filters_v1','smartadmin_clock_entries_v1','smartadmin_home_clock_v1','detailed_last_auto_backup','detailed_last_auto_backup_time'].forEach(function(k){try{localStorage.removeItem(k)}catch(e){}});data={people:[],folders:[{id:'default-accounts',name:'حسابات',image:'',note:'',order:1,createdAt:Date.now()}],settings:{}};save();closeModal('wipeModal');toast('تم المسح');setTimeout(()=>location.reload(),800);}
function addToTrash(item,type,name,parentId){data.settings.trash=data.settings.trash||[];data.settings.trash.unshift({data:item,type,name,parentId,deletedAt:new Date().toLocaleString('ar-u-nu-latn')});save();}
function restoreFromTrash(i){const t=data.settings.trash[i];if(!t)return;try{if(t.type==='person'){data.people.unshift(t.data)}else if(t.type==='op'){const p=data.people.find(x=>String(x.id)===String(t.parentId));if(p){p.ops=p.ops||[];p.ops.push(t.data)}}else if(t.type==='folder'){if(!data.folders.some(x=>String(x.id)===String(t.data.id)))data.folders.push(t.data)}else if(t.type==='invoice'){const f=data.folders.find(x=>String(x.id)===String(t.parentId));if(f){f.invoices=f.invoices||[];if(!f.invoices.some(x=>String(x.id)===String(t.data.id)))f.invoices.push(t.data)}else{toast('تعذر الاستعادة: المجلد الأصلي غير موجود');return}}else if(t.type==='weeklyFilter'){const a=JSON.parse(localStorage.getItem('smartadmin_weekly_filters_v1')||'[]');if(!a.some(x=>String(x.id)===String(t.data.id)))a.push(t.data);localStorage.setItem('smartadmin_weekly_filters_v1',JSON.stringify(a))}else if(t.type==='detail'){const a=JSON.parse(localStorage.getItem('sale_app_data_v2')||'[]');const parent=a.find(x=>String(x.id)===String(t.parentId));if(parent){parent.invoices=parent.invoices||[];if(!parent.invoices.some(x=>String(x.id)===String(t.data.id)))parent.invoices.push(t.data);localStorage.setItem('sale_app_data_v2',JSON.stringify(a))}else{toast('تعذر الاستعادة: سجل التفصيل الأصلي غير موجود');return}}else if(t.type==='clockEntry'){const a=JSON.parse(localStorage.getItem('smartadmin_clock_entries_v1')||'[]');if(!a.some(x=>String(x.id)===String(t.data.id)))a.push(t.data);localStorage.setItem('smartadmin_clock_entries_v1',JSON.stringify(a))}else if(t.type==='paAccount'||t.type==='paFolder'){if(!window.privateAccountsRestore||!window.privateAccountsRestore(t)){toast('تعذر الاستعادة: المجلد الأصلي غير موجود');return}}data.settings.trash.splice(i,1);save();openSettingsPage('trash',true);renderCurrentView();toast('تمت الاستعادة بنجاح')}catch(e){console.error(e);toast('تعذرت الاستعادة')} }
function emptyTrash(){if(!(data.settings.trash||[]).length){toast('السلة فارغة');return}customConfirm('حذف جميع العناصر من السلة نهائيًا؟ لا يمكن التراجع.',()=>{data.settings.trash=[];save();openSettingsPage('trash',true);toast('تم إفراغ السلة')},null,{title:'إفراغ السلة',icon:'🗑️',danger:true,confirmText:'إفراغ السلة'});}
function deleteFromTrash(i){customConfirm('حذف نهائي؟',()=>{data.settings.trash.splice(i,1);save();openSettingsPage('trash',true);toast('تم');},null,{title:'حذف نهائي',icon:'🗑️',danger:true,confirmText:'حذف'});}
/* ===== نسخة احتياطية واحدة تشمل كل صفحات التطبيق ===== */
const APP_BACKUP_EXCLUDE=/device_id|bio_cred|last_auto_backup|_pre_restore_/;
function buildFullBackup(){
  const backup={app:'SmartAdmin',version:2,createdAt:new Date().toISOString(),localStorage:{}};
  try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(APP_BACKUP_EXCLUDE.test(k))continue;backup.localStorage[k]=localStorage.getItem(k);}}catch(e){}
  return backup;
}
function applyFullBackup(b){
  const snap=b.localStorage||{};
  const current={};
  for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(!APP_BACKUP_EXCLUDE.test(k))current[k]=localStorage.getItem(k);}
  // نحفظ نسخة من البيانات الحالية قبل الاستبدال
  try{localStorage.setItem('__pre_restore_'+Date.now(),JSON.stringify(current));}catch(e){throw new Error('Could not preserve current data');}
  Object.keys(current).forEach(k=>{if(!(k in snap))localStorage.removeItem(k);});
  Object.keys(snap).forEach(k=>{if(!APP_BACKUP_EXCLUDE.test(k))localStorage.setItem(k,String(snap[k]));});
  toast('تمت استعادة كل الصفحات؛ سيُعاد تحميل التطبيق');
  setTimeout(()=>location.reload(),800);
}
function restore(input){
  const f=input&&input.files&&input.files[0];if(!f)return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const x=JSON.parse(r.result);
      if(x&&x.format==='smart-admin-unified-backup'&&x.storage){if(!confirm('سيتم استبدال بيانات كل صفحات التطبيق بمحتوى النسخة. هل تريد المتابعة؟'))return;restoreUnifiedBackup(x);return;}
      if(x&&x.app==='SmartAdmin'&&x.localStorage&&typeof x.localStorage==='object'){if(!confirm('سيتم استبدال بيانات كل صفحات التطبيق بمحتوى النسخة. هل تريد المتابعة؟'))return;applyFullBackup(x);return;}
      if(!x||typeof x!=='object'||!Array.isArray(x.people)||!Array.isArray(x.folders)||!x.settings||typeof x.settings!=='object')throw new Error('Invalid backup structure');
      // Keep a recoverable snapshot of the currently saved data before replacing it.
      const currentRaw=safeStorageGet(KEY,null);
      if(currentRaw!==null&&!safeStorageSet(KEY+'_pre_restore_'+Date.now(),currentRaw))throw new Error('Could not preserve current data');
      const previousData=data;
      data=x;
      if(!save()){data=previousData;throw new Error('Could not persist restored data');}
      applyThemeColors(data.settings.color||'#1e40af');applyFont(data.settings.font||'default');applyFontWeight(data.settings.fontWeight||'medium');
      if(data.settings.fontSize)setFontSize(data.settings.fontSize);
      renderCurrentView();closeSettingsPage();toast('تمت استعادة النسخة مع الاحتفاظ بنسخة من البيانات السابقة');
    }catch(e){console.error('فشلت استعادة النسخة',e);toast('ملف غير صالح أو تعذر حفظه؛ لم تكتمل الاستعادة');}
    finally{try{input.value='';}catch(_){}}
  };
  r.onerror=()=>toast('تعذر قراءة ملف النسخة الاحتياطية');
  r.readAsText(f);
}

/* ============================================================
   رفع الصور وإعدادات الملف الشخصي
   ============================================================ */
function uploadImage(key,input){const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{data.settings[key]=r.result;save();openSettingsPage('profile',true);toast('تم');};r.readAsDataURL(f);}
function saveProfileFull(){['profileNameAr','profileNameEn','profileAddressAr','profileAddressEn','profileContacts','profileContactsEn'].forEach(id=>{const el=document.getElementById(id);if(el)data.settings[id]=el.value;});save();toast('✅');}
function saveMsgSetting(k,v){data.settings[k]=v;save();} function toggleMessageFeature(k,btn){const next=data.settings[k]===false;data.settings[k]=next;if(btn)btn.classList.toggle('on',next);save();}
function toggleGlobalMessageSettings(btn){data.settings.globalMessageSettings=!(data.settings.globalMessageSettings!==false);btn.classList.toggle('on',data.settings.globalMessageSettings);save();toast(data.settings.globalMessageSettings?'تم تطبيق الإعدادات العامة على جميع الحسابات':'تم تفعيل إعدادات كل حساب بشكل مستقل');}
function saveMessagesFull(){
  ['msgIntro','msgEnd','payEnd','msgFormatDebt','msgFormatPay','countryCode'].forEach(id=>{const el=document.getElementById(id);if(el)data.settings[id]=el.value;});
  const radios=['sendDest','sendMethod','sendWhen','waType','messageContent','messageFormat','lineKey','waNotifType','docFormat','docType','imageQuality'];
  radios.forEach(name=>{const el=document.querySelector(`input[name="${name}"]:checked`);if(el)data.settings[name]=el.value;});
  save();
  closeSettingsPage();
  clearNav();
  tab('home',true);
  window.scrollTo(0,0);
  openSideMenu();
  toast('✅ تم حفظ إعدادات الرسائل والواتساب');
}
function setStampSetting(key,val){if(!data.settings.stampSettings)data.settings.stampSettings={};data.settings.stampSettings[key]=val;save();toast('✅');}
function togglePrintSetting(key,btn){data.settings[key]=!data.settings[key];btn.classList.toggle('on',data.settings[key]);save();}
function changeImageSize(delta){let val=parseFloat(data.settings.imageSize||1.0)+delta;val=Math.max(0,Math.min(3,val));data.settings.imageSize=parseFloat(val.toFixed(1));save();const el=document.getElementById('imageSizeValue');if(el)el.textContent=data.settings.imageSize.toFixed(1);}
function shareMessagesTemplate(){const s=data.settings;const text=`📋 نماذج الرسائل\n\nالمقدمة:\n${s.msgIntro||'—'}\n\nالختام:\n${s.msgEnd||'—'}\n\nختام طلب السداد:\n${s.payEnd||'—'}`;if(navigator.share){navigator.share({title:'نماذج',text}).catch(()=>{});}else if(navigator.clipboard){navigator.clipboard.writeText(text).then(()=>toast('📋 تم'));}}
function toggleFullHeader(btn){data.settings.useFullHeader=!data.settings.useFullHeader;btn.classList.toggle('on',data.settings.useFullHeader);save();toast(data.settings.useFullHeader?'✅':'❌');}
function deleteLogo(){customConfirm('حذف الشعار؟',()=>{data.settings.logoData='';save();openSettingsPage('profile',true);toast('تم');},null,{title:'حذف',icon:'🖼️',danger:true,confirmText:'حذف'});}
function deleteStamp(){customConfirm('حذف الختم؟',()=>{data.settings.stampData='';save();openSettingsPage('profile',true);toast('تم');},null,{title:'حذف',icon:'🔖',danger:true,confirmText:'حذف'});}
function deleteSign(){customConfirm('حذف التوقيع؟',()=>{data.settings.signData='';save();openSettingsPage('profile',true);toast('تم');},null,{title:'حذف',icon:'✍️',danger:true,confirmText:'حذف'});}

/* ============================================================
   قفل التطبيق
   ============================================================ */
function toggleAppLock(btn){if(!data.settings.appLock)data.settings.appLock={};const enabled=!data.settings.appLock.enabled;data.settings.appLock.enabled=enabled;btn.classList.toggle('on',enabled);save();toast(enabled?'🔒':'🔓');}
function setPin(){openPinModal('set');}
function changePin(){openPinModal('change');}
function openPinModal(mode){let modal=document.getElementById('pinModal');if(!modal){modal=document.createElement('div');modal.id='pinModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}const titles={set:'تعيين رمز',change:'تغيير الرمز'};let html=`<div class="sheet" style="max-width:400px"><h2 style="text-align:center">🔢 ${titles[mode]}</h2>`;if(mode==='change')html+=`<div class="field"><label>الرمز الحالي</label><input type="password" id="pinOld" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div>`;html+=`<div class="field"><label>الرمز الجديد</label><input type="password" id="pinNew" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div><div class="field"><label>تأكيد</label><input type="password" id="pinConfirm" class="smallInput" inputmode="numeric" maxlength="8" style="text-align:center;font-size:24px;letter-spacing:8px"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px"><button class="btn secondary" onclick="closeModal('pinModal')">إلغاء</button><button class="btn primary" onclick="savePin('${mode}')">💾</button></div></div>`;modal.innerHTML=html;modal.classList.add('show');}
function savePin(mode){const oldPin=mode==='change'?document.getElementById('pinOld').value:null;const newPin=document.getElementById('pinNew').value;const conf=document.getElementById('pinConfirm').value;if(mode==='change'&&btoa(oldPin)!==data.settings.appLock.pin){toast('الرمز خطأ');return;}if(!newPin||newPin.length<4){toast('4 أرقام على الأقل');return;}if(newPin!==conf){toast('غير متطابقين');return;}if(!data.settings.appLock)data.settings.appLock={};data.settings.appLock.pin=btoa(newPin);save();closeModal('pinModal');openSettingsPage('appLock',true);toast('✅');}
function removePin(){customConfirm('حذف الرمز؟',()=>{if(data.settings.appLock){data.settings.appLock.pin='';data.settings.appLock.enabled=false;}save();openSettingsPage('appLock',true);toast('تم');},null,{title:'حذف',icon:'🔢',danger:true,confirmText:'حذف'});}
function setAutoLock(v){if(!data.settings.appLock)data.settings.appLock={};data.settings.appLock.autoLock=v;save();toast('تم');}
function toggleBiometric(){
  if(!data.settings.appLock)data.settings.appLock={};
  if(data.settings.appLock.biometric){
    data.settings.appLock.biometric=false;
    localStorage.removeItem('detailed_bio_cred_id');
    save();toast('👆 تم إلغاء');openSettingsPage('appLock',true);return;
  }
  (async()=>{
    try{
      const challenge=new Uint8Array(32);crypto.getRandomValues(challenge);
      const userId=new Uint8Array(16);crypto.getRandomValues(userId);
      const credential=await navigator.credentials.create({publicKey:{challenge,rp:{name:'الاداري برو'},user:{id:userId,name:data.settings.profileNameAr||'user',displayName:'User'},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required'},timeout:60000}});
      if(credential){
        localStorage.setItem('detailed_bio_cred_id',btoa(String.fromCharCode(...new Uint8Array(credential.rawId))));
        data.settings.appLock.biometric=true;
        save();toast('✅');openSettingsPage('appLock',true);
      }
    }catch(e){toast('❌');}
  })();
}
function checkAppLock(){const lock=data.settings.appLock;if(!lock||!lock.enabled)return true;const elapsed=Date.now()-(lock.lastUnlock||0);const ms={'0':0,'30s':30*1000,'1m':60*1000,'5m':5*60*1000,'15m':15*60*1000}[lock.autoLock]||60*1000;if(elapsed<ms)return true;showLockScreen();return false;}
function showLockScreen(){const ls=document.getElementById('lockScreen');if(!ls)return;ls.style.display='flex';setTimeout(()=>document.getElementById('lockScreenPin')?.focus(),200);updateBioButton();}
function tryUnlockApp(){const pin=document.getElementById('lockScreenPin').value;if(btoa(pin)===data.settings.appLock.pin){data.settings.appLock.lastUnlock=Date.now();save();document.getElementById('lockScreen').style.display='none';toast('✅');}else{document.getElementById('lockScreenError').style.display='block';document.getElementById('lockScreenError').textContent='❌ رمز خطأ';document.getElementById('lockScreenPin').value='';document.getElementById('lockScreenPin').focus();}}
async function tryUnlockBiometric(){
  try{
    if(!window.PublicKeyCredential){toast('⚠️');return;}
    const available=await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    if(!available){toast('⚠️');return;}
    const challenge=new Uint8Array(32);crypto.getRandomValues(challenge);
    const credId=localStorage.getItem('detailed_bio_cred_id');
    if(!credId){
      const userId=new Uint8Array(16);crypto.getRandomValues(userId);
      const credential=await navigator.credentials.create({publicKey:{challenge,rp:{name:'الاداري برو'},user:{id:userId,name:data.settings.profileNameAr||'user',displayName:'User'},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required'},timeout:60000}});
      if(credential){localStorage.setItem('detailed_bio_cred_id',btoa(String.fromCharCode(...new Uint8Array(credential.rawId))));data.settings.appLock.lastUnlock=Date.now();save();document.getElementById('lockScreen').style.display='none';toast('✅');}
    } else {
      const rawId=Uint8Array.from(atob(credId),c=>c.charCodeAt(0));
      const assertion=await navigator.credentials.get({publicKey:{challenge,allowCredentials:[{id:rawId,type:'public-key'}],userVerification:'required',timeout:60000}});
      if(assertion){data.settings.appLock.lastUnlock=Date.now();save();document.getElementById('lockScreen').style.display='none';toast('✅');}
    }
  }catch(e){toast('❌');}
}
function updateBioButton(){const btn=document.getElementById('bioBtn');if(!btn)return;const lock=data.settings.appLock;if(lock&&lock.enabled&&window.PublicKeyCredential&&data.settings.appLock.biometric){btn.style.display='block';}else{btn.style.display='none';}}

/* ============================================================
   الطباعة
   ============================================================ */
function getPrintCSS(){
  const s=data.settings||{};
  const paper=s.paper||'a4';
  const fontMap={tajawal:"'Tajawal',Arial",cairo:"'Cairo',Arial",almarai:"'Almarai',Arial",ibm:"'IBM Plex Sans Arabic',Arial",default:"Arial"};
  const font=fontMap[s.printFont||'tajawal']||fontMap.tajawal;
  const color=s.printColor||'#aebeff';
  const sizeMap={a4:'A4 portrait',80:'80mm auto',58:'58mm auto'};
  const pageSize=sizeMap[paper]||'A4 portrait';
  return `@page{size:${pageSize};margin:${paper==='a4'?'10mm':'4mm'}}
  *{box-sizing:border-box}html,body{max-width:100%;background:#fff}body{font-family:${font};direction:rtl;padding:${paper==='a4'?'8px':'4px'};color:#111;font-size:15px;line-height:1.55;margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .print-page,.print-content,.statement-print,.print-document{width:100%;max-width:100%;margin:0 auto;box-sizing:border-box}
  .company-header{display:grid;grid-template-columns:minmax(0,1fr) 95px minmax(0,1fr);gap:10px;align-items:center;border-bottom:2px solid #222;padding:0 4px 8px;margin:0 0 9px;break-inside:avoid;page-break-inside:avoid}
  .company-side{font-size:12px;line-height:1.45}.company-side.ar{text-align:right}.company-side.en{text-align:left;direction:ltr}.company-side .name{font-size:16px;font-weight:900}.company-logo{width:86px;height:72px;object-fit:contain;display:block;margin:auto}.full-image-header{display:block;margin:0 0 9px;padding:0 0 8px;border-bottom:2px solid #222}.full-header-image{display:block!important;width:100%!important;max-width:100%!important;height:120px!important;max-height:none!important;object-fit:fill!important;margin:0!important}.company-logo-placeholder{width:86px;height:72px;display:grid;place-items:center;margin:auto;font-size:11px;color:#777}
  .doc-title{display:block;width:max-content;max-width:100%;min-width:175px;text-align:center;margin:7px auto 10px;padding:6px 26px;border:1.5px solid #333;border-radius:2px;font-size:18px;font-weight:900;background:#fff;color:#111}
  .meta-line{text-align:center;font-size:11px;color:#444;margin:4px 0 8px}.account-heading{display:grid;grid-template-columns:1fr 2fr 1fr;align-items:center;margin:7px 0 10px;font-weight:900;font-size:18px}.account-heading .right{text-align:right}.account-heading .center{text-align:center;font-size:22px}.account-heading .left{text-align:left}.dotted-name{border-bottom:2px dotted #222;padding-bottom:4px}
  .print-table{width:100%;max-width:100%;border-collapse:collapse;margin:8px 0;table-layout:fixed;page-break-inside:auto;break-inside:auto}.print-table thead{display:table-header-group}.print-table tfoot{display:table-footer-group}.print-table tr{page-break-inside:avoid;break-inside:avoid}.print-table th,.print-table td{border:1px solid #536174;padding:6px 5px;text-align:center;vertical-align:middle;overflow-wrap:anywhere;word-break:normal;box-sizing:border-box}.print-table th{background:#aebeff;color:#111;font-size:11px;font-weight:900;white-space:normal}.print-table td{font-size:12px;line-height:1.35}.print-table .debt{color:#b42335;font-weight:900}.print-table .pay{color:#16824a;font-weight:900}.print-table .balance{color:#1739b7;font-weight:900}.print-table .total-row td,.print-table .remaining-row td{background:#e6ecff;font-weight:900}
  .summary-line{font-weight:900;text-align:center;border:1px solid #536174;padding:7px;margin-top:-8px;background:#f7f8fc}.note-box{border:1px solid #777;min-height:38px;padding:8px;text-align:right;margin-top:8px}.voucher-box{border:2px solid #222;margin:8px auto 0;width:96%}.voucher-row{padding:14px 18px;border-bottom:1px solid #444;min-height:62px;display:flex;align-items:center;justify-content:flex-start;font-size:17px;font-weight:900}.voucher-row:last-child{border-bottom:0}.voucher-row .label{margin-left:8px}.voucher-row .value{font-weight:900}
  .auth-intro{text-align:center;font-size:14px;margin:10px 0 12px}.auth-greeting{display:flex;justify-content:space-between;font-size:16px;font-weight:900;margin:8px 10px}.auth-text{text-align:center;font-size:15px;line-height:1.8;margin:8px 0}.auth-date{text-align:right;margin-top:16px;font-size:14px}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:24px;border-top:1px solid #777;margin-top:24px;padding-top:10px}.signature{text-align:center;font-size:13px;line-height:2.1}.signature .line{border-bottom:1px dotted #555;display:inline-block;min-width:120px}.print-footer{border-top:1px solid #999;margin-top:12px;padding-top:7px;display:flex;justify-content:space-between;align-items:end;font-size:10px;color:#555}.print-footer img{max-height:65px;max-width:100px}.stamp-area{text-align:left}.avoid-break{break-inside:avoid;page-break-inside:avoid}
  .voucher-paper{border:1px solid #7b203d;padding:15px;border-radius:2px;max-width:100%;margin:0 auto;break-inside:avoid}.voucher-headline{width:max-content;max-width:100%;min-width:190px;margin:8px auto 10px;padding:8px 24px;text-align:center;border:1.5px solid #4d2a35;border-radius:4px;font-size:20px;font-weight:900;color:#185d39;background:#e9f8ef}.voucher-headline.blue{color:#182f59;background:#e5efff;border-color:#263b5d}.voucher-date{text-align:center;font-size:14px;font-weight:800;margin:6px 0 14px}.voucher-from{display:flex;justify-content:space-between;gap:12px;margin:8px 0;font-weight:800}.voucher-words{border:1px solid #777;border-radius:5px;background:#fafafa;padding:10px;margin:8px 0;text-align:center;font-weight:800}.voucher-detail-title{margin:10px 0 0;padding:7px;text-align:center;background:#6b1736;color:#fff;font-weight:900}.voucher-table{width:100%;border-collapse:collapse;table-layout:fixed}.voucher-table th,.voucher-table td{border:1px solid #552238;padding:8px 5px;text-align:center;overflow-wrap:anywhere}.voucher-table th{background:#aebeff;color:#111}.voucher-total{border:1px solid #7b203d;border-radius:5px;padding:9px;text-align:center;font-size:17px;font-weight:900;margin-top:10px}.voucher-total.green{color:#16824a}.voucher-total.red{color:#a82336}.voucher-signs{display:flex;justify-content:space-between;gap:18px;margin:36px 5px 0;padding-top:10px;font-weight:800}.voucher-signs span{min-width:35%;text-align:center}.statement-card{border:1px solid #536174;padding:12px;margin:8px 0}.statement-card h3{text-align:center;margin:3px 0 10px}.signature-table{width:100%;margin-top:18px;border-collapse:collapse}.signature-table td{border:0;border-top:1px solid #777;padding:18px 8px 0;text-align:center;font-weight:800}
  @media print{html,body{width:100%;margin:0;padding:0;overflow:visible}.company-header,.doc-title,.account-heading,.meta-line,.voucher-paper,.voucher-headline,.voucher-date{break-inside:avoid;page-break-inside:avoid}.print-table{page-break-inside:auto;break-inside:auto}.print-table tr{page-break-inside:avoid;break-inside:avoid}.print-table thead{display:table-header-group}.avoid-break{break-inside:avoid;page-break-inside:avoid}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}}
  @media print and (max-width:79mm){body{font-size:11px;padding:2px}.company-header{grid-template-columns:minmax(0,1fr) 52px minmax(0,1fr);gap:4px}.company-logo,.company-logo-placeholder{width:48px;height:42px}.company-side{font-size:8px}.company-side .name{font-size:10px}.doc-title{min-width:110px;font-size:13px;padding:4px 8px}.account-heading{font-size:12px}.account-heading .center{font-size:15px}.print-table th,.print-table td{padding:4px 2px;font-size:9px}.voucher-paper{padding:7px}.voucher-headline{min-width:130px;font-size:14px;padding:5px}.voucher-table th,.voucher-table td{padding:4px 2px;font-size:9px}.voucher-signs{margin-top:20px;font-size:9px}}
  `;
}
function buildPrintHeader(title){
  const s=data.settings||{};
  const ar=[s.profileNameAr,s.profileAddressAr,s.profileContacts].filter(Boolean)
    .map((x,i)=>`<div class="${i===0?'name':''}">${esc(x)}</div>`).join('');
  const en=[s.profileNameEn,s.profileAddressEn,s.profileContactsEn].filter(Boolean)
    .map((x,i)=>`<div class="${i===0?'name':''}">${esc(x)}</div>`).join('');
  const hasLogo=!!s.logoData;
  let header='';
  if(s.useFullHeader && hasLogo){
    header=`<div class="company-header full-image-header"><img class="company-logo full-header-image" src="${s.logoData}" alt="ترويسة المؤسسة"></div>`;
  }else{
    const logo=hasLogo
      ? `<img class="company-logo" src="${s.logoData}" alt="شعار">`
      : `<div class="company-logo-placeholder"></div>`;
    header=`<div class="company-header text-image-header">
      <div class="company-side ar">${ar}</div>
      <div class="company-logo-cell">${logo}</div>
      <div class="company-side en">${en}</div>
    </div>`;
  }
  return `${header}<div class="doc-title">${esc(title)}</div>`;
}
function buildPrintFooter(mode='statement'){
  const s=data.settings;
  const stampMode=(s.stampSettings&&s.stampSettings[mode])||'sign';
  let media='';
  if((stampMode==='stamp'||stampMode==='all')&&s.stampData)media=`<img src="${s.stampData}" alt="ختم">`;
  if((stampMode==='sign'||stampMode==='all')&&s.signData)media+=`<img src="${s.signData}" alt="توقيع">`;
  const now=new Date();
  return `<div class="print-footer"><span>صفحة 1</span><span>${now.toISOString().slice(0,19).replace('T',' ')}</span><span class="stamp-area">${media}</span></div>`;
}
function buildPrintMeta(){
  const s=data.settings;const now=new Date();let parts=[];
  if(s.showPrintDate)parts.push(`التاريخ: ${now.toLocaleDateString('en-GB')}`);
  if(s.showPrintTime)parts.push(`الوقت: ${now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})}`);
  return parts.length?`<div class="meta-line">${parts.join(' &nbsp; | &nbsp; ')}</div>`:'';
}

function printPDF(){
  const p=data.people.find(x=>x.id===selected);if(!p)return;
  const s=data.settings;const activeCurrency=window._detailActiveCurrency||s.currency||'ر.ي';
  const cName=((s.currencies||[]).find(c=>c.symbol===activeCurrency)||{}).name||activeCurrency;
  const opsFiltered=p.ops.filter(o=>(o.currency||s.currency)===activeCurrency);
  let bal=0,totalDebt=0,totalPay=0;
  const rows=opsFiltered.slice().sort((a,b)=>((a.date||'')+(a.time||'')).localeCompare((b.date||'')+(b.time||''))).map(o=>{bal+=o.type==='debt'?o.amount:-o.amount;if(o.type==='debt')totalDebt+=o.amount;else totalPay+=o.amount;return {...o,runningBalance:bal};});
  const finalBal=totalDebt-totalPay;
  const rowsHtml=rows.map(r=>`<tr><td>${esc(r.date||'')}</td><td>${escNl(r.note||'')}</td><td class="red">${r.type==='debt'?fmt(r.amount):''}</td><td class="grn">${r.type==='pay'?fmt(r.amount):''}</td><td class="blu">${fmt(Math.abs(r.runningBalance))}</td></tr>`).join('');
  const sub=(s.showPhone&&p.phone?`<div class="pv-c">الهاتف: ${esc(p.phone)}</div>`:'')+`<div class="pv-c">العملة: ${esc(cName)} (${esc(activeCurrency)})</div>`;
  const extra=s.addNoteOnStatement&&p.note?`<div class="pv-c"><b>ملاحظة:</b> ${esc(p.note)}</div>`:'';
  PV2.statement({title:'كشف حساب',name:p.name,auth:false,rows:rowsHtml,ng:totalDebt,ps:totalPay,run:-finalBal,unit:activeCurrency,sub:sub,extra:extra});
}
function printBalance(){
  const p=data.people.find(x=>x.id===selected);if(!p)return;
  const s=data.settings;const activeCurrency=window._detailActiveCurrency||s.currency||'ر.ي';
  const opsFiltered=p.ops.filter(o=>(o.currency||s.currency)===activeCurrency);let totalDebt=0,totalPay=0;
  opsFiltered.forEach(o=>o.type==='debt'?totalDebt+=o.amount:totalPay+=o.amount);
  const finalBal=totalDebt-totalPay;
  PV2.statement({title:'مصادقة حساب',name:p.name,auth:true,ng:totalDebt,ps:totalPay,run:-finalBal,unit:activeCurrency});
}
function openPrintMenu(event){if(event)event.stopPropagation();const existing=document.getElementById('printMenu');if(existing)existing.remove();const menu=document.createElement('div');menu.id='printMenu';menu.className='print-menu';menu.innerHTML=`<button onclick="printPDF();closePrintMenu()">📄 طباعة كشف الحساب</button><button onclick="printBalance();closePrintMenu()">📝 طباعة مصادقة الحساب</button>`;document.body.appendChild(menu);const rect=event.target.getBoundingClientRect();menu.style.top=(rect.bottom+4)+'px';menu.style.right=(window.innerWidth-rect.right)+'px';setTimeout(()=>document.addEventListener('click',closePrintMenuOnClickOutside),100);}
function closePrintMenu(){const m=document.getElementById('printMenu');if(m)m.remove();document.removeEventListener('click',closePrintMenuOnClickOutside);}
function closePrintMenuOnClickOutside(e){const m=document.getElementById('printMenu');if(m&&!m.contains(e.target))closePrintMenu();}

function printVoucher(opId){
  const p=data.people.find(x=>x.id===selected);if(!p)return;const op=p.ops.find(o=>o.id===opId);if(!op)return;const s=data.settings;const curr=op.currency||s.currency||'ر.ي';
  const bal=p.ops.filter(o=>(o.currency||s.currency)===curr).reduce((sum,o)=>sum+(o.type==='debt'?o.amount:-o.amount),0);
  const amountLabel=op.type==='debt'?'عليكم':'لكم';const balanceLabel=bal>=0?'عليكم':'لكم';const balanceTitle=op.type==='debt'?'الرصيد الكامل':'الرصيد الباقي';
  PV2.txn({name:p.name,date:op.date||'',dirLabel:amountLabel,amount:fmt(op.amount),unit:curr,note:(op.note||'').trim(),balLabel:balanceTitle,balSide:balanceLabel,balAmt:fmt(Math.abs(bal))});
}
/* ============================================================
   صورة إيصال
   ============================================================ */
function generateReceiptImage(person,type,amount,extra){return new Promise((resolve)=>{const s=data.settings;const currency=extra.currency||s.currency||'ر.ي';const date=extra.date||new Date().toISOString().slice(0,10);const balance=extra.balance||0;const amountLabel=type==='debt'?'عليكم':type==='pay'?'لكم':'عليكم';const balanceLabel=balance>=0?'عليكم':'لكم';const balanceValue=Math.abs(balance);const bayan=(extra.note||'').trim();const balanceTitle=type==='debt'?'الرصيد الكامل':'الرصيد الباقي';const W=1200;const H=1600;const canvas=document.createElement('canvas');canvas.width=W;canvas.height=H;const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);ctx.fillStyle='#000';ctx.font='bold 26px Tajawal, Arial';ctx.textAlign='right';ctx.direction='rtl';ctx.fillText(s.profileNameAr||'اسم المؤسسة',W-50,60);ctx.beginPath();ctx.moveTo(40,100);ctx.lineTo(W-40,100);ctx.stroke();ctx.font='bold 38px Tajawal';ctx.fillText('الاخ:',W-60,180);ctx.textAlign='center';ctx.fillText(person.name,W/2,180);ctx.textAlign='left';ctx.fillText('المحترم',60,180);ctx.strokeRect(60,250,W-120,1000);ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(60,500);ctx.lineTo(W-60,500);ctx.moveTo(60,750);ctx.lineTo(W-60,750);ctx.moveTo(60,1000);ctx.lineTo(W-60,1000);ctx.stroke();ctx.fillStyle='#000';ctx.font='bold 42px Tajawal';ctx.textAlign='center';ctx.fillText(`التاريخ: ${date}`,W/2,410);ctx.font='bold 46px Tajawal';ctx.fillText(`${amountLabel} ${fmt(amount)} (${currency})`,W/2,660);ctx.font='bold 42px Tajawal';if(bayan){const bl=bayan.split('\n');const lh=56;const y0=910-((bl.length-1)*lh)/2;bl.forEach((t,i)=>ctx.fillText(i===0?`البيان: ${t}`:t,W/2,y0+i*lh));}ctx.font='bold 44px Tajawal';ctx.fillText(`${balanceTitle}: ${balanceLabel} ${fmt(balanceValue)} (${currency})`,W/2,1160);resolve(canvas.toDataURL('image/png'));});}

/* ============================================================
   Custom Confirm/Alert
   ============================================================ */
function customConfirm(message,onConfirm,onCancel,options={}){const title=options.title||'تأكيد';const confirmText=options.confirmText||'موافق';const cancelText=options.cancelText||'إلغاء';const isDanger=options.danger||false;const icon=options.icon||'❓';let modal=document.getElementById('customConfirmModal');if(!modal){modal=document.createElement('div');modal.id='customConfirmModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet sa-themed-dialog" style="max-width:400px;text-align:center"><div class="sa-dialog-icon">${icon}</div><h2 style="font-size:19px;font-weight:900;color:var(--primary);margin-bottom:12px">${title}</h2><p style="font-size:14px;color:var(--text2);margin-bottom:24px;line-height:1.7;white-space:pre-wrap">${esc(message)}</p><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px"><button class="btn secondary" id="ccCancelBtn" style="padding:14px;font-size:15px">${cancelText}</button><button class="btn ${isDanger?'danger':'primary'}" id="ccConfirmBtn" style="padding:14px;font-size:15px">${confirmText}</button></div></div>`;modal.classList.add('show');document.getElementById('ccCancelBtn').onclick=()=>{closeModal('customConfirmModal');if(onCancel)onCancel();};document.getElementById('ccConfirmBtn').onclick=()=>{closeModal('customConfirmModal');if(onConfirm)onConfirm();};}
function customAlert(message,options={}){const title=options.title||'تنبيه';const buttonText=options.buttonText||'حسناً';const icon=options.icon||'ℹ️';let modal=document.getElementById('customAlertModal');if(!modal){modal=document.createElement('div');modal.id='customAlertModal';modal.className='overlay';modal.onclick=e=>{if(e.target===modal)modal.classList.remove('show')};document.body.appendChild(modal);}modal.innerHTML=`<div class="sheet sa-themed-dialog" style="max-width:400px;text-align:center"><div class="sa-dialog-icon">${icon}</div><h2 style="font-size:19px;font-weight:900;color:var(--primary);margin-bottom:12px">${title}</h2><p style="font-size:14px;color:var(--text2);margin-bottom:24px;line-height:1.7;white-space:pre-wrap">${esc(message)}</p><button class="btn primary" style="width:100%;padding:14px;font-size:15px" onclick="closeModal('customAlertModal')">${buttonText}</button></div>`;modal.classList.add('show');}

/* ============================================================
   التفعيل
   ============================================================ */
function copyDeviceId(){const deviceId=getDeviceId();if(navigator.clipboard){navigator.clipboard.writeText(deviceId).then(()=>toast('✅'));}}

/* ============================================================
   تحويل الأرقام العربية والفارسية إلى الإنجليزية في كل حقول التطبيق
   ============================================================ */
(function enforceEnglishDigits(){
  const arabicDigits = /[\u0660-\u0669\u06f0-\u06f9]/;
  const digitMap = {'٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9',
                    '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9'};
  const convert = value => String(value == null ? '' : value).replace(/[\u0660-\u0669\u06f0-\u06f9]/g, ch => digitMap[ch] || ch);
  const editableSelector = 'input,textarea,[contenteditable="true"],[contenteditable=""]';

  function getControl(target){
    if(target && target.nodeType === 3) target = target.parentElement;
    return target && target.closest ? target.closest(editableSelector) : null;
  }
  function normalizeControl(el){
    if(!el) return;
    if(el.matches && el.matches('input,textarea')){
      const before = el.value;
      const after = convert(before);
      if(after === before) return;
      let start = null, end = null;
      try { start = el.selectionStart; end = el.selectionEnd; } catch(_) {}
      el.value = after;
      if(start != null && end != null) try { el.setSelectionRange(start, end); } catch(_) {}
      return;
    }
    if(el.isContentEditable){
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let node;
      while((node = walker.nextNode())) node.nodeValue = convert(node.nodeValue);
    }
  }
  function dispatchInput(el, text){
    let ev;
    try { ev = new InputEvent('input', {bubbles:true, inputType:'insertText', data:text}); }
    catch(_) { ev = new Event('input', {bubbles:true}); }
    el.dispatchEvent(ev);
  }
  function insertConvertedText(el, text, inputType){
    if(el.isContentEditable){
      const selection = window.getSelection();
      if(selection && selection.rangeCount && el.contains(selection.anchorNode)){
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const textNode = document.createTextNode(text);
        range.insertNode(textNode);
        range.setStartAfter(textNode); range.collapse(true);
        selection.removeAllRanges(); selection.addRange(range);
      } else el.appendChild(document.createTextNode(text));
    } else if(el.tagName === 'INPUT' && el.type === 'number'){
      const oldValue = convert(el.value || '');
      el.value = /^insertFrom(?:Paste|Drop)$/.test(inputType || '') ? text : oldValue + text;
    } else {
      try {
        const a = el.selectionStart == null ? el.value.length : el.selectionStart;
        const b = el.selectionEnd == null ? a : el.selectionEnd;
        el.setRangeText(text, a, b, 'end');
      } catch(_) { el.value = convert(el.value || '') + text; }
    }
    dispatchInput(el, text);
  }
  function onBeforeInput(event){
    const el = getControl(event.target);
    if(!el || el.disabled || el.readOnly || !event.cancelable) return;
    let incoming = event.data;
    if((incoming == null || incoming === '') && event.dataTransfer){
      try { incoming = event.dataTransfer.getData('text/plain'); } catch(_) {}
    }
    if(!incoming || !arabicDigits.test(incoming)) return;
    event.preventDefault();
    insertConvertedText(el, convert(incoming), event.inputType || '');
  }
  function onInput(event){ normalizeControl(getControl(event.target)); }
  function onPaste(event){
    const target = event.target;
    setTimeout(() => normalizeControl(getControl(target)), 0);
  }
  function scan(root){
    if(!root) return;
    if(root.nodeType === 1 && root.matches && root.matches(editableSelector)) normalizeControl(root);
    if(root.querySelectorAll) root.querySelectorAll(editableSelector).forEach(normalizeControl);
  }

  /* الالتقاط يسبق معالجات خلايا النماذج، لتصل القيمة الإنجليزية إلى منطق الحفظ والحساب. */
  document.addEventListener('beforeinput', onBeforeInput, true);
  document.addEventListener('input', onInput, true);
  document.addEventListener('change', onInput, true);
  document.addEventListener('compositionend', onInput, true);
  document.addEventListener('focusout', onInput, true);
  document.addEventListener('paste', onPaste, true);
  scan(document);
  if(document.body){
    const observer = new MutationObserver(mutations => mutations.forEach(m => m.addedNodes.forEach(scan)));
    observer.observe(document.body, {childList:true, subtree:true});
  }
})();

/* ============================================================
   تهيئة التطبيق
   ============================================================ */
applyThemeColors(data.settings.color||'#1e40af');
document.body.classList.toggle('dark',!!data.settings.dark);
applyFont(data.settings.font||'default');
applyFontWeight(data.settings.fontWeight||'medium');
if(data.settings.fontSize)setFontSize(data.settings.fontSize);
if(data.settings.dark)document.body.classList.add('dark');

document.addEventListener('visibilitychange',function(){
  if(!document.hidden){
    setTimeout(checkAppLock,500);
    setTimeout(()=>{
      const ss=document.getElementById('settingsSub');
      const subTitle=document.getElementById('subTitle');
      if(ss&&ss.classList.contains('on')&&subTitle&&subTitle.textContent==='الأذونات'){refreshPermissionsUI();}
    },700);
  }
});

startBackupScheduler();
setTimeout(checkAppLock,500);

renderCurrentView();

/* source script: person-modal-requested-logic */
function toggleLimitSwitch(){
  const sw=document.getElementById('limitSwitch');
  sw.classList.toggle('on');
  const enabled=sw.classList.contains('on');
  const row=document.getElementById('limitAmountRow');
  if(row)row.style.display=enabled?'flex':'none';
  if(enabled)setTimeout(()=>document.getElementById('pLimitAmount')?.focus(),50);
}
async function pickContactForAccount(){
  // Contacts Picker API works only in supported browsers/secure contexts.
  try{
    if(navigator.contacts && typeof navigator.contacts.select==='function'){
      const contacts=await navigator.contacts.select(['name','tel'],{multiple:false});
      const c=contacts&&contacts[0]; if(!c)return;
      const name=Array.isArray(c.name)?c.name[0]:c.name;
      const tel=Array.isArray(c.tel)?c.tel[0]:c.tel;
      if(name&&!document.getElementById('pName').value.trim())document.getElementById('pName').value=name;
      if(tel)document.getElementById('pPhone').value=tel;
      if(!tel)toast('جهة الاتصال لا تحتوي على رقم هاتف');
      return;
    }
    const bridgeCandidates=[
      ()=>window.SANative&&typeof SANative.pickContact==='function'?SANative.pickContact():null,
      ()=>window.AndroidBackup&&typeof AndroidBackup.pickContact==='function'?AndroidBackup.pickContact():null,
      ()=>window.Android&&typeof Android.pickContact==='function'?Android.pickContact():null
    ];
    for(const get of bridgeCandidates){
      const result=get();
      if(result&&typeof result.then==='function'){
        const c=await result;
        if(c){if(c.name&&!document.getElementById('pName').value.trim())document.getElementById('pName').value=c.name;if(c.phone||c.tel)document.getElementById('pPhone').value=c.phone||c.tel;return;}
      }else if(result&&typeof result==='object'){
        if(result.name&&!document.getElementById('pName').value.trim())document.getElementById('pName').value=result.name;
        if(result.phone||result.tel)document.getElementById('pPhone').value=result.phone||result.tel;
        return;
      }
    }
  }catch(e){console.warn('Contact picker unavailable',e);}
  toast('اختيار جهة الاتصال يحتاج دعم منتقي الأسماء في المتصفح أو Android');
}

/* source script: voucher-calculator-live-functionality */
(function(){
 let expression='', lastResult='';
 const modal=document.getElementById('voucherCalculatorModal');
 const display=document.getElementById('voucherCalculatorDisplay');
 if(!modal||!display)return;
 function show(){modal.classList.add('open');modal.setAttribute('aria-hidden','false');expression='';lastResult='';display.value='';}
 function hide(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');}
 function safeEvaluate(exp){
   exp=String(exp||'').replace(/×/g,'*').replace(/÷/g,'/');
   if(!exp.trim()||!/^[0-9+\-*/().%\s]+$/.test(exp))return null;
   exp=exp.replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');
   try{const n=Function('"use strict";return ('+exp+')')();return Number.isFinite(n)?n:null;}catch(e){return null;}
 }
 window.openVoucherCalculator=show;
 modal.addEventListener('click',function(e){
   if(e.target===modal){hide();return;}
   const b=e.target.closest('[data-vc]');if(!b)return;
   const key=b.dataset.vc;
   if(key==='CANCEL'){hide();return;}
   if(key==='C'){expression='';lastResult='';display.value='';return;}
   if(key==='DEL'){expression=expression.slice(0,-1);display.value=expression;return;}
   if(key==='='){
     const n=safeEvaluate(expression);
     if(n===null){display.value='خطأ في العملية';return;}
     lastResult=String(Number(n.toFixed(8)));expression=lastResult;display.value=lastResult;return;
   }
   if(key==='USE'){
     const n=safeEvaluate(expression);
     const value=n===null?(lastResult!==''?Number(lastResult):null):n;
     if(value===null||!Number.isFinite(value)||value<0){display.value='أدخل مبلغاً صحيحاً';return;}
     const amount=document.getElementById(window.__vcTarget||'opAmount');
     if(!amount){hide();return;}
     amount.value=String(Number(value.toFixed(8)));
     amount.dispatchEvent(new Event('input',{bubbles:true}));
     amount.dispatchEvent(new Event('change',{bubbles:true}));
     if(typeof window.updateVoucherBalance==='function')window.updateVoucherBalance();
     hide();return;
   }
   if(/^[0-9.]$/.test(key)||key==='00'||key==='000'||['+','-','*','/','%'].includes(key)){
     if(key==='.'&&/(\.\d*)$/.test(expression.split(/[+\-*/%]/).pop()))return;
     expression+=key;display.value=expression;
   }
 });
 document.addEventListener('keydown',function(e){
   if(!modal.classList.contains('open'))return;
   if(e.key==='Escape'){hide();e.preventDefault();}
   else if(/^[0-9.]$/.test(e.key)||['+','-','*','/','%'].includes(e.key)){expression+=e.key;display.value=expression;e.preventDefault();}
   else if(e.key==='Backspace'){expression=expression.slice(0,-1);display.value=expression;e.preventDefault();}
   else if(e.key==='Enter'){const n=safeEvaluate(expression);if(n!==null){lastResult=String(Number(n.toFixed(8)));expression=lastResult;display.value=lastResult;}e.preventDefault();}
 });
})();

/* source script: settings-sub-save-return-function */
function saveSettingsSubAndReturn(){
  const sub = document.getElementById('settingsSub');
  if (!sub || !sub.classList.contains('on')) return;
  const title = (document.getElementById('subTitle')?.textContent || '').trim();
  try {
    if (title === 'الملف الشخصي' && typeof saveProfileFull === 'function') {
      saveProfileFull();
    } else if (typeof save === 'function') {
      save();
    }
    closeSettingsPage();
    if (typeof toast === 'function') toast('تم الحفظ');
  } catch (err) {
    console.error('Settings save failed:', err);
    if (typeof toast === 'function') toast('تعذر الحفظ؛ تحقق من البيانات');
  }
}

/* source script: force-account-header-50-percent */
(function () {
  function applyHeaderReduction() {
    var header = document.querySelector('.statement-header');
    if (!header) return;
    var mobile = window.matchMedia('(max-width: 600px)').matches;
    var height = mobile ? '26.5px' : '46px';
    header.style.setProperty('height', height, 'important');
    header.style.setProperty('min-height', height, 'important');
    header.style.setProperty('max-height', height, 'important');
    header.style.setProperty('padding-top', '0', 'important');
    header.style.setProperty('padding-bottom', '0', 'important');
    header.style.setProperty('box-sizing', 'border-box', 'important');
    header.style.setProperty('overflow', 'hidden', 'important');
    header.style.setProperty('align-items', 'center', 'important');

    header.querySelectorAll('.sh-btn').forEach(function (button) {
      var buttonHeight = mobile ? '16px' : '28px';
      button.style.setProperty('height', buttonHeight, 'important');
      button.style.setProperty('min-height', buttonHeight, 'important');
      button.style.setProperty('max-height', buttonHeight, 'important');
      button.style.setProperty('padding-top', '0', 'important');
      button.style.setProperty('padding-bottom', '0', 'important');
      button.style.setProperty('box-sizing', 'border-box', 'important');
      if (mobile) button.style.setProperty('font-size', '10px', 'important');
    });
    var name = header.querySelector('.sh-name');
    if (name) {
      name.style.setProperty('line-height', '1', 'important');
      if (mobile) name.style.setProperty('font-size', '12px', 'important');
    }
  }

  function start() {
    applyHeaderReduction();
    var root = document.getElementById('detailBox') || document.body;
    if (root && !root.__headerReductionObserver) {
      var __hrT=0;var observer = new MutationObserver(function(){if(__hrT)return;__hrT=setTimeout(function(){__hrT=0;applyHeaderReduction();},120);});
      observer.observe(root, { childList: true, subtree: true });
      root.__headerReductionObserver = observer;
    }
    window.addEventListener('resize', applyHeaderReduction);
    /* التحديث الأساسي يتم عند تغيّر DOM أو حجم الشاشة؛ فحص احتياطي متباعد بدلاً من كل ثانيتين */
    if (!window.__headerReductionFallbackTimer) {
      window.__headerReductionFallbackTimer = setInterval(function(){
        if (!document.hidden) applyHeaderReduction();
      }, 10000);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();

/* source script: settings-swipe-close-after-save-return */
(function () {
  var sx = 0, sy = 0, startedInSettings = false, tracking = false;

  function settingsIsOpen() {
    var panel = document.getElementById('settings');
    return !!(panel &&
      document.body.classList.contains('settings-fullscreen') &&
      panel.classList.contains('on'));
  }

  function settingsHomeIsVisible() {
    var home = document.getElementById('settingsHome');
    return !!(home && home.classList.contains('on'));
  }

  function closeSettingsDrawer() {
    if (!settingsIsOpen() || !settingsHomeIsVisible()) return;
    if (typeof showHome === 'function') {
      showHome();
    } else {
      document.body.classList.remove('settings-fullscreen');
      document.querySelectorAll('.section').forEach(function (s) { s.classList.remove('on'); });
      var home = document.getElementById('home');
      if (home) home.classList.add('on');
    }
  }

  document.addEventListener('touchstart', function (e) {
    if (!e.touches || e.touches.length !== 1) { tracking = false; return; }
    var panel = document.getElementById('settings');
    startedInSettings = !!(panel && panel.contains(e.target) && settingsIsOpen());
    if (!startedInSettings) { tracking = false; return; }
    sx = e.touches[0].clientX;
    sy = e.touches[0].clientY;
    tracking = true;
  }, { passive: true, capture: true });

  document.addEventListener('touchend', function (e) {
    if (!tracking || !startedInSettings || !e.changedTouches || !e.changedTouches.length) return;
    tracking = false;
    var dx = e.changedTouches[0].clientX - sx;
    var dy = e.changedTouches[0].clientY - sy;
    /* بعد الرجوع إلى الصفحة الرئيسية للإعدادات (بما في ذلك حفظ والعودة)،
       يسمح بالسحب الأفقي إلى اليمين من أعلى/وسط/أسفل لإغلاق درج الإعدادات. */
    if (dx >= 55 && Math.abs(dx) > Math.abs(dy) * 1.15) {
      closeSettingsDrawer();
    }
  }, { passive: true, capture: true });

  /* احتياطًا للأجهزة التي تعتمد Pointer Events */
  document.addEventListener('pointerdown', function (e) {
    var panel = document.getElementById('settings');
    startedInSettings = !!(panel && panel.contains(e.target) && settingsIsOpen() && e.pointerType !== 'mouse');
    if (!startedInSettings) { tracking = false; return; }
    sx = e.clientX; sy = e.clientY; tracking = true;
  }, true);
  document.addEventListener('pointerup', function (e) {
    if (!tracking || !startedInSettings || e.pointerType === 'mouse') return;
    tracking = false;
    var dx = e.clientX - sx, dy = e.clientY - sy;
    if (dx >= 55 && Math.abs(dx) > Math.abs(dy) * 1.15) closeSettingsDrawer();
  }, true);
})();

/* source script: folder-invoice-integration-script */
let _folderInvoiceEditId=null;
let _folderInvoiceTargetId=null;
let _invoiceLongPressTimer=null;
let _invoiceLongPressTriggered=false;
let _longPressedInvoice=null;
function cancelInvoiceLongPress(){if(_invoiceLongPressTimer){clearTimeout(_invoiceLongPressTimer);_invoiceLongPressTimer=null;}}
function startInvoiceLongPress(event,invoiceId,folderId){
  cancelInvoiceLongPress();
  _invoiceLongPressTriggered=false;
  if(data.settings.invoiceSettings?.longPressActions===false)return;
  if(event.pointerType==='mouse'&&event.button!==0)return;
  _invoiceLongPressTimer=setTimeout(()=>{
    _invoiceLongPressTimer=null;_invoiceLongPressTriggered=true;
    _longPressedInvoice={invoiceId,folderId};
    if(navigator.vibrate)try{navigator.vibrate(35);}catch(e){}
    const menu=document.getElementById('invoiceLongPressMenu');if(menu)menu.style.display='flex';
  },550);
}
function handleInvoiceCardClick(event,invoiceId,folderId){
  cancelInvoiceLongPress();
  if(_invoiceLongPressTriggered){event.preventDefault();event.stopPropagation();_invoiceLongPressTriggered=false;return;}
  const menu=document.getElementById('invoiceLongPressMenu');
  if(menu&&data.settings.invoiceSettings?.longPressActions!==false){_longPressedInvoice={invoiceId,folderId};menu.style.display='flex';return;}
  openFolderInvoice(invoiceId,folderId);
}
function closeInvoiceLongPressMenu(){const menu=document.getElementById('invoiceLongPressMenu');if(menu)menu.style.display='none';_longPressedInvoice=null;}
function editLongPressedInvoice(){const x=_longPressedInvoice;if(!x)return;closeInvoiceLongPressMenu();openFolderInvoice(x.invoiceId,x.folderId);}
function getLongPressedInvoice(){
  const x=_longPressedInvoice;if(!x)return null;
  const folder=data.folders.find(f=>String(f.id)===String(x.folderId));
  const inv=folder&&(folder.invoices||[]).find(v=>String(v.id)===String(x.invoiceId));
  return folder&&inv?{folder,inv}:null;
}
function invoicePreviewHTML(inv){
  if(inv&&inv.invoiceKind==='buyer')return buyerInvoicePreviewHTML(inv);
  return _homeInvoicePreviewHTML(inv);
}
/* عرض فاتورة الشراء اليومية (الشرائي) بنفس تنسيق عرض الفواتير */
function buyerInvoicePreviewHTML(inv){
  const e=v=>esc(v==null?'':String(v));
  const n=v=>{const x=Number(String(v==null?'':v).replace(/,/g,''));return Number.isFinite(x)?x:0};
  const fm=v=>n(v).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  const rows=Array.isArray(inv.buyerRows)?inv.buyerRows:[];
  const rowTotal=r=>(r.total!=null&&r.total!=='')?n(r.total):n(r.qty)*n(r.price);
  const total=inv.buyerTotal!=null?n(inv.buyerTotal):rows.reduce((a,r)=>a+rowTotal(r),0);
  const expense=n(inv.buyerExpense);
  const net=inv.buyerNet!=null?n(inv.buyerNet):total-expense;
  const th=x=>'<th>'+e(x)+'</th>',td=x=>'<td>'+e(x)+'</td>';
  const body=rows.length?rows.map(r=>'<tr>'+td(r.name)+td(r.qty)+td(fm(r.price))+td(fm(rowTotal(r)))+'</tr>').join(''):'<tr><td colspan="4">—</td></tr>';
  const kv=(a,b,cls)=>'<tr'+(cls?' class="'+cls+'"':'')+'><th>'+e(a)+'</th><td>'+e(b)+'</td></tr>';
  let html='<article class="daily-print" dir="rtl"><h2>فاتورة الشراء اليومية</h2>'
    +'<table class="daily-table"><thead><tr>'+th('رقم الجدول')+th('الاسم')+th('التاريخ')+'</tr></thead><tbody><tr>'+td(inv.initNo)+td(inv.initSeller)+td(inv.initDate)+'</tr></tbody></table>'
    +'<table class="daily-table"><thead><tr>'+th('اسم الشروة')+th('العدد')+th('مبلغ الشراء')+th('إجمالي شراء الشروة')+'</tr></thead><tbody>'+body+'</tbody></table>'
    +'<section class="daily-section"><h3>التفصيل النهائي</h3><table class="daily-table"><tbody>'
    +kv('إجمالي شراء الشروات',fm(total))+kv('إجمالي الخرج اليومي',fm(expense))+kv('الصافي',fm(net),'total-row')
    +'</tbody></table></section></article>';
  const st=(_homeInvoicePreviewHTML({}).match(/<style>[\s\S]*<\/style>/)||[''])[0];
  return html+st;
}
function _homeInvoicePreviewHTML(inv){
  const f=inv.formData||{};
  const e=v=>esc(v==null?'':String(v));
  const n=v=>{const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:0};
  const fmt=v=>n(v).toLocaleString('en-US');
  const cell=(v,th=false)=>'<'+(th?'th':'td')+'>'+e(v||'')+'</'+(th?'th':'td')+'>';
  const table=(headers,body,cls='')=>'<table class="daily-table '+cls+'"><thead><tr>'+headers.map(x=>cell(x,true)).join('')+'</tr></thead><tbody>'+body+'</tbody></table>';
  const sales=Array.isArray(f.salesRows)?f.salesRows:[];
  const received=Array.isArray(f.receivedRows)?f.receivedRows:[];
  const out=Array.isArray(f.outRows)?f.outRows:[];
  const withdraw=Array.isArray(f.withdrawRows)?f.withdrawRows:[];
  const currencies=Array.isArray(f.currencyRows)?f.currencyRows:[];
  const saleCount=Math.max(1,Math.min(3,Number(f.saleColCount)||1));
  let sh=[];for(let c=1;c<=saleCount;c++)sh.push('الرقم','المبلغ');sh.push('اسم الدين','الكمية','المبلغ','اسم الخارج','الكمية','المبلغ');
  let sb=sales.map(r=>{let cells='';for(let c=1;c<=saleCount;c++)cells+=cell(r['s'+c+'n'])+cell(r['s'+c+'m']);cells+=cell(r.dname)+cell(r.dn)+cell(r.dm)+cell(r.oname)+cell(r.on)+cell(r.om);return '<tr>'+cells+'</tr>';}).join('');
  if(!sb)sb='<tr><td colspan="'+sh.length+'">—</td></tr>';
  const moneyTable=(title,arr)=>'<section class="daily-section"><h3>'+title+'</h3>'+table(['الاسم','المبلغ'],(arr.length?arr.map(r=>'<tr>'+cell(r.name||r.seller||r.person)+cell(r.amount||r.money||r.m)+'</tr>').join(''):'<tr><td colspan="2">—</td></tr>')+'<tr class="total-row">'+cell('الجملة',true)+cell(fmt(arr.reduce((a,r)=>a+n(r.amount||r.money||r.m),0)),true)+'</tr>')+'</section>';
  const _cashQty=sales.reduce((a,r)=>a+n(r.s1n)+n(r.s2n)+n(r.s3n),0),_debtQty=sales.reduce((a,r)=>a+n(r.dn),0),_outQty=sales.reduce((a,r)=>a+n(r.on),0);const qtyRows=[['الكمية',f.qty||0],['النقد',_cashQty],['القات الدين',_debtQty],['القات خرج',_outQty],['الباقي',n(f.qty)-_cashQty-_debtQty-_outQty]];
  const saleCashTotal=sales.reduce((a,r)=>a+n(r.s1m)+n(r.s2m)+n(r.s3m),0);
  const receivedMoneyTotal=received.reduce((a,r)=>a+n(r.amount||r.money||r.m),0);
  const outMoneyTotal=out.reduce((a,r)=>a+n(r.amount||r.money||r.m),0);
  const withdrawMoneyTotal=withdraw.reduce((a,r)=>a+n(r.amount||r.money||r.m),0);
  /* المعادلة المعتمدة: نقد الباقي = البيع نقد - فلوس خرج؛ الباقي نقد = نقد الباقي + مسلم فلوس - السحب فلوس */
  const cashAfterOut=saleCashTotal-outMoneyTotal;
  const weeklyMoneyTotal=(Array.isArray(f.weeklyRows)?f.weeklyRows:[]).reduce((a,r)=>a+n(r.amount),0);const cashRemaining=cashAfterOut+weeklyMoneyTotal+receivedMoneyTotal-withdrawMoneyTotal;
  const saleRows=[['البيع نقد',saleCashTotal],['− فلوس خرج',outMoneyTotal],['= نقد الباقي',cashAfterOut],['+ مسلم أسبوع',weeklyMoneyTotal],['+ مسلم فلوس',receivedMoneyTotal],['− السحب فلوس',withdrawMoneyTotal],['= الباقي نقد',cashRemaining]];
  const summary=(title,arr)=>'<section class="daily-section"><h3>'+title+'</h3>'+table(['القيمة','البيان'],arr.map(r=>'<tr>'+cell(r[1])+cell(r[0],true)+'</tr>').join(''))+'</section>';
  let html='<article class="daily-print" dir="rtl"><h2>الكارت اليومي</h2>'+table(['مكان البيع','اسم البيع','رقم الجدول','اليوم والتاريخ'],'<tr>'+cell(inv.initPlace)+cell(inv.initSeller)+cell(inv.initNo)+cell(inv.initDate)+'</tr>')+table(['تفاصيل عمود البيع والقات دين والقات خرج'], '<tr><td>'+table(sh,sb)+'</td></tr>')+'<div class="daily-three">'+moneyTable('💰 المسلمه فلوس',received)+moneyTable('↘️ الخرج فلوس',out)+moneyTable('🏦 فلوس سحب',withdraw)+'</div><div class="daily-two">'+summary('عمود الكمية',qtyRows)+summary('عمود البيع',saleRows)+'</div>';
  html+= '<section class="daily-section currency-section"><h3>العملات</h3>'+table(['العملة','مبلغ العملة','سعر الصرف','الناتج'],(currencies.length?currencies.map(r=>'<tr>'+cell(r.currency||r.name)+cell(r.amount||r.money)+cell(r.rate)+cell(r.result||n(r.amount||r.money)*n(r.rate))+'</tr>').join(''):'<tr><td colspan="4">—</td></tr>')+'<tr class="total-row"><td colspan="3">جملة الصرف</td>'+cell(fmt(currencies.reduce((a,r)=>a+n(r.result||n(r.amount||r.money)*n(r.rate)),0)),true)+'</tr>')+'</section>';
  html+='<section class="daily-section note-section"><h3>📝 التنويه</h3><div class="note-body">'+e(inv.note||'')+'</div></section>';
  if(inv.sellerPhoto)html+='<section class="daily-section"><h3>صورة البياع</h3><img src="'+inv.sellerPhoto+'" style="max-width:100%;max-height:250px;object-fit:contain"></section>';
  html+='</article><style>.daily-print{font-family:Arial,Tahoma,sans-serif;color:#242235;background:#fff;border:3px solid #4A1520;border-radius:16px;padding:12px;max-width:100%;line-height:1.35}.daily-print h2{text-align:center;color:#4A1520;font-size:22px;font-weight:900;margin:2px 0 14px}.daily-table{width:100%;border-collapse:collapse;table-layout:fixed;margin:8px 0 12px}.daily-table th,.daily-table td{border:1px solid #e7d8dd;padding:5px 3px;text-align:center;font-size:11px;overflow-wrap:anywhere}.daily-table th{background:#64182c;color:#fff;font-weight:900}.daily-section{border:1px solid #e7d8dd;border-radius:12px;overflow:hidden;margin:10px 0}.daily-section h3{margin:0;padding:10px;background:#f5f0f1;color:#4A1520;font-size:14px;font-weight:900}.daily-section .daily-table{margin:0}.daily-section .daily-table th{background:#f5f0f1;color:#242235}.daily-three{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.daily-two{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.total-row td,.total-row th{font-weight:900;background:#f8e8ed}.daily-two .daily-section:last-child .daily-table tbody tr:nth-child(3){background:#eef6ff;font-weight:900}.daily-two .daily-section:last-child .daily-table tbody tr:last-child{background:#fff3cd;font-weight:900;border-top:2px solid #d9a441}.note-body{min-height:35px;padding:8px;white-space:pre-wrap}.currency-section .total-row td{background:#64182c;color:#fff}@media(max-width:520px){.daily-print{padding:7px;border-radius:10px}.daily-print h2{font-size:18px}.daily-table th,.daily-table td{font-size:9px;padding:4px 2px}.daily-section h3{font-size:12px;padding:8px}.daily-three{gap:4px}.daily-two{gap:5px}}@media print{body{margin:0!important;padding:0!important;background:#fff!important}.daily-print{max-width:none!important;border:2px solid #4A1520!important;border-radius:0!important;padding:5mm!important;box-shadow:none!important;break-inside:avoid}.daily-print h2{font-size:18pt!important}.daily-table{break-inside:avoid}.daily-table th,.daily-table td{font-size:9pt!important;padding:4pt 3pt!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.daily-table th{background:#64182c!important;color:#fff!important}.daily-section{break-inside:avoid;margin:7pt 0}.daily-section h3{background:#f5f0f1!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}@page{size:A4 portrait;margin:8mm}}</style>';
  return html;
}
function viewLongPressedInvoice(){const x=getLongPressedInvoice();if(!x){closeInvoiceLongPressMenu();toast('الفاتورة غير موجودة');return;}closeInvoiceLongPressMenu();document.getElementById('invoicePreviewContent').innerHTML=invoicePreviewHTML(x.inv);document.getElementById('invoicePreviewModal').style.display='block';window._previewInvoiceRef={folderId:x.folder.id,invoiceId:x.inv.id};}
function closeInvoicePreview(){const m=document.getElementById('invoicePreviewModal');if(m)m.style.display='none';}
function printInvoicePreview(){const c=document.getElementById('invoicePreviewContent');if(!c)return;const w=window.open('','_blank');if(!w){toast('اسمح بفتح نافذة الطباعة');return;}w.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>طباعة فاتورة</title><style>body{font-family:Arial,Tahoma,sans-serif;padding:0;color:#111;direction:rtl}.daily-print{font-family:Arial,Tahoma,sans-serif;color:#242235;background:#fff;border:2px solid #4A1520;padding:5mm;line-height:1.35}.daily-print h2{text-align:center;color:#4A1520;font-size:18pt;margin:2px 0 12px}.daily-table{width:100%;border-collapse:collapse;table-layout:fixed;margin:7px 0 10px}.daily-table th,.daily-table td{border:1px solid #e7d8dd;padding:4pt 3pt;text-align:center;font-size:9pt;overflow-wrap:anywhere}.daily-table th{background:#64182c;color:#fff;font-weight:900;-webkit-print-color-adjust:exact;print-color-adjust:exact}.daily-section{border:1px solid #e7d8dd;border-radius:8px;overflow:hidden;margin:7pt 0;break-inside:avoid}.daily-section h3{margin:0;padding:7pt;background:#f5f0f1;color:#4A1520;font-size:11pt;-webkit-print-color-adjust:exact;print-color-adjust:exact}.daily-three{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.daily-two{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.total-row td,.total-row th{font-weight:900;background:#f8e8ed;-webkit-print-color-adjust:exact;print-color-adjust:exact}.note-body{min-height:25px;padding:6px;white-space:pre-wrap}@page{size:A4 portrait;margin:8mm}</style></head><body>'+c.innerHTML+'</body></html>');w.document.close();w.focus();setTimeout(()=>{w.print();},300);}
function saveInvoicePreview(){const c=document.getElementById('invoicePreviewContent');if(!c)return;const blob=new Blob(['<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>نسخة فاتورة</title><body>'+c.innerHTML+'</body></html>'],{type:'text/html;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='فاتورة-'+Date.now()+'.html';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function shareLongPressedInvoice(){const x=getLongPressedInvoice();if(!x){closeInvoiceLongPressMenu();return;}closeInvoiceLongPressMenu();const i=x.inv;const text=i.invoiceKind==='buyer'?('فاتورة الشراء اليومية\nالتاريخ: '+(i.initDate||'')+'\nرقم الجدول: '+(i.initNo||'')+'\nالاسم: '+(i.initSeller||'')+'\nإجمالي الشراء: '+(Number(i.buyerTotal)||0).toLocaleString('en-US')+'\nالخرج اليومي: '+(Number(i.buyerExpense)||0).toLocaleString('en-US')):('فاتورة\nالتاريخ: '+(i.initDate||'')+'\nرقم الجدول: '+(i.initNo||'')+'\nالبياع: '+(i.initSeller||'')+'\nمكان البيع: '+(i.initPlace||'')+'\nالتنويه: '+(i.note||''));try{if(navigator.share)await navigator.share({title:'فاتورة '+(i.initNo||''),text});else if(navigator.clipboard){await navigator.clipboard.writeText(text);toast('تم نسخ بيانات الفاتورة للمشاركة');}else{const b=new Blob([text],{type:'text/plain;charset=utf-8'});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download='بيانات-فاتورة.txt';a.click();URL.revokeObjectURL(u);}}catch(e){}}
function viewLongPressedPhoto(){const x=getLongPressedInvoice();if(!x){closeInvoiceLongPressMenu();return;}closeInvoiceLongPressMenu();if(!x.inv.sellerPhoto){toast('لا توجد صورة محفوظة لهذه الفاتورة');return;}const m=document.getElementById('invoicePreviewModal');document.getElementById('invoicePreviewContent').innerHTML='<div style="text-align:center;direction:rtl"><h3 style="margin-bottom:12px">📷 صورة البياع - '+esc(x.inv.initSeller||'')+'</h3><img src="'+x.inv.sellerPhoto+'" style="max-width:100%;max-height:75vh;object-fit:contain"></div>';m.style.display='block';}
function printLongPressedInvoice(){viewLongPressedInvoice();setTimeout(()=>{if(document.getElementById('invoicePreviewModal').style.display==='block')printInvoicePreview();},150);}
function saveLongPressedInvoice(){viewLongPressedInvoice();setTimeout(()=>{if(document.getElementById('invoicePreviewModal').style.display==='block')saveInvoicePreview();},100);}
function deleteLongPressedInvoice(){const x=_longPressedInvoice;if(!x)return;const folder=data.folders.find(f=>f.id===x.folderId);const inv=folder&&(folder.invoices||[]).find(v=>v.id===x.invoiceId);if(!folder||!inv){closeInvoiceLongPressMenu();toast('الفاتورة غير موجودة');return;}customConfirm('هل تريد حذف الفاتورة «'+(inv.initSeller||'بدون اسم')+'»؟',()=>{folder.invoices=folder.invoices||[];folder.invoices=folder.invoices.filter(v=>v.id!==x.invoiceId);save();rebuildWeekFilterFromFolder(folder);closeInvoiceLongPressMenu();if(currentFolderId===folder.id)renderCurrentView();if(window.__queueAutoSync)window.__queueAutoSync(folder.id);toast('تم حذف الفاتورة');},()=>closeInvoiceLongPressMenu(),{title:'حذف فاتورة',icon:'🧾',danger:true,confirmText:'حذف',cancelText:'إلغاء'});}
function setInvoiceSetting(key,button){data.settings.invoiceSettings=data.settings.invoiceSettings||{showInFolders:true,longPressActions:true};data.settings.invoiceSettings[key]=! (data.settings.invoiceSettings[key]!==false);save();openSettingsPage('invoices',true);if(key==='showInFolders'&&currentFolderId!==null)renderCurrentView();toast('تم حفظ إعدادات الفواتير');}
function openInvoiceFromSettings(){
  if(currentFolderId!==null){openFolderInvoice(null,currentFolderId);return;}
  const folders=(data.folders||[]).filter(f=>!f.locked&&window.__inScope(f));
  if(!folders.length){toast('أنشئ مجلداً أولاً لحفظ الفاتورة بداخله');return;}
  const modal=document.getElementById('invoiceFolderChooser');
  const box=document.getElementById('invoiceFolderChooserContent');
  box.innerHTML='<div style="font-weight:900;font-size:15px;margin-bottom:12px">اختر المجلد لحفظ الفاتورة</div>'+folders.map(f=>'<button type="button" class="btn secondary" style="width:100%;margin-bottom:7px;padding:10px" onclick="document.getElementById(\'invoiceFolderChooser\').style.display=\'none\';openFolderInvoice(null,\''+String(f.id).replace(/['\\]/g,'')+'\')">📁 '+esc(f.name||'مجلد')+'</button>').join('')+'<button type="button" class="btn secondary" style="width:100%;padding:9px" onclick="document.getElementById(\'invoiceFolderChooser\').style.display=\'none\'">إلغاء</button>';
  modal.style.display='flex';
}
var _folderInvoiceInst=null;
function openFolderInvoice(invoiceId=null, explicitFolderId=null){
  const folderId=explicitFolderId||currentFolderId;
  const folder=data.folders.find(f=>f.id===folderId);
  if(!folder){toast('افتح المجلد أولاً لإضافة فاتورة');return;}
  if(folder.locked){toast('المجلد مقفل');return;}
  _folderInvoiceTargetId=folderId;
  _folderInvoiceEditId=invoiceId;
  const modal=document.getElementById('folderInvoiceModal');
  const openKey=String(folderId||'')+'|'+String(invoiceId==null?'':invoiceId);
  if(modal.classList.contains('show')&&modal.dataset.openKey===openKey)return;
  modal.dataset.openKey=openKey;
  const host=document.getElementById('folderInvoiceFrame');
  const inv=invoiceId?(folder.invoices||[]).find(x=>x.id===invoiceId):null;
  document.getElementById('folderInvoiceHostTitle').textContent=inv?'تعديل الفاتورة':'إضافة فاتورة جديدة';
  /* النموذج جزء أصلي من الصفحة: يُبنى مباشرة داخل الحاوية بدون إطار ولا تحميل ولا إعادة تنسيق */
  if(_folderInvoiceInst){_folderInvoiceInst.destroy();_folderInvoiceInst=null;}
  host.innerHTML='';
  const inst=window.NativeForms.mount(folder.scope==='buyer'?'buyer':'seller',host,_onInvoiceFormMessage);
  _folderInvoiceInst=inst;
  modal.classList.add('show');
  host.scrollTop=0;
  inst.post({type:'PRINT_SETTINGS',settings:{paper:data.settings.paper||'a4',printColorMode:data.settings.printColorMode||'color',printColor:data.settings.printColor||'#6B1A2F'}});
  inst.post({type:'WEEKLY_FILTERS',filters:getSavedWeeklyFilters()});
  // Pass the currently opened week identity so the invoice preselects its weekly filter and fills seller/table.
  inst.post({type:'INVOICE_WEEK_CONTEXT',context:{
    folderId:String(folder.id||''),
    weekName:String(folder.name||''),
    filterId:String((getSavedWeeklyFilters().find(x=>String(x.sourceFolderId||'')===String(folder.id))||{}).id||folder.id||''),
    seller:String(folder.name||''),
    tableNo:folder.order!==undefined&&folder.order!==null?String(folder.order):'',
    startDate:String(folder.startDate||''),
    endDate:String(folder.endDate||''),
    takenDates:(folder.invoices||[]).filter(x=>!invoiceId||String(x.id)!==String(invoiceId)).map(x=>String(x.initDateISO||x.invoiceDateISO||'')).filter(Boolean)
  }});
  if(inv){inst.post({type:'LOAD_INVOICE',payload:inv});}
}
function closeFolderInvoice(){
  (function(m){m.classList.remove('show','loading');delete m.dataset.openKey;})(document.getElementById('folderInvoiceModal'));
  _folderInvoiceEditId=null;_folderInvoiceTargetId=null;
  if(_folderInvoiceInst){_folderInvoiceInst.destroy();_folderInvoiceInst=null;}
  const host=document.getElementById('folderInvoiceFrame');if(host)host.innerHTML='';
}
function getSavedWeeklyFilters(){try{const value=JSON.parse(safeStorageGet('smartadmin_weekly_filters_v1','[]'));return Array.isArray(value)?value.filter(x=>x&&x.name):[];}catch(e){console.error('تعذر قراءة الفلاتر الأسبوعية',e);return [];}}
function saveWeeklyFilterFromEntry(filter){
  if(!filter||!String(filter.name||'').trim())return;
  const list=getSavedWeeklyFilters(); const name=String(filter.name).trim();
  const existing=list.findIndex(x=>String(x.name).trim()===name);
  const prior=existing>=0?list[existing]:{};
  const item=Object.assign({},prior,filter,{id:String(filter.id||prior.id||Date.now()),name,fromDate:filter.fromDate||prior.fromDate||'',toDate:filter.toDate||prior.toDate||'',updatedAt:Date.now()});
  if(existing>=0)list[existing]=item;else list.unshift(item);
  if(!safeStorageSet('smartadmin_weekly_filters_v1',JSON.stringify(list))&&typeof toast==='function')toast('تعذر حفظ الفلتر؛ مساحة التخزين قد تكون ممتلئة');
}
function _onWeeklyFormMessage(msg){
  if(!msg)return;
  if(msg.type==='WEEKLY_FILTER_DRAFT'){saveWeeklyFilterFromEntry(msg.filter);return;}
  if(msg.type==='WEEKLY_FILTER_SAVE'){saveWeeklyFilterFromEntry(msg.filter);if(typeof closeWeeklyFilterEntry==='function')closeWeeklyFilterEntry();if(typeof renderWeeklyFilterAccounts==='function')renderWeeklyFilterAccounts();return;}
}
/* إعادة بناء صفوف الفلتر الأسبوعي من كل فواتير المجلد (تُستخدم عند الحذف والتعديل) */
function rebuildWeekFilterFromFolder(folder){
  if(!folder||folder.scope==='buyer')return;
  var filters=getSavedWeeklyFilters();
  var f=filters.find(x=>String(x.sourceFolderId||'')===String(folder.id));
  if(!f)return;
  ['qtyRows','salesRows','moneyRows'].forEach(k=>{
    f[k]=(Array.isArray(f[k])?f[k]:[]).map(r=>({date:r&&r.date||'',day:r&&r.day||''}));
  });
  f.updatedAt=Date.now();
  safeStorageSet('smartadmin_weekly_filters_v1',JSON.stringify(filters));
  (folder.invoices||[]).forEach(inv=>applyInvoiceToWeeklyFilter(Object.assign({},inv,{folderId:folder.id})));
}
window.__afterFolderInvoicesChanged=function(folderId){
  var folder=(data.folders||[]).find(f=>String(f.id)===String(folderId));
  if(!folder||folder.scope==='buyer')return;
  rebuildWeekFilterFromFolder(folder);
  if(window.__queueAutoSync)window.__queueAutoSync(folder.id);
};
function applyInvoiceToWeeklyFilter(payload){
  if(!payload)return;
  const folderId=String(payload.folderId||_folderInvoiceTargetId||'');
  const targetFolder=Array.isArray(data.folders)?data.folders.find(x=>String(x.id)===folderId):null; if(targetFolder&&targetFolder.scope==='buyer')return; const filters=getSavedWeeklyFilters();
  let f=filters.find(x=>String(x.sourceFolderId||'')===folderId)||null;
  if(!f&&targetFolder)f=filters.find(x=>String(x.id)===String(targetFolder.id))||null;
  const cands=[payload.initWeeklyFilter,payload.initPlace,payload.weekName,targetFolder?.name].map(x=>String(x||'').trim()).filter(Boolean);
  if(!f)for(const n of cands){f=filters.find(x=>String(x.name||'').trim()===n)||null;if(f)break;}
  if(!f){if(typeof toast==='function')toast('الفاتورة لم تُربط بالفلتر الأسبوعي: لم يُعثر على فلتر بهذا الاسم');return;}
  const fd=payload.formData||{}; const dateRaw=String(payload.initDateISO||payload.invoiceDateISO||'');
  let date=dateRaw;
  if(!date){const m=String(payload.initDate||'').match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);if(m)date=m[1]+'-'+String(m[2]).padStart(2,'0')+'-'+String(m[3]).padStart(2,'0');}
  if(!date){if(typeof toast==='function')toast('الفاتورة لم تُربط بالفلتر: تاريخ الفاتورة غير صالح');return;}
  if((f.fromDate&&date<f.fromDate)||(f.toDate&&date>f.toDate)){if(typeof toast==='function')toast('تاريخ الفاتورة خارج فترة الفلتر الأسبوعي المحددة');return;}
  const dayNames=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const dateObj=new Date(date+'T12:00:00');if(isNaN(dateObj.getTime()))return;
  const day=dayNames[dateObj.getDay()];
  ['qtyRows','salesRows','moneyRows'].forEach(k=>{if(!Array.isArray(f[k]))f[k]=[];});
  function slot(rows){let i=rows.findIndex(r=>r.date===date);if(i<0)i=rows.findIndex(r=>!r.date&&String(r.day||'').replace(/\s+/g,'')===day.replace(/\s+/g,''));if(i<0&&rows.length<8){i=rows.length;rows.push({day,date});}if(i<0)return -1;rows[i].day=day;rows[i].date=date;return i;}
  const qI=slot(f.qtyRows), sI=slot(f.salesRows), mI=slot(f.moneyRows);
  const num=v=>{const n=parseFloat(String(v||'').replace(/,/g,''));return Number.isFinite(n)?n:0;};
  const sales=Array.isArray(fd.salesRows)?fd.salesRows:[];let cash=0,debt=0,expense=0,sale=0;
  const cols=Math.max(1,Math.min(3,Number(fd.saleColCount)||1));
  sales.forEach(r=>{for(let c=1;c<=cols;c++){cash+=num(r['s'+c+'n']);sale+=num(r['s'+c+'m']);}debt+=num(r.dn);expense+=num(r.on);});
  const sum=a=>(Array.isArray(a)?a:[]).reduce((t,r)=>t+num(r.amount),0);
  const received=sum(fd.receivedRows), out=sum(fd.outRows), withdrawn=sum(fd.withdrawRows), weeklySales=sum(fd.weeklyRows);
  const qty=num(fd.qty);
  if(qI>=0)Object.assign(f.qtyRows[qI],{qty:String(qty),cash:String(cash),debt:String(debt),expense:String(expense)});
  if(sI>=0)Object.assign(f.salesRows[sI],{cash:String(sale-out),saleGross:String(sale),outAmt:String(out),weeklyAmt:String(received),weeklySalesAmt:String(weeklySales),prevAmt:String(withdrawn)});
  const currencies=Array.isArray(fd.currencyRows)?fd.currencyRows:[];
  const curTotal=cur=>currencies.filter(r=>String(r.cur||'').toLowerCase().includes(cur)).reduce((t,r)=>t+num(r.amt),0);
  const exchangeTotal=cur=>currencies.filter(r=>String(r.cur||'').toLowerCase().includes(cur)).reduce((t,r)=>t+num(r.amt)*num(r.rate||1),0);
  if(mI>=0){Object.assign(f.moneyRows[mI],{yemeni:String(exchangeTotal('يمني')||exchangeTotal('yemeni')),saudiAmt:String(curTotal('سعود')||curTotal('saudi')),saudiExch:String(exchangeTotal('سعود')||exchangeTotal('saudi')),omaniAmt:String(curTotal('عمان')||curTotal('omani')),omaniExch:String(exchangeTotal('عمان')||exchangeTotal('omani')),dirhamAmt:String(curTotal('درهم')||curTotal('dirham')),dirhamExch:String(exchangeTotal('درهم')||exchangeTotal('dirham'))});}
  f.updatedAt=Date.now();if(!safeStorageSet('smartadmin_weekly_filters_v1',JSON.stringify(filters))&&typeof toast==='function')toast('تعذر حفظ بيانات الفاتورة داخل الفلتر الأسبوعي');
}
function _onInvoiceFormMessage(msg){
  if(msg&&msg.type==='INVOICE_CANCEL'){closeFolderInvoice();return;}
  if(!msg||msg.type!=='INVOICE_SAVE')return;
  const event={data:msg};
  const folder=data.folders.find(f=>f.id===_folderInvoiceTargetId);
  if(!folder){toast('تعذر تحديد المجلد لحفظ الفاتورة');return;}
  const payload=event.data.payload||{};
  if(!payload.initDate||!payload.initSeller){toast('أدخل التاريخ واسم البياع قبل الحفظ');return;}
  var payDate=String(payload.initDateISO||payload.invoiceDateISO||'');
  if(payDate&&(folder.invoices||[]).some(x=>x&&String(x.id)!==String(_folderInvoiceEditId)&&String(x.initDateISO||x.invoiceDateISO||'')===payDate)){toast('يوجد فاتورة أخرى بنفس التاريخ داخل هذا الأسبوع');return;}
  if(payDate&&((folder.startDate&&payDate<folder.startDate)||(folder.endDate&&payDate>folder.endDate))){toast('التاريخ خارج فترة هذا الأسبوع');return;}
  if(folder.scope!=='buyer')applyInvoiceToWeeklyFilter(payload);
  if(!Array.isArray(folder.invoices))folder.invoices=[];
  const now=Date.now();
  try{
    if(_folderInvoiceEditId){
      const existing=folder.invoices.find(x=>x.id===_folderInvoiceEditId);
      if(!existing){toast('الفاتورة غير موجودة');return;}
      Object.assign(existing,payload,{id:existing.id,folderId:folder.id,createdAt:existing.createdAt||now,updatedAt:now});
    }else{
      folder.invoices.push(Object.assign({},payload,{id:'invoice-'+now+'-'+Math.random().toString(36).slice(2,8),folderId:folder.id,createdAt:now,updatedAt:now}));
    }
    save();
    if(folder.scope!=='buyer')rebuildWeekFilterFromFolder(folder);
    const savedFolderId=folder.id;
    const wasEditing=!!_folderInvoiceEditId;
    closeFolderInvoice();
    if(currentFolderId===savedFolderId)renderCurrentView();
    if(window.bpRefresh)window.bpRefresh();
    if(window.__queueAutoSync&&folder.scope!=='buyer')window.__queueAutoSync(savedFolderId);
    toast(wasEditing?'تم تحديث الفاتورة داخل المجلد':'تم حفظ الفاتورة داخل المجلد');
  }catch(err){
    toast('تعذر حفظ الفاتورة؛ قد تكون مساحة التخزين ممتلئة');
    console.error(err);
  }
}
document.getElementById('folderInvoiceModal').addEventListener('click',function(e){if(e.target===this)closeFolderInvoice();});

/* source script: full-weekly-detail-page-logic */
(function(){
  let ffMode='detail',ffSort='asc';
  const pad=n=>String(n).padStart(2,'0');
  const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  window.renderWeeklyFilterAccounts=function(){
    const host=document.querySelector('#fullFilterPage .ff-empty');if(!host)return;
    let list=(typeof getSavedWeeklyFilters==='function')?getSavedWeeklyFilters():[];
    if(window.__ffCmpFilter)list=list.slice().sort(window.__ffCmpFilter);
    if(!list.length){host.innerHTML='';return;}
    host.innerHTML='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;padding:12px 4px 90px">'+list.map(f=>{
      const esc=v=>String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      return '<button type="button" data-wf-id="'+esc(f.id)+'" onclick="openWeeklyFilterEntry(&quot;'+esc(f.id)+'&quot;)" style="text-align:right;border:1px solid #dce6f2;border-radius:16px;background:#fff;padding:16px;box-shadow:0 3px 12px #0f23300f;color:#10243c;font:inherit"><b style="display:block;font-size:17px;margin-bottom:6px">📁 '+esc(f.name)+'</b><span style="font-size:12px;color:#718096">من '+esc(f.fromDate||'—')+' إلى '+esc(f.toDate||'—')+'</span></button>';
    }).join('')+'</div>';
  };
  window.openFullFilterPage=function(mode){
    const nextMode=mode==='weekly'?'weekly':'detail';
    const page=document.getElementById('fullFilterPage');
    if(page.classList.contains('show')&&ffMode===nextMode)return;
    ffMode=nextMode;
    document.getElementById('ffTitle').textContent=ffMode==='weekly'?'الفلتر الأسبوعي':'التفصيل';
    const today=new Date();
    // النطاق الافتراضي في جميع الأشرطة العلوية: بداية السنة حتى نهايتها.
    const from=new Date(today.getFullYear(),0,1);
    const to=new Date(today.getFullYear(),11,31);
    document.getElementById('ffDateFrom').value=iso(from);
    document.getElementById('ffDateTo').value=iso(to);
    setFullFilterSort('__sync');
    page.classList.add('show');page.setAttribute('aria-hidden','false');document.body.classList.add('full-filter-open');if(ffMode==='weekly')renderWeeklyFilterAccounts();else{const host=document.querySelector('#fullFilterPage .ff-empty');if(host)host.innerHTML='';}
    const fab=document.querySelector('.fab');if(fab){fab.style.display='grid';fab.style.zIndex='3001';fab.style.background='linear-gradient(135deg,#1499f5,#0878d8)';fab.style.color='#fff';fab.style.bottom='calc(24px + env(safe-area-inset-bottom))';fab.style.right='max(18px,calc(50% - 470px))';fab.style.width='88px';fab.style.height='88px';}
  };
  window.closeFullFilterPage=function(){const page=document.getElementById('fullFilterPage');page.classList.remove('show');page.setAttribute('aria-hidden','true');document.body.classList.remove('full-filter-open');const fab=document.querySelector('.fab');if(fab){fab.style.zIndex='20';fab.style.background='';fab.style.color='';fab.style.bottom='';fab.style.right='';fab.style.width='';fab.style.height='';} };
  window.setFullFilterSort=function(sort){ffSort=sort;[['ffSortDate','date'],['ffSortAsc','asc'],['ffSortDesc','desc']].forEach(([id,key])=>{const el=document.getElementById(id);if(el)el.classList.toggle('active',key===sort);});};
  window.shiftFullFilterDates=function(delta){const f=document.getElementById('ffDateFrom'),t=document.getElementById('ffDateTo');if(!f.value||!t.value)return;const from=new Date(f.value+'T12:00:00'),to=new Date(t.value+'T12:00:00');const span=Math.max(1,Math.round((to-from)/86400000)+1);from.setDate(from.getDate()+span*delta);to.setDate(to.getDate()+span*delta);f.value=iso(from);t.value=iso(to);applyFullFilterDates();};
  window.applyFullFilterDates=function(){const f=document.getElementById('ffDateFrom'),t=document.getElementById('ffDateTo');if(f.value&&t.value&&f.value>t.value){const old=f.value;f.value=t.value;t.value=old;}};
  const priorBack=window.navigateBack;
  window.navigateBack=function(){const page=document.getElementById('fullFilterPage');if(page&&page.classList.contains('show')){closeFullFilterPage();return;}if(typeof priorBack==='function')return priorBack();};
  // شاشة إضافة الفلتر الأسبوعي: النموذج جزء أصلي من الصفحة (بدون إطار) داخل طبقة بملء الشاشة.
  var _weeklyInst=null;
  window.__weeklyInst=function(){return _weeklyInst;};
  window.openWeeklyFilterEntry=function(filterId=null){
    let layer=document.getElementById('weeklyFilterEntryLayer');
    const openKey=filterId==null?'__new__':String(filterId);
    if(layer&&layer.style.display!=='none'&&layer.dataset.openKey===openKey)return;
    if(!layer){
      layer=document.createElement('div');layer.id='weeklyFilterEntryLayer';
      layer.style.cssText='position:fixed;inset:0;z-index:5000;background:var(--bg,#fff);display:flex;flex-direction:column;';
      const bar=document.createElement('div');bar.style.cssText='height:44px;min-height:44px;background:#0752a2;display:flex;align-items:center;justify-content:flex-start;padding:0 10px;';
      const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','إغلاق');close.style.cssText='width:34px;height:34px;border:1px solid #fff;border-radius:50%;background:transparent;color:#fff;font-size:25px;line-height:1;';close.onclick=window.closeWeeklyFilterEntry;
      bar.appendChild(close);
      const host=document.createElement('div');host.id='weeklyFilterEntryFrame';host.className='nf-scroll';host.setAttribute('role','region');host.setAttribute('aria-label','إضافة فلتر أسبوعي');
      layer.appendChild(bar);layer.appendChild(host);document.body.appendChild(layer);
    }
    const host=document.getElementById('weeklyFilterEntryFrame');
    const savedFilter=filterId?getSavedWeeklyFilters().find(x=>String(x.id)===String(filterId)):null;
    if(_weeklyInst){_weeklyInst.destroy();_weeklyInst=null;}
    host.innerHTML='';
    _weeklyInst=window.NativeForms.mount('weekly',host,_onWeeklyFormMessage);
    if(savedFilter)_weeklyInst.post({type:'LOAD_WEEKLY_FILTER',filter:savedFilter});
    host.scrollTop=0;
    layer.dataset.openKey=openKey;
    layer.style.display='flex';
    document.body.classList.add('full-filter-open');
  };
  window.closeWeeklyFilterEntry=function(){const layer=document.getElementById('weeklyFilterEntryLayer');if(layer){layer.style.display='none';delete layer.dataset.openKey;}if(_weeklyInst){_weeklyInst.destroy();_weeklyInst=null;}const h=document.getElementById('weeklyFilterEntryFrame');if(h)h.innerHTML='';document.body.classList.remove('full-filter-open');};
  const priorNavigateBack=window.navigateBack;
  window.navigateBack=function(){const layer=document.getElementById('weeklyFilterEntryLayer');if(layer&&layer.style.display!=='none'){closeWeeklyFilterEntry();return;}if(typeof priorNavigateBack==='function')return priorNavigateBack();};
  const priorFab=window.fabAction;
  window.fabAction=function(){const page=document.getElementById('fullFilterPage');if(page&&page.classList.contains('show')){if(ffMode==='weekly'){openWeeklyFilterEntry();}else{openDetailEntry();}return;}if(typeof priorFab==='function')return priorFab();};
})();

/* source script: force-account-header-reduction */
(function(){
  var css = `body.statement-view .statement-header,
  body.statement-view div.statement-header {
    height:55.2px!important; min-height:55.2px!important; max-height:55.2px!important;
    padding-top:0!important; padding-bottom:0!important; box-sizing:border-box!important;
    overflow:hidden!important; align-items:center!important;
  }
  body.statement-view .statement-header .sh-btn,
  body.statement-view .statement-header button.sh-btn {
    height:33px!important; min-height:33px!important; max-height:33px!important;
    padding-top:0!important; padding-bottom:0!important; box-sizing:border-box!important;
  }
  body.statement-view .statement-header .sh-name { line-height:1!important; margin-top:0!important; margin-bottom:0!important; }
  @media(max-width:600px){
    body.statement-view .statement-header, body.statement-view div.statement-header {
      height:31.8px!important; min-height:31.8px!important; max-height:31.8px!important;
      padding-top:0!important; padding-bottom:0!important; overflow:hidden!important;
    }
    body.statement-view .statement-header .sh-btn, body.statement-view .statement-header button.sh-btn {
      height:18px!important; min-height:18px!important; max-height:18px!important;
      padding:0 3px!important; font-size:10px!important;
    }
    body.statement-view .statement-header .sh-name { font-size:11px!important; line-height:1!important; }
  }`;
  function apply(){
    var st=document.getElementById('account-header-reduction-live');
    if(!st){st=document.createElement('style');st.id='account-header-reduction-live';(document.head||document.documentElement).appendChild(st)}
    st.textContent=css;
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',apply); else apply();
  setTimeout(apply,0); setTimeout(apply,300); setTimeout(apply,1000);
})();

/* source script: detail-form-source */

/* source script: harden-js */
(function(){
  'use strict';
  var VP='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover';
  var CSS='*{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}'+
    'input,textarea,[contenteditable="true"]{-webkit-user-select:text;user-select:text}'+
    'html,body,*{touch-action:manipulation}'+
    '*,*::before,*::after{transition-duration:.12s!important;animation-duration:.18s!important;animation-delay:0s!important;scroll-behavior:auto!important}'+
    '*{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}';
  function stop(e){e.preventDefault();}
  function isField(t){return t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.isContentEditable);}
  function harden(doc){
    try{
      if(!doc||!doc.head||doc.getElementById('ui-harden'))return;
      var m=doc.querySelector('meta[name="viewport"]');
      if(!m){m=doc.createElement('meta');m.name='viewport';doc.head.appendChild(m);}
      m.setAttribute('content',VP);
      var st=doc.createElement('style');st.id='ui-harden';st.textContent=CSS;doc.head.appendChild(st);
      ['dragstart','gesturestart','gesturechange','gestureend'].forEach(function(n){doc.addEventListener(n,stop,{passive:false,capture:true});});
      /* النسخ والقص والقائمة المنبثقة مسموحة داخل حقول الإدخال (أرقام ونصوص) ومحجوبة في باقي الصفحة */
      ['copy','cut','contextmenu'].forEach(function(n){doc.addEventListener(n,function(e){if(!isField(e.target))e.preventDefault();},{passive:false,capture:true});});
      doc.addEventListener('selectstart',function(e){if(!isField(e.target))e.preventDefault();},true);
      doc.addEventListener('touchmove',function(e){if(e.touches&&e.touches.length>1)e.preventDefault();},{passive:false,capture:true});
      doc.addEventListener('wheel',function(e){if(e.ctrlKey)e.preventDefault();},{passive:false,capture:true});
      doc.addEventListener('keydown',function(e){if((e.ctrlKey||e.metaKey)&&(e.key==='+'||e.key==='-'||e.key==='='||e.key==='0'||e.key==='c'||e.key==='x'||e.key==='a')&&!isField(e.target))e.preventDefault();
        else if((e.ctrlKey||e.metaKey)&&(e.key==='+'||e.key==='-'||e.key==='='||e.key==='0')&&!isField(e.target))e.preventDefault();},true);
    }catch(e){}
  }
  harden(document);
  function hook(fr){
    if(fr.__hd)return;fr.__hd=1;
    fr.addEventListener('load',function(){harden(fr.contentDocument);});
    try{if(fr.contentDocument&&fr.contentDocument.readyState!=='loading')harden(fr.contentDocument);}catch(e){}
  }
  function scan(root){if(!root.getElementsByTagName)return;var l=root.getElementsByTagName('iframe');for(var i=0;i<l.length;i++)hook(l[i]);}
  scan(document);
  new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType!==1)return;if(n.tagName==='IFRAME')hook(n);else scan(n);});});}).observe(document.documentElement,{childList:true,subtree:true});
})();

/* source script: unified-ui-system-js */
(function(){
  'use strict';
  var KEY='sale_app_data_v2';
  var $=function(id){return document.getElementById(id);};
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});};
  function say(t){try{if(typeof toast==='function')toast(t);}catch(e){}}
  function readAccounts(){try{var a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a:[];}catch(e){return [];}}
  function writeAccounts(a){try{localStorage.setItem(KEY,JSON.stringify(a));return true;}catch(e){return false;}}

  /* ===== الترحيل التلقائي: فاتورة ← فلتر ← تفصيل ← مراقب ===== */
  var AUTO_Q=[],AUTO_BUSY=false;
  function autoNum(v){var n=parseFloat(String(v==null?'':v).replace(/,/g,''));return isFinite(n)?n:0;}
  function autoAttr(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
  function weekAutoValues(folder){
    var debts={},qtys={},weekly={},received={},r3=function(x){return Math.round(x*1000)/1000;};
    (folder.invoices||[]).forEach(function(inv){
      var fd=(inv&&inv.formData)||{};
      /* بيع الدين: الاسم + الكمية (قات الدين من الفواتير اليومية) + المبلغ */
      (Array.isArray(fd.salesRows)?fd.salesRows:[]).forEach(function(r){var nm=String(r&&r.dname||'').trim();if(!nm)return;debts[nm]=(debts[nm]||0)+autoNum(r.dm);qtys[nm]=(qtys[nm]||0)+autoNum(r.dn);});
      /* مسلم أسبوع: ما سلّمه المدين خلال الأسبوع */
      (Array.isArray(fd.weeklyRows)?fd.weeklyRows:[]).forEach(function(r){var nm=String(r&&r.name||'').trim();if(!nm)return;weekly[nm]=(weekly[nm]||0)+autoNum(r.amount);});
      /* مسلم فلوس: الاسم + المبلغ */
      (Array.isArray(fd.receivedRows)?fd.receivedRows:[]).forEach(function(r){var amt=autoNum(r&&r.amount);if(!amt)return;var nm=String(r&&r.name||'').trim();received[nm]=(received[nm]||0)+amt;});
    });
    var debtRows=[];
    Object.keys(debts).forEach(function(nm){var d=r3(debts[nm]),wk=r3(weekly[nm]||0);if(d>0)debtRows.push({name:nm,qty:qtys[nm]?String(r3(qtys[nm])):'',amount:String(d),weekly:wk?String(wk):''});});
    var receivedRows=Object.keys(received).map(function(nm){return {name:nm,amount:String(r3(received[nm]))};});
    var sp=(data.settings.specialties||[]).find(function(s){return String(s.id)===String(folder.specialtyId||'')});
    var workers=0;
    if(sp){
      var cnt=(folder.invoices||[]).filter(function(inv){return String((inv&&inv.specialtyId)||folder.specialtyId||'')===String(sp.id)}).length;
      workers=Math.round(autoNum(sp.workersAmount)*cnt*1000)/1000;
    }
    return {debtRows:debtRows,receivedRows:receivedRows,workers:workers};
  }
  function autoSyncOne(folderId,done){
    var finished=false,fr=null,timer=null,inst=null;
    function finish(){
      if(finished)return;finished=true;clearTimeout(timer);
      var dead=fr,di=inst;setTimeout(function(){try{if(di)di.destroy();}catch(e){}if(dead&&dead.parentNode)dead.parentNode.removeChild(dead);},500);
      done();
    }
    function onMsg(m){
      if(finished||!m)return;
      if(m.type==='DETAIL_TO_CLOCK'){if(window.__detailToClock)window.__detailToClock(m);return;}
      if(m.type!=='DETAIL_SAVED')return;
      try{
        if(Array.isArray(m.accounts)&&m.accounts.length)writeAccounts(m.accounts);
        var target=null;
        readAccounts().forEach(function(a){(a.invoices||[]).forEach(function(i){if(i&&String(i.id)===String(m.id))target=i;});});
        if(target&&typeof window.__clockFromDetail==='function')window.__clockFromDetail(target);
      }catch(err){console.error(err);}
      finish();
    }
    var folder=(data.folders||[]).find(function(f){return String(f.id)===String(folderId)});
    if(!folder)return finish();
    if(typeof window.syncAutoDetails==='function')window.syncAutoDetails();
    var filter=(typeof getSavedWeeklyFilters==='function'?getSavedWeeklyFilters():[]).find(function(x){return String(x.sourceFolderId||'')===String(folder.id)});
    if(!filter)return finish();
    var accs=readAccounts(),acc=null,inv=null;
    accs.forEach(function(a){(a.invoices||[]).forEach(function(i){if(!inv&&i&&i.autoFilterId!=null&&String(i.autoFilterId)===String(filter.id)){inv=i;acc=a;}});});
    if(!inv||!acc)return finish();
    var vals=weekAutoValues(folder);
    fr=document.createElement('div');
    fr.setAttribute('aria-hidden','true');
    fr.style.cssText='position:fixed;left:-9999px;top:0;width:800px;height:600px;overflow:hidden;visibility:hidden';
    document.body.appendChild(fr);
    timer=setTimeout(finish,20000);
    inst=window.NativeForms.mount('detail',fr,onMsg);
    var run=function(){
      try{
        var w=inst.win;
        if(!w.saveInvoiceNow||!w.applyWeeklyFilterTotals)return finish();
        w.eval('accounts='+JSON.stringify(accs)+';currentAccountId='+JSON.stringify(acc.id)+';editingInvoiceId='+JSON.stringify(inv.id)+';window._invoiceInitData={filter:'+JSON.stringify(filter.name)+',no:'+JSON.stringify(inv.initNo||'')+'};');
        w.eval('$("hDetail").value='+JSON.stringify(inv.initDetail||filter.name)+';$("hDateFrom").value='+JSON.stringify(inv.initDateFrom||filter.fromDate||'')+';$("hDateTo").value='+JSON.stringify(inv.initDateTo||filter.toDate||'')+';$("note").value='+JSON.stringify(inv.note||'')+';');
        w.applyWeeklyFilterTotals(filter.name);
        var doc=w.document;
        doc.getElementById('debtBody').innerHTML='';
        vals.debtRows.forEach(function(r){w.addDebtRow(r.name,r.qty,r.amount,r.weekly);});
        if(!vals.debtRows.length)w.addDebtRow();
        /* مسلم فلوس بالأسماء: يُستبدل صف الإجمالي بصفوف الأسماء فقط إذا طابق المجموع نفس الإجمالي */
        try{
          var rcv=vals.receivedRows||[];
          if(rcv.length&&rcv.some(function(r){return r.name;})){
            var curTot=0,newTot=0;
            w.rowsToArray('prevBody').forEach(function(r){curTot+=autoNum(r.amount);});
            rcv.forEach(function(r){newTot+=autoNum(r.amount);});
            if(Math.abs(curTot-newTot)<0.01){
              doc.getElementById('prevBody').innerHTML='';
              rcv.forEach(function(r){w.addRow('prevBody',autoAttr(r.name),autoAttr(r.amount));});
            }
          }
        }catch(e2){console.error(e2);}
        doc.getElementById('sPrivateOut').value=String(vals.workers);
        w.update();
        w.saveInvoiceNow();
      }catch(err){console.error(err);finish();}
    };
    setTimeout(run,60);
  }
  function runAutoQ(){
    if(!AUTO_Q.length){AUTO_BUSY=false;return;}
    AUTO_BUSY=true;
    var id=AUTO_Q.shift();
    try{autoSyncOne(id,runAutoQ);}catch(err){console.error(err);runAutoQ();}
  }
  window.__queueAutoSync=function(folderId){
    if(folderId==null||folderId==='')return;
    var __bf=(data.folders||[]).find(function(f){return String(f.id)===String(folderId)});
    if(__bf&&__bf.scope==='buyer')return;
    AUTO_Q.push(String(folderId));
    if(!AUTO_BUSY)runAutoQ();
  };
  function backHTML(){return '<span class="ui-arrow">→</span><span class="ui-lbl">رجوع</span>';}
  function makeBack(fn){var b=document.createElement('button');b.type='button';b.className='ui-back';b.setAttribute('aria-label','رجوع');b.innerHTML=backHTML();b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();if(typeof fn==='function')fn();});return b;}
  function appBar(title,fn){var bar=document.createElement('div');bar.className='ui-appbar';bar.appendChild(makeBack(fn));var t=document.createElement('div');t.className='ui-title';t.textContent=title||'';bar.appendChild(t);return bar;}
  function goBack(){if(typeof navigateBack==='function')navigateBack();}

  /* ---------- جدول التفصيلات داخل شاشة التفصيل ---------- */
  function isDetailMode(){var t=$('ffTitle');return !!t&&t.textContent.trim()==='التفصيل';}
  function sortMode(){var d=$('ffSortDesc'),a=$('ffSortAsc'),k=$('ffSortDate');
    if(d&&d.classList.contains('active'))return 'desc';
    if(k&&k.classList.contains('active')&&!(a&&a.classList.contains('active')))return 'date';
    return 'asc';}
  function listInvoices(){
    var from=($('ffDateFrom')||{}).value||'',to=($('ffDateTo')||{}).value||'',out=[];
    readAccounts().forEach(function(a){(Array.isArray(a.invoices)?a.invoices:[]).forEach(function(i){out.push(i);});});
    out=out.filter(function(i){var f=i.initDateFrom||'',t=i.initDateTo||f;if(!from||!to||(!f&&!t))return true;return f<=to&&(t||f)>=from;});
    out=out.filter(function(i){return window.__specOkDetail?window.__specOkDetail(i):true});
    var m=sortMode();
    out.sort(window.__ffCmpDetail||function(x,y){return 0;});
    return out;
  }
  window.renderDetailList=function(flashId){
    var host=document.querySelector('#fullFilterPage .ff-empty');if(!host||!isDetailMode())return;
    var list=listInvoices();
    if(!list.length){host.innerHTML='';return;}
    var rows=list.map(function(i,n){
      var total=(i.formData&&(i.formData.calc_mTotal||i.formData.calc_midTotal))||'';
      var per=esc(i.initDateFrom||'')+((i.initDateTo&&i.initDateTo!==i.initDateFrom)?'<br>'+esc(i.initDateTo):'');
      return '<tr data-id="'+esc(i.id)+'"'+(String(i.id)===String(flashId)?' class="flash"':'')+'><td class="nm">'+(n+1)+'. '+esc(i.initDetail||'تفصيل بدون اسم')+(i.initFilter?'<div class="sub">'+esc(i.initFilter)+'</div>':'')+'</td><td>'+per+'</td><td>'+esc(total||'—')+'</td></tr>';
    }).join('');
    host.innerHTML='<div class="ui-table-wrap"><table class="ui-table"><thead><tr><th>التفصيل</th><th>الفترة</th><th>الإجمالي</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
    var fl=host.querySelector('tr.flash');if(fl&&fl.scrollIntoView)try{fl.scrollIntoView({block:'center'});}catch(e){}
  };
  document.addEventListener('click',function(e){
    var r=e.target.closest&&e.target.closest('#fullFilterPage .ui-table tbody tr');if(!r)return;
    if(window.openDetailOptions)window.openDetailOptions(r.getAttribute('data-id'));
  });
  ['openFullFilterPage','setFullFilterSort','shiftFullFilterDates','applyFullFilterDates'].forEach(function(n){
    var orig=window[n];if(typeof orig!=='function')return;
    window[n]=function(){var r=orig.apply(this,arguments);if(isDetailMode())window.renderDetailList();return r;};
  });

  /* ---------- نافذة إضافة/تعديل التفصيل ---------- */
  var _detailInst=null;
  window.closeDetailEntry=function(){if(_detailInst){_detailInst.destroy();_detailInst=null;}var m=$('detailEntryModal');if(m)m.remove();document.body.style.overflow='';};
  function backDetail(){
    try{if(_detailInst&&typeof _detailInst.win.appBack==='function'&&_detailInst.win.appBack())return;}catch(e){}
    window.closeDetailEntry();
  }
  window.openDetailEntry=function(editId,opts){opts=opts||{};
    var entryKey=JSON.stringify([editId==null?'':String(editId),!!opts.readonly,!!opts.print]);
    var existing=$('detailEntryModal');
    if(existing&&existing.dataset.entryKey===entryKey)return;
    if(existing)window.closeDetailEntry();
    var modal=document.createElement('div');modal.id='detailEntryModal';modal.className='ui-layer';modal.dataset.entryKey=entryKey;
    modal.appendChild(appBar(opts.readonly?'عرض التفصيل':(editId?'تعديل التفصيل':'إضافة تفصيل'),backDetail));
    var host=document.createElement('div');host.id='detailEntryFrame';host.className='nf-scroll';host.setAttribute('role','region');host.setAttribute('aria-label','التفصيل');
    modal.appendChild(host);document.body.appendChild(modal);document.body.style.overflow='hidden';
    /* النموذج جزء أصلي من الصفحة: يُبنى مباشرة بدون إطار */
    var inst=window.NativeForms.mount('detail',host,_onDetailFormMessage);_detailInst=inst;
    var cs=getComputedStyle(document.documentElement);var p=cs.getPropertyValue('--primary').trim()||'#1e40af',pd=cs.getPropertyValue('--primary-dark').trim()||p,pl=cs.getPropertyValue('--primary-light').trim()||'rgba(30,64,175,.12)';
    inst.post({type:'DETAIL_INIT',accounts:readAccounts(),editId:editId||null,readonly:!!opts.readonly,theme:{'--primary':p,'--primary-dark':pd,'--accent':p,'--primary-light':pl,'--accent-light':pl}});
    if(opts.print)setTimeout(function(){try{if(_detailInst!==inst)return;var pf=window.NativeForms.printFrame(inst);if(window.__printFramePdf)window.__printFramePdf(pf,'التفصيل');else pf.contentWindow.print();}catch(e){console.error(e)}},900);
  };
  function _onDetailFormMessage(m){
    if(!m)return;
    if(m.type==='DETAIL_TO_CLOCK'){if(window.__detailToClock)window.__detailToClock(m);return;}
    if(m.type!=='DETAIL_SAVED')return;
    if(Array.isArray(m.accounts)&&m.accounts.length)writeAccounts(m.accounts);
    window.closeDetailEntry();
    var page=$('fullFilterPage');
    if(!page||!page.classList.contains('show')||!isDetailMode())window.openFullFilterPage('detail');
    var inv=null;readAccounts().forEach(function(a){(a.invoices||[]).forEach(function(i){if(String(i.id)===String(m.id))inv=i;});});
    if(inv&&typeof window.__clockFromDetail==='function'){try{window.__clockFromDetail(inv)}catch(err){console.error(err)}}
    if(inv){var f=$('ffDateFrom'),t=$('ffDateTo');
      if(f&&inv.initDateFrom&&(!f.value||inv.initDateFrom<f.value))f.value=inv.initDateFrom;
      if(t&&(inv.initDateTo||inv.initDateFrom)&&(!t.value||(inv.initDateTo||inv.initDateFrom)>t.value))t.value=inv.initDateTo||inv.initDateFrom;}
    window.renderDetailList(m.id);
    say(m.updated?'✅ تم تحديث التفصيل':'✅ تم حفظ التفصيل');
  }
  var pb=window.navigateBack;
  window.navigateBack=function(){var m=$('detailEntryModal');if(m){backDetail();return;}var im=$('folderInvoiceModal');if(im&&im.classList.contains('show')){invoiceBack();return;}return typeof pb==='function'?pb.apply(this,arguments):undefined;};

  function invoiceBack(){
    if(typeof closeFolderInvoice==='function')closeFolderInvoice();
  }

  function mountFullFilterBar(){
    var p=$('fullFilterPage');if(!p||p.querySelector(':scope>.ui-appbar'))return;
    var bar=appBar($('ffTitle')?$('ffTitle').textContent:'',function(){if(typeof closeFullFilterPage==='function')closeFullFilterPage();});
    p.insertBefore(bar,p.firstChild);
    var t=$('ffTitle');if(t)new MutationObserver(function(){bar.querySelector('.ui-title').textContent=t.textContent;}).observe(t,{childList:true,characterData:true,subtree:true});
  }
  function mountSettingsBacks(){}
  function mountInvoiceHead(){}
  function upgradeWeeklyBar(){
    var layer=$('weeklyFilterEntryLayer');if(!layer||layer.querySelector('.ui-appbar'))return;
    var old=layer.firstElementChild;var bar=appBar('الفلتر الأسبوعي',function(){if(typeof closeWeeklyFilterEntry==='function')closeWeeklyFilterEntry();});
    if(old&&old.tagName==='DIV')layer.replaceChild(bar,old);else layer.insertBefore(bar,layer.firstChild);
  }
  var ow=window.openWeeklyFilterEntry;
  if(typeof ow==='function')window.openWeeklyFilterEntry=function(){var r=ow.apply(this,arguments);upgradeWeeklyBar();return r;};
  function mountStatementBack(){}
  var db=$('detailBox');if(db)new MutationObserver(mountStatementBack).observe(db,{childList:true});
  /* زر الرأس الرئيسي: قائمة في الصفحة الرئيسية، ورجوع داخل المجلد */
  function inFolder(){try{return !!currentFolderId&&!document.body.classList.contains('statement-view');}catch(e){return false;}}
  /* داخل أي صفحة فرعية (مجلد/كشف/إعدادات) يعمل الزر كرجوع هرمي، وفي الواجهة الرئيسية يفتح قائمة الإعدادات */
  function atSubPage(){try{return navStack.length>0||inFolder()||document.body.classList.contains('statement-view');}catch(e){return false;}}
  window.topLeadAction=function(){if(atSubPage()){navigateBack();return;}openSideMenu();};
  function syncLead(){
    var b=$('menuBtn');if(!b)return;
    var back=atSubPage();
    if(typeof window.__syncInvBack==='function')window.__syncInvBack();
    if(b.classList.contains('ui-back')){b.classList.remove('ui-back');b.textContent='☰';b.title='الإعدادات';}
  }
  var ht=$('headerTitle');if(ht)new MutationObserver(syncLead).observe(ht,{childList:true,characterData:true,subtree:true});
  new MutationObserver(syncLead).observe(document.body,{attributes:true,attributeFilter:['class']});
  document.addEventListener('click',function(){setTimeout(syncLead,60);},true);
  function mountAll(){mountFullFilterBar();mountSettingsBacks();mountInvoiceHead();mountStatementBack();syncLead();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountAll);else mountAll();
  window.addEventListener('load',syncNativeBackupSettings);
})();

/* source script: options-sheet-js */
(function(){
  'use strict';
  var DK='sale_app_data_v2',WK='smartadmin_weekly_filters_v1';
  var $=function(id){return document.getElementById(id);};
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});};
  function say(t){try{if(typeof toast==='function')toast(t);}catch(e){}}
  function rd(k){try{var a=JSON.parse(localStorage.getItem(k)||'[]');return Array.isArray(a)?a:[];}catch(e){return [];}}
  function wr(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){say('تعذر الحفظ؛ مساحة التخزين ممتلئة');return false;}}
  /* نافذة الخيارات الموحدة */
  function sheet(title,items){
    close();
    var ov=document.createElement('div');ov.id='uiOptSheet';ov.className='ui-opt-ov';
    var box='<div class="ui-opt-box"><div class="ui-opt-title">'+esc(title)+'</div>';
    items.forEach(function(it,i){box+='<button type="button" class="ui-opt-btn'+(it.cls?' '+it.cls:'')+'" data-i="'+i+'">'+it.label+'</button>';});
    box+='<button type="button" class="ui-opt-btn" data-i="x">إلغاء</button></div>';
    ov.innerHTML=box;
    ov.addEventListener('click',function(e){
      if(e.target===ov){close();return;}
      var b=e.target.closest('.ui-opt-btn');if(!b)return;var i=b.getAttribute('data-i');close();
      if(i!=='x')items[+i].fn();
    });
    document.body.appendChild(ov);
  }
  function close(){var o=$('uiOptSheet');if(o)o.remove();}
  var pb=window.navigateBack;
  window.navigateBack=function(){if($('uiOptSheet')){close();return;}return typeof pb==='function'?pb.apply(this,arguments):undefined;};
  function share(title,text){
    if(navigator.share){navigator.share({title:title,text:text}).catch(function(){});return;}
    try{navigator.clipboard.writeText(text);say('تم نسخ البيانات للمشاركة');}catch(e){say('المشاركة غير مدعومة في هذا المتصفح');}
  }
  /* ---- خيارات التفصيل ---- */
  function findInv(id){var r=null;rd(DK).forEach(function(a){(a.invoices||[]).forEach(function(i){if(String(i.id)===String(id))r=i;});});return r;}
  window.openDetailOptions=function(id){
    var inv=findInv(id);if(!inv)return;
    sheet('🧾 خيارات التفصيل',[
      {label:'👁️ عرض التفصيل',cls:'main',fn:function(){window.openDetailEntry(id,{readonly:true});}},
      {label:'✏️ فتح / تعديل',fn:function(){window.openDetailEntry(id);}},
      {label:'🖨️ طباعة',fn:function(){window.openDetailEntry(id,{readonly:true,print:true});}},
      {label:'🕒 إلى المراقب',fn:function(){
        if(typeof window.__clockFromDetail!=='function'){say('تعذر الترحيل إلى المراقب');return}
        var r=window.__clockFromDetail(inv);
        window.closeFullFilterPage();window.showHome();
        say(r&&Object.keys(r).some(function(k){return r[k]})?'تم إرسال المبالغ إلى صفحات المراقب كمعاملات':'لا توجد مبالغ في التفصيل لإرسالها');
      }},
      {label:'📤 إرسال / مشاركة',fn:function(){share(inv.initDetail||'تفصيل','التفصيل: '+(inv.initDetail||'')+'\nمن: '+(inv.initDateFrom||'')+'\nإلى: '+(inv.initDateTo||'')+(inv.initFilter?'\nالفلتر: '+inv.initFilter:'')+(inv.note?'\nملاحظة: '+inv.note:''));}},
      {label:'💾 حفظ نسخة',fn:function(){
        var acc=rd(DK);var done=false;
        acc.forEach(function(a){if(done)return;(a.invoices||[]).forEach(function(i){if(done||String(i.id)!==String(id))return;
          var c=JSON.parse(JSON.stringify(i));c.id=Date.now();c.createdAt=Date.now();c.initDetail=(i.initDetail||'تفصيل')+' (نسخة)';a.invoices.push(c);done=true;});});
        if(done&&wr(DK,acc)){window.renderDetailList(Date.now());say('تم حفظ نسخة من التفصيل');}}},
      {label:'🗑️ حذف التفصيل',cls:'danger',fn:function(){
        if(!confirm('حذف هذا التفصيل نهائيًا؟'))return;
        var acc=rd(DK);acc.forEach(function(a){if(Array.isArray(a.invoices))a.invoices=a.invoices.filter(function(i){return String(i.id)!==String(id);});});
        wr(DK,acc);window.renderDetailList();say('تم حذف التفصيل');}}
    ]);
  };
  /* ---- طباعة عدة فلاتر أسبوعية: كل فلتر بنفس هيكل الجدول، وكل واحد في صفحة ---- */
  window.__printWeeklyList=async function(items){
    var bodies=[],css='';
    for(var i=0;i<items.length;i++){
      window.openWeeklyFilterEntry(String(items[i].id));
      var inst=window.__weeklyInst();
      if(!inst)continue;
      await new Promise(function(res){setTimeout(res,150);});
      try{
        var w=inst.win;
        if(w.__weeklyPrintBody){bodies.push(w.__weeklyPrintBody());if(!css)css=w.__PRINT_CSS||'';}
      }catch(e){}
    }
    window.closeWeeklyFilterEntry();
    if(!bodies.length){say('تعذر تجهيز الفلاتر للطباعة');return;}
    var html='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>الفلاتر الأسبوعية</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap"><style>'+css+'.pb{break-before:page;page-break-before:always}</style></head><body><div class="pdoc">'+bodies.map(function(b,k){return (k?'<div class="pb"></div>':'')+b;}).join('')+'</div></body></html>';
    if(window.__printDoc&&window.__printDoc(html))return;
    var pw=window.open('','_blank');
    if(pw){pw.document.write(html.replace('</body>','<script>window.onload=function(){setTimeout(function(){window.print()},250)};<\/script></body>'));pw.document.close();}
  };
  /* ---- خيارات الفلتر الأسبوعي ---- */
  function findF(id){return rd(WK).find(function(f){return f&&String(f.id)===String(id);})||null;}
  function weeklyView(id,print){
    window.openWeeklyFilterEntry(id);
    var inst=window.__weeklyInst();if(!inst)return;
    var t=$('weeklyFilterEntryLayer');var tt=t&&t.querySelector('.ui-title');if(tt)tt.textContent='عرض الفلتر الأسبوعي';
    setTimeout(function(){try{var d=inst.el;
      d.querySelectorAll('input,textarea,select,button').forEach(function(e){e.disabled=true;});
      d.querySelectorAll('.nf-btn').forEach(function(e){e.style.display='none';});
      if(print){var w=inst.win;var ph=(w.__buildWeeklyPrintHtml?w.__buildWeeklyPrintHtml():'');if(ph){if(window.__printDoc&&window.__printDoc(ph))return;var pw=window.open('','_blank');if(pw){pw.document.write(ph.replace('</body>','<script>window.onload=function(){setTimeout(function(){window.print()},250)};<\/script></body>'));pw.document.close();}return;}var pf=window.NativeForms.printFrame(inst);if(window.__printFramePdf)window.__printFramePdf(pf,'الفلتر الأسبوعي');else pf.contentWindow.print();}}catch(e){console.error(e)}},250);
  }
  window.openWeeklyOptions=function(id){
    var f=findF(id);if(!f)return;
    sheet('🗓️ خيارات الفلتر الأسبوعي',[
      {label:'👁️ عرض الفلتر',cls:'main',fn:function(){weeklyView(id,false);}},
      {label:'📋 تفصيل (نقل البيانات)',fn:function(){window.transferWeeklyToDetail(id);}},
      {label:'✏️ فتح / تعديل',fn:function(){window.openWeeklyFilterEntry(id);}},
      {label:'🖨️ طباعة',fn:function(){weeklyView(id,true);}},
      {label:'📤 إرسال / مشاركة',fn:function(){share(f.name,'الفلتر الأسبوعي: '+f.name+'\nمن: '+(f.fromDate||'')+'\nإلى: '+(f.toDate||''));}},
      {label:'💾 حفظ نسخة',fn:function(){
        var l=rd(WK);var c=JSON.parse(JSON.stringify(f));c.id=String(Date.now());c.name=f.name+' (نسخة)';c.updatedAt=Date.now();l.unshift(c);
        if(wr(WK,l)){window.renderWeeklyFilterAccounts();say('تم حفظ نسخة من الفلتر');}}},
      {label:'🗑️ حذف الفلتر',cls:'danger',fn:function(){
        if(!confirm('حذف هذا الفلتر نهائيًا؟'))return;
        wr(WK,rd(WK).filter(function(x){return String(x.id)!==String(id);}));window.renderWeeklyFilterAccounts();say('تم حذف الفلتر');}}
    ]);
  };
  /* ---- التفصيل التلقائي المرتبط بالفلتر الأسبوعي ---- */
  function hasData(i){return !!(i&&i.formData&&Object.keys(i.formData).length);}
  function findAutoIn(acc,fid){var r=null;acc.forEach(function(a){(a.invoices||[]).forEach(function(i){if(i&&i.autoFilterId!=null&&String(i.autoFilterId)===String(fid))r=i;});});return r;}
  window.syncAutoDetails=function(){
    var buyerIds={};(data.folders||[]).forEach(function(fo){if(fo&&fo.scope==='buyer')buyerIds[String(fo.id)]=1;});
    var filters=rd(WK).filter(function(f){return f&&f.fromDate&&f.toDate&&!buyerIds[String(f.sourceFolderId||'')];});
    var acc=rd(DK);if(!acc.length)acc.push({id:1,invoices:[]});
    var target=acc[0];if(!Array.isArray(target.invoices))target.invoices=[];
    var changed=false,ids={};filters.forEach(function(f){ids[String(f.id)]=true;});
    acc.forEach(function(a){if(!Array.isArray(a.invoices))return;var before=a.invoices.length;
      a.invoices=a.invoices.filter(function(i){return !i||i.autoFilterId==null||ids[String(i.autoFilterId)]||hasData(i);});
      if(a.invoices.length!==before)changed=true;});
    var n=0;
    filters.forEach(function(f){
      var inv=findAutoIn(acc,f.id);
      if(!inv){target.invoices.push({id:Date.now()+(n++),initDetail:f.name,initDateFrom:f.fromDate,initDateTo:f.toDate,initNo:'',initFilter:f.name,formData:{},note:'',createdAt:Date.now(),autoFilterId:String(f.id)});changed=true;return;}
      if(inv.initDetail!==f.name||inv.initDateFrom!==f.fromDate||inv.initDateTo!==f.toDate||inv.initFilter!==f.name){
        inv.initDetail=f.name;inv.initDateFrom=f.fromDate;inv.initDateTo=f.toDate;inv.initFilter=f.name;changed=true;}
    });
    if(changed)wr(DK,acc);
    return changed;
  };
  /* نقل بيانات الفلتر الأسبوعي إلى التفصيل التلقائي مباشرة ثم الرجوع لجدول التفصيل */
  window.transferWeeklyToDetail=function(fid){
    var f=findF(fid);if(!f)return;
    if(window.__queueAutoSync)window.__queueAutoSync(f.sourceFolderId);
    say('تم ترحيل بيانات الأسبوع إلى التفصيل تلقائيًا');
  };
  window.syncAutoDetails();
  var svf=window.saveWeeklyFilterFromEntry;
  if(typeof svf==='function')window.saveWeeklyFilterFromEntry=function(){var r=svf.apply(this,arguments);window.syncAutoDetails();return r;};
  var rw=window.renderWeeklyFilterAccounts;
  window.renderWeeklyFilterAccounts=function(){
    window.syncAutoDetails();
    var r=rw.apply(this,arguments);
    document.querySelectorAll('#fullFilterPage .ff-empty button[onclick*="openWeeklyFilterEntry"]').forEach(function(b){
      var m=(b.getAttribute('onclick')||'').match(/openWeeklyFilterEntry\(&quot;(.*?)&quot;\)|openWeeklyFilterEntry\(["'](.*?)["']\)/);
      var id=m&&(m[1]||m[2]);b.removeAttribute('onclick');
      b.addEventListener('click',function(){window.openWeeklyOptions(id);});
    });
    return r;
  };
})();

/* source script: home-clock-logic */
(function(){
 const keys=[['sale','جملة البيع النهائية'],['workers','خرج العمال'],['withdraw','السحب'],['debts','الديون'],['currency','العملات']];
 function read(){try{return JSON.parse(localStorage.getItem('smartadmin_home_clock_v1')||'{}')}catch(e){return {}}}
 function render(){const host=document.getElementById('homeClockRows');if(!host)return;const data=read();const rows=keys.map(([k,label])=>({k,label,n:Number(data[k]||0)}));host.innerHTML=rows.map(({k,label,n})=>{n=Number.isFinite(n)?n:0;const dir=n<0?'عليكم':n>0?'لكم':'متوازن';const cls=n<0?'clock-debt':n>0?'clock-pay':'clock-even';return '<div class="clock-item '+cls+(k==='tasfeer'?' clock-tasfeer':'')+'"><div class="clock-label">'+label+'</div><div class="clock-value">'+Math.abs(n).toLocaleString('en-US')+'</div><div style="font-size:12px;font-weight:900;margin-top:4px">'+dir+'</div></div>';}).join('')+tasfeerClockCard();}
function tasfeerClockCard(){var g=null;try{if(window.__tsGap)g=window.__tsGap()}catch(e){}
var base='<div class="clock-item clock-tasfeer clock-even" id="clockTasfeerBtn" onclick="if(window.openTasfeer)openTasfeer()">';
if(!g)return base+'<div class="clock-label" style="font-size:17px;margin:0">الصرافة</div></div>';
var col=g.side==='acc'?'#15803d':g.side==='fund'?'#dc2626':'#64748b',cap=g.side==='acc'?'الباقي للحسابات':g.side==='fund'?'الباقي للصناديق':'متطابق';
return base+'<div class="clock-label" style="font-size:17px;margin:0 0 4px">الصرافة</div><div class="clock-value" style="color:'+col+'!important">'+Math.abs(g.g).toLocaleString('en-US',{maximumFractionDigits:3})+'</div><div style="font-size:12px;font-weight:900;margin-top:4px;color:'+col+'">'+cap+'</div></div>'}
window.__clockRenderHome=render;
 window.updateHomeClock=function(values){const data=read();Object.keys(values||{}).forEach(k=>{if(keys.some(x=>x[0]===k)){const n=Number(values[k]);if(Number.isFinite(n))data[k]=n;}});data.updatedAt=Date.now();localStorage.setItem('smartadmin_home_clock_v1',JSON.stringify(data));render();};
 window.__detailToClock=function(m){if(m&&m.type==='DETAIL_TO_CLOCK'&&m.totals&&typeof m.totals==='object'){window.updateHomeClock(m.totals);if(typeof toast==='function')toast('تم تحديث مجاميع المراقب');}};
 document.addEventListener('DOMContentLoaded',render);render();
})();

/* source script: longpress-topbar-unified */
(function(){
 'use strict';
 if(window.__lpTopBar)return;window.__lpTopBar=true;
 var DK='sale_app_data_v2',WK='smartadmin_weekly_filters_v1',HOLD=550,MOVE=14;
 var ITEM_INV='button[data-invoice-id]',ITEM_DET='#fullFilterPage .ui-table tbody tr[data-id]',ITEM_FLT='#fullFilterPage .ff-empty>div>button[data-wf-id]';
 var $=function(id){return document.getElementById(id)};
 var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 function say(t){try{if(typeof toast==='function')toast(t)}catch(e){}}
 function rd(k){try{var a=JSON.parse(localStorage.getItem(k)||'[]');return Array.isArray(a)?a:[]}catch(e){return []}}
 function wr(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){say('تعذر الحفظ؛ مساحة التخزين ممتلئة');return false}}
 function ask(msg,ok,title){if(typeof customConfirm==='function'){customConfirm(msg,ok,null,{title:title||'تأكيد',icon:'🗑️',danger:true,confirmText:'نعم',cancelText:'إلغاء'})}else if(confirm(msg)){ok()}}
 function p2(n){return String(n).padStart(2,'0')}
 function shiftDate(s,d){if(!s)return s;var x=new Date(s+'T12:00:00');if(isNaN(x))return s;x.setDate(x.getDate()+d);return x.getFullYear()+'-'+p2(x.getMonth()+1)+'-'+p2(x.getDate())}

 /* ---------- الحالة ---------- */
 var ctx=null,sel=new Set(),timer=null,sx=0,sy=0,swallow=false,swT=null,poll=null;
 function selOf(t){return t==='invoice'?ITEM_INV:t==='detail'?ITEM_DET:ITEM_FLT}
 function idOf(t,el){return String(t==='invoice'?el.getAttribute('data-invoice-id'):t==='detail'?el.getAttribute('data-id'):el.getAttribute('data-wf-id'))}
 function itemOf(t){
  if(!t||!t.closest)return null;var el;
  if(t.closest('#lpTopBar,#lpPicker,.ui-opt-ov'))return null;
  if((el=t.closest(ITEM_INV)))return {type:'invoice',el:el,id:idOf('invoice',el)};
  if((el=t.closest(ITEM_DET)))return {type:'detail',el:el,id:idOf('detail',el)};
  if((el=t.closest(ITEM_FLT)))return {type:'filter',el:el,id:idOf('filter',el)};
  return null;
 }
 function allEls(){return ctx?Array.prototype.slice.call(document.querySelectorAll(selOf(ctx))).filter(function(el){return el.getClientRects().length>0}):[]}
 function isDetailPage(){var t=$('ffTitle');return !!t&&String(t.textContent||'').trim()==='التفصيل'}

 /* ---------- الشريط العلوي ---------- */
 var bar=document.createElement('div');bar.id='lpTopBar';
 bar.innerHTML='<div class="lp-row"><button type="button" class="lp-x" data-a="close" aria-label="إلغاء التحديد">✕</button><span class="lp-count"><b id="lpCount">0</b> محدد</span></div>'
  +'<div class="lp-actions"><button type="button" data-a="all" id="lpAll">☑ تحديد الكل</button><button type="button" data-a="delete" class="lp-del">🗑 مسح</button><button type="button" data-a="copy">📋 نسخ</button><button type="button" data-a="move">↔ نقل</button><button type="button" data-a="print">🖨 طباعة</button><button type="button" data-a="detail" id="lpDetail">📑 تفصيل</button><button type="button" data-a="clock" id="lpClock">🕒 إلى المراقب</button><button type="button" data-a="more" id="lpMore">⋯ المزيد</button></div>';
 document.body.appendChild(bar);

 function refresh(){
  if(!sel.size){exit();return}
  var els=allEls();
  $('lpCount').textContent=sel.size;
  $('lpAll').textContent=(els.length&&sel.size>=els.length)?'☐ إلغاء الكل':'☑ تحديد الكل';
  $('lpDetail').style.display=ctx==='filter'?'':'none';
  $('lpClock').style.display=ctx==='detail'?'':'none';
  $('lpMore').style.display=(ctx==='invoice'&&sel.size===1)?'':'none';
  bar.classList.add('show');
  els.forEach(function(el){el.classList.toggle('lp-sel',sel.has(idOf(ctx,el)))});
 }
 function exit(){
  sel.clear();bar.classList.remove('show');
  Array.prototype.forEach.call(document.querySelectorAll('.lp-sel'),function(e){e.classList.remove('lp-sel')});
  ctx=null;stopPoll();
  try{document.dispatchEvent(new Event('lpexit'))}catch(e){}
 }
 function sync(){
  if(!ctx)return;var present={};
  allEls().forEach(function(el){present[idOf(ctx,el)]=1});
  Array.from(sel).forEach(function(i){if(!present[i])sel.delete(i)});
  refresh();
 }
 function ctxVisible(){
  if(ctx==='invoice'){var m=$('folderInvoiceModal');return !!document.querySelector(ITEM_INV)&&!(m&&m.classList.contains('show'))}
  var p=$('fullFilterPage');if(!p||!p.classList.contains('show'))return false;
  return ctx==='detail'?isDetailPage():!isDetailPage();
 }
 function startPoll(){stopPoll();poll=setInterval(function(){if(!document.hidden&&!ctxVisible())exit()},800)}
 function stopPoll(){if(poll){clearInterval(poll);poll=null}}
 function toggle(id){if(sel.has(id))sel.delete(id);else sel.add(id);refresh()}
 function begin(it){
  ctx=it.type;sel.clear();sel.add(it.id);swallow=true;
  try{if(navigator.vibrate)navigator.vibrate(30)}catch(e){}
  refresh();startPoll();
 }

 /* ---------- وسم أزرار الفلاتر بمعرّفاتها ---------- */
 function tagFilters(){
  var btns=document.querySelectorAll('#fullFilterPage .ff-empty>div>button');if(!btns.length)return;
  var list=(typeof getSavedWeeklyFilters==='function')?getSavedWeeklyFilters():[];
  Array.prototype.forEach.call(btns,function(b,i){if(list[i]&&!b.hasAttribute('data-wf-id'))b.setAttribute('data-wf-id',String(list[i].id))});
 }
 function onMut(){tagFilters();if(sel.size)sync()}
 var cv=$('currentView');if(cv)new MutationObserver(onMut).observe(cv,{childList:true});
 var fe=document.querySelector('#fullFilterPage .ff-empty');if(fe)new MutationObserver(onMut).observe(fe,{childList:true});
 tagFilters();

 /* ---------- الضغط المطول ---------- */
 function clearTimer(){if(timer){clearTimeout(timer);timer=null}}
 document.addEventListener('pointerdown',function(e){
  if(e.pointerType==='mouse'&&e.button!==0)return;
  var it=itemOf(e.target);if(!it)return;
  if(e.target.closest('input,select,textarea'))return;
  if(it.type==='invoice'){try{if(data.settings.invoiceSettings&&data.settings.invoiceSettings.longPressActions===false)return}catch(x){}}
  if(sel.size)return;
  clearTimer();sx=e.clientX;sy=e.clientY;
  timer=setTimeout(function(){timer=null;begin(it)},HOLD);
 },true);
 document.addEventListener('pointermove',function(e){if(timer&&Math.abs(e.clientX-sx)+Math.abs(e.clientY-sy)>MOVE)clearTimer()},true);
 function up(){clearTimer();if(swallow){clearTimeout(swT);swT=setTimeout(function(){swallow=false},400)}}
 document.addEventListener('pointerup',up,true);
 document.addEventListener('pointercancel',up,true);
 window.addEventListener('scroll',clearTimer,true);
 document.addEventListener('contextmenu',function(e){if(itemOf(e.target)&&(timer||swallow||sel.size))e.preventDefault()},true);
 /* إلغاء قائمة الفاتورة القديمة؛ الشريط العلوي يحل محلها */
 window.startInvoiceLongPress=function(){};
 function stop(e){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation()}
 document.addEventListener('click',function(e){
  if(e.target.closest&&e.target.closest('#lpTopBar,#lpPicker'))return;
  if(swallow){swallow=false;clearTimeout(swT);stop(e);return}
  if(!sel.size)return;
  var it=itemOf(e.target);
  if(it&&it.type===ctx){stop(e);toggle(it.id)}
 },true);
 bar.addEventListener('click',function(e){var b=e.target.closest('button[data-a]');if(!b)return;e.stopPropagation();act(b.getAttribute('data-a'))});
 var pb=window.navigateBack;
 window.navigateBack=function(){if(sel.size){exit();return}return typeof pb==='function'?pb.apply(this,arguments):undefined};

 /* ---------- أدوات مساعدة: اختيار + طباعة ---------- */
 function pick(title,opts,cb,extra){
  var old=$('lpPicker');if(old)old.remove();
  var ov=document.createElement('div');ov.id='lpPicker';
  ov.innerHTML='<div class="lp-pbox"><div class="lp-ptitle">'+esc(title)+'</div>'+(extra||'')+opts.map(function(o,i){return '<button type="button" data-i="'+i+'">'+o.label+'</button>'}).join('')+'<button type="button" data-i="x" class="lp-pcancel">إلغاء</button></div>';
  ov.addEventListener('click',function(e){
   if(e.target===ov){ov.remove();return}
   var b=e.target.closest('button[data-i]');if(!b)return;
   var i=b.getAttribute('data-i'),inp=ov.querySelector('input'),val=inp?inp.value:'';
   ov.remove();if(i!=='x')cb(opts[+i],val);
  });
  document.body.appendChild(ov);
 }
 function printHTML(title,body){
  if(window.__pdfFromBody&&window.__printMethod&&window.__printMethod()!=='printer'){window.__pdfFromBody(title,body);return}
  var fr=document.createElement('iframe');fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0';
  document.body.appendChild(fr);
  var d=fr.contentWindow.document;d.open();
  var luxCss=(window.__luxCss&&window.__luxActive&&window.__luxActive())?window.__luxCss(true):'';
  d.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>'+esc(title)+'</title><style>body{font-family:Arial,Tahoma,sans-serif;color:#111;padding:10mm}h2{text-align:center;color:#4A1520;margin:0 0 12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #cbd5e1;padding:6px 8px;text-align:center;font-size:12px}th{background:#64182c;color:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}'+luxCss+'</style></head><body>'+body+'</body></html>');
  d.close();
  window.__printGuard&&window.__printGuard(8000);setTimeout(function(){try{fr.contentWindow.focus();fr.contentWindow.print()}catch(e){say('تعذرت الطباعة')}setTimeout(function(){fr.remove()},2500)},300);
 }
 function tableHTML(title,heads,rows){
  return '<h2>'+esc(title)+'</h2><table><thead><tr>'+heads.map(function(h){return '<th>'+esc(h)+'</th>'}).join('')+'</tr></thead><tbody>'+rows.map(function(r){return '<tr>'+r.map(function(c){return '<td>'+esc(c)+'</td>'}).join('')+'</tr>'}).join('')+'</tbody></table>';
 }

 /* ---------- الفواتير (داخل المجلد) ---------- */
 function fld(){var el=document.querySelector(ITEM_INV);var id=el?el.getAttribute('data-folder-id'):null;return (data.folders||[]).find(function(f){return String(f.id)===String(id)})||null}
 function selInv(f){return (f.invoices||[]).filter(function(i){return sel.has(String(i.id))})}
 function chooseFolder(title,includeCurrent,cb){
  var cur=fld();
  var list=(data.folders||[]).filter(function(f){return !f.locked&&window.__inScope(f)&&(includeCurrent||!cur||String(f.id)!==String(cur.id))});
  if(!list.length){say('لا يوجد مجلد متاح');return}
  pick(title,list.map(function(f){return {label:'📁 '+esc(f.name||'مجلد')+((cur&&String(f.id)===String(cur.id))?' (الحالي)':''),f:f}}),function(o){cb(o.f)});
 }
 var H={};
 H.invoice={
  delete:function(){
   var n=sel.size;
   ask('هل تريد نقل '+n+' فاتورة إلى سلة المحذوفات؟',function(){
    var f=fld();if(!f)return;
    var removed=(f.invoices||[]).filter(function(i){return sel.has(String(i.id))});removed.forEach(function(i){addToTrash(i,'invoice',i.initInvoice||i.initName||i.name||'فاتورة',f.id)});f.invoices=(f.invoices||[]).filter(function(i){return !sel.has(String(i.id))});
    save();if(window.__afterFolderInvoicesChanged)window.__afterFolderInvoicesChanged(f.id);exit();renderCurrentView();say('نُقلت '+n+' فاتورة إلى سلة المحذوفات');
   },'حذف فواتير');
  },
  copy:function(){
   chooseFolder('نسخ الفواتير المحددة إلى',true,function(t){
    var f=fld();if(!f)return;var items=selInv(f),now=Date.now();
    t.invoices=t.invoices||[];
    items.forEach(function(inv,k){var c=JSON.parse(JSON.stringify(inv));c.id='invoice-'+now+'-'+k+'-'+Math.random().toString(36).slice(2,6);c.folderId=t.id;c.createdAt=now+k;c.updatedAt=now+k;t.invoices.push(c)});
    save();exit();renderCurrentView();say('تم نسخ '+items.length+' فاتورة إلى «'+(t.name||'مجلد')+'»');
   });
  },
  move:function(){
   chooseFolder('نقل الفواتير المحددة إلى',false,function(t){
    var f=fld();if(!f)return;var items=selInv(f);
    t.invoices=t.invoices||[];
    items.forEach(function(inv){inv.folderId=t.id;t.invoices.push(inv)});
    f.invoices=(f.invoices||[]).filter(function(i){return !sel.has(String(i.id))});
    save();if(window.__afterFolderInvoicesChanged){window.__afterFolderInvoicesChanged(f.id);window.__afterFolderInvoicesChanged(t.id);}exit();renderCurrentView();say('تم نقل '+items.length+' فاتورة إلى «'+(t.name||'مجلد')+'»');
   });
  },
  print:function(){
   var f=fld();if(!f)return;var items=selInv(f);if(!items.length)return;
   var c=$('invoicePreviewContent'),m=$('invoicePreviewModal');if(!c||!m||typeof invoicePreviewHTML!=='function'){say('تعذرت الطباعة');return}
   c.innerHTML=items.map(function(i){return invoicePreviewHTML(i)}).join('<div style="page-break-after:always;break-after:page;height:8px"></div>');
   m.style.display='block';exit();
   setTimeout(function(){if(typeof printInvoicePreview==='function')printInvoicePreview()},150);
  },
  more:function(){
   var el=document.querySelector(ITEM_INV+'.lp-sel');if(!el)return;
   _longPressedInvoice={invoiceId:el.getAttribute('data-invoice-id'),folderId:el.getAttribute('data-folder-id')};
   exit();var m=$('invoiceLongPressMenu');if(m)m.style.display='flex';
  }
 };

 /* ---------- الفلاتر الأسبوعية ---------- */
 function selFilters(){return getSavedWeeklyFilters().filter(function(f){return sel.has(String(f.id))})}
 function reRenderFilters(){if(typeof window.renderWeeklyFilterAccounts==='function')window.renderWeeklyFilterAccounts()}
 H.filter={
  delete:function(){
   var n=sel.size;
   ask('هل تريد نقل '+n+' فلتر إلى سلة المحذوفات؟',function(){
    var all=rd(WK),removed=all.filter(function(x){return x&&sel.has(String(x.id))});removed.forEach(function(x){addToTrash(x,'weeklyFilter',x.name||'فلتر أسبوعي')});wr(WK,all.filter(function(x){return !(x&&sel.has(String(x.id)))}));
    exit();reRenderFilters();say('نُقلت '+n+' فلاتر إلى سلة المحذوفات');
   },'حذف فلاتر');
  },
  copy:function(){
   var items=selFilters(),l=rd(WK),now=Date.now();
   items.forEach(function(f,k){var c=JSON.parse(JSON.stringify(f));c.id=String(now+k);c.name=f.name+' (نسخة)';c.updatedAt=now;l.unshift(c)});
   if(wr(WK,l)){exit();reRenderFilters();say('تم نسخ '+items.length+' فلتر')}
  },
  move:function(){
   var items=selFilters();
   var first=items.map(function(f){return f.fromDate}).filter(Boolean).sort()[0]||'';
   pick('نقل فترة الفلاتر المحددة',[{label:'✔ نقل'}],function(o,val){
    if(!val||!first){say('حدد بداية الفترة الجديدة');return}
    var delta=Math.round((new Date(val+'T12:00:00')-new Date(first+'T12:00:00'))/86400000);
    if(!delta){say('لم تتغير الفترة');return}
    var ids={};items.forEach(function(f){ids[String(f.id)]=1});
    var l=rd(WK);l.forEach(function(f){if(f&&ids[String(f.id)]){f.fromDate=shiftDate(f.fromDate,delta);f.toDate=shiftDate(f.toDate,delta);f.updatedAt=Date.now()}});
    if(wr(WK,l)){exit();reRenderFilters();say('تم نقل فترة '+items.length+' فلتر')}
   },'<label>بداية الفترة الجديدة<input type="date" value="'+esc(first)+'"></label>');
  },
  print:function(){
   var items=selFilters();if(!items.length)return;
   window.__printWeeklyList(items);
  },
  detail:function(){
   var items=selFilters();
   var from=items.map(function(f){return f.fromDate}).filter(Boolean).sort()[0];
   var to=items.map(function(f){return f.toDate||f.fromDate}).filter(Boolean).sort().slice(-1)[0];
   exit();
   function finish(){
    if(typeof window.openFullFilterPage==='function')window.openFullFilterPage('detail');
    var a=$('ffDateFrom'),b=$('ffDateTo');if(from&&a)a.value=from;if(to&&b)b.value=to;
    if(typeof window.applyFullFilterDates==='function')window.applyFullFilterDates();
    if(typeof window.renderDetailList==='function')window.renderDetailList();
   }
   /* نقل بيانات كل فلتر محدد إلى تفصيله بالتتابع (نفس زر: تفصيل - نقل البيانات) */
   var k=0;
   (function next(){
    if(k>=items.length){finish();return}
    window.transferWeeklyToDetail(items[k++].id);
    var t=0,iv=setInterval(function(){t++;if((!$('detailEntryModal')&&t>8)||t>200){clearInterval(iv);next()}},150);
   })();
  }
 };

 /* ---------- التفصيل ---------- */
 function selDetails(){var out=[];rd(DK).forEach(function(a){(a.invoices||[]).forEach(function(i){if(sel.has(String(i.id)))out.push(i)})});return out}
 function reRenderDetails(){if(typeof window.renderDetailList==='function')window.renderDetailList()}
 function detTotals(inv,t){
  var fd=inv.formData||{};
  function num(){for(var j=0;j<arguments.length;j++){var v=fd[arguments[j]];if(v!==undefined&&v!==null&&v!==''){var n=Number(String(v).replace(/,/g,''));if(Number.isFinite(n))return n}}return 0}
  t.sale+=num('finalSale','saleFinal','totalSale','calc_saleFinal','calc_mTotal');
  t.workers+=num('workersOut','workerOut','totalWorkers','calc_workersOut');
  t.withdraw+=num('withdrawTotal','totalWithdraw','calc_withdraw');
  t.debts+=num('debtSale','totalDebt','calc_debt')-num('moneyDelivered','deliveredMoney','calc_delivered');
  t.currency+=num('yemeniExchange','exchangeYemeni','currencyYemeni')+num('saudiExchange','exchangeSaudi','currencySaudi')+num('omaniExchange','exchangeOmani','currencyOmani');
 }
 H.detail={
  delete:function(){
   var n=sel.size;
   ask('هل تريد نقل '+n+' تفصيل إلى سلة المحذوفات؟',function(){
    var acc=rd(DK);acc.forEach(function(a){if(Array.isArray(a.invoices)){a.invoices.filter(function(i){return sel.has(String(i.id))}).forEach(function(i){addToTrash(i,'detail',i.initDetail||i.name||'تفصيل',a.id)});a.invoices=a.invoices.filter(function(i){return !sel.has(String(i.id))})}});
    if(wr(DK,acc)){exit();reRenderDetails();say('نُقل '+n+' تفصيل إلى سلة المحذوفات')}
   },'حذف تفصيلات');
  },
  copy:function(){
   var acc=rd(DK),now=Date.now(),k=0;
   acc.forEach(function(a){
    var add=[];(a.invoices||[]).forEach(function(i){if(sel.has(String(i.id))){var c=JSON.parse(JSON.stringify(i));c.id=now+(k++);c.createdAt=c.id;c.initDetail=(i.initDetail||'تفصيل')+' (نسخة)';add.push(c)}});
    if(add.length)a.invoices=a.invoices.concat(add);
   });
   if(wr(DK,acc)){exit();reRenderDetails();say('تم نسخ '+k+' تفصيل')}
  },
  move:function(){
   var l=getSavedWeeklyFilters();if(!l.length){say('لا توجد فلاتر أسبوعية لنقل التفصيل إليها');return}
   pick('نقل التفاصيل المحددة إلى الفلتر',l.map(function(f){return {label:'🗓️ '+esc(f.name),name:f.name}}),function(o){
    var acc=rd(DK),n=0;
    acc.forEach(function(a){(a.invoices||[]).forEach(function(i){if(sel.has(String(i.id))){i.initFilter=o.name;n++}})});
    if(wr(DK,acc)){exit();reRenderDetails();say('تم نقل '+n+' تفصيل إلى «'+o.name+'»')}
   });
  },
  print:function(){
   var items=selDetails();if(!items.length)return;
   if(items.length===1&&typeof window.openDetailEntry==='function'){var id=String(items[0].id);exit();window.openDetailEntry(id,{readonly:true,print:true});return}
   printHTML('التفصيلات',tableHTML('التفصيلات',['التفصيل','الفلتر','الفترة','الإجمالي'],items.map(function(i){
    var fd=i.formData||{};return [i.initDetail||'تفصيل بدون اسم',i.initFilter||'—',(i.initDateFrom||'')+((i.initDateTo&&i.initDateTo!==i.initDateFrom)?' → '+i.initDateTo:''),fd.calc_mTotal||fd.calc_midTotal||'—'];
   })));
  },
  clock:function(){
   var items=selDetails();
   if(typeof window.__clockFromDetail!=='function'){say('تعذر الترحيل إلى المراقب');return}
   var n=0;items.forEach(function(i){var r=window.__clockFromDetail(i);if(r&&Object.keys(r).some(function(k){return r[k]}))n++});
   exit();
   if(typeof window.closeFullFilterPage==='function')window.closeFullFilterPage();
   if(typeof showHome==='function')showHome();
   say(n?('تم إرسال '+n+' تفصيل إلى المراقب'):'لا توجد مبالغ في التفصيل المحدد لإرسالها');
  }
 };

window.lpExit=function(){exit()};
 window.lpSelectAll=function(){
  var c=null,p=$('fullFilterPage');
  if(p&&p.classList.contains('show'))c=isDetailPage()?'detail':'filter';else if(document.querySelector(ITEM_INV))c='invoice';
  if(!c)return;
  var els=Array.prototype.slice.call(document.querySelectorAll(selOf(c))).filter(function(el){return el.getClientRects().length>0});
  if(!els.length){say('لا توجد عناصر للتحديد');return}
  ctx=c;sel.clear();els.forEach(function(el){sel.add(idOf(c,el))});refresh();startPoll();
 };
 function act(a){
  if(a==='close'){exit();return}
  if(a==='all'){
   var els=allEls();
   if(els.length&&sel.size>=els.length){exit();return}
   els.forEach(function(el){sel.add(idOf(ctx,el))});refresh();return;
  }
  if(!sel.size||!ctx)return;
  var h=H[ctx]&&H[ctx][a];if(h)h();
 }
})();

/* source script: specialties-feature */
(function(){
 'use strict';
 if(window.__specFeature)return;window.__specFeature=true;
 var $=function(id){return document.getElementById(id)};
 var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 function say(t){try{toast(t)}catch(e){}}
 var forceCtx=null;
 function isBuyer(){return (forceCtx||window.invScope||'home')==='buyer'}
 function sKey(){return isBuyer()?'buyerSpecialties':'specialties'}
 function aKey(){return isBuyer()?'buyerActiveSpecialty':'activeSpecialty'}
 function specs(){if(!Array.isArray(data.settings[sKey()]))data.settings[sKey()]=[];return data.settings[sKey()]}
 function active(){var a=data.settings[aKey()]||'all';if(a!=='all'&&!specs().some(function(s){return String(s.id)===String(a)}))a='all';return a}
 function okId(sid){var a=active();return a==='all'||String(sid||'')===String(a)}
 function folderOfFilter(fl){return fl&&(data.folders||[]).find(function(f){return String(f.id)===String(fl.sourceFolderId)})}
 window.__specOkFolder=function(f){return okId(f&&f.specialtyId)};
 function scopeOkFilter(fl){var fo=folderOfFilter(fl);return !fo||window.__inScope(fo)}
 window.__specOkInv=function(inv,folder){return okId((inv&&inv.specialtyId)||(folder&&folder.specialtyId))};
 window.__specOkFilter=function(fl){var fo=folderOfFilter(fl);if(!scopeOkFilter(fl))return false;return okId((fl&&fl.specialtyId)||(fo&&fo.specialtyId))};
 window.__specOkDetail=function(i){
  if(active()==='all')return true;
  var name=String(i.initFilter||'').trim();
  var fl=getSavedWeeklyFilters().find(function(x){return String(x.name||'').trim()===name});
  var fo=folderOfFilter(fl);
  return okId(i.specialtyId||(fl&&fl.specialtyId)||(fo&&fo.specialtyId));
 };

 /* ---------- شريط التخصيص ---------- */
 function barHTML(showAll){
  var a=active();
  var opts='<option value="all"'+(a==='all'?' selected':'')+'>كل التخاصيص</option>'+specs().map(function(s){return '<option value="'+esc(s.id)+'"'+(String(s.id)===String(a)?' selected':'')+'>'+esc(s.name)+'</option>'}).join('');
  return '<div class="spec-bar"><span class="spec-lbl">التخاصيص</span><select class="spec-sel" onchange="__specChange(this.value)">'+opts+'</select>'+(showAll?'<label class="spec-all"><input type="checkbox" onchange="__specAll(this.checked)"> تحديد الكل</label>':'')+'</div>';
 }
 function injectHome(){
  var box=$('currentView'),inv=$('invoices');
  if(!box||!inv||!inv.classList.contains('on'))return;
  var old=box.querySelector(':scope>.spec-bar');if(old)old.remove();
  box.insertAdjacentHTML('afterbegin',barHTML(currentFolderId!==null));
 }
 function fillFF(){
  var p=$('fullFilterPage');if(!p)return;
  var host=$('ffSpecHost');
  if(!host){var empty=p.querySelector('.ff-empty');if(!empty)return;host=document.createElement('div');host.id='ffSpecHost';empty.parentNode.insertBefore(host,empty)}
  host.innerHTML=barHTML(true);
 }
 function ffShown(){var p=$('fullFilterPage');return !!p&&p.classList.contains('show')}
 function isDetailPage(){var t=$('ffTitle');return !!t&&String(t.textContent||'').trim()==='التفصيل'}
 function hideFilters(){
  var btns=document.querySelectorAll('#fullFilterPage .ff-empty>div>button');if(!btns.length)return;
  var list=getSavedWeeklyFilters(),shown=0;
  var byId={};list.forEach(function(f){byId[String(f.id)]=f});
  Array.prototype.forEach.call(btns,function(b){var fl=byId[b.getAttribute('data-wf-id')];var ok=!fl||window.__specOkFilter(fl);b.style.display=ok?'':'none';if(ok)shown++});
  var grid=btns[0].parentNode,old=grid.parentNode.querySelector('.sp-none');if(old)old.remove();
  
 }
 function refreshAll(){
  if($('invoices')&&$('invoices').classList.contains('on')&&typeof renderCurrentView==='function')renderCurrentView();
  if(ffShown()){fillFF();if(isDetailPage()){if(typeof window.renderDetailList==='function')window.renderDetailList()}else if(typeof window.renderWeeklyFilterAccounts==='function')window.renderWeeklyFilterAccounts()}
 }
 window.__specChange=function(v){data.settings[aKey()]=v||'all';save();if(window.lpExit)window.lpExit();refreshAll()};
 window.__specAll=function(on){if(on){if(window.lpSelectAll)window.lpSelectAll()}else if(window.lpExit)window.lpExit()};
 document.addEventListener('lpexit',function(){Array.prototype.forEach.call(document.querySelectorAll('.spec-all input'),function(c){c.checked=false})});

 var rcv=window.renderCurrentView;
 window.renderCurrentView=function(){var r=rcv.apply(this,arguments);try{injectHome()}catch(e){}return r};
 var rwf=window.renderWeeklyFilterAccounts;
 window.renderWeeklyFilterAccounts=function(){var r=rwf.apply(this,arguments);try{hideFilters()}catch(e){}return r};
 var ofp=window.openFullFilterPage;
 window.openFullFilterPage=function(){var r=ofp.apply(this,arguments);try{fillFF()}catch(e){}return r};

 /* ---------- نافذة إضافة الأسبوع ---------- */
 function fillFolderSel(val){
  var s=$('folderSpecialty');if(!s)return;
  s.innerHTML='<option value="">بدون تخصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>'}).join('');
  s.value=val||'';
 }
 var ofa=window.openFolderAdd;
 window.openFolderAdd=function(){var r=ofa.apply(this,arguments);var a=active();fillFolderSel(a==='all'?'':a);return r};
 var ofe=window.openFolderEdit;
 window.openFolderEdit=function(id){var r=ofe.apply(this,arguments);var f=data.folders.find(function(x){return x.id===id});fillFolderSel(f&&f.specialtyId);return r};
 var sf=window.saveFolder;
 window.saveFolder=function(){
  var v=($('folderSpecialty')||{}).value||'',before=data.folders.length,editId=editFolderId;
  var r=sf.apply(this,arguments);
  var modal=$('folderModal');if(modal&&modal.classList.contains('show'))return r;
  var f=editId?data.folders.find(function(x){return x.id===editId}):(data.folders.length>before?data.folders[data.folders.length-1]:null);
  if(f){f.specialtyId=v;if(!editId&&isBuyer())f.scope='buyer';if(f.scope==='buyer'&&window.bpEnsureWeek)window.bpEnsureWeek(f);save();renderCurrentView();if(window.bpRefresh)window.bpRefresh()}
  return r;
 };

 /* ---------- صفحة التخصيص في الإعدادات ---------- */
 function newId(){return 'sp'+Date.now()+Math.random().toString(36).slice(2,5)}
 function rerenderSpec(){var c=$('subContent');if(c)c.innerHTML=renderSpec()}
 function renderSpec(){
  var l=specs(),allOn=active()==='all';
  return '<div class="settingsCard"><div class="optionRow"><div><b>كل التخاصيص</b></div><button type="button" class="switch '+(allOn?'on':'')+'" onclick="__specToggleAll()"><i></i></button></div></div>'
   +l.map(function(s){return '<div class="settingsCard sp-row"><b>'+esc(s.name)+'</b><div class="sp-acts"><button type="button" onclick="__specEdit(\''+esc(s.id)+'\')">✏️</button><button type="button" onclick="__specDel(\''+esc(s.id)+'\')">🗑</button></div></div>'}).join('')
   +''
   +'<div style="text-align:center;margin:14px 0"><button type="button" class="sp-plus" onclick="__specAdd()">+</button></div>';
 }
 function promptText(title,val,cb,amt){
  var old=$('spPrompt');if(old)old.remove();
  var ov=document.createElement('div');ov.id='spPrompt';
  ov.innerHTML='<div class="box"><b>'+esc(title)+'</b><label style="font-size:13px;font-weight:800">الاسم</label><input type="text" value="'+esc(val||'')+'" placeholder="اكتب الاسم"><label style="font-size:13px;font-weight:800">مبلغ حق العمال (لكل فاتورة)</label><input type="number" inputmode="decimal" step="any" class="spAmt" value="'+esc(amt==null?'':amt)+'" placeholder="0"><div class="row"><button type="button" class="ok">💾 حفظ</button><button type="button" class="no">إلغاء</button></div></div>';
  ov.addEventListener('click',function(e){
   if(e.target===ov||e.target.classList.contains('no')){ov.remove();return}
   if(e.target.classList.contains('ok')){var v=ov.querySelector('input').value.trim();if(!v){say('أدخل اسم التخصيص');return}var am=parseFloat(ov.querySelector('.spAmt').value)||0;ov.remove();cb(v,am)}
  });
  document.body.appendChild(ov);setTimeout(function(){var i=ov.querySelector('input');if(i)i.focus()},50);
 }
 window.__specAdd=function(){promptText('إضافة تخصيص','',function(v,am){specs().push({id:newId(),name:v,workersAmount:am});save();rerenderSpec();say('تمت إضافة التخصيص')},'')};
 window.__specEdit=function(id){var s=specs().find(function(x){return String(x.id)===String(id)});if(!s)return;promptText('تعديل التخصيص',s.name,function(v,am){s.name=v;s.workersAmount=am;save();rerenderSpec();(data.folders||[]).forEach(function(f){if(String(f.specialtyId)===String(s.id)&&window.__queueAutoSync)window.__queueAutoSync(f.id)})},s.workersAmount||'')};
 window.__specDel=function(id){
  var run=function(){
   data.settings[sKey()]=specs().filter(function(x){return String(x.id)!==String(id)});
   (data.folders||[]).forEach(function(f){if(String(f.specialtyId)===String(id))f.specialtyId=''});
   if(String(data.settings[aKey()])===String(id))data.settings[aKey()]='all';
   save();rerenderSpec();say('تم حذف التخصيص');
  };
  if(typeof customConfirm==='function')customConfirm('حذف هذا التخصيص؟ ستبقى الأسابيع بدون تخصيص.',run,null,{title:'حذف تخصيص',icon:'🗑️',danger:true,confirmText:'حذف',cancelText:'إلغاء'});else if(confirm('حذف هذا التخصيص؟'))run();
 };
 window.__specToggleAll=function(){
  if(active()==='all'){var l=specs();if(!l.length){say('أضف تخصيصًا أولاً');return}data.settings[aKey()]=l[0].id}
  else data.settings[aKey()]='all';
  save();rerenderSpec();
 };
 var rsp=window.renderSettingsPage;
 window.renderSettingsPage=function(p){return (p==='specialties'||p==='buyerSpecialties')?renderSpec():rsp.apply(this,arguments)};
 var osp=window.openSettingsPage;
 window.openSettingsPage=function(p){
  forceCtx=p==='buyerSpecialties'?'buyer':p==='specialties'?'home':null;
  var r=osp.apply(this,arguments);
  if(p==='specialties'){var t=$('subTitle'),d=$('subDesc');if(t)t.textContent='التخصيص';if(d)d.textContent='إدارة التخاصيص'}
  if(p==='buyerSpecialties'){var t2=$('subTitle'),d2=$('subDesc');if(t2)t2.textContent='تخصيص الشرائي';if(d2)d2.textContent='إدارة تخاصيص فواتير الشرائي'}
  return r;
 };
 var csp=window.closeSettingsPage;
 if(typeof csp==='function')window.closeSettingsPage=function(){forceCtx=null;return csp.apply(this,arguments)};
 fillFF();
})();

/* source script: invoices-home-back */
(function(){
 'use strict';
 if(window.__invHomeBack)return;window.__invHomeBack=true;
 var $=function(id){return document.getElementById(id)};
 var menu=$('menuBtn');if(!menu||!menu.parentNode)return;
 var b=document.createElement('button');
 b.id='invBackBtn';b.type='button';b.className='ui-back';b.title='رجوع إلى الرئيسية';
 b.innerHTML='<span style="font-size:15px;line-height:1">←</span><span style="margin-inline-start:4px;font-size:13px;font-weight:800">رجوع</span>';
 b.style.display='none';
 b.addEventListener('click',function(e){e.stopPropagation();if(typeof showHome==='function')showHome()});
 
 function atInvoicesRoot(){
  var inv=$('invoices');
  try{return !!inv&&inv.classList.contains('on')&&!currentFolderId&&!document.body.classList.contains('statement-view')}catch(e){return false}
 }
 function sync(){b.style.setProperty('display',atInvoicesRoot()?'inline-flex':'none','important')}
 window.__syncInvBack=sync;
 var inv=$('invoices');if(inv)new MutationObserver(sync).observe(inv,{attributes:true,attributeFilter:['class']});
 var ht=$('headerTitle');if(ht)new MutationObserver(sync).observe(ht,{childList:true,characterData:true,subtree:true});
 var cv=$('currentView');if(cv)new MutationObserver(sync).observe(cv,{childList:true});
 new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['class']});
 document.addEventListener('click',function(){setTimeout(sync,60)},true);
 sync();
 /* زر رجوع الهاتف من صفحة الفواتير يعود للرئيسية بدل رسالة الخروج */
 var nb=window.navigateBack;
 window.navigateBack=function(){
  try{
   var busy=document.querySelector('.overlay.show')||($('lpTopBar')&&$('lpTopBar').classList.contains('show'))||($('fullFilterPage')&&$('fullFilterPage').classList.contains('show'))||($('folderInvoiceModal')&&$('folderInvoiceModal').classList.contains('show'))||($('sideMenuOverlay')&&$('sideMenuOverlay').classList.contains('show'));
   if(!busy&&atInvoicesRoot()&&typeof navStack!=='undefined'&&navStack.length===0){showHome();return}
  }catch(e){}
  return typeof nb==='function'?nb.apply(this,arguments):undefined;
 };
})();

/* source script: print-sort-dates */
(function(){
 'use strict';
 if(window.__psd)return;window.__psd=true;
 var $=function(id){return document.getElementById(id)};
 function say(t){try{toast(t)}catch(e){}}
 function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
 function ffShown(){var p=$('fullFilterPage');return !!p&&p.classList.contains('show')}
 function isDetailPage(){var t=$('ffTitle');return !!t&&String(t.textContent||'').trim()==='التفصيل'}

 /* ================= 1) منع الإدخال النصي في حقول التاريخ ================= */
 function lockDate(i){
  if(i.__dl)return;i.__dl=1;
  try{i.setAttribute('inputmode','none');i.setAttribute('autocomplete','off')}catch(e){}
  i.addEventListener('keydown',function(e){if(e.key==='Tab'||e.key==='Escape'||e.key==='Enter')return;e.preventDefault()});
  i.addEventListener('beforeinput',function(e){e.preventDefault()});
  i.addEventListener('paste',function(e){e.preventDefault()});
  i.addEventListener('drop',function(e){e.preventDefault()});
  i.addEventListener('click',function(){try{if(typeof i.showPicker==='function')i.showPicker()}catch(x){}});
 }
 function lockTextDate(i){
  if(i.__dl)return;i.__dl=1;
  try{i.readOnly=true;i.setAttribute('inputmode','none');i.setAttribute('autocomplete','off')}catch(e){}
  i.addEventListener('click',function(){
   try{
    var d=i.ownerDocument,t=d.getElementById(String(i.id||'').replace(/-text$/,''));
    if(t&&t!==i&&t.type==='date'&&typeof t.showPicker==='function'){t.showPicker();return}
    var btn=i.parentNode&&i.parentNode.querySelector('button');if(btn)btn.click();
   }catch(x){}
  });
 }
 function fmtD(v){var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v||''));return m?m[3]+'/'+m[2]+'/'+m[1]:''}
 function openNative(i){try{if(typeof i.showPicker==='function'){i.showPicker();return}}catch(e){}try{i.focus();i.click()}catch(e){}}
 function enhanceDate(i){
  if(i.__dx||!i.parentNode)return;i.__dx=1;
  var wrap=i.ownerDocument.createElement('span');wrap.className='dx-date';
  var txt=i.ownerDocument.createElement('input');txt.type='text';txt.readOnly=true;txt.className=(i.className||'')+' dx-text';
  txt.placeholder='dd/mm/yyyy';txt.setAttribute('inputmode','none');txt.setAttribute('autocomplete','off');txt.setAttribute('aria-label',i.getAttribute('aria-label')||'التاريخ');
  var btn=i.ownerDocument.createElement('button');btn.type='button';btn.className='dx-btn';btn.textContent='📆';btn.setAttribute('aria-label','فتح التقويم');
  i.parentNode.insertBefore(wrap,i);wrap.appendChild(txt);wrap.appendChild(btn);wrap.appendChild(i);
  i.classList.add('dx-native');i.__dxTxt=txt;txt.value=fmtD(i.value);
  txt.addEventListener('click',function(){openNative(i)});
  btn.addEventListener('click',function(e){e.preventDefault();openNative(i)});
  i.addEventListener('change',function(){txt.value=fmtD(i.value)});
  i.addEventListener('input',function(){txt.value=fmtD(i.value)});
 }
 /* كل تعيين برمجي لقيمة حقل التاريخ يحدّث الصندوق النصي dd/mm/yyyy */
 (function(){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');if(!d||!d.set)return;
  Object.defineProperty(HTMLInputElement.prototype,'value',{configurable:true,enumerable:d.enumerable,get:d.get,set:function(v){d.set.call(this,v);if(this.__dxTxt)this.__dxTxt.value=fmtD(this.value)}})})();
 function watch(doc){
  if(!doc||!doc.body)return;
  try{
   Array.prototype.forEach.call(doc.querySelectorAll('input[type="date"]'),function(i){lockDate(i);enhanceDate(i)});
   Array.prototype.forEach.call(doc.querySelectorAll('input.date-text,input[placeholder="dd/mm/yyyy"],input[type="text"][id*="ate"]'),lockTextDate);
   Array.prototype.forEach.call(doc.querySelectorAll('iframe'),function(fr){
    if(!fr.__dl){fr.__dl=1;fr.addEventListener('load',function(){try{watch(fr.contentDocument)}catch(e){}})}
    try{if(fr.contentDocument&&fr.contentDocument.readyState!=='loading')watch(fr.contentDocument)}catch(e){}
   });
   if(!doc.__dlObs){doc.__dlObs=new MutationObserver(function(){clearTimeout(doc.__dlT);doc.__dlT=setTimeout(function(){watch(doc)},300)});doc.__dlObs.observe(doc.body,{childList:true,subtree:true})}
  }catch(e){}
 }
 watch(document);
  window.__refreshDatePickers=function(){try{watch(document)}catch(e){}};

 /* ================= 2) شريط الترتيب: الأبجدية / التاريخ + تصاعدي / تنازلي ================= */
 var ST={ff:{by:'date',dir:'asc'},home:{by:'order',dir:'asc'}};
 try{var sv=JSON.parse(localStorage.getItem('ui_sort_v1')||'null');if(sv){ST.ff=Object.assign(ST.ff,sv.ff||{});ST.home=Object.assign(ST.home,sv.home||{})}}catch(e){}
 function saveST(){try{localStorage.setItem('ui_sort_v1',JSON.stringify(ST))}catch(e){}}
 function cmpStr(a,b){return String(a||'').localeCompare(String(b||''),'ar')}
 function num(v){return Number(v)||0}
 window.__ffCmpDetail=function(x,y){var S=ST.ff;var r=S.by==='name'?cmpStr(x.initDetail,y.initDetail):(String(x.initDateFrom||'').localeCompare(String(y.initDateFrom||''))||(num(x.createdAt||x.id)-num(y.createdAt||y.id)));return S.dir==='desc'?-r:r};
 window.__ffCmpFilter=function(x,y){var S=ST.ff;var r=S.by==='name'?cmpStr(x.name,y.name):(String(x.fromDate||'').localeCompare(String(y.fromDate||''))||(num(x.updatedAt||x.id)-num(y.updatedAt||y.id)));return S.dir==='desc'?-r:r};
 window.__cmpFolder=function(a,b){var S=ST.home,r;if(S.by==='name')r=cmpStr(a.name,b.name);else if(S.by==='date')r=String(a.startDate||'').localeCompare(String(b.startDate||''))||(num(a.createdAt)-num(b.createdAt));else r=(a.order||0)-(b.order||0);return S.dir==='desc'?-r:r};
 window.__cmpInv=function(a,b){
  /* ترتيب فواتير مجلد الأسبوع: افتراضيًا حسب تاريخ اليوم من بداية الأسبوع إلى نهايته، وحسب شريط الترتيب (تاريخ/أبجدية/مبلغ + تصاعدي/تنازلي) */
  var t=window._folderSortType||'date',o=window._folderSortOrder||'asc';
  function iso(i){var s=String(i.initDateISO||i.invoiceDateISO||'');if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;var m=String(i.initDate||'').match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);return m?m[1]+'-'+('0'+m[2]).slice(-2)+'-'+('0'+m[3]).slice(-2):''}
  function amt(i){return Math.abs(Number(i.buyerNet!=null?i.buyerNet:(i.amount!=null?i.amount:(i.buyerTotal!=null?i.buyerTotal:0))))||0}
  var byDate=function(){var x=iso(a),y=iso(b);return x&&y?x.localeCompare(y):(x?-1:(y?1:0))};
  var r;
  if(t==='name')r=cmpStr(a.initSeller,b.initSeller)||byDate();
  else if(t==='amount')r=(amt(a)-amt(b))||byDate();
  else r=byDate()||((a.createdAt||a.updatedAt||0)-(b.createdAt||b.updatedAt||0));
  return o==='desc'?-r:r;
 };
 function syncFF(){var S=ST.ff,by=$('ffSortBy'),a=$('ffSortAsc'),d=$('ffSortDesc');if(by)by.value=S.by;if(a)a.classList.toggle('active',S.dir==='asc');if(d)d.classList.toggle('active',S.dir==='desc')}
 window.setFullFilterSort=function(k){
  var S=ST.ff;
  if(k==='asc'||k==='desc'){S.dir=k;saveST()}else if(k==='date'||k==='name'||k==='amount'){S.by=k;saveST()}
  syncFF();
  if(k==='__sync')return;
  if(ffShown()){if(isDetailPage()){if(window.renderDetailList)window.renderDetailList()}else if(window.renderWeeklyFilterAccounts)window.renderWeeklyFilterAccounts()}
 };
 syncFF();
 /* شريط الترتيب في قائمة الأسابيع الرئيسية */
 window.__homeSort=function(k){var S=ST.home;if(k==='asc'||k==='desc')S.dir=k;else S.by=k;saveST();renderCurrentView()};
 function homeSortHTML(){
  var S=ST.home;
  function b(k,t){return '<button type="button" onclick="__homeSort(\''+k+'\')" style="padding:6px 10px;border-radius:8px;font-size:11px;font-weight:900;border:0;background:'+(S.dir===k?'var(--primary)':'transparent')+';color:'+(S.dir===k?'#fff':'var(--text)')+'">'+t+'</button>'}
  return '<div class="spec-bar home-sort"><span class="spec-lbl">ترتيب حسب:</span><select class="spec-sel" onchange="__homeSort(this.value)">'
   +'<option value="order"'+(S.by==='order'?' selected':'')+'>🔢 ترتيب الأسبوع</option><option value="date"'+(S.by==='date'?' selected':'')+'>📅 التاريخ</option><option value="name"'+(S.by==='name'?' selected':'')+'>🔤 الأبجدية</option></select>'
   +'<span style="display:flex;gap:3px;background:#f1f5f9;border-radius:10px;padding:3px">'+b('asc','↑ تصاعدي')+b('desc','↓ تنازلي')+'</span></div>';
 }
 var rc=window.renderCurrentView;
 window.renderCurrentView=function(){
  var r=rc.apply(this,arguments);
  try{
   var box=$('currentView'),inv=$('invoices');
   if(box&&inv&&inv.classList.contains('on')){
    var old=box.querySelector(':scope>.home-sort');if(old)old.remove();
    if(currentFolderId===null||currentFolderId===undefined){
     var bar=box.querySelector(':scope>.spec-bar');
     if(bar)bar.insertAdjacentHTML('afterend',homeSortHTML());else box.insertAdjacentHTML('afterbegin',homeSortHTML());
    }
   }
  }catch(e){}
  return r;
 };

 /* ================= 3) طباعة PDF: الفاتورة والفلتر والتفصيل ================= */
 var PAPER={a4:{w:794,pt:[595.28,841.89]},a3:{w:1123,pt:[841.89,1190.55]},'80':{w:302,pt:[226.77,0]},'58':{w:219,pt:[164.41,0]}};
 var FONTS={cairo:{fam:"'Cairo'",face:'Cairo'},honor:{fam:"'Honor Sans'",face:'Honor Sans'},arial:{fam:'Arial'},tahoma:{fam:'Tahoma'},times:{fam:"'Times New Roman'"}};
 var INVOICE_CSS="body{font-family:Arial,Tahoma,sans-serif;padding:0;color:#111;direction:rtl}.daily-print{font-family:Arial,Tahoma,sans-serif;color:#242235;background:#fff;border:2px solid #4A1520;padding:5mm;line-height:1.35}.daily-print h2{text-align:center;color:#4A1520;font-size:18pt;margin:2px 0 12px}.daily-table{width:100%;border-collapse:collapse;table-layout:fixed;margin:7px 0 10px}.daily-table th,.daily-table td{border:1px solid #e7d8dd;padding:4pt 3pt;text-align:center;font-size:9pt;overflow-wrap:anywhere}.daily-table th{background:#64182c;color:#fff;font-weight:900;-webkit-print-color-adjust:exact;print-color-adjust:exact}.daily-section{border:1px solid #e7d8dd;border-radius:8px;overflow:hidden;margin:7pt 0;break-inside:avoid}.daily-section h3{margin:0;padding:7pt;background:#f5f0f1;color:#4A1520;font-size:11pt;-webkit-print-color-adjust:exact;print-color-adjust:exact}.daily-three{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.daily-two{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.total-row td,.total-row th{font-weight:900;background:#f8e8ed;-webkit-print-color-adjust:exact;print-color-adjust:exact}.note-body{min-height:25px;padding:6px;white-space:pre-wrap}@page{size:A4 portrait;margin:8mm}";
 var GENERIC_CSS='body{padding:24px}h2{text-align:center;margin:0 0 14px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #cbd5e1;padding:7px 8px;text-align:center;font-size:13px}';
 function cfg(){
  var s=data.settings||{};
  var lx=!!(s.lux&&s.lux.on);return {method:s.printMethod||'pdf',paper:PAPER[s.paper]?s.paper:'a4',font:FONTS[s.printFont]?s.printFont:'cairo',scale:(Number(s.printFontScale)||100)/100,color:s.printColor||'#6B1A2F',text:s.printTextColor||'#111111',mode:lx?'color':(s.printColorMode||'color'),lux:lx};
 }
 window.__printMethod=function(){return cfg().method};
 var _ff={};
 function fontFaces(face){
  if(!face)return '';if(_ff[face]!=null)return _ff[face];
  var out=[];
  try{Array.prototype.forEach.call(document.styleSheets,function(ss){var rules;try{rules=ss.cssRules}catch(e){return}Array.prototype.forEach.call(rules,function(r){if(r.type===5){var fam=(r.style.getPropertyValue('font-family')||'').replace(/['"]/g,'').trim();if(fam===face)out.push(r.cssText)}})})}catch(e){}
  return (_ff[face]=out.join('\n'));
 }
 function overrideCSS(c){
  var F=FONTS[c.font],col=c.color,tx=c.text,P=PAPER[c.paper],pad=(P&&P.w>=794)?14:6;
  var base='*,*::before,*::after{animation:none!important;transition:none!important}html,body{margin:0!important'+(c.lux?'':';background:#fff!important')+'}'
   +'body{direction:rtl;zoom:'+c.scale+';box-sizing:border-box;padding-left:'+pad+'px;padding-right:'+pad+'px}'
   +'body,body *:not(svg):not(svg *){font-family:'+F.fam+',Arial,Tahoma,sans-serif!important}'
   +'table{max-width:100%}';
  /* الطباعة المرفهة تتحكم وحدها بالألوان والورقة: لا نفرض لون الطباعة ولا لون النص */
  if(c.lux)return base+'body{background-attachment:scroll!important}';
  return base
   +'html{--primary:'+col+';--primary-dark:'+col+';--accent:'+col+'}'
   +'body{color:'+tx+'}td,p,label,li,.note-body,.sub{color:'+tx+'}'
   +'h1,h2,h3,.daily-print h2,.daily-section h3{color:'+col+'!important}'
   +'.daily-table th,table th,thead th{background:'+col+'!important;color:#fff!important;border-color:'+col+'!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
   +'.daily-print{border-color:'+col+'!important}'
   +'.total-row td,.total-row th{background:#f4f4f4!important;color:'+tx+'!important}';
 }
 function buildDoc(bodyHtml,css){
  var c=cfg(),F=FONTS[c.font];
  return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>'+fontFaces(F.face)+'</style><style>'+(css||'')+'</style><style>'+overrideCSS(c)+'</style></head><body>'+bodyHtml+'</body></html>';
 }
 function bake(srcDoc,clone){
  var a=srcDoc.querySelectorAll('input,textarea,select'),b=clone.querySelectorAll('input,textarea,select');
  Array.prototype.forEach.call(a,function(el,i){
   var c=b[i];if(!c)return;
   if(el.tagName==='TEXTAREA'){c.textContent=el.value}
   else if(el.tagName==='SELECT'){Array.prototype.forEach.call(c.options,function(o,k){if(el.options[k]&&el.options[k].selected)o.setAttribute('selected','selected');else o.removeAttribute('selected')})}
   else if(el.type==='checkbox'||el.type==='radio'){if(el.checked)c.setAttribute('checked','checked');else c.removeAttribute('checked')}
   else c.setAttribute('value',el.value);
  });
 }
 function docFromFrame(fr){
  var d=fr.contentDocument,cl=d.documentElement.cloneNode(true);
  bake(d,cl);
  Array.prototype.forEach.call(cl.querySelectorAll('script,link,noscript'),function(n){n.remove()});
  Array.prototype.forEach.call(cl.querySelectorAll('style'),function(st){st.textContent=st.textContent.replace(/@import[^;]+;/g,'').replace(/@media\s+print/g,'@media all')});
  var c=cfg(),F=FONTS[c.font],head=cl.querySelector('head');
  var s1=d.createElement('style');s1.textContent=fontFaces(F.face);head.insertBefore(s1,head.firstChild);
  var s2=d.createElement('style');s2.textContent=overrideCSS(c);head.appendChild(s2);
  if(c.lux&&window.__luxApplyDoc)window.__luxApplyDoc(d,cl.querySelector('body'),cl);
  return '<!doctype html>'+cl.outerHTML;
 }
 function pdfFromJpegs(pages,pw,fixedH){
  var enc=new TextEncoder(),parts=[],pos=0,off=[];
  function w(x){if(typeof x==='string')x=enc.encode(x);parts.push(x);pos+=x.length}
  function o(id){off[id]=pos;w(id+' 0 obj\n')}
  var n=pages.length;
  w('%PDF-1.4\n');
  o(1);w('<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  var kids=[];for(var i=0;i<n;i++)kids.push((3+i*3)+' 0 R');
  o(2);w('<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+n+' >>\nendobj\n');
  pages.forEach(function(p,i){
   var po=3+i*3,co=po+1,io=po+2,ph=fixedH||p.hpt;
   o(po);w('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+pw.toFixed(2)+' '+ph.toFixed(2)+'] /Resources << /XObject << /Im0 '+io+' 0 R >> >> /Contents '+co+' 0 R >>\nendobj\n');
   var cs='q '+pw.toFixed(2)+' 0 0 '+p.hpt.toFixed(2)+' 0 '+(ph-p.hpt).toFixed(2)+' cm /Im0 Do Q';
   o(co);w('<< /Length '+cs.length+' >>\nstream\n'+cs+'\nendstream\nendobj\n');
   o(io);w('<< /Type /XObject /Subtype /Image /Width '+p.w+' /Height '+p.h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+p.bytes.length+' >>\nstream\n');w(p.bytes);w('\nendstream\nendobj\n');
  });
  var total=3+n*3,xo=pos;
  w('xref\n0 '+total+'\n0000000000 65535 f \n');
  for(var k=1;k<total;k++)w(String(off[k]).padStart(10,'0')+' 00000 n \n');
  w('trailer\n<< /Size '+total+' /Root 1 0 R >>\nstartxref\n'+xo+'\n%%EOF');
  return new Blob(parts,{type:'application/pdf'});
 }
 async function htmlToPdf(html){
  var c=cfg(),P=PAPER[c.paper],W=P.w;
  var fr=document.createElement('iframe');
  fr.setAttribute('aria-hidden','true');
  fr.style.cssText='position:fixed;left:-20000px;top:0;width:'+W+'px;height:100px;border:0;visibility:hidden';
  document.body.appendChild(fr);
  try{
   await new Promise(function(res){fr.onload=res;fr.srcdoc=html});
   var d=fr.contentDocument;
   try{await d.fonts.ready}catch(e){}
   await sleep(300);
   /* شبكة أمان: إن زاد عرض المحتوى عن الورقة (جدول عريض) نصغّره ليتسع بدل أن يُقتطع */
   var sw=d.documentElement.scrollWidth;
   for(var zi=0;zi<3&&sw>W+1;zi++){var z0=parseFloat(d.body.style.zoom)||c.scale||1;d.body.style.zoom=String(z0*W/sw*0.99);await sleep(150);sw=d.documentElement.scrollWidth}
   var H=Math.max(d.documentElement.scrollHeight,d.body.scrollHeight,200);
   fr.style.height=H+'px';await sleep(80);
   H=Math.max(d.documentElement.scrollHeight,d.body.scrollHeight,200);
   var bottoms=[];
   Array.prototype.forEach.call(d.querySelectorAll('tr,.daily-section,.daily-two,.daily-three,h2,h3,section,fieldset,.card,table,.note-body,p,li'),function(el){var r=el.getBoundingClientRect();if(r.height>0)bottoms.push(Math.ceil(r.bottom))});
   var pageH=P.pt[1]?Math.round(W*P.pt[1]/P.pt[0]):H;
   var cuts=[0],y=0;
   while(H-y>pageH+2){
    var limit=y+pageH,best=-1;
    for(var i=0;i<bottoms.length;i++){var bt=bottoms[i];if(bt<=limit&&bt>y+pageH*0.55&&bt>best)best=bt}
    if(best<0)best=limit;
    cuts.push(best);y=best;
   }
   cuts.push(H);
   /* تهيئة XHTML للرسم عبر SVG */
   var cl=d.documentElement.cloneNode(true);
   bake(d,cl);
   Array.prototype.forEach.call(cl.querySelectorAll('script,link,noscript,iframe'),function(n){n.remove()});
   var xml=new XMLSerializer().serializeToString(cl);
   var svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'"><foreignObject x="0" y="0" width="'+W+'" height="'+H+'">'+xml+'</foreignObject></svg>';
   var url='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
   var img=new Image();
   await new Promise(function(res,rej){img.onload=res;img.onerror=function(){rej(new Error('svg-load'))};img.src=url});
   try{await img.decode()}catch(e){}
   await sleep(250);
   var sc=Math.min(2,Math.sqrt(1.2e8/(W*H)),30000/H);
   var big=document.createElement('canvas');big.width=Math.max(1,Math.round(W*sc));big.height=Math.max(1,Math.round(H*sc));
   var g=big.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,big.width,big.height);
   g.drawImage(img,0,0,big.width,big.height);
   var filt=c.mode==='gray'?'grayscale(1)':(c.mode==='bw'?'grayscale(1) contrast(3)':'none');
   var pages=[];
   for(var k=0;k<cuts.length-1;k++){
    var y0=cuts[k],hh=cuts[k+1]-y0;if(hh<2)continue;
    var pc=document.createElement('canvas');pc.width=big.width;pc.height=Math.max(1,Math.round(hh*sc));
    var pg=pc.getContext('2d');pg.fillStyle='#fff';pg.fillRect(0,0,pc.width,pc.height);
    try{pg.filter=filt}catch(e){}
    pg.drawImage(big,0,Math.round(y0*sc),big.width,pc.height,0,0,pc.width,pc.height);
    if(k>0){
     var tc=document.createElement('canvas');tc.width=240;tc.height=240;var tg=tc.getContext('2d');tg.drawImage(pc,0,0,240,240);
     var px=tg.getImageData(0,0,240,240).data,ink=false;
     for(var q=0;q<px.length;q+=4){if(px[q]<235||px[q+1]<235||px[q+2]<235){ink=true;break}}
     if(!ink)continue;
    }
    var blob=await new Promise(function(res){pc.toBlob(res,'image/jpeg',0.92)});
    if(!blob)throw new Error('jpeg');
    pages.push({bytes:new Uint8Array(await blob.arrayBuffer()),w:pc.width,h:pc.height,hpt:hh*(P.pt[0]/W)});
   }
   if(!pages.length)throw new Error('empty');
   return pdfFromJpegs(pages,P.pt[0],P.pt[1]||0);
  }finally{fr.remove()}
 }
 function busy(on){
  var b=$('pdfBusy');
  if(on){if(!b){b=document.createElement('div');b.id='pdfBusy';b.textContent='⏳ جاري إنشاء ملف PDF…';document.body.appendChild(b)}}
  else if(b)b.remove();
 }
 function done(blob,title){
  var name=title+'-'+new Date().toISOString().slice(0,10)+'.pdf',url=URL.createObjectURL(blob);
  var old=$('pdfDone');if(old)old.remove();
  var ov=document.createElement('div');ov.id='pdfDone';
  ov.innerHTML='<div class="box"><b>✅ تم إنشاء ملف PDF</b><small>'+name.replace(/[<>&]/g,'')+' — '+Math.max(1,Math.round(blob.size/1024))+' ك.ب</small>'
   +'<button type="button" class="b main" data-a="save">💾 حفظ ملف PDF</button>'
   +'<a class="b" href="'+url+'" download="'+name.replace(/"/g,'')+'">تنزيل مباشر (بديل)</a>'
   +'<button type="button" class="b" data-a="share">📤 مشاركة</button>'
   +'<button type="button" class="b" data-a="view">👁 عرض</button>'
   +'<button type="button" class="b" data-a="close">إغلاق</button></div>';
  ov.addEventListener('click',function(e){
   if(e.target===ov){ov.remove();return}
   var a=e.target.getAttribute&&e.target.getAttribute('data-a');
   if(a==='close')ov.remove();
   else if(a==='save'){
    if(window.AndroidBridge&&typeof window.AndroidBridge.savePdfBase64==='function'){
     (async function(){
      try{
       var bytes=new Uint8Array(await blob.arrayBuffer()),binary='',chunk=0x8000;
       for(var i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+chunk,bytes.length)));
       window.AndroidBridge.savePdfBase64(btoa(binary),name);
      }catch(err){console.error('Native PDF save failed',err);say('تعذر حفظ PDF؛ جرّب تنزيل مباشر')}
     })();
    }else{
     var link=ov.querySelector('a[download]');if(link)link.click();else say('حفظ PDF غير مدعوم على هذا الجهاز');
    }
   }
   else if(a==='view'){window.open(url,'_blank')||say('تعذر فتح الملف؛ استخدم حفظ الملف')}
   else if(a==='share'){
    try{var f=new File([blob],name,{type:'application/pdf'});
     if(navigator.canShare&&navigator.canShare({files:[f]}))navigator.share({files:[f],title:title}).catch(function(){});
     else say('المشاركة غير مدعومة هنا؛ استخدم حفظ الملف');
    }catch(x){say('المشاركة غير مدعومة هنا؛ استخدم حفظ الملف')}
   }
  });
  document.body.appendChild(ov);
 }
 var running=false;
 async function runPdf(title,getHtml,onFail){
  if(running)return;running=true;busy(true);
  try{var html=getHtml();var blob=await htmlToPdf(html);busy(false);done(blob,title)}
  catch(e){busy(false);console.error('PDF failed',e);say('تعذر إنشاء PDF');if(onFail)try{onFail()}catch(x){}}
  finally{running=false}
 }
 window.__pdfFromBody=function(title,body){runPdf(title,function(){return buildDoc(body,GENERIC_CSS)})};
 window.__printFramePdf=function(fr,title){
  if(cfg().method==='printer'){window.__printGuard&&window.__printGuard(8000);try{if(cfg().lux&&window.__luxApplyDoc)window.__luxApplyDoc(fr.contentDocument)}catch(e){}try{fr.contentWindow.focus();fr.contentWindow.print()}catch(e){}return}
  runPdf(title,function(){return docFromFrame(fr)},function(){try{fr.contentWindow.print()}catch(e){}});
 };
 /* طباعة أي مستند كامل HTML (كشف الحساب / الرصيد / السند / الفلتر / التفصيل) كملف PDF حسب الإعدادات */
 window.__printDoc=function(str){str=window.__luxHtml(str);
  if(cfg().method==='printer')return false;
  var d=new DOMParser().parseFromString(String(str||''),'text/html');
  var css=Array.prototype.map.call(d.querySelectorAll('style'),function(st){return st.textContent.replace(/@import[^;]+;/g,'').replace(/@media\s+print/g,'@media all')}).join('\n');
  Array.prototype.forEach.call(d.querySelectorAll('script,link,noscript,iframe'),function(n){n.remove()});
  var bodyHtml=d.body?d.body.innerHTML:'';
  var title=(d.title||'').trim()||'مستند';
  runPdf(title,function(){return buildDoc(bodyHtml,css)},function(){});
  return true;
 };
 var opi=window.printInvoicePreview;
 window.printInvoicePreview=function(){
  var c=$('invoicePreviewContent');if(!c)return;
  if(cfg().method==='printer')return opi.apply(this,arguments);
  runPdf('فاتورة',function(){return buildDoc(c.innerHTML,INVOICE_CSS)},function(){opi()});
 };
 window.__pdfTest=function(html){return htmlToPdf(html)};
 window.__pdfBuildDoc=buildDoc;
 window.__docFromFrame=docFromFrame;
})();

/* source script: clock-pages-logic */
(function(){
 'use strict';
 var KEYS={'جملة البيع النهائية':'sale','خرج العمال':'workers','السحب':'withdraw','الديون':'debts','العملات':'currency'};
 var TITLES={sale:'جملة البيع النهائية',workers:'خرج العمال',withdraw:'السحب',debts:'الديون',currency:'العملات'};
 var DEFAULT_DIR={sale:'لكم',workers:'لكم',withdraw:'عليكم',debts:'لكم',currency:'لكم'};
 var STORE='smartadmin_clock_entries_v1',cur=null,opening=false,selectedIds=[],selectMode=false,longTimer=null,longTriggered=false;
 var $=function(id){return document.getElementById(id)};
 var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 var pad=function(n){return String(n).padStart(2,'0')};
 var iso=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
 var fmt=function(n){return (Number(n)||0).toLocaleString('en-US',{maximumFractionDigits:3})};
 function num(v){var n=Number(String(v==null?'':v).replace(/,/g,''));return Number.isFinite(n)?n:0}
 function read(){try{var v=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(v)?v:[]}catch(e){return []}}
 function write(l){try{localStorage.setItem(STORE,JSON.stringify(l));return true}catch(e){try{toast('تعذر الحفظ؛ مساحة التخزين قد تكون ممتلئة')}catch(_){}return false}}
 function activeSpec(){try{return data.settings.activeSpecialty||'all'}catch(e){return 'all'}}
 function currencyList(){
  var list=(data.settings&&Array.isArray(data.settings.currencies))?data.settings.currencies:[];
  return list.map(function(c){return {name:c.name||'',symbol:c.symbol||''}});
 }
 // الإشارة: عليكم تُحسب سالبة في الديون فقط (كما كان في المراقب)
 function signed(e){var a=entryTotal(e);return e.dir==='عليكم'?-Math.abs(a):Math.abs(a)}
 function syncClock(type){
  var t=read().filter(function(e){return e.type===type}).reduce(function(s,e){return s+signed(e)},0);
  var o={};o[type]=t;if(typeof window.updateHomeClock==='function')window.updateHomeClock(o);
 }
 // تطبيع صف عملة: مبلغ × سعر = ناتج؛ السعر الفارغ يعتبر 1
 function normRow(r){
  var amount=num(r.amount);
  var hasRate=r.rate!=null&&String(r.rate)!=='';
  var rate=hasRate?num(r.rate):1;
  var value=hasRate?amount*rate:(r.value!=null&&String(r.value)!==''?num(r.value):amount);
  return {name:String(r.name||''),symbol:String(r.symbol||''),amount:amount,rate:hasRate?rate:null,value:value};
 }
 function entryRows(e){
  return (Array.isArray(e.rows)?e.rows:[]).filter(function(r){return r&&(num(r.amount)||num(r.value))}).map(normRow);
 }
 function entryTotal(e){
  var rows=entryRows(e);
  return rows.length?rows.reduce(function(s,r){return s+r.value},0):(Number(e.amount)||0);
 }
 // مزامنة إجمالي الصفحة الرئيسية مع صافي كل صفحة ساعة (لكم - عليكم)
 function syncAllClockTotals(){
  var all=read(),totals={};
  Object.keys(TITLES).forEach(function(type){
   totals[type]=all.filter(function(e){return e.type===type}).reduce(function(sum,e){return sum+signed(e)},0);
  });
  if(typeof window.updateHomeClock==='function')window.updateHomeClock(totals);
 }
 // ترتيب سندات جملة البيع النهائية من الإعدادات: حسب (الأبجدي/المبلغ/التاريخ) + الاتجاه
 function saleCmp(x,y){
  var st=data.settings||{},by=st.saleSortBy||'date',dir=st.saleSortDir==='desc'?-1:1,r=0;
  if(by==='name')r=String(entryName(x)).localeCompare(String(entryName(y)),'ar');
  else if(by==='amount')r=Math.abs(entryTotal(x))-Math.abs(entryTotal(y));
  if(!r)r=String(x.date||'').localeCompare(String(y.date||''))||(sentStamp(x)-sentStamp(y));
  return r*dir;
 }
 function visible(){
  var from=($('ffDateFrom')||{}).value||'',to=($('ffDateTo')||{}).value||'',a=activeSpec();
  var l=read().filter(function(e){
   if(e.type!==cur)return false;
   var ef=e.date,et=e.dateTo||e.date;if(from&&to&&(et<from||ef>to))return false;
   if(a!=='all'&&String(e.specialtyId||'')!==String(a))return false;
   return true;
  });
  /* الترتيب حسب شريط الصفحة: التاريخ / الأبجدية / المبلغ + تصاعدي / تنازلي — لكل صفحات المراقب */
  var byEl=$('ffSortBy'),by=(byEl&&byEl.value)||'date';
  var desc=!!($('ffSortDesc')&&$('ffSortDesc').classList.contains('active'));
  function dcmp(x,y){var xd=String(x.date||''),yd=String(y.date||'');return xd<yd?-1:xd>yd?1:(sentStamp(x)-sentStamp(y))}
  l.sort(function(x,y){
   var r=0;
   if(by==='name')r=String(entryName(x)).localeCompare(String(entryName(y)),'ar');
   else if(by==='amount')r=Math.abs(entryTotal(x))-Math.abs(entryTotal(y));
   if(!r)r=dcmp(x,y);
   return desc?-r:r;
  });
  return l;
 }
 var NEWUI={sale:1,workers:1,withdraw:1,currency:1};
 // اسم السند الظاهر في عنوان البطاقة
 function entryName(e){return e.name||e.srcName||e.fundName||e.title||'سند معاملة'}
 // عنوان المعاملة حسب المصدر: لكم من التفصيل / عليكم من المراقب (قبض حسابات أو الصرافة)
 function originTitle(e,isDebt,nm){
  var sub=nm?' <small style="font-weight:700;opacity:.8">— '+nm+'</small>':'';
  if(e.src&&!isDebt){var spn='';try{var sp0=((data.settings&&data.settings.specialties)||[]).find(function(x){return String(x.id)===String(e.specialtyId||'')});if(sp0&&sp0.name)spn=esc(sp0.name)}catch(_){}return 'لكم من '+(nm||'التفصيل')+(spn?' + '+spn:'')}
  if(e.ts&&isDebt){
   var T={sale:'عليكم من المراقب قبض حسابات',workers:'عليكم من المراقب الصرافة قبض حسابات',withdraw:'عليكم من المراقب قبض حسابات',currency:e.tsKind==='acc'?'عليكم من المراقب الصرافة قبض حسابات':'عليكم من المراقب الصرافة قبض صناديق'};
   return (T[e.type]||'عليكم من المراقب')+sub;
  }
  return e.type==='currency'?(isDebt?'عليكم إلى '+nm:'لكم من '+nm):((isDebt?'عليكم':'لكم')+' ('+nm+')');
 }
 function headNew(e,per,isDebt){
  var nm=esc(entryName(e));
  var t=originTitle(e,isDebt,nm);
  return '<div class="cp-head"><span class="cp-title '+(isDebt?'debt':'pay')+'">'+t+'</span><span class="cp-date">'+per+'</span></div>';
 }
 // شريط أعلى صفحة العملات: إجمالي لكم/عليكم وصافي كل عملة + الناتج الإجمالي
 function stripHTML(l){
  var by={},order=[],meta={};
  function isUsdCurrency(c){var v=String((c&&c.name)||c||'').toLowerCase(),s=String((c&&c.symbol)||'').toLowerCase();return /دولار|usd|دولار أمريكي|us dollar/.test(v)||s==='$'||s==='usd';}
  // الدولار لا يدخل في شريط المراقب: نستبدله بعرض الناتج الفعلي لكل عملة.
  var allCurrencies=currencyList().filter(function(c){return !isUsdCurrency(c)}).slice();
  function rank(name){name=String(name||'');return /يمني/.test(name)?0:/سعودي/.test(name)?1:/عماني/.test(name)?2:/درهم/.test(name)?3:4}
  allCurrencies.sort(function(a,b){var r=rank(a.name)-rank(b.name);return r||String(a.name).localeCompare(String(b.name),'ar')});
  // مفتاح موحّد للعملة: يدمج (يمني / ريال يمني / YER / ر.ي) في خانة واحدة، فيظهر كل اسم مرة واحدة للقبض والسحب معاً
  function ckey(n,sy){var t=(String(n||'')+' '+String(sy||'')).toLowerCase();
    if(/يمني|yer|ر\.ي/.test(t))return 'يمني';if(/سعودي|sar|ر\.س/.test(t))return 'سعودي';if(/عماني|omr|ر\.ع/.test(t))return 'عماني';if(/درهم|aed/.test(t))return 'درهم';
    return String(n||sy||'').trim().toLowerCase()}
  allCurrencies.forEach(function(c){var k=ckey(c.name,c.symbol);if(by[k])return;by[k]={pay:0,debt:0,net:0};order.push(k);meta[k]=(c.name||'')+(c.symbol&&c.symbol!==c.name?' ('+c.symbol+')':'')});
  var total=0;
  l.forEach(function(e){
   var isDebt=e.dir==='عليكم',rows=entryRows(e),entryResult=0;
   rows.forEach(function(r){
    if(isUsdCurrency(r))return;
    var rk=ckey(r.name,r.symbol);if(!by[rk]){by[rk]={pay:0,debt:0,net:0};order.push(rk);meta[rk]=r.name+(r.symbol&&r.symbol!==r.name?' ('+r.symbol+')':'')}
    // بطاقات العملات تعرض مبلغ العملة الأصلي، وليس ناتج التحويل.
    var amount=Math.abs(Number(r.amount)||0);by[rk][isDebt?'debt':'pay']+=amount;by[rk].net+=isDebt?-amount:amount;
    entryResult+=Math.abs(Number(r.value)||0);
   });
   // الناتج الإجمالي النهائي فقط يعتمد على ناتج التحويل (المبلغ × سعر الصرف).
   total+=(rows.length?(isDebt?-entryResult:entryResult):signed(e));
  });
  var dir=function(v){return v>1e-9?'لكم':v<-1e-9?'عليكم':'متعادل'};
  var cell=function(n){var x=by[n]||{pay:0,debt:0,net:0},cl=x.net< -1e-9?'neg':x.net>1e-9?'pos':'zero';
   return '<div class="cp-sc '+cl+'"><span>'+esc(meta[n]||n)+'</span><b class="cp-gross-pay">لكم: '+fmt(x.pay)+'</b><b class="cp-gross-debt">عليكم: '+fmt(x.debt)+'</b><b class="cp-rest '+cl+'">الباقي: '+fmt(Math.abs(x.net))+(Math.abs(x.net)>1e-9?' '+dir(x.net):'')+'</b></div>';
  };
  var totalCell='<div class="cp-sc tot '+(total< -1e-9?'neg':total>1e-9?'pos':'zero')+'"><span>الناتج لجميع العملات</span><b>'+fmt(Math.abs(total))+'</b><em>'+dir(total)+'</em></div>';
  return '<div class="cp-strip">'+order.map(cell).join('')+totalCell+'</div>';
 }
 // النموذج أ = العملات (شريط العملات) ، النموذج ب = البيع النهائية/السحب/خرج العمال (3 بطاقات إجمالي)
 function sumHTML(l){
  var pay=0,debt=0;
  l.forEach(function(e){var a=Math.abs(entryTotal(e));if(e.dir==='عليكم')debt+=a;else pay+=a});
  var net=pay-debt,lb=net>0?'الباقي لكم':net<0?'الباقي عليكم':'لا يوجد رصيد';
  var c=function(t,v,col){return '<div class="sm-c"><b style="color:'+col+'">'+fmt(v)+'</b><span>'+t+'</span></div>'};
  return c('الإجمالي عليكم',debt,'#dc2626')+c('الإجمالي لكم',pay,'#15803d')+c(lb,Math.abs(net),net<0?'#dc2626':'#0f172a');
 }
window.__signHtml='<div style="display:flex;justify-content:space-between;gap:20px;margin-top:40px;font-weight:700;break-inside:avoid"><span>عن العميل<br>الاسم: __________<br>التوقيع: __________</span><span>مدير الحسابات<br>الاسم: __________<br>التوقيع: __________</span></div>';
 function syncPrintBtn(){
  var bar=document.querySelector('#fullFilterPage>.ui-appbar');if(!bar)return;
  var show=!!cur;
  if(cur==='debts'){var st=window.__debtFunds&&window.__debtFunds.state?window.__debtFunds.state():null;show=!!st&&st.v!=='main'}
  var bp=bar.querySelector('[data-clock-print]'),ba=bar.querySelector('[data-clock-auth]'),bs=bar.querySelector('[data-clock-send]');
  var showSend=false;var accView=cur==='debts'&&!!window.__debtFunds&&!!window.__debtFunds.state&&window.__debtFunds.state().v==='acc';
  if(!showSend&&bs){bs.remove();bs=null}
  if(!show){if(bp)bp.remove();if(ba)ba.remove();if(bs)bs.remove();return}
  var css='border:1px solid rgba(255,255,255,.55);border-radius:10px;background:rgba(255,255,255,.18);color:#fff;padding:8px 10px;font:900 13px inherit;cursor:pointer;flex:none;white-space:nowrap';
  if(!bp){bp=document.createElement('button');bp.type='button';bp.className='cp-print-btn';bp.setAttribute('data-clock-print','');bp.textContent='🖨️ طباعة';bp.style.cssText=css+';margin-inline-start:auto';bar.appendChild(bp)}
  if(!ba){ba=document.createElement('button');ba.type='button';ba.className='cp-print-btn';ba.setAttribute('data-clock-auth','');ba.textContent='📝 مصادقة';ba.style.cssText=css+';margin-inline-start:6px';bar.appendChild(ba)}
  bar.classList.toggle('acc-bar',accView);
  if(bp){bp.textContent=accView?'🖨️':'🖨️ طباعة';bp.title='طباعة';bp.setAttribute('aria-label','طباعة')}
  if(ba){ba.textContent=accView?'📝':'📝 مصادقة';ba.title='مصادقة';ba.setAttribute('aria-label','مصادقة')}
 }
 function layout(l){syncPrintBtn();
  var p=$('fullFilterPage');if(!p)return;
  var accV=cur==='debts'&&!!window.__debtFunds&&!!window.__debtFunds.state&&window.__debtFunds.state().v==='acc';
  document.body.classList.toggle('debt-acc-view',accV);
  if(!p.__accObs){p.__accObs=true;new MutationObserver(function(){if(!p.classList.contains('show'))document.body.classList.remove('debt-acc-view','debt-fund-view')}).observe(p,{attributes:true,attributeFilter:['class']})}
  var b=cur==='sale'||cur==='workers'||cur==='withdraw',currency=cur==='currency';
  var dfund=cur==='debts'&&!!window.__debtFunds&&!!window.__debtFunds.state&&window.__debtFunds.state().v==='fund';
  document.body.classList.toggle('debt-fund-view',dfund);
  p.classList.toggle('ff-fmt-a',currency);
  p.classList.toggle('ff-fmt-b',b||dfund);
  var h=$('ffSumHost');
  if(b||currency||dfund){
   if(!h){h=document.createElement('div');h.id='ffSumHost';var sort=p.querySelector('.ff-sort');if(sort)p.insertBefore(h,sort);else p.appendChild(h)}
   h.className=currency?'currency-summary':'';
   h.innerHTML=currency?stripHTML(l):dfund?window.__debtFunds.sumHTML():sumHTML(l);
  }else if(h){h.remove()}
 }
 // ===== شكل سند جملة البيع النهائية: النوع | التاريخ | المبلغ | الكمية | البيان | الرصيد (تراكمي) =====
 var saleBal={};
 function sentStamp(e){
  var t=Number(e.sentAt||e.createdAt||0);
  if(!t){var m=/^ck(\d{12,13})/.exec(String(e.id||''));if(m)t=Number(m[1])}
  return t||0;
 }
 // الصفحات التي تستخدم شكل جملة البيع النهائية (الصف والطباعة والترتيب والرصيد التراكمي)
 var SALE_LIKE={sale:1,withdraw:1,workers:1};
 // سندات التفصيل تتبع اتجاهها المخزّن؛ سندات الحسابات اليدوية في جملة البيع والسحب دائماً «عليكم»
 function saleIsDebt(e){
  if(e.src)return e.dir==='عليكم';
  if(e.type==='sale'||e.type==='withdraw')return e.dir!=='لكم';
  return e.dir==='عليكم';
 }
 function saleSigned(e){var a=Math.abs(entryTotal(e));return saleIsDebt(e)?-a:a}
 function computeSaleBal(l){
  saleBal={};var run=0;
  l.slice().sort(function(a,b){
   var x=String(a.date||''),y=String(b.date||'');
   if(x!==y)return x<y?-1:1;
   return sentStamp(a)-sentStamp(b);
  }).forEach(function(e){run+=saleSigned(e);saleBal[String(e.id)]=run});
 }
 function saleHeadHTML(){
  var cols=cur==='sale'?['النوع','التاريخ','المبلغ','الكمية','البيان','الرصيد']:['النوع','التاريخ','المبلغ','البيان','الرصيد'];
  return '<div class="cp-shead'+(cur==='sale'?'':' noqty')+'">'+cols.map(function(t){return '<span>'+t+'</span>'}).join('')+'</div>';
 }
 function saleRowHTML(e){
  var sel=selectedIds.indexOf(String(e.id))>=0;
  var fromDetail=!!e.src;
  var isDebt=saleIsDebt(e);
  var t=sentStamp(e),dd='—',tm='';
  // التاريخ = تاريخ إرسال السند
  if(t){var d=new Date(t);dd=pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear();tm=pad(d.getHours())+':'+pad(d.getMinutes())}
  else if(e.date){var q=String(e.date).split('-');dd=q.length===3?q[2]+'/'+q[1]+'/'+q[0]:esc(e.date)}
  var per=e.dateTo&&e.dateTo!==e.date?'من '+esc(e.date)+' إلى '+esc(e.dateTo):esc(e.date||'');
  var nm=esc(entryName(e)),bal=saleBal[String(e.id)];if(bal==null)bal=saleSigned(e);
  var qty=(e.qty!==undefined&&e.qty!=='')?esc(e.qty):'—';
  // البيان: سندات التفصيل بالفترة، وسندات الحسابات باسم الحساب + سند قبض للحساب
  var note=fromDetail?'<small>'+per+'</small>':'<small>سند قبض للحساب'+(e.note?' — '+escNl(e.note):'')+'</small>';
  return '<div class="cp-row cp-srow '+(sel?'cp-selected':'')+' '+(isDebt?'debt':'pay')+(cur==='sale'?'':' noqty')+'" data-cid="'+esc(e.id)+'" style="touch-action:pan-y;position:relative" onpointerdown="window.__clockEntryLongStart(event,\''+esc(e.id)+'\')" onpointerup="window.__clockEntryLongCancel()" onpointerleave="window.__clockEntryLongCancel()" onpointercancel="window.__clockEntryLongCancel()">'
   +'<span class="c-type">'+(selectMode?'<i class="cp-chk">'+(sel?'☑':'☐')+'</i>':'')+(isDebt?'عليكم':'لكم')+'</span>'
   +'<span class="c-date">'+dd+(tm?'<small>'+tm+'</small>':'')+'</span>'
   +'<span class="c-amt">'+fmt(Math.abs(entryTotal(e)))+'</span>'
   +(cur==='sale'?'<span class="c-qty">'+qty+'</span>':'')
   +'<span class="c-note"><b>'+nm+'</b>'+note+'</span>'
   +'<span class="c-bal '+(bal<0?'neg':'pos')+'">'+fmt(Math.abs(bal))+'</span>'
   +'</div>';
 }
 // سند الدين من التفصيل: جدول مسلم فلوس (لكم) أو جدول بيع الدين (عليكم)
 function dfmtStamp(e){var t=sentStamp(e);if(t){var d=new Date(t);return pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear()}var q=String(e.date||'').split('-');return q.length===3?q[2]+'/'+q[1]+'/'+q[0]:esc(e.date||'—')}
 function debtSlipHTML(e){
  var isRec=e.kind==='received',cell=function(v,b){return '<td><span class="ds-c'+(b?' b':'')+'">'+v+'</span></td>'};
  var per=e.dateTo&&e.dateTo!==e.date?'من '+esc(e.date)+' إلى '+esc(e.dateTo):esc(e.date||'');
  var sel=selectedIds.indexOf(String(e.id))>=0,tot=Math.abs(Number(e.amount)||0),table;
  if(isRec){
   var rr=Array.isArray(e.recRows)?e.recRows:[];
   table='<table class="ds-t"><thead><tr><th>الاسم</th><th style="width:36%">المبلغ</th></tr></thead><tbody>'
    +(rr.map(function(r){return '<tr>'+cell(esc(r.name||'—'))+cell(fmt(r.amount))+'</tr>'}).join('')||'<tr><td colspan="2" class="ds-none">—</td></tr>')
    +'</tbody><tfoot><tr><th>المجموع</th><td><span class="ds-c b">'+fmt(tot)+'</span></td></tr></tfoot></table>';
  }else{
   var dr=Array.isArray(e.debtRows)?e.debtRows:[];
   table='<table class="ds-t ds-wide"><thead><tr><th>الاسم</th><th style="width:12%">الكمية</th><th>المبلغ</th><th>مسلم أسبوع</th><th>مبلغ الدين الباقي</th></tr></thead><tbody>'
    +(dr.map(function(r){return '<tr>'+cell(esc(r.name||'—'))+cell(r.qty===''?'—':esc(r.qty))+cell(fmt(r.amount))+cell(fmt(r.weekly))+cell(fmt(r.rest),1)+'</tr>'}).join('')||'<tr><td colspan="5" class="ds-none">—</td></tr>')
    +'</tbody><tfoot><tr><th colspan="4">المجموع</th><td><span class="ds-c b">'+fmt(tot)+'</span></td></tr></tfoot></table>';
  }
  return '<div class="cp-row ds-slip '+(isRec?'ds-pay':'ds-debt')+(sel?' cp-selected':'')+'" data-cid="'+esc(e.id)+'" style="display:block;touch-action:pan-y;position:relative" onpointerdown="window.__clockEntryLongStart(event,\''+esc(e.id)+'\')" onpointerup="window.__clockEntryLongCancel()" onpointerleave="window.__clockEntryLongCancel()" onpointercancel="window.__clockEntryLongCancel()">'
   +(selectMode?'<span class="cp-check">'+(sel?'☑':'☐')+'</span>':'')
   +'<div class="ds-head"><span class="ds-title">'+(isRec?'لكم مسلم فلوس':'عليكم بيع دين')+'</span><span>'+esc(e.srcName||'—')+'</span><span>'+per+'</span><span>'+dfmtStamp(e)+'</span></div>'
   +table+'</div>';
 }
 function cardHTML(e){
  if(cur==='debts'&&e.kind&&e.src)return debtSlipHTML(e);
  if(SALE_LIKE[cur]&&e.type===cur)return saleRowHTML(e);
  var per=e.dateTo&&e.dateTo!==e.date?'من '+esc(e.date)+' إلى '+esc(e.dateTo):esc(e.date);
  var rows=entryRows(e),isDebt=e.dir==='عليكم';
  var table=rows.length?'<table><tr><th>اسم العملة</th><th>مبلغ العملة</th><th>سعر الصرف</th><th>ناتج الصرف</th></tr>'
   +rows.map(function(r){return '<tr><td>'+esc(r.name)+'</td><td>'+fmt(r.amount)+'</td><td>'+(r.rate==null?'—':fmt(r.rate))+'</td><td><b>'+fmt(r.value)+'</b></td></tr>'}).join('')+'</table>':'';
  var extra=[];
  if(e.qty!==undefined&&e.qty!=='')extra.push('الكمية: '+esc(e.qty));
  if(e.days)extra.push('أيام: '+esc(e.days));
  return '<div class="cp-row '+(selectedIds.indexOf(String(e.id))>=0?'cp-selected':'')+'" data-cid="'+esc(e.id)+'" style="display:block;touch-action:pan-y;position:relative" onpointerdown="window.__clockEntryLongStart(event,\''+esc(e.id)+'\')" onpointerup="window.__clockEntryLongCancel()" onpointerleave="window.__clockEntryLongCancel()" onpointercancel="window.__clockEntryLongCancel()">'+(selectMode?'<span class="cp-check">'+(selectedIds.indexOf(String(e.id))>=0?'☑':'☐')+'</span>':'')
   +(NEWUI[e.type]?headNew(e,per,isDebt):'<div class="d" style="border-bottom:1px solid #e2e8f0;padding-bottom:5px;margin-bottom:6px">'+per+(e.src?' • '+esc(e.srcName||'من التفصيل'):'')+'</div>')
   +table
   +(e.note?'<div class="n" style="font-weight:700;font-size:13px;margin-top:4px">البيان: '+escNl(e.note)+'</div>':'')
   +(extra.length?'<div style="font-size:12px;color:#718096">'+extra.join(' · ')+'</div>':'')
   +'<div class="ce-foot"><span class="ce-badge '+(isDebt?'debt':'pay')+'">'+(isDebt?'عليكم':'لكم')+'</span>'
   +'<span>الإجمالي: <b style="direction:ltr;display:inline-block;color:'+(isDebt?'#dc2626':'#15803d')+'">'+fmt(entryTotal(e))+'</b></span></div>'
   +'</div>';
 }
 function render(){
  if(!cur)return;
  var host=document.querySelector('#fullFilterPage .ff-empty');if(!host)return;
  if(cur==='debts'&&window.__debtFunds){layout([]);window.__debtFunds.render(host,{visible:visible,card:cardHTML,signed:signed,from:($('ffDateFrom')||{}).value||'',to:($('ffDateTo')||{}).value||''});syncPrintBtn();return}
  var l=visible();layout(l);
  if(SALE_LIKE[cur])computeSaleBal(l);
  if(!l.length){host.innerHTML='';return;}
  var tot=l.reduce(function(s,e){return s+signed(e)},0),balLabel=tot<0?'عليكم':tot>0?'لكم':'متوازن',balColor=tot<0?'#dc2626':tot>0?'#15803d':'#0752a2';
  syncPrintBtn();host.innerHTML='<div class="cp-printbar" style="display:flex;justify-content:flex-start;gap:7px;flex-wrap:wrap;margin:'+(selectMode?'8px 0':'0')+';">'+(selectMode?'<button type="button" data-cp-all style="border:0;border-radius:10px;background:#e0f2fe;color:#0752a2;padding:10px;font-weight:900">☑ تحديد الكل</button><button type="button" data-cp-delete style="border:0;border-radius:10px;background:#fee2e2;color:#b91c1c;padding:10px;font-weight:900">🗑 حذف المحدد</button><button type="button" data-cp-done style="border:0;border-radius:10px;padding:10px;font-weight:900">إلغاء التحديد</button>':'')+'</div>'
   +(NEWUI[cur]?'':'<div class="cp-count">العدد: '+l.length+'</div><div class="cp-total" style="display:flex;justify-content:space-between;align-items:center;gap:8px;color:'+balColor+';font-weight:900;padding:10px 12px;border-radius:12px;background:'+(tot<0?'#fee2e2':tot>0?'#dcfce7':'#eaf2fb')+';margin:8px 0"><span>الإجمالي داخل الصفحة: '+balLabel+'</span><span style="direction:ltr;color:'+balColor+'">'+fmt(Math.abs(tot))+'</span></div>')
   +(SALE_LIKE[cur]?saleHeadHTML():'')+l.map(cardHTML).join('');
 }
 // شكل نافذة إضافة المعاملة (من الصور): عنوان حسب الصفحة، تاريخ بتقويم، حقول مبلغ بإطار، بيان متعدد الأسطر مع إضافة/حذف سطر، نوع، حفظ/إلغاء
 var CE_TITLES={sale:'سند معامله: جملة البيع النهائية',workers:'سند معامله : خرج العمال',withdraw:'سند سحب: السحوبات',debts:'سند دين: صندوق الديون التلقائي'};
 var CE_CSS='<style>'
  +'.ce-box{border-radius:18px!important;padding:16px!important;box-shadow:0 10px 30px rgba(15,23,42,.25)}'
  +'.ce-title{font-weight:900;font-size:17px;color:#0f172a;text-align:center;margin-bottom:10px}'
  +'.ce-date-row label,.ce-note label{display:block;font-weight:800;font-size:13px;color:#334155;margin:8px 0 4px}'
  +'.ce-datebox{display:flex;align-items:center;gap:8px}.ce-cal{font-size:22px}'
  +'.ce-datebox input{flex:1;border:1.5px solid #64748b;border-radius:10px;padding:8px;font-size:15px}'
  +'#clkEntryOv input[type=number],#clkEntryOv input[type=date],#clkEntryOv textarea{border:1.5px solid #64748b!important;border-radius:10px!important;background:#fff}'
  +'.ce-lines{display:flex;gap:8px;margin:6px 0}.ce-lines button{flex:1;padding:8px;border:1.5px solid #64748b;border-radius:10px;background:#f8fafc;font-weight:800;cursor:pointer}'
  +'.ce-total{border:1.5px solid #64748b;border-radius:10px;padding:8px;display:flex;justify-content:space-between;font-weight:900}'
  +'.ce-actions button{border-radius:12px!important;font-weight:900}.ce-save{background:#1e3a8a!important;color:#fff!important}'
  +'.ce-cancel{background:#f1f5f9!important;color:#334155!important;border:1.5px solid #94a3b8!important}'
  +'</style>';

// النافذة الموحدة لجميع صفحات المراقب: تاريخ + عملات (مبلغ × سعر) + بيان + لكم/عليكم
 /* النافذة الجديدة لصفحات جملة البيع وخرج العمال والسحب (مبلغ واحد) وصندوق الديون (صفوف اسم ومبلغ) — حسب الصور المرفقة */
function openEntryNew(id){
  var old=$('clkEntryOv');if(old)old.remove();
  var e=id?read().find(function(x){return x.id===id}):null;
  if(e&&e.kind&&e.src){try{toast('سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً')}catch(_){}return}
  var isDebt=cur==='debts';
  var dir=e?(e.dir||DEFAULT_DIR[cur]):DEFAULT_DIR[cur];
  var base=currencyList()[0]||{name:'',symbol:''};
  var spList=(data.settings&&Array.isArray(data.settings.specialties))?data.settings.specialties:[];
  var curSp=e?(e.specialtyId||''):(activeSpec()==='all'?'':activeSpec());
  var spHtml='<option value="">بدون تخصيص</option>'+spList.map(function(s){var v=String(s.id||s.name||'');return '<option value="'+esc(v)+'"'+(v===String(curSp)?' selected':'')+'>'+esc(s.name||s.label||v)+'</option>'}).join('');
  var dRow=function(name,amount){return '<tr><td><input type="text" data-f="name" value="'+esc(name||'')+'"></td><td><input type="number" inputmode="decimal" step="any" data-f="amount" value="'+(amount===''||amount==null?'':esc(amount))+'" placeholder="0"></td><td><button type="button" class="ce-delrow">×</button></td></tr>'};
  var body;
  if(isDebt){
    var dr=e&&Array.isArray(e.rows)&&e.rows.length?e.rows:[{name:'',amount:''}];
    body='<table class="ce-debt-t"><thead><tr><th>الاسم</th><th>المبلغ</th><th></th></tr></thead><tbody>'+dr.map(function(r){return dRow(r.name,r.amount)}).join('')+'</tbody></table>'
     +'<button type="button" class="ce-addrow">+ إضافة صف</button>'
     +'<div class="ce-total"><span>الجملة</span><b id="ceTotal">0</b></div>';
  }else{
    var amt=e?(Array.isArray(e.rows)&&e.rows[0]?e.rows[0].amount:e.amount):'';
    body='<div class="ce-note"><label for="ceAmt">المبلغ ('+esc(base.name)+')</label><input type="number" inputmode="decimal" step="any" id="ceAmt" value="'+(amt===''||amt==null?'':esc(amt))+'" placeholder="0"></div>';
  }
  var ov=document.createElement('div');ov.id='clkEntryOv';
  ov.innerHTML=CE_CSS+'<style>.ce-debt-t{width:100%;border-collapse:collapse;margin:8px 0}.ce-debt-t th,.ce-debt-t td{border:1px solid #94a3b8;padding:6px;text-align:center}.ce-debt-t input{width:100%;box-sizing:border-box;padding:6px;border:1.5px solid #64748b;border-radius:8px}.ce-addrow{margin:6px 0;padding:8px 12px;border-radius:10px;border:1.5px solid #1e3a8a;background:#fff;font-weight:900;color:#1e3a8a}</style>'
   +'<div class="ce-box" role="dialog" aria-modal="true">'
   +'<div class="ce-title">'+(e?'تعديل ':'')+esc(CE_TITLES[cur]||('سند معاملة: '+TITLES[cur]))+'</div>'
   +'<div class="ce-date-row"><label for="ceDate">التاريخ</label><div class="ce-datebox"><span class="ce-cal">📅</span><input type="date" id="ceDate" value="'+esc(e?e.date:iso(new Date()))+'"></div></div>'
   +body
   +'<div class="ce-note"><label for="ceSp">التخصيص</label><select id="ceSp">'+spHtml+'</select></div>'
   +(isDebt?'':'<div class="ce-note"><label for="ceNote">البيان — متعدد الأسطر</label><textarea id="ceNote" rows="2" style="width:100%;min-height:58px;resize:vertical;white-space:pre-wrap;text-align:right;box-sizing:border-box" placeholder="اكتب البيان ويمكنك إضافة عدة سطور">'+esc(e?e.note||'':'')+'</textarea></div>'
     +'<div class="ce-lines"><button type="button" class="ce-del-line">حذف السطر</button><button type="button" class="ce-add-line">+ إضافة سطر</button></div>'
     +'<div class="ce-note"><label>إرفاق صورة</label><input type="file" accept="image/*" id="ceImg"><span id="ceImgName" style="font-size:12px">'+(e&&e.img?'صورة مرفقة':'لم يتم اختيار أي ملف')+'</span></div>')
   +'<div class="ce-dir">'
   +'<label class="ce-pay'+(dir==='لكم'?' on':'')+'"><input type="radio" name="ceDir" value="لكم"'+(dir==='لكم'?' checked':'')+'> لكم</label>'
   +'<label class="ce-debt'+(dir==='عليكم'?' on':'')+'"><input type="radio" name="ceDir" value="عليكم"'+(dir==='عليكم'?' checked':'')+'> عليكم</label>'
   +'</div>'
   +'<div class="ce-actions"><button type="button" class="ce-cancel">إلغاء</button><button type="button" class="ce-save">💾 حفظ</button></div>'
   +(e?'<button type="button" class="ce-del">🗑 حذف</button>':'')
   +'</div>';
  var imgData=null;
  function recalc(){var t=0;ov.querySelectorAll('[data-f=amount]').forEach(function(i){t+=num(i.value)});var tot=ov.querySelector('#ceTotal');if(tot)tot.textContent=fmt(t)}
  function debtRows(){var out=[];ov.querySelectorAll('.ce-debt-t tbody tr').forEach(function(tr){var nm=(tr.querySelector('[data-f=name]').value||'').trim(),a=num(tr.querySelector('[data-f=amount]').value);if(a>0)out.push({name:nm,symbol:base.symbol||'',amount:a,rate:1,value:a})});return out}
  var noteEl=ov.querySelector('#ceNote');
  if(noteEl){
    ov.querySelector('.ce-add-line').addEventListener('click',function(){noteEl.value=noteEl.value.replace(/\s*$/,'')+'\n';noteEl.focus()});
    ov.querySelector('.ce-del-line').addEventListener('click',function(){var L=noteEl.value.split('\n');L.pop();noteEl.value=L.join('\n');noteEl.focus()});
  }
  var imgEl=ov.querySelector('#ceImg');
  if(imgEl)imgEl.addEventListener('change',function(){var f=imgEl.files&&imgEl.files[0];if(!f)return;var r=new FileReader();r.onload=function(){imgData=r.result;ov.querySelector('#ceImgName').textContent=f.name};r.readAsDataURL(f)});
  var addRow=ov.querySelector('.ce-addrow');
  if(addRow)addRow.addEventListener('click',function(){ov.querySelector('.ce-debt-t tbody').insertAdjacentHTML('beforeend',dRow('',''));recalc()});
  ov.addEventListener('input',function(ev){if(ev.target.matches&&ev.target.matches('[data-f]'))recalc()});
  ov.addEventListener('change',function(ev){if(ev.target.name==='ceDir'){ov.querySelectorAll('.ce-dir label').forEach(function(l){l.classList.toggle('on',!!l.querySelector('input:checked'))})}});
  ov.addEventListener('click',function(ev){
   var c=ev.target.classList;
   if(ev.target===ov||c.contains('ce-cancel')){ov.remove();return}
   if(c.contains('ce-delrow')){ev.target.closest('tr').remove();recalc();return}
   if(c.contains('ce-save')){
    var d=ov.querySelector('#ceDate').value;
    if(!d){toast('أدخل التاريخ');return}
    var out,total,note='';
    if(isDebt){out=debtRows();if(!out.length){toast('أدخل اسماً ومبلغاً على الأقل');return}}
    else{var a=num(ov.querySelector('#ceAmt').value);if(!(a>0)){toast('أدخل المبلغ');return}out=[{name:base.name,symbol:base.symbol,amount:a,rate:1,value:a}];note=noteEl?noteEl.value.trim():''}
    total=out.reduce(function(s,r){return s+r.value},0);
    var dirV=ov.querySelector('input[name=ceDir]:checked').value;
    var sp=ov.querySelector('#ceSp').value;
    var l=read();
    if(e){
     var x=l.find(function(z){return z.id===id});
     if(x){x.date=d;delete x.dateTo;x.type=cur;x.dir=dirV;x.amount=total;x.note=note;x.rows=out;x.specialtyId=sp;if(imgData)x.img=imgData;}
    }else{
     l.push({id:'ck'+Date.now()+Math.random().toString(36).slice(2,6),type:cur,date:d,dir:dirV,amount:total,note:note,name:'',rows:out,specialtyId:sp,img:imgData||''});
    }
    if(write(l)){ov.remove();syncClock(cur);render();toast('تم الحفظ')}
    return;
   }
   if(c.contains('ce-del')){
    if(!confirm('حذف هذا السند؟'))return;
    var allEntries=read(),deleted=allEntries.find(function(z){return String(z.id)===String(id)});if(deleted&&typeof addToTrash==='function')addToTrash(deleted,'clockEntry',(deleted.note||deleted.type||'عملية المراقب')+' - '+(deleted.date||''));write(allEntries.filter(function(z){return String(z.id)!==String(id)}));ov.remove();syncClock(cur);render();
   }
  });
  document.body.appendChild(ov);
  recalc();
}

function openEntry(id){
  if(cur!=='currency')return openEntryNew(id);
  var old=$('clkEntryOv');if(old)old.remove();
  var e=id?read().find(function(x){return x.id===id}):null;
  if(e&&e.kind&&e.src){try{toast('سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً')}catch(_){}return}
  var dir=e?(e.dir||DEFAULT_DIR[cur]):DEFAULT_DIR[cur];
  var inRows=e?entryRows(e):[];
  var rows=currencyList().map(function(c){
   var m=inRows.find(function(r){return r.name===c.name||(c.symbol&&r.symbol===c.symbol)});
   return {name:c.name,symbol:c.symbol,amount:m?m.amount:'',rate:m&&m.rate!=null?m.rate:''};
  });
  inRows.forEach(function(r){
   if(!rows.some(function(x){return x.name===r.name}))rows.push({name:r.name,symbol:r.symbol,amount:r.amount,rate:r.rate!=null?r.rate:''});
  });
  var ov=document.createElement('div');ov.id='clkEntryOv';
  ov.innerHTML=CE_CSS+'<div class="ce-box" role="dialog" aria-modal="true">'
   +'<div class="ce-title">'+(e?'تعديل ':'')+esc(CE_TITLES[cur]||('سند معاملة: '+TITLES[cur])) +'</div>'
   +'<div class="ce-date-row"><label for="ceDate">التاريخ</label><div class="ce-datebox"><span class="ce-cal">📅</span><input type="date" id="ceDate" value="'+esc(e?e.date:iso(new Date()))+'"></div></div>'
   +'<div class="ce-note"><label for="ceName">اسم السند</label><input type="text" id="ceName" value="'+esc(e?e.name||'':'')+'" placeholder="مثال: سحب رياض اليافعي"></div>'
   +'<table><tr><th>اسم العملة</th><th>مبلغ العملة</th><th>سعر الصرف</th><th>ناتج صرف العملة</th></tr>'
   +rows.map(function(r,i){
     return '<tr data-i="'+i+'"><td class="ce-name">'+esc(r.name)+'</td>'
      +'<td><input type="number" inputmode="decimal" step="any" data-f="amount" value="'+(r.amount===''?'':esc(r.amount))+'" placeholder="0"></td>'
      +'<td><input type="number" inputmode="decimal" step="any" data-f="rate" value="'+(r.rate===''?'':esc(r.rate))+'" placeholder="1"></td>'
      +'<td class="ce-val" data-val>0</td></tr>';
    }).join('')
   +'</table>'
   +'<div class="ce-total"><span>الجملة</span><b id="ceTotal">0</b></div>'
   +'<div class="ce-note"><label for="ceNote">البيان</label><textarea id="ceNote" rows="2" style="width:100%;min-height:58px;resize:vertical;white-space:pre-wrap;text-align:right;box-sizing:border-box" placeholder="اختياري — Enter لإضافة سطر">'+esc(e?e.note||'':'')+'</textarea></div>'
   +'<div class="ce-lines"><button type="button" class="ce-del-line">حذف السطر</button><button type="button" class="ce-add-line">+ إضافة سطر</button></div>'
   +'<div class="ce-dir">'
   +'<label class="ce-pay'+(dir==='لكم'?' on':'')+'"><input type="radio" name="ceDir" value="لكم"'+(dir==='لكم'?' checked':'')+'> لكم</label>'
   +'<label class="ce-debt'+(dir==='عليكم'?' on':'')+'"><input type="radio" name="ceDir" value="عليكم"'+(dir==='عليكم'?' checked':'')+'> عليكم</label>'
   +'</div>'
   +'<div class="ce-actions"><button type="button" class="ce-cancel">إلغاء</button><button type="button" class="ce-save">💾 حفظ</button></div>'
   +(e?'<button type="button" class="ce-del">🗑 حذف</button>':'')
   +'</div>';

  var ceNoteEl=ov.querySelector('#ceNote');
  ov.querySelector('.ce-add-line').addEventListener('click',function(){ceNoteEl.value=ceNoteEl.value.replace(/\s*$/,'')+'\n';ceNoteEl.focus()});
  ov.querySelector('.ce-del-line').addEventListener('click',function(){var L=ceNoteEl.value.split('\n');L.pop();ceNoteEl.value=L.join('\n');ceNoteEl.focus()});
  function recalc(){
   var total=0;
   ov.querySelectorAll('tr[data-i]').forEach(function(tr){
    var a=num(tr.querySelector('[data-f=amount]').value);
    var rt=tr.querySelector('[data-f=rate]').value;
    var v=a*(rt===''?1:num(rt));
    total+=v;
    tr.querySelector('[data-val]').textContent=fmt(v);
   });
   ov.querySelector('#ceTotal').textContent=fmt(total);
  }
  function collect(){
   var out=[];
   ov.querySelectorAll('tr[data-i]').forEach(function(tr){
    var base=rows[+tr.getAttribute('data-i')];
    var a=num(tr.querySelector('[data-f=amount]').value);
    if(!(a>0))return;
    var rt=tr.querySelector('[data-f=rate]').value;
    var rate=rt===''?1:num(rt);
    out.push({name:base.name,symbol:base.symbol,amount:a,rate:rate,value:a*rate});
   });
   return out;
  }
  ov.addEventListener('input',function(ev){if(ev.target.matches('[data-f]'))recalc()});
  ov.addEventListener('change',function(ev){
   if(ev.target.name==='ceDir'){
    ov.querySelectorAll('.ce-dir label').forEach(function(l){l.classList.toggle('on',!!l.querySelector('input:checked'))});
   }
  });
  ov.addEventListener('click',function(ev){
   var c=ev.target.classList;
   if(ev.target===ov||c.contains('ce-cancel')){ov.remove();return}
   if(c.contains('ce-save')){
    var d=ov.querySelector('#ceDate').value;
    if(!d){toast('أدخل التاريخ');return}
    var out=collect();
    if(!out.length){toast('أدخل مبلغ عملة واحدة على الأقل');return}
    var total=out.reduce(function(s,r){return s+r.value},0);
    var dirV=ov.querySelector('input[name=ceDir]:checked').value;
    var note=ov.querySelector('#ceNote').value.trim(),nm=ov.querySelector('#ceName').value.trim();
    var l=read();
    if(e){
     var x=l.find(function(z){return z.id===id});
     if(x){x.date=d;delete x.dateTo;x.type=cur;x.dir=dirV;x.amount=total;x.note=note;x.name=nm;x.rows=out;}
    }else{
     var sp=activeSpec();
     l.push({id:'ck'+Date.now()+Math.random().toString(36).slice(2,6),type:cur,date:d,dir:dirV,amount:total,note:note,name:nm,rows:out,specialtyId:sp==='all'?'':sp});
    }
    if(write(l)){ov.remove();syncClock(cur);render();toast('تم الحفظ')}
    return;
   }
   if(c.contains('ce-del')){
    if(!confirm('حذف هذا السند؟'))return;
    var allEntries=read(),deleted=allEntries.find(function(z){return String(z.id)===String(id)});if(deleted&&typeof addToTrash==='function')addToTrash(deleted,'clockEntry',(deleted.note||deleted.type||'عملية المراقب')+' - '+(deleted.date||''));write(allEntries.filter(function(z){return String(z.id)!==String(id)}));ov.remove();syncClock(cur);render();
   }
  });
  document.body.appendChild(ov);
  recalc();
 }

 // ترحيل تفاصيل الفاتورة إلى صفحات المراقب (بدون تغيير)
 window.__clockFromDetail=function(inv){
  var fd=inv.formData||{},from=inv.initDateFrom||iso(new Date()),to=inv.initDateTo||from,sp=inv.specialtyId||'';
  if(!sp){try{var fl=getSavedWeeklyFilters().find(function(x){return String(x.name||'').trim()===String(inv.initFilter||'').trim()});
   var fo=fl&&(data.folders||[]).find(function(f){return String(f.id)===String(fl.sourceFolderId)});
   sp=(fl&&fl.specialtyId)||(fo&&fo.specialtyId)||'';}catch(e){}}
  var days=Math.max(1,Math.round((new Date(to+'T12:00:00')-new Date(from+'T12:00:00'))/86400000)+1);
  var l=read().filter(function(e){return String(e.src)!==String(inv.id)});
  function add(type,amount,extra){
   if(!(Math.abs(amount)>1e-9))return false;
   l.push(Object.assign({id:'ck'+Date.now()+Math.random().toString(36).slice(2,6),type:type,date:from,dateTo:to,amount:Math.abs(amount),src:String(inv.id),srcName:inv.initDetail||'',specialtyId:sp,note:''},extra||{}));return true;
  }
  var r={};
  r.sale=add('sale',num(fd.calc_sGrand),{dir:'لكم',qty:fd.qQty||''});
  r.workers=add('workers',num(fd.sPrivateOut),{dir:'لكم',days:days});
  /* السحب: سند منفصل لكل فاتورة يومية (كالعملات)، وإن لم تتوفر الأيام يُرسل المجموع كسند واحد */
  var wDays=(Array.isArray(fd.__withdraw)?fd.__withdraw:[]).filter(function(x){return x&&num(x.amount)});
  r.withdraw=false;
  var wLabel=String(fd.wNote||'').trim()||'سحب فلوس';
  if(wDays.length){wDays.forEach(function(x){var wd=String(x.date||'').trim();var stmt=wLabel+' — '+String(x.name||'').trim()+(wd?' '+wd:'');if(add('withdraw',num(x.amount),{dir:'عليكم',name:stmt,date:wd||from,dateTo:wd||to,note:stmt}))r.withdraw=true})}
  else{r.withdraw=add('withdraw',num(fd.wValue),{dir:'عليكم',name:wLabel,note:wLabel})}
  /* سندان للدين بدل سند واحد: (1) مسلم فلوس لكم (2) بيع دين عليكم */
  var grossDebt=num(fd.calc_debtTotal),paidMoney=num(fd.calc_prevTotal);
  var recRows=(Array.isArray(fd.__prev)?fd.__prev:[]).filter(function(x){return x&&num(x.amount)}).map(function(x){return {name:String(x.name||'').trim(),amount:num(x.amount)}});
  var debtRows=(Array.isArray(fd.__debt)?fd.__debt:[]).filter(function(x){return x&&(String(x.name||'').trim()||num(x.amount)||num(x.weekly))}).map(function(x){var a=num(x.amount),w=num(x.weekly);return {name:String(x.name||'').trim(),qty:String(x.qty==null?'':x.qty).trim(),amount:a,weekly:w,rest:Math.round((a-w)*1000)/1000}});
  if(!grossDebt&&debtRows.length)grossDebt=debtRows.reduce(function(t,x){return t+x.rest},0);
  if(!paidMoney&&recRows.length)paidMoney=recRows.reduce(function(t,x){return t+x.amount},0);
  r.received=add('debts',paidMoney,{dir:'لكم',kind:'received',recRows:recRows,note:''});
  r.debtsale=add('debts',grossDebt,{dir:'عليكم',kind:'debtsale',debtRows:debtRows,note:''});
  /* العملات: سند واحد لكل فاتورة يوم (يجمع صفوف العملات في ذلك اليوم)؛ وإن لم تتوفر الأيام يُرسل سند واحد للتفصيل */
  var curDays=(Array.isArray(fd.__moneyDays)?fd.__moneyDays:[]).filter(function(d){return d&&Array.isArray(d.rows)&&d.rows.length});
  r.currency=false;
  if(curDays.length){curDays.forEach(function(d){
   var rs=d.rows.map(function(x){return {name:String(x.name||'').trim(),amount:num(x.amount),value:num(x.value)}}).filter(function(x){return x.value});
   var tot=rs.reduce(function(s,x){return s+x.value},0),dd=String(d.date||'').trim();
   if(add('currency',tot,{dir:'لكم',name:'عملات '+(d.name||dd),date:dd||from,dateTo:dd||to,rows:rs}))r.currency=true;
  })}
  else{
   var rows=(Array.isArray(fd.__money)?fd.__money:[]).filter(function(x){return x&&(x.name||num(x.amount)||num(x.value))});
   var tot0=rows.reduce(function(s,x){return s+num(x.value)},0);
   r.currency=add('currency',tot0,{dir:'لكم',rows:rows});
  }
  write(l);
  ['sale','workers','withdraw','debts','currency'].forEach(syncClock);
  return r;
 };
 function fmt0(n){return n.toLocaleString('en-US',{maximumFractionDigits:3})}

 // كشف العملات للطباعة: قسم لكل عملة مختارة، وكل صف سند عملة (قيمة بعد الصرف ومبلغ العملة وسعر الصرف)
 function curMatch(a,b){a=String(a||'').trim();b=String(b||'').trim();return !!a&&!!b&&(a===b||a.indexOf(b)>=0||b.indexOf(a)>=0)}
 window.__currencyStmtSelected=function(){
  var s=data.settings||{},all=(s.currencies||[]).map(function(c){return String(c.name||'').trim()}).filter(Boolean);
  if(Array.isArray(s.currencyStmtList))return s.currencyStmtList.slice();
  return all;
 };
 function printCurrencyStatement(auth){
  if(!window.PV2||!window.PV2.currencyStatement){toast('تعذر تجهيز الطباعة');return}
  var s=data.settings||{},sel=window.__currencyStmtSelected();
  if(!sel.length){toast('اختر عملة واحدة على الأقل من إعدادات الطباعة');return}
  var from=($('ffDateFrom')||{}).value||'',to=($('ffDateTo')||{}).value||'';
  var dayFmt=function(v){var q=String(v||'').split('-');return q.length===3?q[2]+'/'+q[1]+'/'+q[0]:'—'};
  var list=visible().slice();
  list.sort(function(a,b){var x=String(a.date||''),y=String(b.date||'');if(x!==y)return x<y?-1:1;return sentStamp(a)-sentStamp(b)});
  var known=(s.currencies||[]).map(function(c){return {name:String(c.name||'').trim(),sym:c.symbol||''}});
  var sections=sel.map(function(name){
   var meta=known.find(function(k){return k.name===name})||{name:name,sym:''};
   var run=0,amtL=0,amtO=0,totL=0,totO=0,rows=[];
   list.forEach(function(e){
    (Array.isArray(e.rows)?e.rows:[]).forEach(function(rw){
     if(!curMatch(rw.name,name))return;
     var amount=num(rw.amount),value=num(rw.value);
     if(!value&&!amount)return;
     var lk=e.dir!=='عليكم';
     run+=lk?value:-value;
     if(lk){totL+=value;amtL+=amount}else{totO+=value;amtO+=amount}
     var t=sentStamp(e),dd=dayFmt(e.date);
     if(t){var d=new Date(t);dd=pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear()}
     rows.push({stmt:esc(entryName(e))+(e.note?'<br>'+esc(e.note):''),bal:run,dir:lk?'لكم':'عليكم',value:value,amount:amount,rate:amount?value/amount:1,type:lk?'سند قبض لكم':'سند حوالة عليكم',date:dd});
    });
   });
   return {heading:'العملة',name:meta.name,sym:meta.sym,rows:rows,balance:run,totalL:totL,totalO:totO,amtL:amtL,amtO:amtO};
  });
  window.PV2.currencyStatement({
   title:(auth?'مصادقة ':'')+'ملخص المعاملات المالية',
   period:(auth?'للفترة من ':'خلال الفترة من ')+dayFmt(from)+' إلى '+dayFmt(to),
   filterLine:'العملة: '+sel.join(' | ')+' | نوع المعاملة: سندات العملات والحوالات',
   header:s.currencyStmtHeader!==false,
   summary:s.currencyStmtSummary!==false,
   sections:sections
  });
 }
 // بطاقة إعدادات كشف العملات في إعدادات الطباعة
 /* الطباعة المرفهة: إعدادات الشكل تُحفظ في data.settings.lux وتُطبَّق على كل الطباعة عبر luxCss() */
 var LUX_STYLES=[['neu','Neumorphism'],['skeu','Skeuomorphism'],['glass','Glassmorphism'],['fluent','Fluent Design'],['flat','Flat Design'],['m3','Material Design 3'],['minimal','Minimal UI'],['neobrut','Neobrutalism'],['luxury','Luxury UI'],['bento','Bento Grid'],['editorial','Editorial UI'],['classic','Classic UI'],['futuristic','Futuristic UI'],['3d','3D UI'],['hybrid','Hybrid UI']];
 var LUX_SHAPES=[['box','مربع'],['soft','زوايا خفيفة'],['rounded','مستدير'],['corners','دائري الزوايا'],['capsule','كبسولي'],['circle','دائري']];
 var LUX_LINES=[['solid','متصل'],['dashed','متقطع'],['dotted','منقط'],['double','مزدوج'],['groove','محفور'],['ridge','بارز'],['inset','داخلي'],['outset','خارجي']];
 var LUX_BTNS=[['classic','كلاسيكي مزخرف'],['rounded','مستطيل بحواف دائرية'],['simple','بسيط']];
 var LUX_THICK=[['thin','رفيع'],['medium','متوسط'],['thick','سميك']];
 window.setLux=function(k,v){data.settings.lux=data.settings.lux||{};data.settings.lux[k]=v;save();};
 window.setLuxOn=function(btn){var on=!((data.settings.lux||{}).on);setLux('on',on);btn.classList.toggle('on',on);try{var sc=document.getElementById('subContent');if(sc&&/تفعيل الطباعة المرفهة/.test(sc.innerHTML)){var y=window.pageYOffset,y2=sc.scrollTop;sc.innerHTML=renderSettingsPage('printing');window.scrollTo(0,y);sc.scrollTop=y2}}catch(e){}};
 window.setLuxBg=function(input){var f=input.files&&input.files[0];if(!f)return;var r=new FileReader();r.onload=function(){setLux('bg',r.result);if(typeof toast==='function')toast('تم حفظ الخلفية')};r.readAsDataURL(f);};
 window.__luxuryPrintCard=function(){
  var L=(data.settings.lux)||{};
  var sel=function(key,list,def){return '<select onchange="setLux(\''+key+'\',this.value)" style="width:100%;padding:6px;border-radius:8px">'+list.map(function(x){return '<option value="'+x[0]+'"'+((L[key]||def)===x[0]?' selected':'')+'>'+x[1]+'</option>'}).join('')+'</select>'};
  var row=function(label,html){return '<div style="margin:8px 0"><div style="font-weight:800;margin-bottom:4px">'+label+'</div>'+html+'</div>'};
  var clear=L.clear==null?100:+L.clear;
  return '<div class="settingsCard"><h3>الطباعة المرفهة</h3>'
   +'<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin:6px 0"><b style="font-size:14px">تفعيل الطباعة المرفهة</b><button class="switch '+(L.on?'on':'')+'" onclick="setLuxOn(this)"><i></i></button></div>'
   +row('قوالب جاهزة (تتجاوز الخيارات الأخرى)',sel('tpl',[['','بدون قالب (اختياري)'],['1','القالب 1: ذهبي فاخر'],['2','القالب 2: زجاجي حديث'],['3','القالب 3: مينيمال نظيف'],['4','القالب 4: نيوبروتاليزم'],['5','القالب 5: شبكة بينتو'],['6','القالب 6: مادة 3'],['7','القالب 7: مستقبلي داكن'],['8','القالب 8: تحريري أنيق'],['9','القالب 9: كلاسيكي مزخرف'],['10','القالب 10: هجين عصري']],''))
   +row('نوع التصميم للخلايا والأعمدة',sel('style',LUX_STYLES,'minimal'))
   +row('شكل الإطار للخلايا والأعمدة',sel('shape',LUX_SHAPES,'box'))
   +row('نمط خط الإطار للخلايا والأعمدة',sel('line',LUX_LINES,'solid'))
   +row('شكل الأزرار للخلايا والأعمدة',sel('btn',LUX_BTNS,'simple'))
   +row('قوالب أزرار الخلايا (تضاف فوق)',sel('btnT',[['','بدون'],['pill','حبوب'],['grad','تدرج داكن'],['outline','إطار شفاف'],['raised','بارز مع ظل'],['glass','زجاجي'],['neon','نيون']],''))
   +row('قوالب الأعمدة (تضاف فوق)',sel('colT',[['','بدون'],['zebra','تخطيط متناوب'],['firstAccent','عمود أول مميز'],['vsep','فواصل عمودية فقط'],['hsep','فواصل أفقية فقط'],['gold','إطار ذهبي'],['tint','ألوان لكم وعليكم']],''))
   +row('عناصر عصرية (تضاف فوق)',sel('modT',[['','بدون'],['rowcards','صفوف منفصلة'],['floating','جدول عائم'],['gradbar','شريط عنوان متدرج'],['pillsum','إجمالي حبة'],['mono','أحادي أنيق'],['dark','داكن']],''))
   +row('الظلال للإطار والخلايا والأعمدة',sel('shadow',[['on','تشغيل'],['off','إيقاف']],'off'))
   +row('سمك الإطار للخلايا والأعمدة',sel('thick',LUX_THICK,'medium'))
   +'<div style="font-size:12px;opacity:.8;margin:6px 0">عند التفعيل تتحكم الطباعة المرفهة بالشكل والألوان وشكل الورقة في كل الكشوفات والسندات، وتتعطل «ألوان الطباعة» و«لون النص».</div>'
   +row('لون النصوص العادية',luxColor(L,'txt'))
   +'<div style="font-weight:900;margin:12px 0 2px;border-top:1px solid #ddd;padding-top:8px">مبالغ «لكم»</div>'
   +row('لون نص مبلغ «لكم»',luxColor(L,'txtL'))
   +row('لون أرقام المبالغ «لكم»',luxColor(L,'numL'))
   +'<div style="font-weight:900;margin:12px 0 2px;border-top:1px solid #ddd;padding-top:8px">مبالغ «عليكم»</div>'
   +row('لون نص مبلغ «عليكم»',luxColor(L,'txtO'))
   +row('لون أرقام المبالغ «عليكم»',luxColor(L,'numO'))
   +'<div style="font-weight:900;margin:12px 0 2px;border-top:1px solid #ddd;padding-top:8px">المبالغ الإجمالية</div>'
   +row('لون نص الإجماليات',luxColor(L,'txtT'))
   +row('لون أرقام الإجماليات',luxColor(L,'numT'))
   +'<div style="font-weight:900;margin:12px 0 2px;border-top:1px solid #ddd;padding-top:8px">شكل الورقة</div>'
   +row('لون الورقة',luxColor(L,'paper'))
   +row('إطار الورقة',sel('frame',[['','بدون'],['thin','رفيع'],['thick','سميك'],['double','مزدوج']],''))
   +row('الخلفية للورقة',(L.bg?'<img src="'+L.bg+'" style="max-height:60px;display:block;margin-bottom:6px">':'')+'<input type="file" accept="image/*" onchange="setLuxBg(this)">'+(L.bg?' <button type="button" onclick="setLux(\'bg\',\'\');this.parentNode.querySelector(\'img\')&&this.parentNode.querySelector(\'img\').remove();this.remove()">حذف الخلفية</button>':''))
   +row('درجة وضوح الخلفية: <span id="luxClearVal">'+clear+'%</span>','<input type="range" min="0" max="100" value="'+clear+'" oninput="setLux(\'clear\',+this.value);document.getElementById(\'luxClearVal\').textContent=this.value+\'%\'" style="width:100%">')
   +'</div>';
 };
window.__currencyStmtCard=function(){
  var s=data.settings||{},sel=window.__currencyStmtSelected(),all=s.currencies||[];
  var sw=function(key,label){var on=s[key]!==false;return '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin:6px 0"><b style="font-size:14px">'+label+'</b><button class="switch '+(on?'on':'')+'" onclick="toggleCurrencyStmtSet(\''+key+'\',this)"><i></i></button></div>'};
  return '<div class="settingsCard"><h3>كشف العملات للطباعة</h3>'+sw('currencyStmtHeader','عرض الترويسة')+sw('currencyStmtSummary','عرض التجميع أسفل الكشف')+'<div style="margin-top:8px;font-weight:800">العملات المطبوعة</div>'+all.map(function(c){var nm=String(c.name||'').trim();return '<label style="display:flex;align-items:center;gap:8px;margin:6px 0"><input type="checkbox" '+(sel.indexOf(nm)>=0?'checked':'')+' onchange="toggleCurrencyStmtItem(\''+nm.replace(/\\/g,'\\\\').replace(/'/g,"\\'")+'\',this.checked)"> '+esc(c.name)+'</label>'}).join('')+'</div>';
 };
 window.toggleCurrencyStmtSet=function(key,btn){data.settings[key]=data.settings[key]===false;btn.classList.toggle('on',data.settings[key]!==false);save();};
 window.toggleCurrencyStmtItem=function(name,on){var cur=window.__currencyStmtSelected().slice();var i=cur.indexOf(name);if(on&&i<0)cur.push(name);if(!on&&i>=0)cur.splice(i,1);data.settings.currencyStmtList=cur;save();};

 // كشف جملة البيع النهائية: ترويسة وورق الكشوف من الإعدادات
 // الأعمدة (من اليمين): لكم | عليكم | الرصيد | التاريخ | المستند | الكمية | البيان
 function printFinalStatement(auth){
  if(cur==='currency'){printCurrencyStatement(auth);return}
  if(!window.PV2||!window.PV2.saleStatement){toast('تعذر تجهيز الطباعة');return}
  var l=visible().slice(),from=($('ffDateFrom')||{}).value||'',to=($('ffDateTo')||{}).value||'';
  l.sort(function(a,b){var x=String(a.date||''),y=String(b.date||'');if(x!==y)return x<y?-1:1;return sentStamp(a)-sentStamp(b)});
  var run=0,debt=0,pay=0;
  var dayFmt=function(v){var q=String(v||'').split('-');return q.length===3?q[2]+'/'+q[1]+'/'+q[0]:'—'};
  var rows=l.map(function(e){
   var s=saleSigned(e),amt=Math.abs(entryTotal(e)),isDebt=s<0;
   run+=s;
   if(isDebt)debt+=amt;else pay+=amt;
   var t=sentStamp(e),dd=dayFmt(e.date);
   if(t){var d=new Date(t);dd=pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear()}
   var fromDetail=!!e.src;
   var doc=fromDetail?esc(e.srcName||entryName(e)):'سند قبض للحساب<br>'+esc(entryName(e));
   var note=(e.note?escNl(e.note):'')+(fromDetail&&e.dateTo&&e.dateTo!==e.date?(e.note?'<br>':'')+'من '+esc(e.date)+' إلى '+esc(e.dateTo):'');
   return {date:dd,pay:isDebt?0:amt,debt:isDebt?amt:0,bal:run,doc:doc,qty:(fromDetail&&e.qty!==undefined&&e.qty!=='')?String(e.qty):'',note:note};
  });
  var a=activeSpec(),spn='كل التخصيصات';
  if(a!=='all'){var sp=((data.settings&&data.settings.specialties)||[]).find(function(x){return String(x.id)===String(a)});if(sp&&sp.name)spn=sp.name}
  var range=dayFmt(from)+' إلى '+dayFmt(to);
  window.PV2.saleStatement({
   auth:!!auth,showQty:cur==='sale',
   title:'كشف '+TITLES[cur]+' تخصيص('+spn+')',
   heading:'كشف '+TITLES[cur]+'، ويغطي العمليات المالية',
   period:(auth?'للفترة من ':'خلال الفترة من ')+range,
   name:spn,unit:(data.settings&&data.settings.currency)||'',
   rows:rows,debt:debt,pay:pay
  });
 }
 window.openClockPage=function(key){
  if(!TITLES[key])return;
  opening=true;
  try{window.openFullFilterPage('weekly')}finally{opening=false}
  cur=key;document.body.classList.toggle('debt-clock-page',key==='debts');if(key==='debts'&&window.__debtFunds)window.__debtFunds.reset();
  var t=$('ffTitle');if(t)t.textContent=TITLES[key];
  render();
 };
 // إعادة تعيين الوضع عند فتح أي صفحة أخرى
 var ofp=window.openFullFilterPage;
 window.openFullFilterPage=function(){if(!opening){cur=null;layout([])}return ofp.apply(this,arguments)};
 var cfp=window.closeFullFilterPage;
 window.closeFullFilterPage=function(){if(cur==='debts'&&window.__debtFunds&&window.__debtFunds.back())return;cur=null;document.body.classList.remove('debt-clock-page');layout([]);var o=$('clkEntryOv');if(o)o.remove();return cfp.apply(this,arguments)};
 ['setFullFilterSort','shiftFullFilterDates','applyFullFilterDates','renderWeeklyFilterAccounts'].forEach(function(n){
  var o=window[n];if(typeof o!=='function')return;
  window[n]=function(){var r=o.apply(this,arguments);if(cur)render();return r};
 });
 // زر (+) في أي صفحة من صفحات المراقب يفتح النافذة الموحدة
 var fab=window.fabAction;
 window.fabAction=function(){var p=$('fullFilterPage');if(cur&&p&&p.classList.contains('show')){if(cur==='debts'&&window.__debtFunds&&window.__debtFunds.fab())return;openEntry(null);return}return fab.apply(this,arguments)};
 var style=document.createElement('style');style.textContent='#fullFilterPage .cp-row.cp-selected{outline:3px solid #2563eb;background:#eff6ff}#fullFilterPage .cp-check{float:right;color:#0752a2;font-size:20px;font-weight:900;margin-left:8px}#clockEntryActionMenu{position:fixed;inset:0;z-index:10120;background:#0008;display:flex;align-items:center;justify-content:center;padding:18px}#clockEntryActionMenu .menu{width:100%;max-width:360px;background:#fff;border-radius:18px;padding:14px;display:grid;gap:8px}#clockEntryActionMenu button{border:0;border-radius:10px;padding:12px;font:900 14px inherit;background:#eaf2fb;color:#12345a}';document.head.appendChild(style);
 var sst=document.createElement('style');sst.textContent='#fullFilterPage .cp-shead{display:grid;grid-template-columns:11% 19% 15% 9% 29% 17%;direction:rtl;align-items:center;text-align:center;background:linear-gradient(180deg,#7a0d1c,#4a0612);color:#fff;font-weight:900;font-size:13px;padding:9px 6px;border-radius:12px;margin:6px 0 8px}#fullFilterPage .cp-row.cp-srow{display:grid!important;grid-template-columns:11% 19% 15% 9% 29% 17%;direction:rtl;align-items:center;gap:0;padding:12px 6px;border-radius:14px;border-inline-start:5px solid #15803d;text-align:center}#fullFilterPage .cp-row.cp-srow.debt{border-inline-start-color:#dc2626}#fullFilterPage .cp-srow>span{min-width:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font-weight:800;font-size:13px;color:#10243c;word-break:break-word}#fullFilterPage .cp-srow small{font-size:11px;font-weight:700;color:#64748b}#fullFilterPage .cp-srow .c-type{font-weight:900;color:#15803d}#fullFilterPage .cp-srow.debt .c-type{color:#dc2626}#fullFilterPage .cp-srow .c-amt{font-weight:900;color:#0f172a;direction:ltr}#fullFilterPage .cp-srow .c-note{align-items:flex-start;text-align:right}#fullFilterPage .cp-srow .c-note b{font-size:13px;font-weight:900;line-height:1.5}#fullFilterPage .cp-srow .c-bal{font-weight:900;direction:ltr}#fullFilterPage .cp-srow .c-bal.pos{color:#15803d}#fullFilterPage .cp-srow .c-bal.neg{color:#dc2626}#fullFilterPage .cp-srow .cp-chk{font-style:normal;color:#0752a2;font-size:18px}#fullFilterPage .cp-shead.noqty,#fullFilterPage .cp-row.cp-srow.noqty{grid-template-columns:12% 21% 17% 33% 17%}#fullFilterPage .cp-srow.pay .c-amt{color:#15803d}#fullFilterPage .cp-srow.debt .c-amt{color:#dc2626}';document.head.appendChild(sst);
 function closeEntryMenu(){var m=$('clockEntryActionMenu');if(m)m.remove()}
 function openEntryMenu(id){closeEntryMenu();var m=document.createElement('div');m.id='clockEntryActionMenu';m.innerHTML='<div class="menu"><b style="text-align:center">خيارات المعاملة</b><button data-act="select">☑ تحديد المعاملة</button><button data-act="all">☑ تحديد الكل</button><button data-act="delete" style="background:#fee2e2;color:#b91c1c">🗑 حذف المعاملة</button><button data-act="print">🖨️ طباعة سند</button><button data-act="image">📷 حفظ صورة سند</button><button data-act="edit">✏️ تعديل المعاملة</button><button data-act="cancel">إغلاق</button></div>';m.addEventListener('click',function(ev){if(ev.target===m||ev.target.dataset.act==='cancel'){closeEntryMenu();return}var a=ev.target.dataset.act;if(!a)return;closeEntryMenu();if(a==='select'){selectMode=true;selectedIds=[String(id)];render()}else if(a==='all'){selectMode=true;selectedIds=visible().map(function(x){return String(x.id)});render()}else if(a==='delete'){deleteEntries([String(id)])}else if(a==='print'){printSingleEntry(id)}else if(a==='image'){saveSingleEntryImage(id)}else if(a==='edit'){openEntry(id)}});document.body.appendChild(m)}
 function deleteEntries(ids){if(!ids.length)return;if(!confirm('حذف المعاملات المحددة؟ سيتم نقلها إلى سلة المحذوفات إن كانت مفعلة.'))return;var all=read(),gone=all.filter(function(x){return ids.indexOf(String(x.id))>=0});gone.forEach(function(x){if(typeof addToTrash==='function')addToTrash(x,'clockEntry',(x.note||x.type||'عملية المراقب')+' - '+(x.date||''))});write(all.filter(function(x){return ids.indexOf(String(x.id))<0}));selectedIds=[];selectMode=false;syncClock(cur);render();toast('تم حذف المعاملات المحددة')}
  function curVoucherLines(e){
   var out=(e.dir==='عليكم'),dayNames=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
   var dmyOf=function(v){var q=String(v||'').split('-');return q.length===3?q[2]+'/'+q[1]+'/'+q[0]:(v||'—')};
   var sp=((data.settings&&data.settings.specialties)||[]).find(function(x){return String(x.id)===String(e.specialtyId||'')});
   var from=out?((e.fundName||e.name||'')+' + الصرافة'):('من '+(e.srcName||entryName(e))+(sp&&sp.name?' + '+sp.name:''));
   var dObj=new Date(String(e.date||'')+'T12:00:00'),invoiceDay=(isNaN(dObj.getTime())?'':dayNames[dObj.getDay()]+' ')+dmyOf(e.date);
   var t=sentStamp(e),bond=dmyOf(e.date);if(t){var d=new Date(t);bond=pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear()}
   return {out:out,from:from,invoiceDay:invoiceDay,dateStr:bond};
 }
 function printSingleEntry(id){var e=read().find(function(x){return String(x.id)===String(id)});if(!e)return;var out=(e.dir==='عليكم');
  if(e.type==='currency'&&window.PV2&&window.PV2.currencyVoucher){var L=curVoucherLines(e);PV2.currencyVoucher({title:'سند عملات',out:L.out,from:L.from,invoiceDay:L.invoiceDay,dateStr:L.dateStr,rows:entryRows(e).map(function(r){return {a:r.amount,c:r.name,v:r.value}}),total:entryTotal(e)});return}PV2.voucher({title:out?'سند صرف':'سند قبض',out:out,dateStr:String(e.date||'')+(e.dateTo&&e.dateTo!==e.date?' إلى '+e.dateTo:''),from:TITLES[e.type]||'الصفحة',words:esc(e.note||''),label:out?'المبلغ عليكم':'المبلغ لكم',rows:entryRows(e).map(function(r){return {a:r.amount,c:r.name,v:r.value}}),total:entryTotal(e),unit:'',note:''})}
 function saveSingleEntryImage(id){var e=read().find(function(x){return String(x.id)===String(id)});if(!e)return;var c=document.createElement('canvas');c.width=1000;c.height=700;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.fillStyle='#111';x.direction='rtl';x.textAlign='right';x.font='bold 34px Arial';
 if(e.type==='currency'){var L=curVoucherLines(e);x.fillText('سند عملات',940,65);x.font='26px Arial';x.fillText(L.from,940,125);x.fillText(L.invoiceDay,940,175);x.fillText('تاريخ السند: '+L.dateStr,940,225);}
 else{x.fillText('سند '+(TITLES[e.type]||'معاملة'),940,65);x.font='26px Arial';x.fillText('التاريخ: '+e.date,940,125);x.fillText('البيان: '+(e.note||'—'),940,175);x.fillText('الرصيد: '+(e.dir||'لكم'),940,225);}var yy=300;entryRows(e).forEach(function(r){x.fillText(r.name+' : '+fmt(r.amount)+' × '+fmt(r.rate==null?1:r.rate)+' = '+fmt(r.value),940,yy);yy+=48});x.font='bold 32px Arial';x.fillText('الإجمالي: '+fmt(entryTotal(e)),940,Math.min(650,yy+30));var a=document.createElement('a');a.href=c.toDataURL('image/png');a.download='سند-'+e.date+'.png';a.click()}
 window.__clockEntryLongStart=function(ev,id){if(selectMode)return;longTriggered=false;if(longTimer)clearTimeout(longTimer);longTimer=setTimeout(function(){longTriggered=true;if(navigator.vibrate)navigator.vibrate(35);openEntryMenu(id)},550)};
 window.__clockEntryLongCancel=function(){if(longTimer){clearTimeout(longTimer);longTimer=null}};
 document.addEventListener('click',function(e){
  var allBtn=e.target.closest&&e.target.closest('[data-cp-all]');if(allBtn){selectMode=true;selectedIds=visible().map(function(x){return String(x.id)});render();return}
  var delBtn=e.target.closest&&e.target.closest('[data-cp-delete]');if(delBtn){deleteEntries(selectedIds.slice());return}
  var doneBtn=e.target.closest&&e.target.closest('[data-cp-done]');if(doneBtn){selectMode=false;selectedIds=[];render();return}
  var printBtn=e.target.closest&&e.target.closest('[data-clock-print]');
  var sendBtn=e.target.closest&&e.target.closest('[data-clock-send]');if(sendBtn&&cur==='debts'&&window.__debtFunds){window.__debtFunds.sendNow();return}
  var authBtn=e.target.closest&&e.target.closest('[data-clock-auth]');
  if((printBtn||authBtn)&&cur){var au=!!authBtn;if(cur==='debts'&&window.__debtFunds){window.__debtFunds.printNow(au);return}printFinalStatement(au);return}
  var it=e.target.closest&&e.target.closest('#homeClock .clock-item');
  if(it){var lb=it.querySelector('.clock-label');var k=lb&&KEYS[lb.textContent.trim()];if(k){window.openClockPage(k)}return}
  var r=e.target.closest&&e.target.closest('#fullFilterPage .cp-row');
  if(r&&cur){var id=r.getAttribute('data-cid');if(longTriggered){longTriggered=false;e.preventDefault();e.stopPropagation();return}if(selectMode){var ix=selectedIds.indexOf(String(id));if(ix>=0)selectedIds.splice(ix,1);else selectedIds.push(String(id));render();return}openEntry(id);}
 });
 // تحديث بطاقات المراقب عند فتح التطبيق، حتى لا تبقى مجاميع قديمة أو مجموع مبالغ لكم وعليكم دون طرح
 try{if(!localStorage.getItem('smartadmin_clock_dir_mig_v1')){var ml=read(),ch=false;ml.forEach(function(x){if(x&&x.src&&(x.type==='withdraw'||x.type==='currency')&&x.dir==='عليكم'){x.dir='لكم';ch=true}});if(ch)write(ml);localStorage.setItem('smartadmin_clock_dir_mig_v1','1')}}catch(_e){}
 window.__clockSyncAll=syncAllClockTotals;window.__clockRerender=function(){if(cur)render()};
 setTimeout(syncAllClockTotals,0);
 window.addEventListener('pageshow',syncAllClockTotals);
 // تغيير التخصيص من الشريط
 var sc=window.__specChange;
 if(typeof sc==='function')window.__specChange=function(){var r=sc.apply(this,arguments);if(cur)render();return r};
})();

/* source script: debt-funds-logic */
(function(){'use strict';
var K='smartadmin_clock_debt_funds_v1',v='main',fid=null,aid=null,C=null;
var $=function(i){return document.getElementById(i)};
var E=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var F=function(n){return (Number(n)||0).toLocaleString('en-US',{maximumFractionDigits:3})};
function db(){try{var d=JSON.parse(localStorage.getItem(K));if(d&&d.funds)return d}catch(e){}return {funds:[],accounts:[],vouchers:[]}}
function sv(d){try{localStorage.setItem(K,JSON.stringify(d))}catch(e){toast('تعذر الحفظ')}}
function uid(p){return p+Date.now()+Math.random().toString(36).slice(2,5)}
function rr(){if(window.__clockRerender)window.__clockRerender()}
function inR(x,f,t){return (!f||x>=f)&&(!t||x<=t)}
function T(vs){var p=0,q=0;vs.forEach(function(x){if(x.dir==='له')p+=x.amount;else q+=x.amount});return {pay:p,debt:q,net:p-q}}
function lb(n){return n>0?'لكم':n<0?'عليكم':'متعادل'}
function cl(n){return n>0?'#15803d':n<0?'#dc2626':'#64748b'}
function fV(d,id,f,t){var ids=d.accounts.filter(function(a){return a.fund===id}).map(function(a){return a.id});return d.vouchers.filter(function(x){return ids.indexOf(x.acc)>=0&&inR(x.date,f,t)})}
function grid(t){return '<div class="dfG"><div>لكم<b style="color:#15803d">'+F(t.pay)+'</b></div><div>عليكم<b style="color:#dc2626">'+F(t.debt)+'</b></div><div>الباقي<b style="color:'+cl(t.net)+'">'+F(Math.abs(t.net))+'</b>'+lb(t.net)+'</div></div>'}
function card(name,img,t,attr,btns,cls){return '<div class="dfC '+(cls||'')+'" '+attr+'><div class="n">'+(img?'<img src="'+img+'">':'📥')+E(name)+'</div>'+grid(t)+(btns||'')+'</div>'}
function dlg(title,body,ok,del){var o=document.createElement('div');o.id='dfOv';
 o.innerHTML='<div class="b"><b style="font-size:17px">'+title+'</b>'+body+'<div class="a"><button class="s">💾 حفظ</button><button class="c">إلغاء</button>'+(del?'<button class="x">🗑</button>':'')+'</div></div>';
 o.onclick=function(e){var c=e.target.className;if(e.target===o||c==='c')o.remove();else if(c==='s'){if(ok(o)!==false)o.remove()}else if(c==='x'&&confirm('تأكيد الحذف؟')){del();o.remove()}};
 var old=$('dfOv');if(old)old.remove();document.body.appendChild(o);return o}
function fl(id,l,val,type){return '<label>'+l+'</label><input id="'+id+'" type="'+(type||'text')+'" value="'+E(val==null?'':val)+'"'+(type==='number'?' inputmode="decimal" step="any"':'')+'>'}
function g(o,i){return o.querySelector('#'+i).value.trim()}
function fundDlg(id){var d=db(),f=id?d.funds.find(function(x){return x.id===id}):null;
 var o=dlg(f?'تعديل الصندوق':'إضافة صندوق حسابات ديون',fl('fN','اسم الصندوق',f&&f.name)+'<label>صورة الصندوق</label><input id="fI" type="file" accept="image/*">'+fl('fO','ترتيب الصندوق',f?f.order:d.funds.length+1,'number'),function(o){
  var n=g(o,'fN');if(!n){toast('أدخل اسم الصندوق');return false}
  var d=db(),x=id?d.funds.find(function(z){return z.id===id}):null;
  if(!x){x={id:uid('df')};d.funds.push(x)}
  x.name=n;x.order=Number(g(o,'fO'))||0;if(o._img)x.img=o._img;sv(d);rr();toast('تم الحفظ')},
  f&&function(){var d=db();var ids=d.accounts.filter(function(a){return a.fund===id}).map(function(a){return a.id});d.funds=d.funds.filter(function(x){return x.id!==id});d.accounts=d.accounts.filter(function(a){return a.fund!==id});d.vouchers=d.vouchers.filter(function(x){return ids.indexOf(x.acc)<0});sv(d);rr()});
 o.querySelector('#fI').onchange=function(){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var c=document.createElement('canvas');c.width=c.height=96;c.getContext('2d').drawImage(im,0,0,96,96);o._img=c.toDataURL('image/jpeg',.7)};im.src=r.result};if(this.files[0])r.readAsDataURL(this.files[0])}}
function accDlg(id){var d=db(),a=id?d.accounts.find(function(x){return x.id===id}):null;var m=a&&a.message||{},set=a&&a.settings||{};
 var body=fl('aN','الاسم',a&&a.name)+fl('aP','رقم الهاتف',a&&a.phone,'tel')+'<label style="display:flex;gap:8px;align-items:center;margin:10px 0"><input id="aCapOn" type="checkbox" '+(a&&a.lim>0?'checked':'')+'> تفعيل سقف المديونية</label>'+fl('aL','سقف المديونية',a&&a.lim,'number')+'<div id="account-send-timing" style="border-top:1px solid #dbe3ef;margin-top:10px;padding-top:8px"><label>تحديد الإرسال</label><div class="a"><label><input type="radio" name="dfWhen" value="auto" '+((m.when||'confirm')==='auto'?'checked':'')+'> تلقائي</label><label><input type="radio" name="dfWhen" value="confirm" '+((m.when||'confirm')==='confirm'?'checked':'')+'> بعد التأكيد</label><label><input type="radio" name="dfWhen" value="never" '+(m.when==='never'?'checked':'')+'> لا ترسل</label></div></div>';
 dlg(a?'تعديل الحساب':'إضافة حساب جديد',body,function(o){var n=g(o,'aN');if(!n){toast('أدخل الاسم');return false}var limOn=o.querySelector('#aCapOn').checked,lim=limOn?Number(g(o,'aL')):0;if(limOn&&!(lim>0)){toast('أدخل سقفاً أكبر من صفر');return false}var d=db(),x=a?d.accounts.find(function(z){return z.id===id}):null;if(!x){x={id:uid('da'),fund:fid};d.accounts.push(x)}x.name=n;x.phone=g(o,'aP');x.lim=lim;x.message=x.message||{};x.message.when=o.querySelector('[name=dfWhen]:checked')?.value||'confirm';sv(d);rr();toast('تم الحفظ')},a&&function(){var d=db();d.accounts=d.accounts.filter(function(x){return x.id!==id});d.vouchers=d.vouchers.filter(function(x){return x.acc!==id});sv(d);v='fund';rr()})}
function openDebtVoucherCalculator(){
 var old=document.getElementById('dfVoucherCalc');if(old)old.remove();
 var modal=document.createElement('div');modal.id='dfVoucherCalc';modal.style.cssText='position:fixed;inset:0;z-index:10300;background:rgba(15,23,42,.62);display:flex;align-items:center;justify-content:center;padding:12px;direction:rtl';
 var keys=[['7','8','9','*'],['4','5','6','-'],['1','2','3','+'],['0','00','.','/'],['%','DEL','C','=']];
 var grid=keys.map(function(row){return row.map(function(k){var op=['*','-','+','/','='].indexOf(k)>=0,clr=k==='C';return '<button type="button" data-vck="'+k+'" style="min-height:49px;border:1px solid #07529b;border-radius:9px;background:'+(op?'#07529b':clr?'#dc2626':'#f8fafc')+';color:'+(op||clr?'#fff':'#111827')+';font-size:21px;font-weight:800">'+({'*':'×','-':'−','/':'÷','DEL':'حذف'}[k]||k)+'</button>'}).join('')}).join('');
 modal.innerHTML='<div style="width:min(420px,100%);background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 18px 55px #0005;color:#111827"><div style="padding:12px 16px;font-size:20px;font-weight:900;color:#0f3f78">الحاسبة</div><input id="dfVcDisplay" readonly inputmode="decimal" style="display:block;box-sizing:border-box;width:calc(100% - 16px);margin:0 8px 6px;height:68px;border:2px solid #07529b;border-radius:10px;background:#f8fafc;padding:8px 12px;font-size:25px;text-align:left;direction:ltr;color:#111827"><div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:4px;padding:0 8px">'+grid+'</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;padding:7px 8px 9px"><button type="button" data-vck="CANCEL" style="min-height:45px;border:1px solid #07529b;border-radius:9px;background:#f8fafc;font-weight:800">إلغاء</button><button type="button" data-vck="USE" style="min-height:45px;border:0;border-radius:9px;background:#f59e0b;color:#fff;font-weight:900">استخدام المبلغ</button></div></div>';
 document.body.appendChild(modal);var display=modal.querySelector('#dfVcDisplay'),expr='';function close(){modal.remove()}
 function calc(){if(!expr||!/^[0-9+\-*/().%\s]+$/.test(expr))return null;var e=expr.replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');try{var n=Function('"use strict";return ('+e+')')();return Number.isFinite(n)?n:null}catch(_){return null}}
 modal.addEventListener('click',function(ev){if(ev.target===modal){close();return}var b=ev.target.closest('[data-vck]');if(!b)return;var k=b.getAttribute('data-vck');if(k==='CANCEL'){close();return}if(k==='C'){expr='';display.value='';return}if(k==='DEL'){expr=expr.slice(0,-1);display.value=expr;return}if(k==='='){var n=calc();if(n===null){display.value='خطأ في العملية';return}expr=String(Number(n.toFixed(8)));display.value=expr;return}if(k==='USE'){var n=calc();if(n===null||n<0){display.value='أدخل مبلغاً صحيحاً';return}var field=document.querySelector('#dfOv #vA');if(field){field.value=String(Number(n.toFixed(8)));field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}))}close();return}if(k==='.'&&/(\.\d*)$/.test(expr.split(/[+\-*/%]/).pop()))return;expr+=k;display.value=expr});
 modal._keyHandler=function(e){if(e.key==='Escape')close();else if(/^[0-9.]$/.test(e.key)||['+','-','*','/','%'].includes(e.key)){expr+=e.key;display.value=expr}else if(e.key==='Backspace'){expr=expr.slice(0,-1);display.value=expr}else if(e.key==='Enter'){var n=calc();if(n!==null){expr=String(Number(n.toFixed(8)));display.value=expr}}};document.addEventListener('keydown',modal._keyHandler);var rm=modal.remove.bind(modal);modal.remove=function(){document.removeEventListener('keydown',modal._keyHandler);rm()};
}
function vDlg(id){var d=db(),x=id?d.vouchers.find(function(z){return z.id===id}):null,dir=x?x.dir:'عليه',spList=(typeof data!=='undefined'&&data.settings&&Array.isArray(data.settings.specialties))?data.settings.specialties:[],oldSp=x&&(x.specialtyId||x.specialty)||'';var rows=x&&Array.isArray(x.lines)&&x.lines.length?x.lines:[{text:x&&x.note||''}];var lineHtml=rows.map(function(z,i){return '<div class="dfLine"><textarea class="dfVoucherLine" rows="2" placeholder="اكتب البيان ويمكنك إضافة عدة سطور">'+E(z.text||'')+'</textarea><button type="button" class="dfBtn dfRemoveLine">حذف السطر</button></div>'}).join('');
 var o=dlg(x?'تعديل سند':'سند جديد',fl('vD','التاريخ',x?x.date:new Date().toISOString().slice(0,10),'date')+fl('vA','المبلغ',x&&x.amount,'number')+'<button type="button" id="dfOpenVoucherCalc" class="dfBtn" style="width:100%;margin:-3px 0 10px;background:linear-gradient(135deg,#1e40af,#1e3a8a);color:#fff">🧮 فتح الحاسبة</button><label>التخصيص</label><select id="vSp"><option value="">بدون تخصيص</option>'+((oldSp&&!spList.some(function(z){return String(z.id)===String(oldSp)}))?'<option value="'+E(oldSp)+'" selected>'+E(oldSp)+'</option>':'')+spList.map(function(z){return '<option value="'+E(z.id)+'"'+(String(z.id)===String(oldSp)?' selected':'')+'>'+E(z.name)+'</option>'}).join('')+'</select><label>البيان — متعدد الأسطر</label><div id="dfLines">'+lineHtml+'</div><button type="button" id="dfAddLine" class="dfBtn">＋ إضافة سطر</button><label>إرفاق صورة</label><input id="vImg" type="file" accept="image/*">'+(x&&x.image?'<img src="'+x.image+'" style="width:70px;height:70px;object-fit:cover;border-radius:8px">':'')+'<label>النوع</label><select id="vT"><option'+(dir==='عليه'?' selected':'')+'>عليه</option><option'+(dir==='له'?' selected':'')+'>له</option></select>',function(o){var am=Number(g(o,'vA'));if(!(am>0)){toast('أدخل مبلغاً صحيحاً');return false}var dr=o.querySelector('#vT').value,d=db(),a=d.accounts.find(function(z){return z.id===aid});var old=id?d.vouchers.find(function(z){return z.id===id}):null;var balance=-T(d.vouchers.filter(function(z){return z.acc===aid&&z.id!==id})).net;if(a&&a.lim>0&&dr==='عليه'&&balance+am>a.lim){toast('تم رفض المعاملة: ستتجاوز سقف المديونية '+F(a.lim));return false}var lines=Array.from(o.querySelectorAll('.dfVoucherLine')).map(function(z){return z.value.trim()}).filter(Boolean),note=lines.join('\n');var y=old;if(!y){y={id:uid('dv'),acc:aid,ts:Date.now()};d.vouchers.push(y)}y.date=g(o,'vD');y.amount=am;y.note=note;y.lines=lines.map(function(z){return {text:z}});y.specialtyId=g(o,'vSp');y.specialty=g(o,'vSp');y.dir=dr;if(o._img)y.image=o._img;sv(d);rr();if(!old)sendDebtMessage(a,y);toast('تم الحفظ')},x&&function(){var d=db();d.vouchers=d.vouchers.filter(function(z){return z.id!==id});sv(d);rr()});var ov=$('dfOv');var calcBtn=ov&&ov.querySelector('#dfOpenVoucherCalc');if(calcBtn)calcBtn.onclick=openDebtVoucherCalculator;var add=ov&&ov.querySelector('#dfAddLine');if(ov)ov.addEventListener('focusin',function(e){if(e.target.classList&&e.target.classList.contains('dfVoucherLine'))ov._vta=e.target});if(add)add.onclick=function(){var tas=ov.querySelectorAll('#dfLines .dfVoucherLine');var ta=ov._vta&&ov.contains(ov._vta)?ov._vta:tas[tas.length-1];if(!ta)return;var st=typeof ta.selectionStart==='number'?ta.selectionStart:ta.value.length,en=typeof ta.selectionEnd==='number'?ta.selectionEnd:ta.value.length;var before=ta.value.slice(0,st),after=ta.value.slice(en);var ins=(before.length&&!before.endsWith('\n')?'\n':'')+'\n';ta.value=before+ins+after;ta.rows=Math.max(2,ta.value.split('\n').length);var pos=(before+ins).length;ta.focus();if(ta.setSelectionRange)ta.setSelectionRange(pos,pos)};if(ov)ov.addEventListener('click',function(e){if(e.target.classList.contains('dfRemoveLine')){e.preventDefault();e.stopPropagation();e.target.parentNode.remove()}});var fi=ov&&ov.querySelector('#vImg');if(fi)fi.onchange=function(){var file=this.files&&this.files[0];if(!file)return;var r=new FileReader();r.onload=function(){ov._img=r.result};r.readAsDataURL(file)}}
function debtSendNow(a,type,amount,extra,img){
 var s=(typeof data!=='undefined'&&data.settings)||{},method=s.sendMethod||'whatsapp',d=db(),bal=-T(d.vouchers.filter(function(z){return z.acc===a.id})).net;
 extra=Object.assign({balance:bal,currency:a.cur||a.c||s.currency||''},extra||{});
 var person={name:a.name,phone:a.phone},text=buildMessageText(person,type,amount,extra);
 var phone=(a.phone||'').replace(/[^0-9+]/g,''),cc=(s.countryCode||'').trim();
 if(phone&&cc&&!phone.startsWith('+')){if(!phone.startsWith(cc.replace('+','')))phone=cc+phone}
 if(!phone){toast('لا يوجد رقم');return}
 var lineKey=s.lineKey||'empty';
 if(lineKey==='zero'&&!phone.startsWith('0'))phone='0'+phone;
 if(lineKey==='country'&&cc&&!phone.startsWith(cc))phone=cc+phone;
 if(method==='share'){shareDebtText(a,text,{method:'share'});return}
 sendConfiguredMessage(person,phone,text,{image:img},method,s.waType||'business')}
function sendDebtMessage(a,x){if(!a)return;var s=(typeof data!=='undefined'&&data.settings)||{},globalWhen=s.sendWhen||'confirm',accountWhen=(a.message&&a.message.when)||globalWhen;if(accountWhen==='never')return;
 var go=function(){debtSendNow(a,x.dir==='له'?'pay':'debt',x.amount,{date:x.date,note:x.note},x.image)};
 if(accountWhen==='confirm'){if(confirm('تم حفظ المعاملة. هل تريد إرسال رسالة للحساب؟'))go()}else go()}
function shareDebtText(a,text,m){var method=m.method||'whatsapp';if(method==='sms'){location.href='sms:'+encodeURIComponent(a.phone||'')+'?body='+encodeURIComponent(text)}else if(method==='share'){if(navigator.share)navigator.share({title:'حساب '+a.name,text:text}).catch(function(){});else if(navigator.clipboard)navigator.clipboard.writeText(text)}else{var phone=(a.phone||'').replace(/[^0-9+]/g,'');var base=m.wa==='green'?'https://wa.me/':'https://api.whatsapp.com/send?phone=';var url=m.wa==='green'?base+phone+'&text='+encodeURIComponent(text):base+phone+'&text='+encodeURIComponent(text);window.open(url,'_blank')}}
function smc(t,val,col){return '<div class="sm-c"><b style="color:'+col+'">'+F(val)+'</b><span>'+t+'</span></div>'}
 // الشريط العلوي الموحّد للصندوق التلقائي وصفحة الصناديق (نفس شكل صفحة الصندوق)
 function topBar(html){var p=$('fullFilterPage');if(!p)return;p.classList.add('ff-fmt-b');var h=$('ffSumHost');if(!h){h=document.createElement('div');h.id='ffSumHost';var sort=p.querySelector('.ff-sort');if(sort)p.insertBefore(h,sort);else p.appendChild(h)}h.className='';h.innerHTML=html}
 function render(host,c){C=c;var d=db(),f=c.from,t=c.to,h='',tt=$('ffTitle'),back='<button class="dfBack" data-d="back">→ رجوع</button>';
 var l=c.visible(),A={pay:0,debt:0};l.forEach(function(e){var s=c.signed(e);if(s>0)A.pay+=s;else A.debt-=s});A.net=A.pay-A.debt;
 if(v==='auto'){tt.textContent='الصندوق التلقائي';
  topBar(smc('الإجمالي عليكم',A.debt,'#dc2626')+smc('الإجمالي لكم',A.pay,'#15803d')+smc(A.net>1e-9?'الباقي لكم':A.net<-1e-9?'الباقي عليكم':'لا يوجد رصيد',Math.abs(A.net),A.net<-1e-9?'#dc2626':'#0f172a'));
  h=l.length?l.map(c.card).join(''):''}
 else if(v==='fund'){var fo=d.funds.find(function(x){return x.id===fid});if(!fo){v='main';return render(host,c)}tt.textContent=fo.name;
  h=d.accounts.filter(function(a){return a.fund===fid}).map(function(a){var n=T(d.vouchers.filter(function(x){return x.acc===a.id&&inR(x.date,f,t)})).net;
   return '<div class="dfC acc-card" data-d="acc" data-i="'+a.id+'" data-clock-account="'+a.id+'"><span class="ac-av">'+E(String(a.name||'?').trim().charAt(0)||'?')+'</span><span class="ac-mid"><b class="ac-name">'+E(a.name)+'</b>'+(a.phone?'<small class="ac-ph">'+E(a.phone)+'</small>':'')+'</span><span class="ac-bal" style="color:'+(Math.abs(n)<1e-9?'#16a37a':cl(n))+'"><em>'+(Math.abs(n)<1e-9?'متعادل':lb(n))+'</em><b>'+F(Math.abs(n))+' '+E(a.cur||a.c||'')+'</b></span></div>'}).join('')||back}
 else if(v==='acc'){var a=d.accounts.find(function(x){return x.id===aid});if(!a){v='fund';return render(host,c)}tt.textContent=a.name;
  var vs=d.vouchers.filter(function(x){return x.acc===aid&&inR(x.date,f,t)}).sort(function(p,q){return (p.date+p.ts).localeCompare(q.date+q.ts)}),run=0,tl=T(vs);
  h='<div style="overflow-x:auto"><table class="dfT"><tr><th>النوع</th><th>المبلغ</th><th>التفاصيل</th><th>الرصيد</th><th></th></tr>'
  +(vs.map(function(x){run+=x.dir==='له'?x.amount:-x.amount;return '<tr data-clock-voucher="'+x.id+'"><td style="color:'+(x.dir==='له'?'#15803d':'#dc2626')+';font-weight:900">'+x.dir+'</td><td><b>'+F(x.amount)+'</b><br><small>'+E(x.date)+'</small></td><td>'+E(x.note).replace(/\n/g,'<br>')+'</td><td>'+F(Math.abs(run))+'<br><small>'+lb(run)+'</small></td><td></td></tr>'}).join('')||'')+'</table></div>'+card('الإجمالي','',tl,'','','df-total-card')}
 else{tt.textContent='الديون';var FT=T(d.funds.reduce(function(s,x){return s.concat(fV(d,x.id,f,t))},[])),diff=A.net+FT.net;
  topBar(smc('الإجمالي عليكم',FT.debt,'#dc2626')+smc('الإجمالي لكم',FT.pay,'#15803d')+smc(FT.net>1e-9?'الباقي لكم':FT.net<-1e-9?'الباقي عليكم':'لا يوجد رصيد',Math.abs(FT.net),FT.net<-1e-9?'#dc2626':'#0f172a'));
  h='<div class="dfBand">📥 صندوق ثابت لاستلام سندات الدين من التفصيل</div>'+card('الصندوق التلقائي','',A,'data-d="auto" data-clock-fund="auto"')
  +'<div class="dfBand">قائمة الصناديق التي تفتح حسابات العملاء داخلها في صفحة الدين</div>'
  +(d.funds.slice().sort(function(x,y){return (x.order||0)-(y.order||0)}).map(function(x){return card(x.name,x.img,T(fV(d,x.id,f,t)),'data-d="fund" data-i="'+x.id+'" data-clock-fund="'+x.id+'"','<button class="dfBtn" data-d="ef" data-i="'+x.id+'">✏️ تعديل</button>')}).join('')||'')}
 host.innerHTML=h}

// ميزات الضغط المطوّل الحسابات الخصوصيةة حصراً بصفحة الديون داخل المراقب.
var longTimer=null,longFired=false,chosenVouchers=[];
function debtPeriod(){return {from:C&&C.from||'',to:C&&C.to||''}}
function periodLabel(){var r=debtPeriod();return (r.from||'البداية')+' — '+(r.to||'حتى اليوم')}
function printDoc(title,content){
 var head='';try{if(typeof buildPrintHeader==='function')head=buildPrintHeader(title)}catch(_e){}
 if(!head){try{if(typeof printProfileHeader==='function')head=printProfileHeader()+'<h2>'+E(title)+'</h2>'}catch(_e){head='<h2>'+E(title)+'</h2>'}}
 var css='';try{if(typeof getPrintCSS==='function')css=getPrintCSS()}catch(_e){}
 if(!css)css='@page{size:A4 portrait;margin:10mm}body{font:14px Tahoma,Arial,sans-serif;color:#111}table{width:100%;border-collapse:collapse}th{background:#aebeff;color:#111}th,td{border:1px solid #536174;padding:8px;text-align:center}.sign{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:32px}.sign span{text-align:center;border-top:1px solid #777;padding-top:8px}'
 var html='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(title)+'</title><style>'+css+(window.__luxCss?window.__luxCss():'')+'.df-print{max-width:100%;margin:0 auto}.df-print>p{text-align:right;margin:8px 0;font-weight:700}.df-print table{width:100%;border-collapse:collapse;margin:10px 0;table-layout:fixed}.df-print th,.df-print td{border:1px solid #536174;padding:7px 5px;text-align:center;overflow-wrap:anywhere}.df-print th{background:#aebeff;color:#111;font-weight:900}.df-print .sign{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:28px;border-top:1px solid #777;padding-top:10px}.df-print .sign span{text-align:center;line-height:2;font-weight:800}.df-print .df-total{border:1px solid #536174;background:#f3f5fb;padding:9px;text-align:center;font-weight:900;margin-top:10px}.df-print .df-amount{font-weight:900;color:#a82336}</style></head><body><main class="df-print">'+head+content+'</main><script>window.onload=function(){setTimeout(function(){window.print()},250)};<\/script></body></html>';
 if(window.__printMethod&&window.__printMethod()!=='printer'&&window.__printDoc&&window.__printDoc(html))return;
 var w=window.open('','_blank');if(!w){toast('اسمح بالنوافذ المنبثقة');return}w.document.write(html);w.document.close()
}
function printAutoDebtBox(auth){
 var r=debtPeriod(),es=(C&&C.visible?C.visible():[]).filter(function(e){return inR(e.date,r.from,r.to)});
 var debts=[],recs=[];
 es.forEach(function(e,idx){
  if(e.kind==='debtsale'&&Array.isArray(e.debtRows))e.debtRows.forEach(function(x){var nm=String(x.name||'').trim(),amt=Number(x.amount)||0;if(!nm||!amt)return;debts.push({idx:idx,date:e.date||'',name:nm,amount:amt,paid:0,left:amt})});
  if(e.kind==='received'&&Array.isArray(e.recRows))e.recRows.forEach(function(x){var nm=String(x.name||'').trim(),amt=Number(x.amount)||0;if(!nm||!amt)return;recs.push({idx:idx,name:nm,amount:amt})});
 });
 /* مسلم فلوس: ما سلّمه المدين في فاتورة لاحقة، يُخصم من أقدم دين مفتوح للاسم نفسه */
 recs.forEach(function(rc){var amt=rc.amount;debts.forEach(function(d){if(amt<=1e-9||d.name!==rc.name||d.idx>=rc.idx||d.left<=1e-9)return;var take=Math.min(d.left,amt);d.paid+=take;d.left-=take;amt-=take;})});
 var open=debts.filter(function(d){return d.left>1e-9}),run=0,tA=0,tP=0,tL=0,rows='';
 open.forEach(function(d){run+=d.left;tA+=d.amount;tP+=d.paid;tL+=d.left;rows+='<tr><td>'+E(d.date)+'</td><td>'+E(d.name)+'</td><td>'+F(d.amount)+'</td><td>'+F(d.paid)+'</td><td>'+F(d.left)+'</td><td>'+F(run)+'</td></tr>'});
 var sign=auth?'<div class="sign"><span>عن العميل<br>الاسم: __________<br>التوقيع: __________</span><span>مدير الحسابات<br>الاسم: __________<br>التوقيع: __________</span></div>':'';
 printDoc((auth?'مصادقة ':'')+'كشف اجمالي الديون','<p>كشف اجمالي الديون الباقية عليكم خلال فترة من تاريخ '+E(r.from||'البداية')+' إلى '+E(r.to||'حتى اليوم')+'</p><table><thead><tr><th>التاريخ</th><th>الاسم</th><th>المبلغ</th><th>مسلم فلوس</th><th>مبلغ الدين الباقي</th><th>الرصيد</th></tr></thead><tbody>'+(rows||'<tr><td colspan="6">لا توجد ديون باقية ضمن الفترة</td></tr>')+'<tr><td></td><td><b>الاجمالي</b></td><td><b>'+F(tA)+'</b></td><td><b>'+F(tP)+'</b></td><td><b>'+F(tL)+'</b></td><td></td></tr></tbody></table>'+sign);
}
function printFund(id,auth){var d=db(),r=debtPeriod(),f=d.funds.find(function(x){return x.id===id}),accounts=d.accounts.filter(function(x){return x.fund===id}),rows='',p=0,q=0;if(id==='auto'){printAutoDebtBox(auth);return}
 accounts.forEach(function(a){var vs=d.vouchers.filter(function(x){return x.acc===a.id&&inR(x.date,r.from,r.to)}),z=T(vs);p+=z.pay;q+=z.debt;rows+='<tr><td>'+E(a.name)+'</td><td>'+F(z.pay)+'</td><td>'+F(z.debt)+'</td><td>'+E(lb(z.net))+' '+F(Math.abs(z.net))+'</td></tr>'});
 printDoc((auth?'مصادقة':'كشف حسابات')+' — '+(f?f.name:'الصندوق التلقائي'),'<p>الفترة: '+E(periodLabel())+'</p><table><thead><tr><th>الحساب</th><th>لكم</th><th>عليكم</th><th>الرصيد</th></tr></thead><tbody>'+(rows||'<tr><td colspan="4">لا توجد حسابات أو حركات ضمن الفترة</td></tr>')+'</tbody></table><p><b>الإجمالي لكم: '+F(p)+' | الإجمالي عليكم: '+F(q)+' | الصافي: '+F(p-q)+'</b></p>'+(auth?'<div class="sign"><span>عن العميل<br>الاسم: __________<br>التوقيع: __________</span><span>مدير الحسابات<br>الاسم: __________<br>التوقيع: __________</span></div>':''))}
function printAccount(id,auth){var d=db(),a=d.accounts.find(function(x){return x.id===id});if(!a)return;var r=debtPeriod(),vs=d.vouchers.filter(function(x){return x.acc===id&&inR(x.date,r.from,r.to)}).sort(function(x,y){return (x.date||'').localeCompare(y.date||'')});var run=0,p=0,q=0,rows=vs.map(function(x){run+=x.dir==='له'?x.amount:-x.amount;if(x.dir==='له')p+=x.amount;else q+=x.amount;return '<tr><td>'+E(x.date)+'</td><td>'+E(x.note).replace(/\n/g,'<br>')+'</td><td>'+(x.dir==='عليه'?F(x.amount):'')+'</td><td>'+(x.dir==='له'?F(x.amount):'')+'</td><td>'+E(lb(run))+' '+F(Math.abs(run))+'</td></tr>'}).join('');
  PV2.statement({title:auth?'مصادقة حساب':'كشف حساب',name:a.name,auth:auth,rows:rows,ng:q,ps:p,run:run,unit:a.cur||a.c||''})}
function printVoucherById(id){
 var d=db(),x=d.vouchers.find(function(z){return z.id===id}),a=x&&d.accounts.find(function(z){return z.id===x.acc});if(!x)return;
  var isPay=x.dir==='له',allv=d.vouchers.filter(function(z){return z.acc===x.acc}),net=T(allv).net,dp=String(x.date||'').split('-'),dd=dp.length===3?dp[2]+'-'+dp[1]+'-'+dp[0]:(x.date||'');
  PV2.txn({name:a&&a.name||'',date:dd,dirLabel:isPay?'لكم':'عليكم',amount:F(x.amount||0),unit:x.cur||x.c||(a&&(a.cur||a.c))||'',note:x.note||'',balLabel:isPay?'الرصيد الباقي':'الرصيد الكامل',balSide:lb(net),balAmt:F(Math.abs(net))});
}
function menu(html){var old=$('dfActionMenu');if(old)old.remove();var o=document.createElement('div');o.id='dfActionMenu';o.style.cssText='position:fixed;inset:0;z-index:10110;background:#0008;display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl';o.innerHTML='<div style="background:#fff;border-radius:18px;padding:16px;width:min(430px,100%);max-height:85vh;overflow:auto;display:grid;gap:8px"><b style="font-size:17px;text-align:center">إجراءات الديون في المراقب</b>'+html+'<button data-dfaction="close" class="dfBtn">إغلاق</button></div>';o.onclick=function(e){if(e.target===o||e.target.getAttribute('data-dfaction')==='close')o.remove();else{var ac=e.target.closest('[data-dfaction]');if(ac)doDebtAction(ac.getAttribute('data-dfaction'),ac.getAttribute('data-id')||'',ac.getAttribute('data-mode')||'')}};document.body.appendChild(o)}
function actionButton(label,action,id,mode){return '<button class="dfBtn" data-dfaction="'+action+'" data-id="'+E(id)+'" data-mode="'+E(mode||'')+'">'+label+'</button>'}
function openFundMenu(id){var title=id==='auto'?'الصندوق الثابت — الصندوق التلقائي':(db().funds.find(function(f){return f.id===id})||{}).name||'الصندوق';menu('<p>الفترة: '+E(periodLabel())+'</p>'+actionButton('🖨️ طباعة كشف للفترة المحددة','fundprint',id)+actionButton('📝 طباعة مصادقة للفترة المحددة','fundauth',id)+(id!=='auto'?actionButton('✏️ تعديل اسم الصندوق','editfund',id):''))}
function openAccountMenu(id){var a=db().accounts.find(function(x){return x.id===id});if(!a)return;menu('<b style="text-align:center">'+E(a.name)+'</b>'+actionButton('✏️ تعديل الحساب','editacc',id)+actionButton('🗑️ حذف الحساب','deleteacc',id)+actionButton('🖨️ طباعة كشف للفترة المحددة','accprint',id)+actionButton('📝 طباعة مصادقة حساب للفترة المحددة','accauth',id)+actionButton('📋 نسخ الحساب إلى صندوق آخر','copyacc',id)+actionButton('↔ نقل الحساب إلى صندوق آخر','moveacc',id))}
function openVoucherMenu(id){var x=db().vouchers.find(function(z){return z.id===id});if(!x)return;menu(actionButton('🖨️ طباعة سند المعاملة','printv',id)+actionButton('✏️ تعديل المعاملة','editv',id)+actionButton((chosenVouchers.indexOf(id)>=0?'☑ إلغاء تحديد':'☐ تحديد المعاملة'),'selectv',id)+actionButton('☑ تحديد الكل في الحساب الحالي','selectall',id)+actionButton(x.image?'🖼️ فتح الصورة المرفقة':'📷 إضافة/فتح صورة المعاملة','imagev',id)+actionButton('↔ نقل المعاملة إلى حساب آخر','movev',id)+actionButton('📋 نسخ المعاملة إلى حساب آخر','copyv',id)+actionButton('🗑️ حذف المعاملة','deletev',id))}
function doDebtAction(action,id,mode){var d=db(),x,a;var modal=$('dfActionMenu');if(modal)modal.remove();if(action==='fundprint'||action==='fundauth'){printFund(id,action==='fundauth');return}if(action==='accprint'||action==='accauth'){printAccount(id,action==='accauth');return}if(action==='editfund'){fundDlg(id);return}if(action==='editacc'){fid=(d.accounts.find(function(z){return z.id===id})||{}).fund;accDlg(id);return}if(action==='deleteacc'){if(!confirm('حذف الحساب وكل معاملاته؟'))return;d.accounts=d.accounts.filter(function(z){return z.id!==id});d.vouchers=d.vouchers.filter(function(z){return z.acc!==id});sv(d);v='fund';rr();return}if(action==='copyacc'||action==='moveacc'){var choices=d.funds.filter(function(f){return mode==='copy'||f.id!==(d.accounts.find(function(z){return z.id===id})||{}).fund});menu(choices.map(function(f){return actionButton('📁 '+f.name,'targetacc',id,action+':'+f.id)}).join('')||'');return}if(action==='targetacc'){var bits=mode.split(':'),how=bits[0],target=bits[1];a=d.accounts.find(function(z){return z.id===id});if(!a)return;if(how==='move')a.fund=target;else{var cp=JSON.parse(JSON.stringify(a));cp.id=uid('da');cp.fund=target;cp.name=a.name+' (نسخة)';d.accounts.push(cp);d.vouchers.filter(function(z){return z.acc===id}).forEach(function(z){var cz=JSON.parse(JSON.stringify(z));cz.id=uid('dv');cz.acc=cp.id;d.vouchers.push(cz)})}sv(d);v='main';rr();return}if(action==='printv'){printVoucherById(id);return}if(action==='editv'){var vv=d.vouchers.find(function(z){return z.id===id});if(vv){aid=vv.acc;v='acc';rr();setTimeout(function(){vDlg(id)},50)}return}if(action==='selectv'){chosenVouchers.indexOf(id)>=0?chosenVouchers=chosenVouchers.filter(function(z){return z!==id}):chosenVouchers.push(id);openVoucherMenu(id);return}if(action==='selectall'){chosenVouchers=d.vouchers.filter(function(z){return z.acc===aid&&inR(z.date,debtPeriod().from,debtPeriod().to)}).map(function(z){return z.id});menu('<b>'+chosenVouchers.length+' معاملة محددة</b>'+actionButton('↔ نقل المحدد','bulkmove')+actionButton('📋 نسخ المحدد','bulkcopy')+actionButton('🗑️ حذف المحدد','bulkdelete'));return}if(action==='imagev'){x=d.vouchers.find(function(z){return z.id===id});if(x&&x.image){var win=window.open();if(win){win.document.write('<meta name="viewport" content="width=device-width"><img style="max-width:100%;max-height:95vh;display:block;margin:auto" src="'+x.image+'">');win.document.close()}}else{aid=x.acc;v='acc';rr();setTimeout(function(){vDlg(id)},50)}return}if(action==='deletev'){if(confirm('حذف هذه المعاملة؟')){d.vouchers=d.vouchers.filter(function(z){return z.id!==id});sv(d);rr()}return}if(action==='movev'||action==='copyv'||action==='bulkmove'||action==='bulkcopy'){var ids=action.indexOf('bulk')===0?chosenVouchers:[id],how=action.indexOf('copy')>=0?'copy':'move';menu(d.accounts.filter(function(z){return ids.every(function(k){return (d.vouchers.find(function(q){return q.id===k})||{}).acc!==z.id})}).map(function(z){return actionButton('👤 '+z.name,'targetv',ids.join(','),how+':'+z.id)}).join('')||'');return}if(action==='targetv'){var part=mode.split(':'),how=part[0],target=part[1],ids=id.split(','),count=0;ids.forEach(function(k){x=d.vouchers.find(function(z){return z.id===k});if(!x)return;if(how==='move')x.acc=target;else{var cp=JSON.parse(JSON.stringify(x));cp.id=uid('dv');cp.acc=target;d.vouchers.push(cp)}count++});sv(d);chosenVouchers=[];rr();toast(how==='move'?'تم نقل المعاملة':'تم نسخ المعاملة');return}if(action==='bulkdelete'){if(confirm('حذف المعاملات المحددة؟')){d.vouchers=d.vouchers.filter(function(z){return chosenVouchers.indexOf(z.id)<0});sv(d);chosenVouchers=[];rr()}return}}
function onPressStart(e){var row=e.target.closest&&e.target.closest('#fullFilterPage .dfT tr[data-clock-voucher]'),card=e.target.closest&&e.target.closest('#fullFilterPage .dfC');var kind='',id='';if(row){kind='voucher';id=row.getAttribute('data-clock-voucher')}else if(card){if(card.getAttribute('data-clock-account')){kind='account';id=card.getAttribute('data-clock-account')}else if(card.getAttribute('data-clock-fund')){kind='fund';id=card.getAttribute('data-clock-fund')}}if(!kind)return;clearTimeout(longTimer);longFired=false;longTimer=setTimeout(function(){longFired=true;if(navigator.vibrate)navigator.vibrate(30);if(kind==='fund')openFundMenu(id);else if(kind==='account')openAccountMenu(id);else openVoucherMenu(id)},550)}
document.addEventListener('pointerdown',onPressStart,true);['pointerup','pointercancel','pointerleave'].forEach(function(k){document.addEventListener(k,function(){clearTimeout(longTimer)},true)});

document.addEventListener('click',function(e){if(longFired){e.preventDefault();e.stopImmediatePropagation();longFired=false;return}var b=e.target.closest&&e.target.closest('#fullFilterPage [data-d]');if(!b)return;var k=b.getAttribute('data-d'),i=b.getAttribute('data-i');
 if(k==='back'){window.__debtFunds.back();return}
 e.stopPropagation();
 if(k==='auto'){v='auto'}else if(k==='fund'){v='fund';fid=i}else if(k==='acc'){v='acc';aid=i}
 else if(k==='ef'){fundDlg(i);return}else if(k==='eacc'){accDlg(aid);return}else if(k==='ev'){vDlg(i);return}
 rr()},true);
window.__debtFunds={render:render,reset:function(){v='main';fid=aid=null},sendNow:function(){if(v!=='acc')return;var a=db().accounts.find(function(z){return z.id===aid});if(a)debtSendNow(a,'statement',0,{date:new Date().toISOString().slice(0,10)})},sumHTML:function(){var d=db(),f=($('ffDateFrom')||{}).value||'',t=($('ffDateTo')||{}).value||'',x=T(fV(d,fid,f,t)),net=x.net,nl=net>1e-9?'الباقي لكم':net<-1e-9?'الباقي عليكم':'لا يوجد رصيد',c=function(a,val,col){return '<div class="sm-c"><b style="color:'+col+'">'+F(val)+'</b><span>'+a+'</span></div>'};return c('الإجمالي عليكم',x.debt,'#dc2626')+c('الإجمالي لكم',x.pay,'#15803d')+c(nl,Math.abs(net),net<-1e-9?'#dc2626':'#0f172a')},state:function(){return {v:v,fid:fid,aid:aid}},printNow:function(auth){if(v==='auto')printFund('auto',auth);else if(v==='fund'&&fid)printFund(fid,auth);else if(v==='acc'&&aid)printAccount(aid,auth)},
 back:function(){if(v==='main')return false;v=v==='acc'?'fund':'main';rr();return true},
 fab:function(){if(v==='main'){fundDlg();return true}if(v==='fund'){accDlg();return true}if(v==='acc'){vDlg();return true}return false}};
})();

/* source script: seller-photo-viewer-logic */
(function(){
 'use strict';
 function spvSaveToGallery(src,name){
  try{
   if(window.SANative&&SANative.saveImageToGallery){SANative.saveImageToGallery(src,name);toast('⏳ جارٍ حفظ الصورة في الاستوديو');return}
   if(window.AndroidBackup&&AndroidBackup.saveImageToGallery){AndroidBackup.saveImageToGallery(src,name);toast('⏳ جارٍ حفظ الصورة في الاستوديو');return}
   var a=document.createElement('a');a.href=src;a.download=name;document.body.appendChild(a);a.click();a.remove();
   toast('تم تنزيل الصورة');
  }catch(e){toast('تعذر حفظ الصورة')}
 }
 function spvClose(){var v=document.getElementById('sellerPhotoViewer');if(v)v.remove()}
 window.viewLongPressedPhoto=function(){
  var x=getLongPressedInvoice();
  if(!x){closeInvoiceLongPressMenu();return}
  closeInvoiceLongPressMenu();
  var folderId=String(x.folder.id),invoiceId=String(x.inv.id);
  var src=x.inv.sellerPhoto;
  if(!src){toast('لا توجد صورة محفوظة لهذه الفاتورة');return}
  spvClose();
  var m=/^data:image\/(\w+)/.exec(src);
  var ext=m?(m[1]==='jpeg'?'jpg':m[1]):'jpg';
  var name='صورة-بياع-'+invoiceId+'.'+ext;
  var v=document.createElement('div');v.id='sellerPhotoViewer';
  v.innerHTML='<div class="spv-head"><span>📷 صورة البياع - '+esc(x.inv.initSeller||'')+'</span><button type="button" class="spv-close" aria-label="إغلاق">✕</button></div>'
   +'<div class="spv-body"><img alt="صورة البياع"></div>'
   +'<div class="spv-actions"><button type="button" class="spv-save">💾 حفظ للاستوديو</button><button type="button" class="spv-del">🗑 حذف الصورة</button></div>';
  v.querySelector('img').src=src;
  v.addEventListener('click',function(ev){
   var c=ev.target.classList;
   if(c.contains('spv-close')||ev.target===v){spvClose();return}
   if(c.contains('spv-save')){spvSaveToGallery(src,name);return}
   if(c.contains('spv-del')){
    customConfirm('حذف صورة البياع من هذه الفاتورة؟',function(){
     var folder=data.folders.find(function(f){return String(f.id)===folderId});
     var inv=folder&&(folder.invoices||[]).find(function(i){return String(i.id)===invoiceId});
     if(!inv){spvClose();toast('الفاتورة غير موجودة');return}
     delete inv.sellerPhoto;
     save();spvClose();
     if(String(currentFolderId)===folderId&&typeof renderCurrentView==='function')renderCurrentView();
     toast('تم حذف الصورة');
    },null,{title:'حذف صورة',icon:'📷',danger:true,confirmText:'حذف',cancelText:'إلغاء'});
   }
  });
  document.body.appendChild(v);
 };
})();

/* source script: settings-actions-fixed */


/* source script: window-stack-manager */
(function(){
 'use strict';
 if(window.__stk)return;window.__stk=1;
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();}catch(e){}
 var SKIP={lockScreen:1,selectionBar:1,lpTopBar:1,fullFilterPage:1,embedLayer:1,toast:1,imageViewer:0};
 var stack=[],watched=new WeakSet(),mo=null,pending=0;
 function isWin(el){
  if(!el||el.nodeType!==1||!el.id||SKIP[el.id])return false;
  if(el.classList.contains('ui-layer')||el.classList.contains('embed-layer'))return false;
  return el.classList.contains('overlay')||/(Modal|Sheet|Chooser|Popup|Dialog|Menu)$/.test(el.id)||el.id==='imageViewer';
 }
 function shown(el){
  var cs=getComputedStyle(el);
  return cs.display!=='none'&&el.isConnected;
 }
 function sync(){
  pending=0;
  stack=stack.filter(function(e){return e.isConnected&&shown(e);});
  var cands=document.querySelectorAll('body > [id]');
  for(var i=0;i<cands.length;i++){var e=cands[i];if(isWin(e)&&shown(e)&&stack.indexOf(e)<0)stack.push(e);}
  for(var j=0;j<stack.length;j++){stack[j].classList.toggle('__stk-hide',j<stack.length-1);}
 }
 function schedule(){if(pending)return;pending=requestAnimationFrame(sync);}
 function watch(el){if(watched.has(el))return;watched.add(el);mo.observe(el,{attributes:true,attributeFilter:['class','style']});}
 function scan(){var c=document.querySelectorAll('body > [id]');for(var i=0;i<c.length;i++)if(isWin(c[i]))watch(c[i]);}
 function init(){
  mo=new MutationObserver(function(ms){
   for(var i=0;i<ms.length;i++){var m=ms[i];
    if(m.type==='childList'){for(var k=0;k<m.addedNodes.length;k++){var n=m.addedNodes[k];if(isWin(n))watch(n);}}
   }
   schedule();
  });
  mo.observe(document.body,{childList:true});
  scan();schedule();
 }
 if(document.body)init();else document.addEventListener('DOMContentLoaded',init);
})();

/* source script: inline */
(function(){
  if(!window.SANav)return;
  function init(){
    var tr=document.querySelector('.toprow');
    if(tr&&!document.getElementById('saTopBack')){var b=SANav.makeBackButton('top-icon-btn');b.id='saTopBack';tr.insertBefore(b,tr.firstChild);}
    SANav.watch('.section',function(e){return e.classList.contains('on');});
    /* ترويسات الصفحات الكاملة (الإعدادات + الكشف) تخفي الشريط العلوي، فنضيف لها سهم رجوع */
    SANav.ensureBack('.subTop,.statement-header');
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* source script: print-v2 */
(function(){
 var E=function(x){return String(x==null?'':x).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 var F=function(n){return (Number(n)||0).toLocaleString('en-US',{maximumFractionDigits:3})};
 function st(){try{return (typeof data!=='undefined'&&data.settings)||{}}catch(e){return {}}}
 function p2(n){return String(n).padStart(2,'0')}
 function dmy(d){return p2(d.getDate())+'/'+p2(d.getMonth()+1)+'/'+d.getFullYear()}
 function t12(d){var h=d.getHours(),m=h>=12?'PM':'AM';h=h%12||12;return p2(h)+':'+p2(d.getMinutes())+' '+m}
 function hdrCss(){return ".company-header{display:grid;grid-template-columns:minmax(0,1fr) 95px minmax(0,1fr);gap:10px;align-items:center;border-bottom:2px solid #222;padding:0 4px 8px;margin:0 0 9px;break-inside:avoid;page-break-inside:avoid}\n  .company-side{font-size:12px;line-height:1.45}.company-side.ar{text-align:right}.company-side.en{text-align:left;direction:ltr}.company-side .name{font-size:16px;font-weight:900}.company-logo{width:86px;height:72px;object-fit:contain;display:block;margin:auto}.full-image-header{display:block;margin:0 0 9px;padding:0 0 8px;border-bottom:2px solid #222}.full-header-image{display:block!important;width:100%!important;max-width:100%!important;height:120px!important;max-height:none!important;object-fit:fill!important;margin:0!important}.company-logo-placeholder{width:86px;height:72px;display:grid;place-items:center;margin:auto;font-size:11px;color:#777}\n  .doc-title{display:block;width:max-content;max-width:100%;min-width:175px;text-align:center;margin:7px auto 10px;padding:6px 26px;border:1.5px solid #333;border-radius:2px;font-size:18px;font-weight:900;background:#fff;color:#111}"}
var LUX_S={
 neu:['#e0e5ec','#374151','#e0e5ec','#171717','#c9ced8','2px 2px 5px #bcc3cd,-2px -2px 5px #fff'],
 skeu:['linear-gradient(#f7f7f7,#cfcfcf)','#222222','#ffffff','#171717','#7a7a7a','0 1px 2px rgba(0,0,0,.35)'],
 glass:['rgba(255,255,255,.6)','#111111','rgba(255,255,255,.4)','#171717','#94a3b8','0 4px 12px rgba(0,0,0,.08)'],
 fluent:['#f3f3f3','#201f1e','#ffffff','#171717','#c8c6c4','none'],
 flat:['#334155','#ffffff','#ffffff','#171717','#334155','none'],
 m3:['#ede6f7','#1d1b20','#fef7ff','#171717','#79747e','none'],
 minimal:['#ffffff','#111111','#ffffff','#171717','#d1d5db','none'],
 neobrut:['#ffe600','#000000','#ffffff','#000000','#000000','4px 4px 0 #000'],
 luxury:['#1c1917','#d4af37','#fffbeb','#171717','#b8860b','none'],
 bento:['#f1f5f9','#0f172a','#ffffff','#171717','#cbd5e1','0 1px 3px rgba(0,0,0,.06)'],
 editorial:['#ffffff','#111111','#ffffff','#111111','#111111','none'],
 classic:['#e8dcc0','#4a3b1f','#fffdf5','#171717','#7c5e2b','none'],
 futuristic:['#0b1220','#22d3ee','#0f172a','#e2e8f0','#22d3ee','0 0 6px rgba(34,211,238,.4)'],
 '3d':['linear-gradient(#94a3b8,#475569)','#ffffff','#ffffff','#171717','#334155','0 3px 0 #94a3b8'],
 hybrid:['#dbeafe','#1e3a8a','#ffffff','#171717','#3b82f6','0 1px 2px rgba(0,0,0,.1)']
};
/* الطباعة المرفهة: عند التفعيل تتحكم وحدها بشكل القالب وألوان الخط وشكل الورقة، وتُعطَّل «ألوان الطباعة» و«لون النص» العاديان */
window.__luxActive=function(){try{return !!((st().lux)||{}).on}catch(e){return false}};
function luxL(){var L=(st().lux)||{};var on=!!L.on;var TP=LUX_TPL[L.tpl];if(TP)L=Object.assign({},L,TP);L.on=on;return L}
function luxHexRgb(h){h=String(h||'#ffffff').replace('#','');if(h.length===3)h=h.replace(/(.)/g,'$1$1');var n=parseInt(h,16);if(isNaN(n))n=0xffffff;return [(n>>16)&255,(n>>8)&255,n&255]}
/* ---- تلوين الكلمات والأرقام حسب الجهة (لكم / عليكم / إجمالي) ---- */
var LX_SIDEW={'لكم':'L','له':'L','عليكم':'O','عليه':'O'};
var LX_CL_L=/(^|\s)(grn|pay|pos|green)(\s|$)/,LX_CL_O=/(^|\s)(red|debt|neg|df-amount)(\s|$)/;
var LX_CL_T=/(^|\s)(pv-sum|total-row|remaining-row|summary|vc-tot|pv-bal|voucher-total|paper-balance|df-total|summary-line)(\s|$)/;
function lxCls(c){return {s:LX_CL_L.test(c)?'L':LX_CL_O.test(c)?'O':'',t:LX_CL_T.test(c)}}
/* يرجع مصفوفة قطع {t,c} أو null إن لم يوجد ما يُلوَّن */
function lxPieces(t,anc,tot){
 var toks=[],re=/(\d[\d,]*(?:\.\d+)?(?:[\/:]\d+)*)|([ء-ي]+)/g,m,sides=[];
 while((m=re.exec(t))){
  if(m[1]){if(/[\/:]/.test(m[1]))continue;toks.push({i:m.index,l:m[0].length,k:'n'})}
  else if(LX_SIDEW[m[2]]){var s=LX_SIDEW[m[2]];toks.push({i:m.index,l:m[0].length,k:'w',s:s});sides.push(s)}
 }
 if(!toks.length)return null;
 var uniq=sides.filter(function(s,i){return sides.indexOf(s)===i}),cur=null;
 toks.forEach(function(k,idx){
  if(k.k==='w'){cur=k.s;k.c=k.s==='L'?'lx-wl':'lx-wo';return}
  var s=anc;
  if(uniq.length===1)s=uniq[0];
  else if(uniq.length>1){s=cur;if(!s){for(var j=idx+1;j<toks.length;j++)if(toks[j].k==='w'){s=toks[j].s;break}}}
  k.c=(s||tot)?'lx-n'+(s?' lx-n'+s.toLowerCase():''):'';
 });
 var out=[],p=0;
 toks.forEach(function(k){if(!k.c)return;if(k.i>p)out.push({t:t.slice(p,k.i)});out.push({t:t.substr(k.i,k.l),c:k.c});p=k.i+k.l});
 if(!out.length)return null;
 if(p<t.length)out.push({t:t.slice(p)});
 return out;
}
function luxNeedsMark(L){return !!(L.txtL||L.txtO||L.txtT||L.numL||L.numO||L.numT)}
var LX_VOID={br:1,img:1,hr:1,input:1,meta:1,link:1,col:1,area:1,base:1,source:1,wbr:1};
function luxMarkHtml(h){
 var parts=String(h).split(/(<!--[\s\S]*?-->|<[^>]+>)/),stack=[],skip='';
 for(var i=0;i<parts.length;i++){
  var p=parts[i];
  if(i%2===1){
   var mo=/^<([a-zA-Z][\w:-]*)([^>]*)>$/.exec(p),mc=/^<\/([a-zA-Z][\w:-]*)/.exec(p);
   if(skip){if(mc&&mc[1].toLowerCase()===skip)skip='';continue}
   if(mo){
    var nm=mo[1].toLowerCase();
    if(nm==='script'||nm==='style'||nm==='title'||nm==='textarea'){skip=nm;continue}
    if(LX_VOID[nm]||/\/\s*>$/.test(p))continue;
    var cm=/class\s*=\s*("([^"]*)"|'([^']*)')/.exec(mo[2]||''),c=cm?(cm[2]||cm[3]||''):'',k=lxCls(c),top=stack[stack.length-1]||{s:'',t:false};
    stack.push({n:nm,s:k.s||top.s,t:k.t||top.t});
   }else if(mc){
    var n2=mc[1].toLowerCase();
    for(var j=stack.length-1;j>=0;j--)if(stack[j].n===n2){stack.length=j;break}
   }
   continue;
  }
  if(skip||!p||!/[\dء-ي]/.test(p))continue;
  var ctx=stack[stack.length-1]||{s:'',t:false};
  parts[i]=p.split(/(&#?\w+;)/).map(function(seg,si){
   if(si%2===1)return seg;
   var pc=lxPieces(seg,ctx.s,ctx.t);
   return pc?pc.map(function(x){return x.c?'<span class="'+x.c+'">'+x.t+'</span>':x.t}).join(''):seg;
  }).join('');
 }
 return parts.join('');
}
function luxMarkDom(root){
 if(!root)return;var doc=root.ownerDocument,nodes=[],w=doc.createTreeWalker(root,4,null),n;
 while((n=w.nextNode()))nodes.push(n);
 nodes.forEach(function(tn){
  var t=tn.nodeValue;if(!t||!/[\dء-ي]/.test(t))return;
  var s='',tot=false,el=tn.parentNode,bad=false;
  while(el&&el.nodeType===1&&el!==root.parentNode){
   var nm=el.nodeName.toLowerCase();if(nm==='script'||nm==='style'||nm==='title'||nm==='textarea'){bad=true;break}
   var k=lxCls(el.getAttribute('class')||'');if(!s&&k.s)s=k.s;if(k.t)tot=true;el=el.parentNode;
  }
  if(bad)return;
  var pc=lxPieces(t,s,tot);if(!pc)return;
  var fr=doc.createDocumentFragment();
  pc.forEach(function(x){if(x.c){var sp=doc.createElement('span');sp.className=x.c;sp.textContent=x.t;fr.appendChild(sp)}else fr.appendChild(doc.createTextNode(x.t))});
  tn.parentNode.replaceChild(fr,tn);
 });
}
/* يُضاف فوق CSS الطباعة العادية عند تفعيل الطباعة المرفهة فقط. generic=true يعمّم الجداول على أي مستند (التفصيل/الفلتر) */
function luxCss(generic){
 var L=luxL();if(!L.on)return '';
 var S=LUX_S[L.style||'minimal']||LUX_S.minimal,bc=S[4];
 var luxPaper=L.paper||S[2],luxText=L.txt||S[3];
 var th=({thin:'1px',medium:'1.5px',thick:'3px'})[L.thick||'medium']||'1.5px',ln=L.line||'solid';
 var rad=({box:'0',soft:'4px',rounded:'10px',corners:'18px',capsule:'999px',circle:'50%'})[L.shape||'box']||'0';
 var brad=rad==='50%'?'18px':rad;
 var x=L.shadow==='on'?(S[5]==='none'?'0 1px 3px rgba(0,0,0,.25)':S[5]):'none';
 var btn=({classic:'outline:2px double '+bc+';outline-offset:-4px',rounded:'border-radius:8px'})[L.btn||'simple']||'';
 var hf=L.style==='editorial'?'Georgia,serif':'';
 var TB=['.pv-t','.cs-t','.vc-t','.hw-t','.print-table','table.statement','table.paper-table','table.voucher-table','.df-print table','.by-print table'];
 if(generic)TB.push('table');
 var cells=function(t){return TB.map(function(b){return b+' '+t}).join(',')};
 var SUMR=['tr.pv-sum','tr.total-row','tr.remaining-row','tr.summary','tfoot tr'];
 var sumCells=SUMR.map(function(r){return TB.map(function(b){return b+' '+r+' td,'+b+' '+r+' th'}).join(',')}).join(',');
 var HD='.pv-title,.doc-title,.paper-title,.voucher-headline,.vc-dh,.voucher-detail-title';
 var BX='.pv-bal,.vc-tot,.vc-w,.hw-amt div,.tx,.voucher-total,.paper-balance,.summary-line,.df-total,.voucher-words,.paper-words,.note-box,.voucher-box,.vc,.voucher-paper,.receipt-sheet';
 var out='html,body{background-color:'+luxPaper+'!important;color:'+luxText+'!important}body,body *{border-color:'+bc+'}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}'+cells('th')+','+cells('td')+'{border:'+th+' '+ln+' '+bc+'!important;border-radius:'+rad+'!important;background:'+S[2]+'!important;color:'+luxText+'!important;box-shadow:'+x+'!important}'
  +cells('th')+'{background:'+S[0]+'!important;color:'+S[1]+'!important;'+btn+(hf?';font-family:'+hf+'!important':'')+'}'
  +sumCells+'{background:'+S[0]+'!important;color:'+S[1]+'!important}'
  +TB.join(',')+'{border:2px '+ln+' '+bc+'!important;border-radius:'+rad+'}'
  +HD+'{background:'+S[0]+'!important;color:'+S[1]+'!important;border:'+th+' '+ln+' '+bc+'!important;border-radius:'+brad+'!important;box-shadow:'+x+'!important'+(hf?';font-family:'+hf+'!important':'')+'}'
  +BX+'{border:'+th+' '+ln+' '+bc+'!important;border-radius:'+brad+'!important;background:'+S[2]+'!important;color:'+S[3]+'!important;box-shadow:'+x+'!important}'
  +'.tx div{border-top:'+th+' '+ln+' '+bc+'!important}.vc-wl{border-right:'+th+' '+ln+' '+bc+'!important;background:'+S[2]+'!important;color:'+S[3]+'!important}'
  +'.hw-amt div.hw-b,.vc-t td.vc-c{background:'+S[0]+'!important;color:'+S[1]+'!important}'
  +'.company-header,.print-profile-header,.full-image-header{border-bottom:2px '+ln+' '+bc+'!important}'
  +'.pv-foot,.pv-sign,.signatures,.paper-signatures,.voucher-signs,.print-footer,.paper-footer{border-top-color:'+bc+'!important}'
  +'.pv-acc,.dotted-name,.paper-name,.tx-who .nm{border-bottom-color:'+bc+'!important}';
 /* ---- ألوان النصوص (أولويتها أعلى من ألوان القالب) ---- */
 var STY=[BX,cells('td')].join(','); /* العناوين وصفوف الإجمالي تبقى بلون القالب (خلفيتها داكنة في بعض القوالب) */
 var pre=function(list){return list.split(',').map(function(s){return 'html body '+s}).join(',')};
 var TOT=['tr.pv-sum','tr.total-row','tr.remaining-row','tr.summary','.pv-bal','.vc-tot','.voucher-total','.paper-balance','.summary-line','.df-total'].join(',');
 var TOTSEL=TOT.split(',').map(function(s){return 'html:root:root body '+s+',html:root:root body '+s+' *'}).join(',');
 var TOTNUM=TOT.split(',').map(function(s){return 'html:root:root:root body '+s+' .lx-n,html:root:root:root body '+s+' .lx-nl,html:root:root:root body '+s+' .lx-no'}).join(',');
 var TX='';
 TX+='html body,html body *{color:'+luxText+'!important}'+pre(STY)+'{color:'+luxText+'!important}';
 if(L.txtL)TX+='html body .lx-wl{color:'+L.txtL+'!important}';
 if(L.numL)TX+='html body .lx-nl{color:'+L.numL+'!important}';
 if(L.txtO)TX+='html body .lx-wo{color:'+L.txtO+'!important}';
 if(L.numO)TX+='html body .lx-no{color:'+L.numO+'!important}';
 if(L.txtT)TX+=TOTSEL+'{color:'+L.txtT+'!important}';
 if(L.numT)TX+=TOTNUM+'{color:'+L.numT+'!important}';
 out+=TX;
 /* ---- شكل الورقة: لون / صورة خلفية / إطار ---- */
 var pr=luxPaper;
 out+='html,body{background-color:'+pr+'!important}';
 if(L.bg){var op=(L.clear==null?100:+L.clear)/100,rg=luxHexRgb(pr||'#ffffff'),ov='rgba('+rg[0]+','+rg[1]+','+rg[2]+','+(1-op)+')';out+='body{background:linear-gradient('+ov+','+ov+'),url("'+L.bg+'") center/cover no-repeat fixed!important}'}
 var fr=({thin:'1.5px solid',thick:'3px solid',double:'5px double'})[L.frame||''];
 if(fr)out+='html body{box-sizing:border-box!important;border:'+fr+' '+bc+'!important;border-radius:'+brad+'!important;padding-top:6px!important;padding-bottom:6px!important}';
 return '/*LUXP*/'+out;
}
/* 10 قوالب جاهزة: كل قالب يحدد الشكل كاملاً ويتجاوز الخيارات الأخرى */
var LUX_TPL={
 '1':{style:'luxury',shape:'corners',line:'solid',btn:'classic',shadow:'on',thick:'medium',on:true},
 '2':{style:'glass',shape:'rounded',line:'solid',btn:'rounded',shadow:'on',thick:'thin',on:true},
 '3':{style:'minimal',shape:'soft',line:'solid',btn:'simple',shadow:'off',thick:'thin',on:true},
 '4':{style:'neobrut',shape:'box',line:'solid',btn:'simple',shadow:'on',thick:'thick',on:true},
 '5':{style:'bento',shape:'rounded',line:'solid',btn:'rounded',shadow:'on',thick:'thin',on:true},
 '6':{style:'m3',shape:'corners',line:'solid',btn:'rounded',shadow:'off',thick:'medium',on:true},
 '7':{style:'futuristic',shape:'soft',line:'dotted',btn:'simple',shadow:'on',thick:'thin',on:true},
 '8':{style:'editorial',shape:'box',line:'double',btn:'simple',shadow:'off',thick:'thin',on:true},
 '9':{style:'classic',shape:'box',line:'double',btn:'classic',shadow:'off',thick:'medium',on:true},
 '10':{style:'hybrid',shape:'rounded',line:'dashed',btn:'rounded',shadow:'on',thick:'medium',on:true}
};
/* ثلاث مجموعات قوالب إضافية: أزرار الخلايا، الأعمدة، عناصر عصرية (تُضاف فوق القالب المختار) */
var LUX_BTN_T={
 pill:'border-radius:999px!important',
 grad:'background:linear-gradient(135deg,#1e293b,#64748b)!important;color:#fff!important',
 outline:'background:transparent!important;color:inherit!important;border:2px solid currentColor!important',
 raised:'box-shadow:0 3px 0 rgba(0,0,0,.35)!important',
 glass:'background:rgba(255,255,255,.55)!important;border-radius:12px!important',
 neon:'background:#0f172a!important;color:#22d3ee!important;box-shadow:0 0 8px #22d3ee!important'
};
var LUX_COL={
 zebra:'.pv-t tbody tr:nth-child(even) td{background:#f8fafc!important}',
 firstAccent:'.pv-t td:first-child{font-weight:900!important;background:#eef2ff!important}',
 vsep:'.pv-t th,.pv-t td{border-top:none!important;border-bottom:none!important}',
 hsep:'.pv-t th,.pv-t td{border-left:none!important;border-right:none!important}',
 gold:'.pv-t th,.pv-t td{border-color:#c9a227!important}',
 tint:'.pv-t td:nth-child(3),.pv-t td:nth-child(4){background:#ecfdf5!important}.pv-t td:nth-child(5),.pv-t td:nth-child(6){background:#fef2f2!important}'
};
var LUX_MOD={
 rowcards:'.pv-t{border-collapse:separate!important;border-spacing:0 6px!important}.pv-t th,.pv-t td{border-radius:8px!important}',
 floating:'.pv-t{box-shadow:0 8px 24px rgba(15,23,42,.12)!important;border-radius:14px!important}',
 gradbar:'.pv-title,.pv-cur{background:linear-gradient(90deg,#0f172a,#334155)!important;color:#fff!important;border-radius:10px!important}',
 pillsum:'.pv-t tr.pv-sum td:first-child{border-radius:999px!important}',
 mono:'.pv-t th,.pv-t td{background:#fff!important;color:#111!important;border-color:#111!important}',
 dark:'.pv-t th,.pv-t td{background:#0b1220!important;color:#e2e8f0!important;border-color:#334155!important}'
};
/* حقن CSS الطباعة المرفهة في أي مستند طباعة HTML (نوافذ الطباعة والمستندات) دون تكرار */
/* حقل لون مع زر إعادة الافتراضي (يُخزَّن في data.settings.lux) */
window.luxColor=function(L,key){var d=key==='paper'?'#ffffff':'#000000';return '<input type="color" value="'+(L[key]||d)+'" onchange="setLux(\''+key+'\',this.value)"> <button type="button" onclick="setLux(\''+key+'\',\'\');this.previousElementSibling.value=\''+d+'\'">إعادة الافتراضي</button>'};
window.__luxHtml=function(h){h=window.__toWestern?window.__toWestern(h):String(h==null?'':h);var L=luxL();if(!L.on)return h;
 if(h.indexOf('<!--LUXM-->')<0){
  if(h.indexOf('/*LUXP*/')<0){var c=luxCss();if(c){var sy='<style>'+c+'</style>';h=h.indexOf('</head>')>=0?h.replace('</head>',sy+'</head>'):(h.indexOf('<body')>=0?h.replace('<body',sy+'<body'):sy+h)}}
  if(luxNeedsMark(L))h=luxMarkHtml(h);
  h+='<!--LUXM-->';
 }
 return h};
/* تطبيق القالب على مستند DOM (نسخة الإطارات: التفصيل/الفلتر) */
window.__luxApplyDoc=function(doc,root,top){try{var L=luxL();if(!L.on||!doc)return;var tp=top||doc.documentElement;if(tp.getAttribute&&tp.getAttribute('data-luxd'))return;var head=tp.querySelector('head'),body=root||doc.body;if(!head||!body)return;tp.setAttribute('data-luxd','1');var st=doc.createElement('style');st.textContent=luxCss(true);head.appendChild(st);if(luxNeedsMark(L))luxMarkDom(body)}catch(e){console.error(e)}};
/* كل نافذة طباعة تُفتح بـ window.open('') ثم تُكتب فيها المستندات تمر بالحقن */
(function(){var _open=window.open;window.open=function(){var w=_open.apply(window,arguments);try{var u=arguments[0];if(w&&(u===undefined||u==='')){var d=w.document;if(d&&!d.__luxP){d.__luxP=1;var dw=d.write.bind(d);d.write=function(){var s=Array.prototype.slice.call(arguments).join('');return dw(window.__luxHtml(s))}}}}catch(e){}return w};})();
window.__luxCss=luxCss;
function css(kind){var s=st(),paper=PSIZE[paperKey(kind)]||'A4 portrait',mg=/mm auto/.test(paper)?'4mm':'10mm',lx=!!(s.lux&&s.lux.on),col=lx?'#aebeff':(s.printColor||'#aebeff'),font=s.printFont==='cairo'?'Cairo':s.printFont==='arial'?'Arial':s.printFont==='tahoma'?'Tahoma':'Tajawal';if(!lx&&s.printColorMode==='bw')col='#e8e8e8';
  var fb=(false&&s.useFullHeader&&s.logoData&&!/mm auto/.test(paper))?('@page{margin:'+mg+' 0}body{padding-left:'+mg+'!important;padding-right:'+mg+'!important}'+'.print-profile-header.full{display:block!important;width:auto!important;max-width:none!important;margin-left:-'+mg+'!important;margin-right:-'+mg+'!important;padding:0!important;box-sizing:border-box!important}'+'.print-profile-header.full img{display:block!important;width:100%!important;max-width:none!important;height:auto!important;max-height:none!important;margin:0!important;object-fit:contain!important}'):'';
  return '@page{size:'+paper+';margin:'+mg+'}'+fb+hdrCss()+'*{box-sizing:border-box}html,body{max-width:100%;background:#fff}body{font-family:'+font+',Arial,Tahoma,sans-serif;color:'+(lx?'#171717':(s.printTextColor||'#171717'))+';font-size:'+(14*((Number(s.printFontScale)||100)/100))+'px;line-height:1.5;margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
  +'.pv{width:100%;margin:0 auto}.print-profile-header{width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;box-sizing:border-box!important}.print-profile-header{display:grid;grid-template-columns:minmax(0,1fr) 82px minmax(0,1fr);gap:9px;align-items:center;border-bottom:2px solid #333;padding:0 0 8px;margin-bottom:8px;text-align:center}.print-profile-header img{display:block;margin:auto;width:72px;height:58px;object-fit:contain}.profile-ar{text-align:right;direction:rtl;font-weight:800;line-height:1.4}.profile-en{text-align:left;direction:ltr;font-weight:800;line-height:1.4}'
  +'.pv-title{width:max-content;max-width:100%;min-width:170px;margin:10px auto 6px;padding:6px 26px;border:1.5px solid #444;font-size:19px;font-weight:900;text-align:center;background:#fff}.pv-title.green{background:#e5f7eb;border-color:#3f8f5b;color:#185d39;border-radius:6px}.pv-title.blue{background:#fff}'
  +'.pv-meta{text-align:center;font-size:12px;color:#555;margin:6px 0 12px}.pv-meta.bold{font-weight:900;color:#222;font-size:13px}.pv-who{display:flex;justify-content:space-between;gap:10px;font-weight:900;font-size:16px;margin:10px 4px}.pv-c{text-align:center;margin:8px 0;font-weight:700}.pv-r{text-align:right;margin:14px 4px 0;font-weight:700}'
  +'.pv-acc{text-align:center;font-size:22px;font-weight:900;margin:8px 0 14px;padding-bottom:4px;border-bottom:3px dotted #222;width:max-content;max-width:100%;margin-left:auto;margin-right:auto;min-width:50%}'
  +'table.pv-t{width:100%;border-collapse:collapse;margin:8px 0 0;border:2px solid #1f2937}.pv-t th,.pv-t td{border:1.5px solid #1f2937;padding:7px 5px;text-align:center;overflow-wrap:anywhere;font-weight:700}.pv-t th{background:'+col+';font-weight:900}.pv-t tr.pv-sum td{background:'+col+';font-weight:900}.red{color:#b42335}.grn{color:#16824a}.blu{color:#1e3a8a}'
  +'.pv-bal{border:1px solid #536174;border-top:0;padding:10px;text-align:center;font-size:17px;font-weight:900}.pv-foot{display:grid;grid-template-columns:1fr 1fr 1fr;font-size:10px;color:#666;border-top:1px solid #999;margin-top:14px;padding-top:6px;text-align:center}.pv-foot span:first-child{text-align:right}.pv-foot span:last-child{text-align:left}'
  +'.pv-sign{display:grid;grid-template-columns:1fr 1fr;gap:24px;border-top:1px solid #777;margin-top:22px;padding-top:10px;text-align:center;font-weight:800;line-height:2.1}'
  +'.vc{border:1px solid #7b203d;padding:12px;border-radius:2px}.vc-w{display:flex;border:2px solid #4a1520;border-radius:10px;overflow:hidden;margin:8px 0;background:#f8f8fb}.vc-wt{flex:1;padding:9px;text-align:center;font-weight:900}.vc-wl{padding:9px 12px;border-right:2px solid #4a1520;font-weight:900;color:#16824a;background:#fff;white-space:nowrap}'
  +'.vc-dh{margin-top:10px;padding:8px;text-align:center;background:#6b1736;color:#fff;font-weight:900;border-radius:10px 10px 0 0}table.vc-t{width:100%;border-collapse:collapse;border:2px solid #6b1736}.vc-t td{border:1px solid #6b1736;padding:9px 6px;text-align:center;font-weight:900;width:34%}.vc-t td.vc-c{background:#6b1736;color:#fff;width:32%}'
  +'.vc-tot{border:2px solid #4a1520;border-radius:10px;padding:10px;text-align:center;font-weight:900;margin-top:12px;font-size:16px}.vc-note{margin:8px 0;font-weight:800}.vc-sign{display:flex;justify-content:space-between;margin-top:26px;font-size:12px;font-weight:700}'
  +'.hw-lab{text-align:right;font-weight:900;margin:12px 0 4px}.hw-amt{display:grid;grid-template-columns:minmax(0,1fr) 38%;gap:10px;margin-bottom:12px}.hw-amt div{border:1.5px solid #222;padding:12px;text-align:center;font-weight:900;font-size:17px}.hw-amt .hw-b{background:#a9c8f5}'
  +'table.hw-t{width:100%;border-collapse:collapse;border:1.5px solid #222}.hw-t th,.hw-t td{border:1px solid #222;padding:10px 6px;text-align:center;font-weight:900}.hw-t th{width:17%}.hw-t td.red{color:#c0182b}.hw-s{display:flex;justify-content:space-between;margin-top:44px;font-weight:900;font-size:13px;padding:0 20px}'
  +'.tx-who{display:flex;align-items:baseline;gap:10px;margin:14px 6px;font-weight:900;font-size:16px}.tx-who .nm{flex:1;text-align:center;border-bottom:3px dotted #222;font-size:20px}.tx{width:78%;margin:14px auto 0;border-right:3px solid #000;border-left:3px solid #000;border-bottom:3px solid #000}.tx div{border-top:3px solid #000;padding:20px 12px;font-weight:900;font-size:22px;text-align:right}'
  +'.pv-foot img,.vc-stamp img{max-height:65px;max-width:100px}.vc-stamp{text-align:left;margin-top:8px}.print-profile-header{width:100%}.profile-ar,.profile-en{font-size:13px}.print-profile-header.full{display:block;padding:0 0 6px;margin-bottom:8px;border-bottom:2px solid #333}.print-profile-header.full img{display:block;width:auto;max-width:100%;height:auto;max-height:120px;object-fit:contain;margin:0 auto}'
  }
 function hdr(){var s=st();if(s.showHeaderData===false)return '';try{return buildPrintHeader('').replace('<div class="doc-title"></div>','')}catch(e){}if(s.useFullHeader&&s.logoData)return '<div class="print-profile-header full"><img src="'+s.logoData+'" alt="ترويسة"></div>';var ar=[s.profileNameAr,s.profileAddressAr,s.profileContacts].filter(Boolean).map(E).join('<br>'),en=[s.profileNameEn,s.profileAddressEn,s.profileContactsEn].filter(Boolean).map(E).join('<br>'),logo=s.logoData?'<img src="'+s.logoData+'">':'<span></span>';return '<div class="print-profile-header"><div class="profile-ar">'+ar+'</div><div>'+logo+'</div><div class="profile-en">'+en+'</div></div>'}
 var PSIZE={a5:'A5 portrait',a4:'A4 portrait',a3:'A3 portrait','58':'58mm auto','80':'80mm auto'};
 function paperKey(kind){var s=st();var k=kind==='voucher'?(s.paperVoucher||s.paper):(s.paperStatement||s.paper);return PSIZE[k]?k:'a4'}
 window.__paperCss=function(kind){return PSIZE[paperKey(kind)]||'A4 portrait'};
 function stamp(mode){var s=st(),m=(s.stampSettings&&s.stampSettings[mode])||'sign',h='';if((m==='stamp'||m==='all')&&s.stampData)h='<img src="'+s.stampData+'" alt="ختم">';if((m==='sign'||m==='all')&&s.signData)h+='<img src="'+s.signData+'" alt="توقيع">';return h}
 function sign(){return '<div class="pv-sign"><div>مدير الحسابات<br>الاسم: ........................<br>التوقيع: ........................</div><div>عن العميل<br>الاسم: ........................<br>التوقيع: ........................</div></div>'}
 function page(title,body,kind){var html='<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(title)+'</title><style>'+css(kind)+luxCss()+'</style></head><body>'+body+'<script>window.onload=function(){setTimeout(function(){window.print()},250)};<\/script></body></html>';
  if(window.__printDoc&&window.__printDoc(html))return;var w=window.open('','_blank');if(!w){alert('اسمح بفتح نافذة الطباعة');return}w.document.write(html);w.document.close()}
 function statement(o){var n=new Date(),run=Number(o.run)||0,ab=Math.abs(run),side=run<0?'عليكم':run>0?'لكم':'متوازن',cls=run<0?'red':run>0?'grn':'blu',ng=Number(o.ng)||0,ps=Number(o.ps)||0,u=E(o.unit||'');
  var b='<div class="pv">'+hdr()+'<div class="pv-title">'+E(o.title)+'</div><div class="pv-meta">التاريخ: '+dmy(n)+' &nbsp;|&nbsp; الوقت: '+t12(n)+'</div>';
  if(o.auth){b+='<div class="pv-who"><span>الأخ / '+E(o.name)+'</span><span>المحترم</span></div><div class="pv-c">تحية طيبة وبعد</div><div class="pv-c">نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div><div class="pv-c">وأرصدتكم لدينا كالتالي</div>'
   +'<table class="pv-t"><thead><tr><th>عليكم</th><th>لكم</th><th style="width:30%"></th><th>الرصيد</th><th>العملة</th></tr></thead><tbody><tr><td class="red">'+F(ng)+'</td><td>'+F(ps)+'</td><td></td><td class="blu">'+F(ab)+'</td><td>'+u+'</td></tr></tbody></table><div class="pv-bal '+cls+'">الرصيد '+side+': '+F(ab)+(u?' ('+u+')':'')+'</div>'+(o.mid||'')
   +'<div class="pv-c">الرجاء مصادقة الرصيد وموافقتنا بالرد</div><div class="pv-c">علماً أنه لا يوجد لدينا أي أرصدة أخرى خلال الفترة المحددة</div><div class="pv-r">تاريخ المصادقة: '+dmy(n)+'</div>'+sign();
  }else{b+='<div class="pv-acc">'+E(o.name)+'</div>'+(o.sub||'')+'<table class="pv-t"><thead><tr><th>التاريخ</th><th>البيان</th><th>عليه</th><th>له</th><th>الرصيد</th></tr></thead><tbody>'+(o.rows||'<tr><td colspan="5">لا توجد حركات خلال الفترة المحددة</td></tr>')
   +'<tr class="pv-sum"><td colspan="2">الإجمالي</td><td class="red">'+F(ng)+'</td><td class="grn">'+F(ps)+'</td><td class="blu">'+F(ab)+'</td></tr><tr class="pv-sum"><td colspan="2">الباقي</td><td class="red">'+F(Math.max(ng-ps,0))+'</td><td class="grn">'+F(Math.max(ps-ng,0))+'</td><td class="blu">'+F(ab)+'</td></tr></tbody></table><div class="pv-bal '+cls+'">الرصيد '+side+': '+F(ab)+'</div>';}
  b+=(o.extra||'')+'<div class="pv-foot"><span>صفحة 1</span><span>'+n.getFullYear()+'-'+p2(n.getMonth()+1)+'-'+p2(n.getDate())+' '+p2(n.getHours())+':'+p2(n.getMinutes())+':'+p2(n.getSeconds())+'</span><span>'+stamp(o.auth?'balance':'statement')+'</span></div></div>';
  page(o.title+' - '+(o.name||''),b,'statement')}
 function voucher(o){var rows=(o.rows||[]).map(function(r){return '<tr><td>'+F(r.a)+'</td><td class="vc-c">'+E(r.c)+'</td><td>'+F(r.v)+'</td></tr>'}).join('')||'<tr><td>'+F(o.total)+'</td><td class="vc-c">'+E(o.unit||'')+'</td><td>'+F(o.total)+'</td></tr>';
  var b='<div class="pv"><div class="vc">'+hdr()+'<div class="pv-title green">📥 '+E(o.title)+'</div><div class="pv-meta bold">التاريخ: '+E(o.dateStr)+'</div><div class="pv-who"><span>من / '+E(o.from)+'</span><span>المحترم</span></div>'
   +'<div class="vc-w"><div class="vc-wt">'+(o.words||'')+'</div><div class="vc-wl">'+E(o.label||'')+'</div></div><div class="vc-dh">💱 العملات والتفصيل</div><table class="vc-t"><tbody>'+rows+'</tbody></table>'+(o.note?'<div class="vc-note">البيان: '+E(o.note)+'</div>':'')
   +'<div class="vc-tot">'+(o.out?'المبلغ عليكم':'المبلغ 💚 لكم')+': <span class="grn">'+F(o.total)+(o.unit?' '+E(o.unit):'')+'</span></div><div class="vc-sign"><span>المستلم: ......................</span><span>أمين الصندوق: ......................</span></div><div class="vc-stamp">'+stamp('vouchers')+'</div></div></div>';
  page(o.title,b,'voucher')}
 function hawala(o){var b='<div class="pv">'+hdr()+'<div class="pv-title">سند إرسال حوالة</div><div class="pv-meta bold">التاريخ : '+E(o.dateStr)+'</div><div class="hw-lab">مبلغ ورمز العملة</div><div class="hw-amt"><div>'+E(o.amts)+'</div><div class="hw-b">إرسال حوالة</div></div>'
   +'<table class="hw-t"><tbody><tr><th>من حساب</th><td colspan="3">'+E(o.from)+'</td></tr><tr><th>مبلغ الحوالة</th><td colspan="2">'+E(o.words)+'</td><td>عمولة '+E(o.com)+'</td></tr><tr><th>اسم المرسل</th><td colspan="2">'+E(o.sender)+'</td><td>إجمالي</td></tr><tr><th>اسم المستلم</th><td colspan="2">'+E(o.receiver)+'</td><td class="red">'+E(o.totalTxt)+'</td></tr><tr><th>جهة التحويل</th><td>'+E(o.dest)+'</td><th>رقم الحوالة</th><td>'+E(o.no)+'</td></tr></tbody></table>'+(o.note?'<div class="vc-note">البيان: '+E(o.note)+'</div>':'')+'<div class="hw-s"><span>توقيع المرسل</span><span>توقيع الموظف</span></div></div>';
  page('سند إرسال حوالة',b,'voucher')}
 function txn(o){var u=o.unit?'('+E(o.unit)+')':'';var b='<div class="pv">'+hdr()+'<div class="tx-who"><span>الأخ:</span><span class="nm">'+E(o.name)+'</span><span>المحترم</span></div><div class="tx"><div>التاريخ: '+E(o.date)+'</div><div>'+E(o.dirLabel)+' '+E(o.amount)+u+'</div><div>البيان: '+E(o.note||'').replace(/\n/g,'<br>')+'</div><div>'+E(o.balLabel)+' '+E(o.balSide)+': '+E(o.balAmt)+u+'</div></div><div class="vc-stamp">'+stamp('vouchers')+'</div></div>';
  page('سند معاملة — '+(o.name||''),b,'voucher')}
 function saleAuth(o){
  var n=new Date(),debt=Number(o.debt)||0,pay=Number(o.pay)||0,net=pay-debt,ab=Math.abs(net),side=net<0?'عليكم':net>0?'لكم':'متوازن';
  var words=window.tafqeet?window.tafqeet(ab)+(o.unit?' '+o.unit:'')+' فقط لا غير':'';
  var b='<div class="pv">'+hdr()+'<div class="pv-title">مصادقة رصيد</div>'
   +'<div class="pv-meta bold">'+E(o.heading)+' '+E(o.period)+'</div>'
   +'<div class="pv-who"><span>الأخ / '+E(o.name)+'</span><span>المحترم</span></div>'
   +'<div class="pv-c">تحية طيبة وبعد</div>'
   +'<div class="pv-c">نرجو منكم مطابقة ومصادقة الأرصدة أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div>'
   +'<div class="pv-c">وأرصدتكم لدينا كالتالي</div>'
   +'<table class="pv-t"><thead><tr><th>عليكم</th><th>لكم</th><th>الرصيد</th></tr></thead><tbody>'
   +'<tr><td class="red">'+F(debt)+'</td><td class="grn">'+F(pay)+'</td><td class="blu">'+F(ab)+' '+side+'</td></tr>'
   +'<tr><td colspan="3">'+E(words)+'</td></tr></tbody></table>'
   +'<div class="pv-c">الرجا مصادقة الرصيد وموافاتنا بالرد</div>'
   +'<div class="pv-c">علما انه لايوجد لدينا أي أرصدة اخرى خلال الفترة المحددة</div>'
   +'<div class="pv-r">تاريخ المصادقة: '+dmy(n)+'</div>'+sign()
   +'<div class="pv-foot"><span>صفحة 1</span><span>'+n.getFullYear()+'-'+p2(n.getMonth()+1)+'-'+p2(n.getDate())+' '+p2(n.getHours())+':'+p2(n.getMinutes())+'</span><span>'+stamp('balance')+'</span></div></div>';
  page(o.title,b,'statement');
 }
 function saleStatement(o){
  if(o.auth)return saleAuth(o);
  var n=new Date(),debt=Number(o.debt)||0,pay=Number(o.pay)||0,net=pay-debt,ab=Math.abs(net),side=net<0?'عليكم':net>0?'لكم':'متوازن',cls=net<0?'red':net>0?'grn':'blu';
  var body=(o.rows||[]).map(function(r){return '<tr><td class="grn">'+(r.pay?F(r.pay):'')+'</td><td class="red">'+(r.debt?F(r.debt):'')+'</td><td class="blu">'+F(Math.abs(r.bal))+(r.bal<0?' عليكم':r.bal>0?' لكم':'')+'</td><td>'+E(r.date)+'</td><td>'+r.doc+'</td>'+(o.showQty?'<td>'+E(r.qty)+'</td>':'')+'<td>'+r.note+'</td></tr>'}).join('');
  var b='<div class="pv">'+hdr()+'<div class="pv-title">'+E(o.title)+'</div><div class="pv-meta bold">'+E(o.period)+'</div><div class="pv-meta">التاريخ: '+dmy(n)+' &nbsp;|&nbsp; الوقت: '+t12(n)+'</div>'
   +'<table class="pv-t"><thead><tr><th>لكم</th><th>عليكم</th><th>الرصيد</th><th>التاريخ</th><th>المستند</th>'+(o.showQty?'<th>الكمية</th>':'')+'<th>البيان</th></tr></thead><tbody>'+(body||'<tr><td colspan="7">لا توجد حركات خلال الفترة المحددة</td></tr>')
   +'<tr class="pv-sum"><td class="grn">'+F(pay)+'</td><td class="red">'+F(debt)+'</td><td></td><td colspan="'+(o.showQty?4:3)+'">الإجمالي</td></tr></tbody></table>'
   +'<div class="pv-bal '+cls+'">الرصيد الباقي '+side+(ab?': '+F(ab):'')+'</div>'
   +'<div class="pv-foot"><span>صفحة 1</span><span>'+n.getFullYear()+'-'+p2(n.getMonth()+1)+'-'+p2(n.getDate())+' '+p2(n.getHours())+':'+p2(n.getMinutes())+'</span><span>'+stamp('statement')+'</span></div></div>';
  page(o.title,b,'statement');
 }
 function currencyStatement(o){
  var n=new Date(),parts=['<style>.cs-t{width:100%;max-width:100%;border-collapse:collapse;table-layout:auto}.cs-t th,.cs-t td{white-space:normal;overflow-wrap:break-word;word-break:normal;font-size:11px;padding:3px 4px;text-align:center;border:1.5px solid #1f2937}.cs-t td:first-child,.cs-t td.grn,.cs-t td.red{white-space:nowrap}.cs-t td.cs-stmt{white-space:normal;text-align:right;font-weight:700;min-width:60px}.pv table{max-width:100%}.pv-cur{font-weight:900;font-size:13px;margin:12px 0 4px}</style>'];
  if(o.header!==false)parts.push(hdr());
  parts.push('<div class="pv-title">'+E(o.title)+'</div>');
  parts.push('<div class="pv-meta bold">'+E(o.period)+'</div>');
  if(o.filterLine)parts.push('<div class="pv-meta">'+E(o.filterLine)+'</div>');
  parts.push('<div class="pv-meta">التاريخ: '+dmy(n)+' &nbsp;|&nbsp; الوقت: '+t12(n)+'</div>');
  (o.sections||[]).forEach(function(sec){
   var body=sec.rows.map(function(r){
    var lk=r.dir==='لكم',ob=!lk;
    if(r.open)return '<tr><td>'+E(r.date)+'</td><td>'+E(r.type)+'</td><td></td><td></td><td></td><td></td><td></td><td class="blu">'+F(Math.abs(r.bal))+' '+(r.bal<0?'عليكم':r.bal>0?'لكم':'')+'</td><td class="cs-stmt">'+(r.stmt||'')+'</td></tr>';
    return '<tr><td>'+E(r.date)+'</td><td>'+E(r.type)+'</td><td class="grn">'+(lk?F(r.amount):'')+'</td><td class="red">'+(ob?F(r.amount):'')+'</td><td>'+F(r.rate)+'</td><td class="grn">'+(lk?F(r.value):'')+'</td><td class="red">'+(ob?F(r.value):'')+'</td><td class="blu">'+F(Math.abs(r.bal))+' '+(r.bal<0?'عليكم':r.bal>0?'لكم':'')+'</td><td class="cs-stmt">'+r.stmt+'</td></tr>';
   }).join('');
   parts.push('<div class="pv-cur">'+E(sec.heading)+': '+E(sec.name)+(sec.sym?' ('+E(sec.sym)+')':'')+'</div>');
   parts.push('<table class="pv-t cs-t"><thead><tr><th rowspan="2">التاريخ</th><th rowspan="2">نوع السند</th><th colspan="2">مبلغ العملة</th><th rowspan="2">سعر الصرف</th><th colspan="2">القيمة بعد الصرف</th><th rowspan="2">الرصيد</th><th rowspan="2">البيان</th></tr><tr><th>لكم</th><th>عليكم</th><th>لكم</th><th>عليكم</th></tr></thead><tbody>'+(body||'<tr><td colspan="9">لا توجد حركات خلال الفترة المحددة</td></tr>')+'<tr class="pv-sum"><td>الإجمالي</td><td></td><td class="grn">'+F(sec.amtL)+'</td><td class="red">'+F(sec.amtO)+'</td><td></td><td class="grn">'+F(sec.totalL)+'</td><td class="red">'+F(sec.totalO)+'</td><td class="blu">'+F(Math.abs(sec.balance))+' '+(sec.balance<0?'عليكم':'لكم')+'</td><td></td></tr></tbody></table>');
   var net=Math.round(((sec.bal0||0)+sec.amtL-sec.amtO)*1000)/1000;
   parts.push('<div class="pv-meta">إجمالي '+E(sec.name)+' بعملتها: لكم '+F(sec.amtL)+' &nbsp;|&nbsp; عليكم '+F(sec.amtO)+(sec.bal0?' &nbsp;|&nbsp; رصيد سابق: '+F(sec.bal0):'')+'</div>');
   var vn=Math.round(((sec.totalL||0)-(sec.totalO||0))*1000)/1000;
   var sideCol=(net||vn)<0?'red':(net||vn)>0?'grn':'blu';
   parts.push('<div class="pv-bal '+sideCol+'">'+E(sec.name)+' '+(net<0?'الباقي عليكم':net>0?'الباقي لكم':(vn?'الباقي 0':'متوازن'))+(net?': '+F(Math.abs(net))+' '+E(sec.sym||sec.name):'')+(vn?' [الرصيد '+F(Math.abs(vn))+' '+(vn<0?'عليكم':'لكم')+']':' [الرصيد 0]')+'</div>');
  });
  if(o.summary&&o.sections&&o.sections.length){
   var tv=Math.round(o.sections.reduce(function(a,s){return a+(s.totalL||0)-(s.totalO||0)},0)*1000)/1000;
   parts.push('<div class="pv-cur">'+E(o.summaryTitle||'تجميع القبض من العملات + إرسال الحوالات')+'</div><table class="pv-t cs-t"><thead><tr><th>العملة</th><th>لكم (بعد الصرف)</th><th>عليكم (بعد الصرف)</th><th>مبلغ العملة لكم</th><th>مبلغ العملة عليكم</th><th>الرصيد بعد الصرف بالعملة</th></tr></thead><tbody>'+o.sections.map(function(s){var net=Math.round(((s.bal0||0)+s.amtL-s.amtO)*1000)/1000;return '<tr><td>'+E(s.name)+'</td><td class="grn">'+F(s.totalL)+'</td><td class="red">'+F(s.totalO)+'</td><td class="grn">'+F(s.amtL)+'</td><td class="red">'+F(s.amtO)+'</td><td class="blu">'+F(Math.abs(net))+' '+(net<0?'عليكم':'لكم')+'</td></tr>'}).join('')+'<tr class="pv-sum"><td colspan="6" style="text-align:right">إجمالي كامل رصيد العملات (كل عملة بعملتها): '+o.sections.map(function(s){var net=Math.round(((s.bal0||0)+s.amtL-s.amtO)*1000)/1000;return E(s.name)+' '+F(Math.abs(net))+' '+(net<0?'عليكم':net>0?'لكم':'متوازن')}).join(' &nbsp;|&nbsp; ')+' &nbsp; [الرصيد '+F(Math.abs(tv))+' '+(tv<0?'عليكم':'لكم')+']</td></tr></tbody></table>');
  }
  parts.push('<div class="pv-foot"><span>صفحة 1</span><span>'+n.getFullYear()+'-'+p2(n.getMonth()+1)+'-'+p2(n.getDate())+' '+p2(n.getHours())+':'+p2(n.getMinutes())+'</span><span>'+stamp('statement')+'</span></div>');
  page(o.title,'<div class="pv">'+parts.join('')+'</div>','statement');
 }
 function currencyVoucher(o){
  var rows=(o.rows||[]).map(function(r){return '<tr><td>'+F(r.a)+'</td><td class="vc-c">'+E(r.c)+'</td><td>'+F(r.v)+'</td></tr>'}).join('')||'<tr><td colspan="3">لا توجد عملات</td></tr>';
  var b='<div class="pv"><div class="vc">'+hdr()+'<div class="pv-title green">📥 '+E(o.title)+'</div>'
   +'<div style="display:flex;justify-content:space-between;gap:8px;font-weight:900;font-size:13px;margin:10px 4px"><span>'+E(o.from)+'</span><span>'+E(o.invoiceDay)+'</span><span>تاريخ السند: '+E(o.dateStr)+'</span></div>'
   +'<table class="vc-t"><tbody>'+rows+'</tbody></table>'
   +'<div class="vc-tot">'+(o.out?'المبلغ عليكم':'المبلغ 💚 لكم')+': <span class="grn">'+F(o.total)+'</span></div><div class="vc-sign"><span>المستلم: ......................</span><span>أمين الصندوق: ......................</span></div><div class="vc-stamp">'+stamp('vouchers')+'</div></div></div>';
  page(o.title,b,'voucher')
 }
 window.PV2={statement:statement,voucher:voucher,hawala:hawala,txn:txn,saleStatement:saleStatement,currencyStatement:currencyStatement,currencyVoucher:currencyVoucher};
})();

/* source script: tasfeer-logic */
(function(){
 'use strict';
 if(window.__tsLoaded)return;window.__tsLoaded=1;
 var K='smartadmin_tasfeer_v1',$=function(i){return document.getElementById(i)};
 var E=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
 var F=function(n){return (Number(n)||0).toLocaleString('en-US',{maximumFractionDigits:3})};
 var td=function(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
 var PAGES=['جملة البيع النهائية','خرج العمال','السحب','الديون','العملات'];
 var selMode=false,selIds=[],tab='home',sub=null,cur='',srt='date',asc=true,dFrom=(new Date().getFullYear()-1)+'-12-31',dTo=td();
 function db(){try{var d=JSON.parse(localStorage.getItem(K));if(d&&d.funds)return d}catch(e){}
  return {funds:[{id:'f1',name:'صندوق التوريد الرئيسي'},{id:'f2',name:'صندوق التوريد الفرعي'}],folders:[{id:'g1',name:'مجلد حسابات 1'},{id:'g2',name:'مجلد حسابات 2'}],accounts:[],vouchers:[]}}
 function save(d){try{fxRecalc(d)}catch(e){}try{localStorage.setItem(K,JSON.stringify(d))}catch(e){alert('تعذر الحفظ')}try{if(window.__clockRenderHome)window.__clockRenderHome()}catch(e){}}
 // ===== فارق الصرف: سعر الشراء (قبض/وارد) مقابل سعر البيع (ترحيل بين الصناديق / حوالة) =====
 // تكلفة كل عملة داخل الصندوق = المتوسط المرجّح لأسعار الشراء. عند الترحيل أو الحوالة يُقارن سعر البيع بها،
 // ويُنشأ سند داخل الصندوق المصدر: «لكم ربح فارق صرف» أو «عليكم خسارة فارق صرف» بعملة الأساس.
 // السندات التلقائية (fx) تُعاد بناؤها عند كل حفظ حتى تبقى مطابقة بعد التعديل أو الحذف.
 function fxRecalc(d){
  var base=(curs()[0]||{}).n,st={},out=[];
  function S(f,c){var k=f+'|'+c;return st[k]||(st[k]={q:0,v:0})}
  function avg(f,c){var s=S(f,c);return s.q>1e-9?s.v/s.q:null}
  function inn(f,c,a,val){var s=S(f,c);s.q+=a;s.v+=val}
  function outc(f,c,a){var s=S(f,c),g=avg(f,c);s.q-=a;if(g!=null)s.v-=a*g;if(s.q<=1e-9){s.q=0;s.v=0}}
  (d.vouchers||[]).forEach(function(v){
   if(v.fx)return;
   out.push(v);
   var R=v.rows||[],diff=0,note=[];
   function rt(r){return r.r==null||r.r===''?1:+r.r}
   function sell(f){R.forEach(function(r){var a=+r.a||0;if(!(a>0))return;
    var g=r.c===base?null:avg(f,r.c);
    if(g!=null)r.g=g;else delete r.g;
    if(g!=null){var df=a*(rt(r)-g);if(Math.abs(df)>=0.005){diff+=df;note.push(sym(r.c)+' '+F(a)+' (شراء '+F(g)+' / بيع '+F(rt(r))+')')}}
    outc(f,r.c,a)})}
   if(v.t==='receipt'){if(v.dir==='out')sell(v.f);else R.forEach(function(r){var a=+r.a||0;if(!(a>0))return;inn(v.f,r.c,a,a*rt(r))})}
   else if(v.t==='transfer'){sell(v.f);R.forEach(function(r){var a=+r.a||0;if(a>0)inn(v.f2,r.c,a,a*rt(r))})}
   else if(v.t==='internal'){sell(v.f)}
   else if(v.t==='exchange'){var g=avg(v.f,v.from),cost=(+v.fa||0)*(g==null?1:g);outc(v.f,v.from,+v.fa||0);inn(v.f,v.to,+v.ta||0,cost)}
   diff=Math.round(diff*100)/100;
   var stSet=d.settings||{};
   var isRO=(v.t==='receipt'&&v.dir==='out');
   if(v.t==='transfer'){if(stSet.fxAcc&&Math.abs(diff)>=0.01&&base)v.cd=1;else delete v.cd}
   if((v.t==='transfer'||v.t==='internal'||isRO)&&Math.abs(diff)>=0.01&&base){
    var m=Math.abs(diff),fxTxt=(diff>0?'لكم ربح مبلغ فارق صرف ':'عليكم خسارة مبلغ فارق صرف ')+F(m)+' — '+note.join(' ، ');
    if(stSet.fxAcc){var fxo={id:'fx'+v.id,t:'fxacc',d:v.d,acc:stSet.fxAcc,dir:diff>0?'in':'out',rows:[{c:base,a:m,r:1,v:m}],fx:1,pl:v.id,n:fxTxt};if(v.t!=='transfer'){fxo.f=v.f;fxo.inFund=1}out.push(fxo)}
    else out.push({id:'fx'+v.id,t:'receipt',d:v.d,f:v.f,dir:diff>0?'in':'out',rows:[{c:base,a:m,r:1,v:m}],fx:1,pl:v.id,n:fxTxt});
   }
   if(v.t==='internal'&&(+v.com||0)>0&&base&&stSet.comAcc){
    out.push({id:'com'+v.id,t:'comacc',d:v.d,acc:stSet.comAcc,dir:'in',rows:[{c:base,a:+v.com,r:1,v:+v.com}],fx:1,pl:v.id,n:'عمولة حوالة'+(v.rn?' — '+v.rn:'')+' '+F(v.com)});
   }
  });
  d.vouchers=out}
 function isFx(id){var x=db().vouchers.find(function(z){return z.id===id});return !!(x&&x.fx)}
 function curs(){var l=[];try{l=(data.settings.currencies||[]).map(function(c){return {n:c.name,s:c.symbol||c.name}}).filter(function(c){return c.n})}catch(e){}
  return l}
 function spn(id){try{var x=data.settings.specialties.find(function(z){return String(z.id)===String(id)});return x?x.name:''}catch(e){return ''}}
 function sym(n){var c=curs().find(function(x){return x.n===n});return c?c.s:n}
 function tot(v){var n=v.t==='exchange'?Number(v.ta)||0:(v.rows||[]).reduce(function(s,r){return s+(Number(r.v)||0)},0);return v.t==='internal'?n+(Number(v.com)||0):n}
 function fb(d,id){var b={};function add(c,x){b[c]=(b[c]||0)+x}
  d.vouchers.forEach(function(v){var R=v.rows||[];
   if(v.t==='receipt'&&v.f===id)R.forEach(function(r){add(r.c,v.dir==='out'?-r.a:r.a)});
   else if(v.t==='exchange'&&v.f===id){add(v.from,-v.fa);add(v.to,v.ta)}
   else if(v.t==='transfer'){if(v.f===id)R.forEach(function(r){add(r.c,-r.a)});if(v.f2===id)R.forEach(function(r){add(r.c,r.a)})}
   else if(v.t==='internal'&&v.f===id)R.forEach(function(r){add(r.c,-r.a)})});
  return b}
 // تحقق مركزي من رصيد الصندوق قبل أي حوالة/صرف؛ يعتمد على رصيد كل عملة
 // بعد استبعاد السند الجاري تعديله، ويمنع اعتماد رصيد سالب أو قيمة غير صالحة.
 function checkFundCoverage(d,fundId,rows,excludeVoucherId){
  var source=(d.vouchers||[]).filter(function(v){return !excludeVoucherId||v.id!==excludeVoucherId});
  var balance=fb({vouchers:source},fundId),problems=[];
  (rows||[]).forEach(function(r){
   var amount=Number(r.a),currency=String(r.c==null?'':r.c),available=Number(balance[currency]||0);
   if(!(amount>0)||!isFinite(amount)){problems.push('أدخل مبلغاً صحيحاً لعملة '+sym(currency));return}
   if(!isFinite(available)||available+1e-9<amount){problems.push('الرصيد المتاح في '+sym(currency)+' هو '+F(available)+'، والمطلوب '+F(amount));}
  });
  if(problems.length){alert('لا يمكن إرسال الحوالة: رصيد الصندوق غير كافٍ.\n'+problems.join('\n'));return false}
  return true;
 }
 function fsum(b){return Object.keys(b).reduce(function(s,k){return s+b[k]},0)}
 function abal(d,id){return d.vouchers.filter(function(v){return v.acc===id}).reduce(function(s,v){return s+(v.t==='internal'?-Math.abs(tot(v)):(v.dir==='in'?1:-1)*tot(v))},0)}
 function fname(d,id){var f=d.funds.find(function(x){return x.id===id});return f?f.name:'—'}
 function chips(b){var k=Object.keys(b);return k.length?k.map(function(c){return '<span style="margin-left:8px;font-weight:800">'+E(sym(c))+' '+F(b[c])+'</span>'}).join(''):'<span style="color:var(--muted)">0</span>'}
 function vline(d,v){if(v.t==='exchange'){var detail=' • '+E(v.d)+(v.f?' • '+E(fname(d,v.f)):'')+(v.n?' • '+E(v.n):'');return '<div class="exchange-ledger-pair-list"><div class="tsV exchange-debit"><div><b>عليكم — صرف '+F(v.fa)+' '+E(v.from)+' ('+E(sym(v.from))+')</b><small>'+detail+' • ناتج الصرف: '+F(v.ta)+' '+E(v.to)+' ('+E(sym(v.to))+')</small></div><div style="text-align:left"><b style="color:#dc2626;direction:ltr;display:block">−'+F(v.fa)+' '+E(sym(v.from))+'</b></div></div><div class="tsV exchange-credit"><div><b>لكم — إضافة '+F(v.ta)+' '+E(v.to)+' ('+E(sym(v.to))+')</b><small>'+detail+' • مقابل صرف: '+F(v.fa)+' '+E(v.from)+' ('+E(sym(v.from))+')</small></div><div style="text-align:left"><b style="color:#15803d;direction:ltr;display:block">+'+F(v.ta)+' '+E(sym(v.to))+'</b><button data-a="delv" data-i="'+v.id+'" style="color:#dc2626;font-size:12px">🗑 حذف المعاملة</button></div></div></div>'}
  var L={fxacc:v.dir==='out'?'عليكم خسارة فارق صرف — حساب':'لكم ربح فارق صرف — حساب',comacc:'لكم عمولة حوالة — حساب',receipt:v.fx?(v.dir==='out'?'عليكم خسارة فارق صرف':'لكم ربح فارق صرف'):v.dir==='out'?'سند من العملات — إرسال':'سند قبض من العملات',exchange:'صرافة عملات',transfer:'ترحيل بين الصناديق',internal:'حوالة داخلية — إرسال',clockacc:'سند من المراقب — '+(v.dir==='out'?'عليكم':'لكم')+(v.pg?' ('+v.pg+')':'')};
  var accN=v.acc?(d.accounts.find(function(a){return a.id===v.acc})||{}).name:'';
  var det=F(tot(v));
  var col=((v.t==='receipt'&&v.dir!=='out')||(v.dir==='in'&&v.t!=='internal'))?'#15803d':(v.t==='transfer')?'var(--primary)':'#dc2626';
  return '<div class="tsV"><div><b>'+L[v.t]+'</b><small>'+E(v.d)+(v.f?' • '+E(fname(d,v.f)):'')+(v.f2?' ← '+E(fname(d,v.f2)):'')+(accN?' • '+E(accN):'')+(v.p?' • '+E(v.p):'')+(v.sp&&spn(v.sp)?' • '+E(spn(v.sp)):'')+(v.com?' • عمولة '+F(v.com):'')+(v.img?' • 📷':'')+(v.n?' • '+E(v.n):'')+'</small></div><div style="text-align:left"><b style="color:'+col+';direction:ltr;display:block">'+det+'</b><button data-a="delv" data-i="'+v.id+'" style="color:#dc2626;font-size:12px">🗑 حذف</button></div></div>'}
 function vlist(d,arr){arr=arr.slice().reverse();return arr.length?'<div class="tsC">'+arr.map(function(v){return vline(d,v)}).join('')+'</div>':''}
 function card(l,v,c){return '<div class="tsC" style="border-right:4px solid '+c+'"><small>'+l+'</small><b>'+F(v)+'</b></div>'}
 function home(d){var t=td(),V=d.vouchers.filter(function(v){return v.d===t});
  function S(f){return V.filter(f).reduce(function(s,v){return s+tot(v)},0)}
  var fa=d.funds.reduce(function(s,f){return s+fval(d,f.id)},0),aa=d.accounts.reduce(function(s,a){return s+abal(d,a.id)},0);
  return '<div class="tsQ"><button class="r" data-a="q-internal">إرسال حوالات داخلية من الصناديق على الحسابات</button><button class="p" data-a="q-clock">سندات قبض من صفحات المراقب الى الحسابات</button><button style="background:#5b0f2a" data-a="q-receipt">سند قبض من العملات إلى الصناديق</button></div><div class="tsG">'
  +card('إجمالي مقبوضات من العملات اليوم',S(function(v){return v.t==='receipt'&&v.dir!=='out'&&!v.fx}),'#16a34a')
  +card('إجمالي السحب من الصناديق اليوم',S(function(v){return v.t==='internal'&&v.dir==='out'}),'#dc2626')
  +card('إجمالي مقبوضات الى الحسابات اليوم',S(function(v){return v.t==='clockacc'&&v.dir==='in'}),'#5b0f2a')
  +card('إجمالي السحب من الحسابات اليوم',S(function(v){return v.t==='clockacc'&&v.dir==='out'}),'#7c3aed')
  +card('إجمالي السحب الداخلي من الصناديق على الحسابات اليوم',S(function(v){return v.t==='internal'&&v.dir==='out'&&v.acc}),'#16a34a')
  +card('إجمالي التحويل بين الصناديق اليوم',S(function(v){return v.t==='transfer'}),'#16a34a')
  +cardV('رصيد الحسابات الكامل',aa)+cardV('رصيد الصناديق الكامل',fa)+'</div>'+gapBox(aa,fa)}
function cardV(l,v){var p=v>1e-9,n=v<-1e-9,col=n?'#dc2626':p?'#15803d':'#64748b';return '<div class="tsC tsCv" style="border-right:4px solid '+col+'"><small>'+l+'</small><b style="color:'+col+'">'+(n||p?'<em style="font-style:normal;font-size:.68em;margin-left:8px">'+(n?'عليكم':'لكم')+'</em>':'')+F(Math.abs(v))+'</b></div>'}
function gapInfo(d){d=d||db();var fa=d.funds.reduce(function(s,f){return s+fval(d,f.id)},0),aa=d.accounts.reduce(function(s,a){return s+abal(d,a.id)},0),g=Math.round((aa-fa)*1000)/1000;return {aa:aa,fa:fa,g:g,side:g>0?'acc':g<0?'fund':'eq'}}
window.__tsGap=function(){return gapInfo()};
function gapBox(aa,fa){var i=gapInfo(),col=i.side==='acc'?'#15803d':i.side==='fund'?'#dc2626':'#64748b',lbl=i.side==='acc'?'الرصيد الباقي للحسابات':i.side==='fund'?'الرصيد الباقي للصناديق':'الحسابات والصناديق متطابقة';
return '<div class="tsGapT">ناتج المبالغ بين الحسابات والصناديق</div><button type="button" class="tsGap" data-a="gap" style="border-color:'+col+'"><span class="tsGapL" style="color:'+col+'">'+lbl+'</span><b class="tsGapV" style="color:'+col+'">'+F(Math.abs(i.g))+'</b></button>'}
function gapModal(){var i=gapInfo(),col=i.side==='acc'?'#15803d':i.side==='fund'?'#dc2626':'#64748b',lbl=i.side==='acc'?'الفارق الباقي للحسابات (الحسابات أكبر من الصناديق)':i.side==='fund'?'الفارق الباقي للصناديق (الصناديق أكبر من الحسابات)':'لا يوجد فارق';
var row=function(a,b,c){return '<div class="tsC" style="border-right:4px solid '+c+'"><small>'+a+'</small><b style="color:'+c+'">'+b+'</b></div>'};
modal('ناتج المبالغ بين الحسابات والصناديق',row('رصيد الحسابات الكامل',(i.aa<0?'−':'')+F(Math.abs(i.aa)),i.aa<0?'#dc2626':'#15803d')+row('رصيد الصناديق الكامل',(i.fa<0?'−':'')+F(Math.abs(i.fa)),i.fa<0?'#dc2626':'#15803d')+row(lbl,F(Math.abs(i.g)),col),null)}
 function funds(d){var pos=0,neg=0;d.funds.forEach(function(f){var x=fval(d,f.id);if(x>0)pos+=x;else neg+=x});
  return '<div class="tsB" style="margin:0 0 8px"><button data-a="nf">➕ صندوق جديد</button></div><div class="tsG" style="grid-template-columns:repeat(3,1fr);margin:0 0 10px">'+card('عليكم',Math.abs(neg),'#dc2626')+card('لكم',pos,'#16a34a')+card('الباقي',pos+neg,'#64748b')+'</div>'
  +'<div class="tsC" style="background:#fff;color:var(--primary);font-weight:900">📥 صندوق توريد ('+d.funds.length+') — الإجمالي: '+F(d.funds.reduce(function(s,f){return s+fval(d,f.id)},0))+'</div>'
  +d.funds.slice().sort(function(a,b){return (+a.order||0)-(+b.order||0)}).map(function(f){var b=fb(d,f.id);return '<div class="tsC" style="border-top:3px solid #16a34a"><div data-a="fund" data-i="'+f.id+'" style="cursor:pointer"><b style="color:var(--text)">'+E(f.name)+'</b><div style="margin-top:6px">'+chips(b)+'</div></div><div class="tsB"><button class="p" data-a="tr" data-i="'+f.id+'">🔄 ترحيل</button><button class="g" data-a="rc" data-i="'+f.id+'">📥 توريد</button><button class="r" data-a="hw" data-i="'+f.id+'">📤 حواله</button><button class="o" data-a="ef" data-i="'+f.id+'">✏️ تعديل</button></div></div>'}).join('')}
 function spOK(v){var a='all';try{a=data.settings.activeSpecialty||'all'}catch(e){}return a==='all'||String(v.sp||'')===String(a)}
 function unit(){return sym((curs()[0]||{}).n)}
 function specBar(){var a='all',L=[];try{a=data.settings.activeSpecialty||'all';L=data.settings.specialties||[]}catch(e){}
  return '<div class="tsSpec"><span>التخاصيص</span><select id="tsSpec"><option value="all"'+(a==='all'?' selected':'')+'>كل التخاصيص</option>'+L.map(function(x){return '<option value="'+E(x.id)+'"'+(String(x.id)===String(a)?' selected':'')+'>'+E(x.name)+'</option>'}).join('')+'</select></div>'}
 function sum3(ng,ps){var net=ps-ng,u=E(unit());
  var c=function(v,l,col){return '<div><b style="color:'+col+'">'+F(v)+' <small>'+u+'</small></b><span>'+l+'</span></div>'};
  return '<div class="tsS3n">'+c(ng,'الإجمالي عليكم','#dc2626')+c(ps,'الإجمالي لكم','#15803d')+c(Math.abs(net),net>0?'الباقي لكم':net<0?'الباقي عليكم':'لا يوجد رصيد',net<0?'#dc2626':net>0?'#15803d':'#64748b')+'</div>'}
 function sortBar(all){var o=function(v,t){return '<option value="'+v+'"'+(srt===v?' selected':'')+'>'+t+'</option>'};
  return '<div class="tsSort"><span>ترتيب حسب:</span><select id="tsSrt">'+(all?o('date','📅 التاريخ')+o('name','الاسم')+o('bal','الرصيد'):'<option value="date" selected>📅 التاريخ</option>')+'</select><button data-a="asc" class="'+(asc?'on':'')+'">↑ تصاعدي</button><button data-a="desc" class="'+(asc?'':'on')+'">↓ تنازلي</button></div>'}
 function dateBar(){return '<div class="tsDt date-range-unified"><button type="button" data-a="dp" aria-label="الفترة السابقة">→</button><input type="date" id="tsFrom" value="'+dFrom+'" aria-label="تاريخ البداية"><span>إلى</span><input type="date" id="tsTo" value="'+dTo+'" aria-label="تاريخ النهاية"><button type="button" data-a="dn" aria-label="الفترة التالية">←</button></div>'}
 function strip(b,T){var C=curs().map(function(c){return c.n});Object.keys(b).forEach(function(k){if(C.indexOf(k)<0)C.push(k)});
  var dw=function(v){return v>1e-9?'لكم':v<-1e-9?'عليكم':''};
  var cell=function(n,v){return '<div class="'+(v<0?'neg':'')+'"><span>'+E(sym(n))+'</span><b>'+F2(Math.abs(v))+'</b><em>'+dw(v)+'</em></div>'};
  if(T==null)T=fsum(b);
  return '<div class="tsStrip">'+C.map(function(n){return cell(n,b[n]||0)}).join('')+'<div class="tot'+(T<0?' neg':'')+'"><span>'+(dw(T)?'الناتج '+dw(T):'الناتج')+'</span><b>'+F2(Math.abs(T))+'</b></div></div>'}
 // إجمالي الصندوق بالقيمة الناتجة (مبلغ × سعر الصرف) وليس جمع مبالغ عملات مختلفة
 // قيمة الترحيل في الصندوق المرسل بسعر الشراء (التكلفة) عند تفعيل حساب فارق الصرف؛ المستلم بسعر البيع
 function costTot(v){return (v.rows||[]).reduce(function(s,r){return s+(r.g!=null?(+r.a||0)*r.g:(Number(r.v)||0))},0)}
 function shownRows(v,fid){var cost=v.t==='transfer'&&v.cd&&fid&&v.f===fid;return (v.rows||[]).map(function(r){return cost&&r.g!=null?{c:r.c,a:r.a,r:r.g,v:(+r.a||0)*r.g}:r})}
 function shownTot(v,fid){return v.t==='transfer'&&v.cd&&fid&&v.f===fid?costTot(v):tot(v)}
 function fval(d,id){var t=0;d.vouchers.forEach(function(v){
  if(v.t==='receipt'&&v.f===id)t+=(v.dir==='out'?-1:1)*tot(v);
  else if(v.t==='fxacc'&&v.inFund&&v.f===id)t+=(v.dir==='in'?1:-1)*tot(v);
  else if(v.t==='transfer'){if(v.f===id)t-=(v.cd?costTot(v):tot(v));if(v.f2===id)t+=tot(v)}
  else if(v.t==='internal'&&v.f===id)t-=Math.abs(tot(v))});return t}
 function vKind(v,fid){if(v.t==='exchange')return 'x';if(v.t==='transfer')return v.f===fid?'out':'in';if(v.t==='internal')return 'out';if(fid&&v.t==='receipt')return v.dir==='out'?'out':'in';return v.dir==='in'?'in':'out'}
 function vTitle(d,v,fid){if(v.fx)return v.dir==='out'?'عليكم خسارة فارق صرف':'لكم ربح فارق صرف';var sp=v.sp&&spn(v.sp)?' /'+E(spn(v.sp)):'',acc=v.acc?((d.accounts.find(function(a){return a.id===v.acc})||{}).name||''):'';
  if(!fid){if(v.t==='clockacc')return (v.dir==='out'?'عليكم':'لكم')+' قبض من صفحة ('+E(v.pg||'—')+')'+sp;if(v.t==='internal')return 'عليكم حواله من صندوق ('+E(fname(d,v.f))+')';return E(v.t)}
  if(v.t==='receipt')return (v.dir==='out'?'عليكم إرسال من العملات':'لكم قبض من العملات')+sp;
  if(v.t==='internal')return 'عليكم حواله داخليه-حساب '+E(acc);
  if(v.t==='transfer')return v.f===fid?'عليكم ترحيل إلى صندوق '+E(fname(d,v.f2)):'لكم ترحيل من صندوق '+E(fname(d,v.f));
  return 'صرافة عملات'}
 function vTable(v,fid){if(v.t==='exchange')return '<div class="exchange-ledger-pair"><div class="exchange-ledger-row exchange-debit"><b>عليكم — صرف</b><span>المبلغ: '+F(v.fa)+' '+E(v.from)+' ('+E(sym(v.from))+')</span><small>ناتج الصرف: '+F(v.ta)+' '+E(v.to)+' ('+E(sym(v.to))+')</small></div><div class="exchange-ledger-row exchange-credit"><b>لكم — إضافة</b><span>المبلغ المضاف: '+F(v.ta)+' '+E(v.to)+' ('+E(sym(v.to))+')</span><small>مقابل صرف: '+F(v.fa)+' '+E(v.from)+' ('+E(sym(v.from))+')</small></div>'+(v.r?'<small class="exchange-ledger-rate">سعر الصرف: 1 '+E(v.from)+' = '+F(v.r)+' '+E(v.to)+'</small>':'')+'</div>';
  return '<table class="tsVt"><tr><th>اسم العملة</th><th>مبلغ العملة</th><th>'+(v.t==='transfer'&&v.cd&&fid&&v.f===fid?'سعر الشراء':v.t==='receipt'&&v.dir!=='out'?'سعر الشراء':'سعر البيع')+'</th><th>ناتج الصرف</th></tr>'+shownRows(v,fid).map(function(r){return '<tr><td>'+E(r.c)+'</td><td>'+F(r.a)+'</td><td>'+F(r.r==null?1:r.r)+'</td><td><b>'+F(r.v)+'</b></td></tr>'}).join('')+'</table>'}
 function vCard(d,v,fid){var k=vKind(v,fid),ex=[];
  if(v.t==='internal'){if(v.rn)ex.push('المستلم: '+E(v.rn));if(v.sn)ex.push('المرسل: '+E(v.sn));if(v.no)ex.push('رقم الحوالة: '+E(v.no));if(v.dest)ex.push('الجهة: '+E(v.dest));if(v.com)ex.push('عمولة '+F(v.com))}
  var bd=k==='x'?'<span class="bg xb">صرافة</span>':'<span class="bg '+(k==='in'?'pay':'debt')+'">'+(k==='in'?'لكم':'عليكم')+'</span>';
  return '<div class="tsVC'+(selMode&&selIds.indexOf(v.id)>=0?' tsSel':'')+'" data-vid="'+v.id+'">'+(selMode?'<span class="tsCk">'+(selIds.indexOf(v.id)>=0?'☑':'☐')+'</span>':'')+'<div class="vh"><span class="vt '+(k==='in'?'pay':k==='out'?'debt':'')+'">'+vTitle(d,v,fid)+'</span><span class="vd">'+E(v.d)+'</span></div>'+vTable(v,fid)+(v.n?'<div class="vn">البيان: '+E(v.n)+'</div>':'')+(ex.length?'<div class="vx">'+ex.join(' · ')+'</div>':'')+'<div class="vf">'+bd+(v.t==='exchange'?'<span>عليكم: <b>'+F(v.fa)+' '+E(v.from)+'</b> | لكم: <b>'+F(v.ta)+' '+E(v.to)+'</b></span>':'<span>الإجمالي: <b>'+F(shownTot(v,fid))+'</b></span>')+(v.img?'<button data-a="photo" data-i="'+v.id+'" class="vdel" style="color:#0752a2">📷</button>':'')+'<button data-a="delv" data-i="'+v.id+'" class="vdel">🗑</button></div></div>'}
 function fundView(d,id){var f=d.funds.find(function(x){return x.id===id});if(!f)return '';var b=fb(d,id),V=d.vouchers.filter(function(v){return v.f===id||v.f2===id});
  return '<div class="tsFund"><div class="fn">'+E(f.name)+'</div>'+strip(b,fval(d,id))+'</div>'
  +'<div class="tsB tsB6"><button style="background:#0d9488" data-a="ex" data-i="'+id+'">💱<br>صرافة عملات</button><button class="g" data-a="rc" data-i="'+id+'">➕<br>سند قبض</button><button class="p" data-a="tr" data-i="'+id+'">🔄<br>ترحيل</button><button class="r" data-a="hw" data-i="'+id+'">📤<br>حواله</button><button class="o" data-a="ks" data-i="'+id+'">🖨<br>كشف</button><button class="o" data-a="ef" data-i="'+id+'">✏️<br>تعديل</button><button class="g" data-a="sp" data-i="'+id+'">📥<br>معاملة قبض خاصة</button></div>'
  +'<div class="tsBook">📒 دفتر الحركات</div>'+(V.length?V.slice().reverse().map(function(v){return vCard(d,v,id)}).join(''):'')}
 function F2(n){return (Number(n)||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
 function pad(n){return String(n).padStart(2,'0')}
 function shiftM(v,m){var q=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v||''));if(!q)return v;var y=+q[1],mo=+q[2]-1,day=+q[3],first=new Date(y,mo+m,1),last=new Date(first.getFullYear(),first.getMonth()+1,0).getDate(),x=new Date(first.getFullYear(),first.getMonth(),Math.min(day,last));return x.getFullYear()+'-'+pad(x.getMonth()+1)+'-'+pad(x.getDate())}
 function abc(d,id,to){var b={};d.vouchers.forEach(function(v){if(v.acc!==id||(to&&v.d>to))return;(v.rows||[]).forEach(function(r){b[r.c]=(b[r.c]||0)+(v.dir==='in'?1:-1)*r.a})});return b}
 function fbc(d,gid){var b={};d.accounts.forEach(function(a){if(a.g!==gid)return;var x=abc(d,a.id);for(var c in x)b[c]=(b[c]||0)+x[c]});return b}
 function money(b){var k=Object.keys(b).filter(function(c){return Math.abs(b[c])>1e-9});if(!k.length)return '0.00 '+E(sym((curs()[0]||{}).n));return k.map(function(c){return '<span style="color:'+(b[c]<0?'#dc2626':'#15803d')+'">'+F2(Math.abs(b[c]))+' '+E(sym(c))+'</span>'}).join(' • ')}
 function fnet(d,gid){return d.accounts.filter(function(a){return a.g===gid}).reduce(function(s,a){return s+abal(d,a.id)},0)}
function nmoney(v){v=Math.round(v*1000)/1000;if(Math.abs(v)<1e-9)return '<span style="color:#64748b;font-weight:900">0</span>';return '<span style="color:'+(v<0?'#dc2626':'#15803d')+';font-weight:900">'+F(Math.abs(v))+' '+(v<0?'عليكم':'لكم')+'</span>'}
function folders(d){var G=d.folders.slice().sort(function(a,b){return (a.o||0)-(b.o||0)});
  return '<div class="tsBlue"><button data-a="nfo">إضافة مجلد حسابات</button><button data-a="stat">الإحصائيات</button><button data-a="qs">البحث السريع</button></div><div class="tsFg">'+G.map(function(g){var n=d.accounts.filter(function(a){return a.g===g.id}).length;return '<div class="tsF" data-a="fol" data-i="'+g.id+'"><span class="ed" data-a="efo" data-i="'+g.id+'">✏️</span><div class="ic">'+(g.img?'<img src="'+E(g.img)+'">':'👥')+'</div><b>'+E(g.name)+'</b><small>'+nmoney(fnet(d,g.id))+'</small><small>'+n+' حساب</small></div>'}).join('')+'</div>'+(G.length?'':'')}
 function accRows(d,gid){return d.accounts.filter(function(a){return a.g===gid}).map(function(a){var V=d.vouchers.filter(function(v){return v.acc===a.id}),I=V.filter(function(v){return v.d>=dFrom&&v.d<=dTo&&(v.rows||[]).some(function(r){return r.c===cur})});
   return {a:a,b:abc(d,a.id,dTo)[cur]||0,last:I.reduce(function(m,v){return v.d>m?v.d:m},''),show:!V.length||I.length}}).filter(function(x){return x.show})}
 function folderView(d,gid){var ng=0,ps=0,u=E(unit());
  var R=d.accounts.filter(function(a){return a.g===gid}).map(function(a){var all=d.vouchers.filter(function(v){return v.acc===a.id}),V=all.filter(function(v){return spOK(v)&&v.d<=dTo}),I=V.filter(function(v){return v.d>=dFrom});
   var b=V.reduce(function(s,v){return s+(v.dir==='in'?1:-1)*tot(v)},0);
   return {a:a,b:b,last:I.reduce(function(m,v){return v.d>m?v.d:m},''),show:!all.length||I.length}}).filter(function(x){return x.show});
  R.forEach(function(x){if(x.b<0)ng-=x.b;else ps+=x.b});
  R.sort(function(p,q){var r=srt==='name'?p.a.name.localeCompare(q.a.name,'ar'):srt==='bal'?Math.abs(p.b)-Math.abs(q.b):(p.last||'').localeCompare(q.last||'');return asc?r:-r});
  return specBar()+sum3(ng,ps)+sortBar(true)+dateBar()
  +(R.length?R.map(function(x){return '<div class="tsC acc-card" data-a="acc" data-i="'+x.a.id+'"><span class="ac-av">'+E(String(x.a.name||'?').trim().charAt(0)||'?')+'</span><span class="ac-mid"><b class="ac-name">'+E(x.a.name)+'</b>'+(x.a.ph?'<small class="ac-ph">'+E(x.a.ph)+'</small>':'')+'</span><span class="ac-bal" style="color:'+(x.b<-1e-9?'#dc2626':x.b>1e-9?'#15803d':'#16a37a')+'"><em>'+(x.b<-1e-9?'عليكم':x.b>1e-9?'لكم':'متعادل')+'</em><b>'+F(Math.abs(x.b))+'</b></span></div>'}).join(''):'')
  +'<button class="tsFab" data-a="na" data-i="'+gid+'">＋</button>'}
 function accTable(d,V){
  if(!document.getElementById('tsStStyle2')){var st=document.createElement('style');st.id='tsStStyle2';st.textContent='.tsStWrap{overflow-x:auto;margin:8px 0}.tsSt{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed;background:#fff;border-radius:10px;overflow:hidden}.tsSt th{background:#1e3a8a;color:#fff;padding:8px 3px;font-weight:800;text-align:center}.tsSt td{padding:7px 4px;text-align:center;border-bottom:1px solid #e2e8f0;vertical-align:middle;overflow-wrap:anywhere}.tsSt tr:last-child td{border-bottom:0}.tsStTop{font-weight:800;font-size:12px;line-height:1.35}.tsStBot{font-weight:700;font-size:11px;line-height:1.35}.tsStDebt{color:#dc2626}.tsStPay{color:#16a34a}.tsStAmt{font-size:16px;font-weight:900;line-height:1.2}.tsStAmt.debt{color:#dc2626}.tsStAmt.pay{color:#16a34a}.tsStDate{font-size:10px;color:#64748b;direction:ltr;margin-top:2px}.tsStNote{font-size:12px;font-weight:700;color:#334155;margin-bottom:2px}.tsStIc{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}.tsStIc button{border:0;background:transparent;font-size:15px;padding:2px 4px;cursor:pointer;line-height:1}.tsStIc .ic-blue{color:#1d4ed8}.tsStIc .ic-red{color:#dc2626}.tsStBal{font-weight:700;font-size:12px}';document.head.appendChild(st)}
  var chron=V.slice().sort(function(p,q){return (p.d||'').localeCompare(q.d||'')}),run=0,bal={};
  chron.forEach(function(v){run+=(v.dir==='in'?1:-1)*tot(v);bal[v.id]=run});
  var body=V.map(function(v){
   var out=v.dir!=='in',r=bal[v.id]||0,cls=out?'debt':'pay';
   return '<tr>'
    +'<td><div class="tsStTop '+(out?'tsStDebt':'tsStPay')+'">'+(out?'عليكم':'لكم')+' —</div><div class="tsStBot '+(out?'tsStDebt':'tsStPay')+'">'+E(v.pg||vName(v))+'</div></td>'
    +'<td><div class="tsStAmt '+cls+'">'+F(tot(v))+'</div><div class="tsStDate">'+E(v.d)+'</div></td>'
    +'<td><div class="tsStNote">'+(v.n?E(v.n):'—')+'</div><div class="tsStIc">'
    +'<button type="button" class="ic-blue" data-a="tph" data-i="'+v.id+'" title="الصورة">📷</button>'
    +'<button type="button" class="ic-blue" data-a="tsh" data-i="'+v.id+'" title="مشاركة">📤</button>'
    +'<button type="button" class="ic-blue" data-a="tpr" data-i="'+v.id+'" title="طباعة">🖨️</button>'
    +'<button type="button" class="ic-blue" data-a="ted" data-i="'+v.id+'" title="تعديل">✏️</button>'
    +'<button type="button" class="ic-red" data-a="tdl" data-i="'+v.id+'" title="حذف">🗑</button>'
    +'</div></td>'
    +'<td><div class="tsStBal">'+(r<0?'عليكم ':'لكم ')+F(Math.abs(r))+'</div></td>'
    +'</tr>';
  }).join('');
  return '<div class="tsStWrap"><table class="tsSt"><thead><tr><th>النوع</th><th>المبلغ</th><th>التفصيل</th><th>الرصيد</th></tr></thead><tbody>'+body+'</tbody></table></div>';
 }
 function shareV(id){var o=vFind(id),v=o.v;if(!v)return;var text=vInfo(o.d,v).map(function(x){return x[0]+': '+x[1]}).concat(vLines(v)).join('\n');
  if(navigator.share){navigator.share({title:vName(v),text:text}).catch(function(){});return}
  if(navigator.clipboard){navigator.clipboard.writeText(text).then(function(){alert('تم نسخ بيانات السند')}).catch(function(){})}}
 function accView(d,id){var a=d.accounts.find(function(x){return x.id===id});if(!a)return '';
  var V=d.vouchers.filter(function(v){return v.acc===id&&spOK(v)&&v.d>=dFrom&&v.d<=dTo}),ng=0,ps=0;
  V.forEach(function(v){if(v.dir==='in')ps+=tot(v);else ng+=tot(v)});
  V.sort(function(p,q){var r=(p.d||'').localeCompare(q.d||'');return asc?r:-r});
  return specBar()+sum3(ng,ps)+sortBar(false)+dateBar()
  +'<div class="tsAccH"><div>'+(a.ph?'<small>📞 '+E(a.ph)+'</small>':'')+(a.lim?'<small>سقف المديونية: '+F(a.lim)+'</small>':'')+'</div></div>'
  +(V.length?accTable(d,V):'')}
 function more(d){d=d||db();var st=d.settings||{};var accN=function(id){var a=(d.accounts||[]).find(function(x){return x.id===id});return a?a.name:'غير محدد'};
 return '<div class="tsC" data-a="fxset" data-i="fx" style="cursor:pointer"><small>حساب فارق الصرافة (الربح والخسارة يُرحَّل إليه مباشرة)</small><b>'+E(accN(st.fxAcc))+'</b></div>'
  +'<div class="tsC" data-a="fxset" data-i="com" style="cursor:pointer"><small>حساب عمولة الحوالة</small><b>'+E(accN(st.comAcc))+'</b></div>'
  +'<div class="tsC" data-a="reset" style="cursor:pointer"><b style="color:#dc2626">🗑 تصفير بيانات الصرافة</b></div>'}
 function tsTopPrint(auth){if(tab==='accs'&&sub&&sub.k==='acc')printTasfeerAccount(sub.id,auth);else if(tab==='funds'&&sub&&sub.k==='fund')fundPrintDialog(sub.id,auth)}
 function syncTsTop(){var top=document.querySelector('#tsPage .tsTop');if(!top)return;
  [].forEach.call(top.querySelectorAll('[data-tsbtn]'),function(b){b.remove()});
  if(!((tab==='accs'&&sub&&sub.k==='acc')||(tab==='funds'&&sub&&sub.k==='fund')))return;
  var anchor=top.querySelector('b');
  [['tsprint','🖨️','طباعة كشف'],['tsauth','📝','طباعة مصادقة']].forEach(function(x){var b=document.createElement('button');b.type='button';b.setAttribute('data-tsbtn','1');b.dataset.a=x[0];b.title=x[2];b.textContent=x[1];top.insertBefore(b,anchor)})}
 function render(){var tsScrollHost=$('tsBody'),tsScrollTop=tsScrollHost?tsScrollHost.scrollTop:0;var d=db(),t=$('tsTitle'),h='';
  if(tab==='home'){t.textContent='الرئيسية';h=home(d)}
  else if(tab==='funds'){if(sub&&sub.k==='fund'){t.textContent='داخل الصندوق';h=fundView(d,sub.id)}else{t.textContent='الصناديق';h=funds(d)}}
  else if(tab==='accs'){if(sub&&sub.k==='fol'){t.textContent='صفحة مجلد الحساب';h=folderView(d,sub.id)}else if(sub&&sub.k==='acc'){var acT=d.accounts.find(function(x){return x.id===sub.id});t.textContent=acT?acT.name:'كشف الحساب';h=accView(d,sub.id)}else{t.textContent='صفحة الحسابات';h=folders(d)}}
  else if(tab==='vouch'){t.textContent='السندات';h=vlist(d,d.vouchers)}
  else{t.textContent='المزيد';h=more(d)}
  syncTsTop();tsScrollHost.innerHTML=(selMode?selBar():'')+h;if(window.__refreshDatePickers)window.__refreshDatePickers();tsScrollHost.scrollTop=tsScrollTop;requestAnimationFrame(function(){if(tsScrollHost)tsScrollHost.scrollTop=tsScrollTop});
  document.querySelectorAll('#tsPage .tsNav button').forEach(function(b){b.classList.toggle('on',b.dataset.t===tab)})}
 function modal(title,body,ok,lbl,cls){var o=document.createElement('div');o.className='tsOv';
  o.innerHTML='<div class="tsBox '+(cls||'')+'"><div class="tsMH"><b>'+title+'</b><button type="button" data-x>✕</button></div><div class="tsMB">'+body+'</div><div class="tsAct">'+(ok?'<button type="button" class="tsOk">'+(lbl||'حفظ')+'</button><button type="button" data-x>إلغاء</button>':'<button type="button" data-x>إغلاق</button>')+'</div></div>';
  o.addEventListener('click',function(e){if(e.target===o||e.target.hasAttribute('data-x'))o.remove();else if(ok&&e.target.classList.contains('tsOk')){if(ok(o)!==false)o.remove()}});
  $('tsPage').appendChild(o);return o}
 function radio(n,L,v){return L.map(function(x){return '<label><input type="radio" name="'+n+'" value="'+x[0]+'"'+(x[0]===v?' checked':'')+'>'+x[1]+'</label>'}).join('')}
 function accModal(gid,id){var d=db(),a=(id&&d.accounts.find(function(x){return x.id===id}))||{},has=a.lim>0;
  var o=modal(id?'تعديل الحساب':'إضافة حساب جديد',
   '<label>الاسم<input id="aN" placeholder="ادخل الاسم" value="'+E(a.name)+'"></label>'
   +'<label>رقم الهاتف<div style="display:flex;gap:6px"><input id="aP" inputmode="tel" placeholder="اختر رقم الهاتف من الأسماء" value="'+E(a.ph)+'"><button type="button" data-pick style="background:var(--primary);color:#fff;border-radius:10px;padding:0 14px">👥</button></div></label>'
   +'<label style="display:flex;flex-direction:row;justify-content:space-between;align-items:center"><span>إضافة سقف مديونية</span><input type="checkbox" id="aL" style="width:22px;height:22px"'+(has?' checked':'')+'></label>'
   +'<input id="aLA" type="number" inputmode="decimal" placeholder="مبلغ سقف المديونية" value="'+(a.lim||'')+'" style="display:'+(has?'block':'none')+'">'
   +'' ,
   function(o){var n=o.querySelector('#aN').value.trim();if(!n){alert('أدخل الاسم');return false}
    var d=db(),x=id?d.accounts.find(function(z){return z.id===id}):null;
    if(d.accounts.some(function(z){return z.name===n&&(!x||z.id!==x.id)})){alert('يوجد حساب بنفس الاسم');return false}
    if(!x){x={id:'a'+Date.now(),g:gid};d.accounts.push(x)}
    x.name=n;x.ph=o.querySelector('#aP').value.trim();x.lim=o.querySelector('#aL').checked?(+o.querySelector('#aLA').value||0):0;
    save(d);render()});
  o.addEventListener('change',function(e){if(e.target.id==='aL')o.querySelector('#aLA').style.display=e.target.checked?'block':'none'});
  o.addEventListener('click',async function(e){if(!e.target.closest('[data-pick]'))return;
   try{if(navigator.contacts&&navigator.contacts.select){var r=await navigator.contacts.select(['name','tel'],{multiple:false}),c=r&&r[0];if(!c)return;var n=[].concat(c.name||[])[0],t=[].concat(c.tel||[])[0];if(n&&!o.querySelector('#aN').value.trim())o.querySelector('#aN').value=n;if(t)o.querySelector('#aP').value=t}else alert('اختيار جهات الاتصال غير مدعوم في هذا المتصفح، اكتب الرقم يدوياً')}catch(x){}})}
 function folModal(id){var d=db(),g=id?d.folders.find(function(x){return x.id===id}):null,img=(g&&g.img)||'',pv=function(){return img?'<img src="'+img+'" style="height:50px;width:50px;object-fit:cover;border-radius:50%">':'📷'};
  var o=modal(g?'📁 تعديل مجلد':'📁 إضافة مجلد',
   '<label>صورة المجلد<div id="fImgB" data-pickimg style="border:2px dashed var(--primary);border-radius:10px;padding:10px;text-align:center;cursor:pointer;font-size:22px">'+pv()+'</div></label><input type="file" id="fImgI" accept="image/*" hidden>'
   +'<label>اسم المجلد<input id="fN" value="'+E(g&&g.name)+'"></label><label>ترتيب المجلد<input id="fO" type="number" value="'+(g?(g.o||0):d.folders.length+1)+'"></label>'
   +(g?'<button type="button" data-delf style="color:#dc2626;font-weight:900;padding:8px">🗑 حذف المجلد</button>':''),
   function(o){var n=o.querySelector('#fN').value.trim();if(!n){alert('أدخل اسم المجلد');return false}
    var d=db(),x=id?d.folders.find(function(z){return z.id===id}):null;if(!x){x={id:'g'+Date.now()};d.folders.push(x)}
    x.name=n;x.o=+o.querySelector('#fO').value||0;if(img)x.img=img;save(d);render()});
  o.querySelector('#fImgI').addEventListener('change',function(){var f=this.files[0];if(!f)return;var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var k=160/Math.max(im.width,im.height,160),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);img=c.toDataURL('image/jpeg',.8);o.querySelector('#fImgB').innerHTML=pv()};im.src=r.result};r.readAsDataURL(f)});
  o.addEventListener('click',function(e){if(e.target.closest('[data-pickimg]'))o.querySelector('#fImgI').click();
   if(e.target.closest('[data-delf]')){var d=db();if(d.accounts.some(function(a){return a.g===id})){alert('انقل حسابات هذا المجلد أو احذفها أولاً');return}if(!confirm('حذف المجلد؟'))return;d.folders=d.folders.filter(function(z){return z.id!==id});save(d);o.remove();render()}})}
 function statsModal(){var d=db(),ng={},ps={};d.accounts.forEach(function(a){var b=abc(d,a.id);for(var c in b){if(b[c]<0)ng[c]=(ng[c]||0)-b[c];else ps[c]=(ps[c]||0)+b[c]}});
  var cs=Object.keys(ng).concat(Object.keys(ps)).filter(function(c,i,r){return r.indexOf(c)===i});
  modal('📊 الإحصائيات','<div class="tsC"><b style="color:var(--text)">'+d.folders.length+' مجلد — '+d.accounts.length+' حساب</b></div>'+(cs.length?cs.map(function(c){return '<div class="tsC"><b style="color:var(--text)">'+E(sym(c))+'</b><div style="margin-top:4px;color:#dc2626;font-weight:800">الإجمالي عليكم: '+F(ng[c]||0)+'</div><div style="color:#15803d;font-weight:800">الإجمالي لكم: '+F(ps[c]||0)+'</div></div>'}).join(''):''),null)}
 function searchModal(){var d=db(),o=modal('🔍 البحث السريع','<input id="qS" placeholder="اسم الحساب أو رقم الهاتف" autofocus><div id="qR"></div>',null);
  function go(){var q=o.querySelector('#qS').value.trim().toLowerCase();o.querySelector('#qR').innerHTML=q?(d.accounts.filter(function(a){return (a.name||'').toLowerCase().indexOf(q)>-1||(a.ph||'').indexOf(q)>-1}).map(function(a){return '<div class="tsC" data-open="'+a.id+'" style="cursor:pointer"><b style="color:var(--text)">'+E(a.name)+'</b><small>'+E(a.ph||'')+'</small></div>'}).join('')||''):''}
  o.addEventListener('input',go);o.addEventListener('click',function(e){var r=e.target.closest('[data-open]');if(r){o.remove();A.acc(r.dataset.open)}})}
 /* سعر الصرف من إعدادات العملات: kind='buy' (سعر الشراء) أو 'sell' (سعر البيع)، وبدونه يبقى الإدخال اليدوي (تحويل بين الصناديق فقط) */
 function rateOf(name,kind){var c=(data.settings.currencies||[]).find(function(x){return x.name===name});if(!c)return 1;var r=+(kind==='buy'?c.buyRate:c.sellRate);return r>0?r:1}
 function rowsHTML(l,kind){var fixed=kind==='buy'||kind==='sell';return '<table class="tsT"><tr><th>العملة</th><th>المبلغ</th><th>'+(l||'سعر الصرف')+'</th></tr>'+curs().map(function(c){var rc=fixed?'<span data-r data-fixed="1">'+rateOf(c.n,kind)+'</span>':'<input type="number" inputmode="decimal" data-r placeholder="1">';return '<tr data-c="'+E(c.n)+'"><td>'+E(c.s)+'</td><td><input type="number" inputmode="decimal" data-a></td><td>'+rc+'</td></tr>'}).join('')+'</table>'}
 function readRows(o){var r=[];o.querySelectorAll('tr[data-c]').forEach(function(tr){var a=+tr.querySelector('[data-a]').value;if(a>0){var rEl=tr.querySelector('[data-r]');var x=rEl.tagName==='INPUT'?rEl.value:rEl.textContent;x=(x===''||x==null)?1:+x;r.push({c:tr.dataset.c,a:a,r:x,v:a*x})}});return r}
 function fsel(d,id,idn){return '<select id="'+idn+'">'+d.funds.map(function(f){return '<option value="'+f.id+'"'+(f.id===id?' selected':'')+'>'+E(f.name)+'</option>'}).join('')+'</select>'}
 function dFmt(v){var p=(v||'').split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:(v||'')}
 function dateHTML(){return '<div class="fld">التاريخ<div class="vDt"><div class="vDv" data-dv>'+dFmt(td())+'</div><button type="button" class="vCal" data-cal>📆</button><input type="date" id="vDate" class="vDh" value="'+td()+'" tabindex="-1"></div></div>'}
 function photoHTML(){return '<label class="vPh" data-ph><span class="vPhI">📷<small>صورة</small></span><input type="file" id="vImgI" accept="image/*" style="position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;font-size:0"></label>'}
 function totHTML(l){return '<div class="vTot"><span>'+l+'</span><b data-tot>0</b></div>'}
 function asel(d){return '<select id="vAcc"><option value="">اختر الحساب</option>'+d.accounts.map(function(a){return '<option value="'+a.id+'">'+E(a.name)+'</option>'}).join('')+'<option value="__new">＋ حساب جديد...</option></select><input id="vAccN" placeholder="اسم الحساب الجديد" style="display:none;margin-top:6px">'}
 function wire(o){
  var di=o.querySelector('#vDate'),dv=o.querySelector('[data-dv]');
  if(di&&dv){var show=function(){try{di.showPicker()}catch(e){di.focus();di.click()}};
   o.querySelectorAll('[data-cal],[data-dv]').forEach(function(x){x.addEventListener('click',show)});
   di.addEventListener('change',function(){dv.textContent=dFmt(di.value)})}
  var pb=o.querySelector('[data-ph]'),pi=o.querySelector('#vImgI');
  if(pb&&pi){
   pi.addEventListener('change',function(){var f=pi.files[0];if(!f)return;var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var k=700/Math.max(im.width,im.height,700),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);o._img=c.toDataURL('image/jpeg',.6);pb.querySelector('.vPhI').innerHTML='<img src="'+o._img+'">'};im.src=r.result};r.readAsDataURL(f)})}
  var as=o.querySelector('#vAcc'),an=o.querySelector('#vAccN');
  if(as&&an)as.addEventListener('change',function(){an.style.display=as.value==='__new'?'block':'none';if(as.value==='__new')an.focus()});
  var tt=o.querySelector('[data-tot]');
  if(tt)o.addEventListener('input',function(){var n=readRows(o).reduce(function(x,r){return x+r.v},0),cm=Number((o.querySelector('#vCom')||{}).value)||0;tt.textContent=F(n+(o.querySelector('#vCom')?cm:0))})}
 function clockAmtRows(o,sel){var a=+((o.querySelector(sel)||{}).value)||0;if(a<=0)return [];var c=(curs()[0]||{}).n||'المبلغ';return [{c:c,a:a,r:1,v:a}]}
 function voucher(type,fid,titleOverride){var d=db(),T={receipt:'سند قبض من العملات إلى الصناديق',transfer:'سند ترحيل إلى صندوق آخر',internal:'سند إرسال واستلام حوالة داخلية',clockacc:'سند قبض من صفحات المراقب إلى الحسابات'};
  if(!d.funds.length&&type!=='clockacc'){alert('أضف صندوقاً أولاً');return}
  var h='<div class="vTop">'+dateHTML()+photoHTML()+'</div>',f0=fid||(d.funds[0]||{}).id;
  if(type==='transfer')h+='<label>من صندوق'+fsel(d,f0,'vF')+'</label><label>إلى صندوق'+fsel(d,(d.funds.find(function(x){return x.id!==f0})||d.funds[0]).id,'vF2')+'</label>'+rowsHTML('سعر الصرف')+totHTML('اجمالي ناتج الترحيل');
  else if(type==='internal')h+='<div class="v2"><label>الصندوق'+fsel(d,f0,'vF')+'</label><label>الحساب'+asel(d)+'</label></div>'
   +'<div class="v4"><label>اسم المرسل<input id="vSn"></label><label>اسم المستلم<input id="vRn"></label><label>رقم الحواله<input id="vNo" inputmode="numeric"></label><label>جهة الحواله<input id="vDest"></label></div>'
   +rowsHTML('سعر البيع','sell')+'<div class="v2"><label>مبلغ العمولة<input type="number" inputmode="decimal" id="vCom"></label>'+totHTML('ناتج الصرف + العمولة')+'</div>';
  else if(type==='clockacc'){var sp2=[];try{sp2=(data.settings.specialties||[])}catch(e){}
   h+='<div class="v2"><label>صفحات المراقب<select id="vPg">'+PAGES.map(function(p){return '<option>'+p+'</option>'}).join('')+'</select></label><label>اختار التخصيص للصفحه<select id="vSp"><option value="">بدون تخصيص</option>'+sp2.map(function(x){return '<option value="'+E(x.id)+'">'+E(x.name)+'</option>'}).join('')+'</select></label></div><label>الحساب'+asel(d)+'</label><label>المبلغ الإجمالي<input type="number" inputmode="decimal" id="vAmt" placeholder="0"></label><label>البيان<input id="vN"></label>'+'<div class="vDir"><label class="in"><input type="radio" name="vDir" value="in" checked>💚 لكم — قيد للحساب</label><label class="out"><input type="radio" name="vDir" value="out">❤️ عليكم — قيد على الحساب</label></div>'}
  else if(false)h+=rowsHTML()+totHTML('اجمالي ناتج القبض');
  else{var sp=[];try{sp=(data.settings.specialties||[])}catch(e){}
   h+='<label>الصندوق'+fsel(d,f0,'vF')+'</label><div class="v2"><label>اختار التخصيص للعملات<select id="vSp"><option value="">بدون تخصيص</option>'+sp.map(function(x){return '<option value="'+E(x.id)+'">'+E(x.name)+'</option>'}).join('')+'</select></label><label>البيان<input id="vN"></label></div>'
   +rowsHTML('سعر الشراء','buy')+totHTML('اجمالي ناتج القبض')+'<div class="vDir"><label class="in"><input type="radio" name="vDir" value="in" checked>💚 لكم — استلام</label><label class="out"><input type="radio" name="vDir" value="out">❤️ عليكم — إرسال</label></div>'}
  var o=modal(titleOverride||T[type],h,function(o){
   var rows=type==='clockacc'?clockAmtRows(o,'#vAmt'):readRows(o);if(!rows.length){alert(type==='clockacc'?'أدخل المبلغ':'أدخل مبلغ عملة واحدة على الأقل');return false}
   var d=db(),q=function(i){var e=o.querySelector(i);return e?e.value.trim():''},v={id:'v'+Date.now()+Math.random().toString(36).slice(2,5),t:type,d:q('#vDate')||td(),rows:rows};
   if(q('#vN'))v.n=q('#vN');if(o._img)v.img=o._img;
   if(type!=='clockacc')v.f=q('#vF');
   if(type==='transfer'){v.f2=q('#vF2');if(v.f===v.f2){alert('اختر صندوقين مختلفين');return false}}
   if(type==='receipt'){v.dir=o.querySelector('[name=vDir]:checked').value;if(q('#vSp'))v.sp=q('#vSp')}
   if(type==='clockacc'){v.pg=q('#vPg');var vd=o.querySelector('[name=vDir]:checked');v.dir=vd?vd.value:'in';if(q('#vSp'))v.sp=q('#vSp')}
   if(type==='internal'){v.dir='out';v.sn=q('#vSn');v.rn=q('#vRn');v.no=q('#vNo');v.dest=q('#vDest');if(+q('#vCom')>0)v.com=+q('#vCom');if(v.rn)v.p=v.rn}
   if(type==='internal'||type==='clockacc'){v.acc=q('#vAcc');if(!v.acc){alert('اختر الحساب');return false}
    if(v.acc==='__new'){var nm=q('#vAccN');if(!nm){alert('أدخل اسم الحساب الجديد');return false}
     var ex=d.accounts.find(function(x){return x.name===nm});if(!ex){ex={id:'a'+Date.now(),g:(d.folders[0]||{}).id||'',name:nm};d.accounts.push(ex)}v.acc=ex.id}}
   if(type==='receipt'&&v.dir==='out'){
    if(!checkFundCoverage(d,v.f,rows,null))return false;
   }
   clockLink(v,d);d.vouchers.push(v);save(d);render()},'حفظ','v');
  if(type==='receipt'){var syncL=function(){var out=(o.querySelector('[name=vDir]:checked')||{}).value==='out',th=o.querySelector('.tsT th:nth-child(3)'),ts=o.querySelector('.vTot span');if(th)th.textContent=out?'سعر البيع':'سعر الشراء';if(ts&&!ts.parentNode.querySelector('[data-fxp]'))ts.textContent=out?'اجمالي ناتج الصرف':'اجمالي ناتج القبض'};o.addEventListener('change',syncL);syncL()}
  if(type==='transfer'||type==='internal'||type==='receipt'){var pv=document.createElement('div');pv.className='vTot';pv.style.cssText='display:none;margin-top:6px';pv.innerHTML='<span>فارق الصرف المتوقع</span><b data-fxp>0</b>';var tb=o.querySelector('.vTot');if(tb&&tb.parentNode)tb.parentNode.insertBefore(pv,tb.nextSibling);
   var upP=function(){var dd=db(),f=(o.querySelector('#vF')||{}).value,R=readRows(o),rr={funds:dd.funds,vouchers:JSON.parse(JSON.stringify(dd.vouchers.filter(function(z){return !z.fx})))};
    var isR=type==='receipt',dirOut=(o.querySelector('[name=vDir]:checked')||{}).value==='out';if(isR&&!dirOut){pv.style.display='none';return}
    rr.vouchers.push(isR?{id:'__p',t:'receipt',dir:'out',d:td(),f:f,rows:R}:{id:'__p',t:'internal',d:td(),f:f,rows:R});fxRecalc(rr);var fx=rr.vouchers.find(function(z){return z.pl==='__p'});
    var m=fx?(fx.dir==='out'?-1:1)*fx.rows[0].a:0;pv.style.display=R.length?'flex':'none';var b=pv.querySelector('[data-fxp]');b.textContent=(m>0?'ربح ':m<0?'خسارة ':'')+F(Math.abs(m));b.style.color=m>0?'#15803d':m<0?'#dc2626':''};
   o.addEventListener('input',upP);o.addEventListener('change',upP)}
  wire(o)}

 function vName(v){return v.fx?(v.dir==='out'?'عليكم خسارة فارق صرف':'لكم ربح فارق صرف'):v.t==='receipt'?(v.dir==='out'?'سند من العملات — إرسال':'سند قبض من العملات'):v.t==='exchange'?'صرافة عملات':v.t==='transfer'?'ترحيل بين الصناديق':v.t==='internal'?'حوالة داخلية — إرسال':'سند من المراقب — '+(v.dir==='out'?'عليكم':'لكم')+(v.pg?' ('+v.pg+')':'')}
 function vFind(id){var d=db();return {d:d,v:d.vouchers.find(function(x){return x.id===id})}}
 function vInfo(d,v){var a=v.acc?((d.accounts.find(function(x){return x.id===v.acc})||{}).name||''):'',L=[['التاريخ',v.d]];
  if(v.f)L.push(['الصندوق',fname(d,v.f)]);if(v.f2)L.push(['إلى صندوق',fname(d,v.f2)]);if(v.t==='receipt'||v.t==='clockacc')L.push(['الاتجاه',v.dir==='out'?'عليكم':'لكم']);if(a)L.push(['الحساب',a]);
  if(v.sp&&spn(v.sp))L.push(['التخصيص',spn(v.sp)]);if(v.sn)L.push(['المرسل',v.sn]);if(v.rn)L.push(['المستلم',v.rn]);if(v.no)L.push(['رقم الحوالة',v.no]);if(v.dest)L.push(['الجهة',v.dest]);if(v.com)L.push(['العمولة',F(v.com)]);if(v.n)L.push(['البيان',v.n]);
  L.push(['الإجمالي',F(tot(v))]);return L}
 function vLines(v){return v.t==='exchange'?[F(v.fa)+' '+sym(v.from)+' ← '+F(v.ta)+' '+sym(v.to)+(v.r?' (سعر الصرف '+F(v.r)+')':'')]:(v.rows||[]).map(function(r){return sym(r.c)+': '+F(r.a)+' × '+F(r.r==null?1:r.r)+' = '+F(r.v)})}
 function viewV(id){var o=vFind(id),v=o.v;if(!v)return;
  modal('👁 '+E(vName(v)),'<div class="tsC">'+vInfo(o.d,v).map(function(x){return '<div style="display:flex;justify-content:space-between;gap:8px;padding:3px 0"><span style="color:#64748b">'+E(x[0])+'</span><b>'+E(x[1])+'</b></div>'}).join('')+'</div>'+vTable(v)+(v.img?'<img src="'+v.img+'" style="width:100%;border-radius:10px;margin-top:8px">':''),null)}

 // تفقيط المبالغ بالعربية
 function tafqeet(n){n=Math.floor(Math.abs(Number(n)||0));if(!n)return 'صفر';
  var ones=['','واحد','اثنان','ثلاثة','أربعة','خمسة','ستة','سبعة','ثمانية','تسعة','عشرة','أحد عشر','اثنا عشر','ثلاثة عشر','أربعة عشر','خمسة عشر','ستة عشر','سبعة عشر','ثمانية عشر','تسعة عشر'],
   tens=['','','عشرون','ثلاثون','أربعون','خمسون','ستون','سبعون','ثمانون','تسعون'],
   hund=['','مئة','مئتان','ثلاثمئة','أربعمئة','خمسمئة','ستمئة','سبعمئة','ثمانمئة','تسعمئة'];
  function u1000(x){var h=Math.floor(x/100),r=x%100,p=[];if(h)p.push(hund[h]);
   if(r){if(r<20)p.push(ones[r]);else{var u=r%10,t=Math.floor(r/10);p.push(u?ones[u]+' و'+tens[t]:tens[t])}}
   return p.map(function(t,i){return i?'و'+t:t}).join(' ')}
  function grp(x,a,b,c){if(x===1)return a;if(x===2)return b;var r=x%100;return u1000(x)+' '+((r>=3&&r<=10)?c:a)}
  var parts=[],bn=Math.floor(n/1e9),ml=Math.floor(n%1e9/1e6),th=Math.floor(n%1e6/1e3),un=n%1000;
  if(bn)parts.push(grp(bn,'مليار','ملياران','مليارات'));if(ml)parts.push(grp(ml,'مليون','مليونان','ملايين'));
  if(th)parts.push(grp(th,'ألف','ألفان','آلاف'));if(un)parts.push(u1000(un));
  return parts.map(function(t,i){return i?'و'+t:t}).join(' ')}
 window.tafqeet=tafqeet;
 function curWords(amount,name){var unitW=/دولار|\$/.test(name)?'دولار':/درهم|إمارات|اماراتي/.test(name)?'درهم':'ريال';
  var lab=name.indexOf(unitW)>=0?name:unitW+' '+name;return tafqeet(amount)+' '+lab.trim()+' فقط لا غير'}
 function printHawala(d,v){
 var rows=(v.rows||[]),acc=v.acc?((d.accounts.find(function(a){return a.id===v.acc})||{}).name||''):'';
 var m=/^v(\d{13})/.exec(v.id||''),tm=m?new Date(+m[1]):new Date(),hh=String(tm.getHours()).padStart(2,'0')+':'+String(tm.getMinutes()).padStart(2,'0');
 var wd='';try{wd=new Date(v.d+'T12:00:00').toLocaleDateString('ar-u-nu-latn',{weekday:'long'})}catch(e){}
 var u=unit(),base=rows.reduce(function(s,r){return s+(Number(r.v)||0)},0),com=+v.com||0,total=base+com;
 var amountBox=rows.map(function(r){return '<div>'+E(sym(r.c))+' '+F(r.a)+'</div>'}).join('')||'<div>'+F(base)+' '+E(u)+'</div>';
 var words=rows.map(function(r){return '<div>'+E(curWords(r.a,r.c))+'</div>'}).join('');
  PV2.hawala({dateStr:wd+' '+dFmt(v.d)+' '+hh,amts:rows.map(function(r){return sym(r.c)+' '+F(r.a)}).join(' + ')||(F(base)+' '+u),from:(acc||fname(d,v.f)),words:rows.map(function(r){return curWords(r.a,r.c)}).join(' — ')||(F(base)+' '+u),com:F(com)+' '+u,sender:v.sn||'',receiver:v.rn||'',totalTxt:F(total)+' '+u,dest:v.dest||'',no:v.no||'',note:v.n||''});
}
function printV(id){
 var o=vFind(id),v=o.v;if(!v)return;if(v.t==='internal'){printHawala(o.d,v);return}
 var d=o.d,isOut=v.dir==='out',title=v.t==='receipt'?(v.dir==='out'?'سند صرف':'سند قبض'):(v.t==='exchange'?'سند صرافة':v.t==='clockacc'?'سند من المراقب — '+(isOut?'عليكم':'لكم'):'سند '+vName(v)),acc=v.acc?((d.accounts.find(function(a){return a.id===v.acc})||{}).name||''):'';
 var tm=new Date(v.d+'T12:00:00'),date=E(v.d||'')+' '+String(tm.getHours()).padStart(2,'0')+':'+String(tm.getMinutes()).padStart(2,'0'),rows=v.rows||[],total=tot(v),currency=rows.length===1?sym(rows[0].c):unit(),direction=isOut?'المبلغ عليكم':'المبلغ لكم';
 var bodyRows=rows.map(function(r){return '<tr><td>'+E(sym(r.c))+'</td><td>'+F(r.a)+'</td><td>'+F(r.r==null?1:r.r)+'</td><td>'+F(r.v==null?r.a:r.v)+'</td></tr>'}).join('');
 var words=rows.map(function(r){return E(curWords(r.a,r.c))}).join(' — ');
 var profile='';try{profile=printProfileHeader()}catch(e){}
  var mm=/^v(\d{13})/.exec(v.id||''),t2=mm?new Date(+mm[1]):new Date(),hm=String(t2.getHours()).padStart(2,'0')+':'+String(t2.getMinutes()).padStart(2,'0'),wd='';try{wd=new Date(v.d+'T12:00:00').toLocaleDateString('ar-u-nu-latn',{weekday:'long'})}catch(e){}
  PV2.voucher({title:title,out:isOut,dateStr:wd+' '+dFmt(v.d)+' / '+hm,from:(v.pg||acc||'الصفحة'),words:words,label:direction,rows:rows.map(function(r){return {a:r.a,c:sym(r.c),v:(r.v==null?r.a:r.v)}}),total:total,unit:currency,note:v.n});
}
function printProfileHeader(){var s=data.settings||{};if(s.showHeaderData===false)return '';try{return buildPrintHeader('').replace('<div class="doc-title"></div>','')}catch(e){}var ar=[s.profileNameAr,s.profileAddressAr,s.profileContacts].filter(Boolean).map(function(x){return E(x)}).join('<br>'),en=[s.profileNameEn,s.profileAddressEn,s.profileContactsEn].filter(Boolean).map(function(x){return E(x)}).join('<br>'),logo=s.logoData?'<img src=\"'+s.logoData+'\" style=\"width:82px;height:62px;object-fit:contain\">':'<span></span>';return '<div class=\"print-profile-header\"><div class=\"profile-ar\">'+ar+'</div><div>'+logo+'</div><div class=\"profile-en\">'+en+'</div></div>'}
 function printPaperCss(){
 var s=data.settings||{},paper=(window.__paperCss?window.__paperCss('statement'):'A4 portrait'),margin=/mm auto/.test(paper)?'4mm':'10mm',lx=!!(s.lux&&s.lux.on),color=lx?'#aebeff':(s.printColor||'#aebeff'),font=s.printFont==='cairo'?'Cairo':s.printFont==='arial'?'Arial':s.printFont==='tahoma'?'Tahoma':'Tajawal',scale=(Number(s.printFontScale)||100)/100,mode=lx?'color':(s.printColorMode||'color');if(mode==='bw')color='#e8e8e8';
 return '@page{size:'+paper+';margin:'+margin+'}'+hdrCss()+'*{box-sizing:border-box}html,body{max-width:100%;background:#fff}body{font-family:'+font+',Arial,Tahoma,sans-serif;color:'+(lx?'#171717':(s.printTextColor||'#171717'))+';font-size:'+(14*scale)+'px;line-height:1.5;margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}.sheet,.receipt-sheet{max-width:none;width:100%;margin:0;box-sizing:border-box}.print-profile-header{display:grid;grid-template-columns:minmax(0,1fr) 82px minmax(0,1fr);gap:9px;align-items:center;border-bottom:2px solid #222;padding:0 0 8px;margin:0 0 8px;width:100%;max-width:none;min-width:0;box-sizing:border-box;text-align:center;break-inside:avoid;page-break-inside:avoid}.print-profile-header img{display:block;margin:auto;width:72px;height:58px;object-fit:contain}.profile-ar{text-align:right;direction:rtl;font-weight:800;line-height:1.4}.profile-en{text-align:left;direction:ltr;font-weight:800;line-height:1.4}.paper-title{width:max-content;max-width:100%;min-width:170px;margin:8px auto;padding:6px 24px;text-align:center;border:1.5px solid #333;font-size:19px;font-weight:900;background:#fff}.paper-meta{text-align:center;font-size:12px;font-weight:800;margin:5px 0 10px}.paper-period{text-align:center;color:#444;font-size:12px;margin:4px 0 10px}.paper-name{font-size:18px;font-weight:900;margin:8px 0;padding:7px;text-align:center;border-bottom:2px dotted #222}.paper-greeting{display:flex;justify-content:space-between;gap:10px;font-weight:800;margin:9px 4px}.paper-intro{text-align:center;line-height:1.8;margin:9px 0}.paper-words{border:1px solid #777;border-radius:4px;background:#fafafa;padding:9px;margin:8px 0;text-align:center;font-weight:800}.statement,.paper-table,.voucher-table{width:100%;border-collapse:collapse;margin:9px 0;table-layout:fixed}.statement th,.statement td,.paper-table th,.paper-table td,.voucher-table th,.voucher-table td{border:1px solid #536174;padding:7px 5px;text-align:center;vertical-align:middle;overflow-wrap:anywhere}.statement th,.paper-table th,.voucher-table th{background:'+(mode==='color'?color:'#e7e7e7')+';color:#111;font-weight:900}.statement td,.paper-table td,.voucher-table td{font-weight:700}.statement .summary,.paper-table .summary{background:#e6ecff;font-weight:900}.paper-balance,.voucher-total{border:1px solid #536174;border-radius:4px;padding:9px;text-align:center;font-size:16px;font-weight:900;margin-top:10px}.paper-balance .neg,.voucher-total.red{color:#b42335}.paper-balance .pos,.voucher-total.green{color:#16824a}.paper-signatures,.voucher-signs{display:grid;grid-template-columns:1fr 1fr;gap:24px;border-top:1px solid #777;margin-top:28px;padding-top:11px;font-weight:800;text-align:center}.paper-signatures>div,.voucher-signs>span{line-height:2}.paper-footer{text-align:center;color:#666;font-size:10px;border-top:1px solid #aaa;margin-top:12px;padding-top:6px}.receipt-sheet,.voucher-paper{border:1px solid #7b203d;padding:14px;border-radius:2px}.voucher-headline{width:max-content;max-width:100%;min-width:180px;margin:7px auto;padding:7px 22px;text-align:center;border:1.5px solid #3f5a49;border-radius:4px;background:#e5f7eb;color:#185d39;font-size:19px;font-weight:900}.voucher-headline.blue{background:#e5efff;border-color:#263b5d;color:#182f59}.voucher-date{text-align:center;font-weight:800;margin:6px 0 12px}.voucher-from{display:flex;justify-content:space-between;gap:10px;margin:7px 0;font-weight:800}.voucher-detail-title{margin:10px 0 0;padding:7px;text-align:center;background:#6b1736;color:#fff;font-weight:900}.voucher-words{border:1px solid #777;border-radius:4px;background:#fafafa;padding:9px;margin:8px 0;text-align:center;font-weight:800}.voucher-table th,.voucher-table td{padding:8px 5px}.voucher-total{color:#16824a}.paper-signatures{margin-top:35px}.no-break{break-inside:avoid;page-break-inside:avoid}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}@media print{html,body{width:100%!important;max-width:100%!important;margin:0!important;padding:0!important;overflow:visible!important}.sheet,.receipt-sheet{width:100%!important;max-width:none!important;margin:0!important;box-sizing:border-box!important}.print-profile-header{width:100%!important;max-width:none!important;margin-left:0!important;margin-right:0!important;grid-template-columns:minmax(0,1fr) 82px minmax(0,1fr)!important;box-sizing:border-box!important}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}.sheet,.receipt-sheet,.voucher-paper,.paper-title,.paper-name{break-inside:avoid;page-break-inside:avoid}.statement,.paper-table,.voucher-table{page-break-inside:auto}.statement tr,.paper-table tr,.voucher-table tr{break-inside:avoid;page-break-inside:avoid}}@media print and (max-width:79mm){body{font-size:10px}.print-profile-header{grid-template-columns:minmax(0,1fr) 45px minmax(0,1fr);gap:4px}.print-profile-header img{width:42px;height:38px}.profile-ar,.profile-en{font-size:8px}.paper-title,.voucher-headline{min-width:120px;font-size:13px;padding:4px 8px}.paper-name{font-size:14px}.statement th,.statement td,.paper-table th,.paper-table td,.voucher-table th,.voucher-table td{font-size:9px;padding:4px 2px}.paper-signatures,.voucher-signs{gap:8px;font-size:9px;margin-top:18px}.receipt-sheet,.voucher-paper{padding:6px}}'
}
function imgV(id){var o=vFind(id),v=o.v;if(!v)return;var L=vInfo(o.d,v).map(function(x){return x[0]+': '+x[1]}).concat(vLines(v));
  var c=document.createElement('canvas'),H=200+L.length*52;c.width=1000;c.height=H;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,1000,H);x.fillStyle='#111';x.direction='rtl';x.textAlign='right';x.font='bold 36px Arial';x.fillText(vName(v),940,70);x.font='26px Arial';var y=130;L.forEach(function(t){x.fillText(t,940,y);y+=52});
  var src=c.toDataURL('image/png'),name='سند-'+v.d+'-'+v.id+'.png';
  try{if(window.SANative&&SANative.saveImageToGallery){SANative.saveImageToGallery(src,name);return}if(window.AndroidBackup&&AndroidBackup.saveImageToGallery){AndroidBackup.saveImageToGallery(src,name);return}var a=document.createElement('a');a.href=src;a.download=name;document.body.appendChild(a);a.click();a.remove()}catch(e){alert('تعذر حفظ الصورة')}}
 function editV(id){var o=vFind(id),v=o.v;if(!v)return;if(v.fx){alert('هذا سند فارق صرف تلقائي؛ يتغير بتعديل أو حذف الترحيل/الحوالة الأصلية.');return}
  var h='<label>التاريخ<input type="date" id="eD" value="'+E(v.d)+'"></label>'+photoHTML()+(v.t==='exchange'?'':v.t==='clockacc'?'<label>المبلغ الإجمالي<input type="number" inputmode="decimal" id="eAmt" value="'+E(tot(v))+'"></label>':rowsHTML(v.t==='receipt'&&v.dir!=='out'?'سعر الشراء':'سعر البيع',v.t==='transfer'?undefined:(v.t==='receipt'&&v.dir!=='out'?'buy':'sell'))+(v.t==='internal'?'<label>مبلغ العمولة<input type="number" inputmode="decimal" id="eCom" value="'+E(v.com||0)+'"></label>':'')+totHTML('ناتج الصرف + العمولة'))+'<label>البيان<input id="eN" value="'+E(v.n||'')+'"></label>';
  var m=modal('✏️ تعديل '+E(vName(v)),h,function(m){
   var d=db(),x=d.vouchers.find(function(z){return z.id===id});if(!x)return;
   var dt=m.querySelector('#eD').value;if(!dt){alert('أدخل التاريخ');return false}
   if(x.t!=='exchange'){var rows=x.t==='clockacc'?clockAmtRows(m,'#eAmt'):readRows(m);if(!rows.length){alert('أدخل مبلغ عملة واحدة على الأقل');return false}
    if(x.t==='receipt'&&x.dir==='out'){
     if(!checkFundCoverage(d,x.f,rows,id))return false;
    }
    x.rows=rows;if(x.t==='internal'){var cm=Number(m.querySelector('#eCom')&&m.querySelector('#eCom').value)||0;x.com=cm>0?cm:0}}
   if(m._img)x.img=m._img;x.d=dt;var n=m.querySelector('#eN').value.trim();if(n)x.n=n;else delete x.n;
   clockUnlink(id);clockLink(x,d);save(d);render()},'💾 حفظ التعديل','v');
  if(v.t!=='exchange'){m.querySelectorAll('tr[data-c]').forEach(function(tr){var r=(v.rows||[]).find(function(z){return z.c===tr.dataset.c});if(r){tr.querySelector('[data-a]').value=r.a;tr.querySelector('[data-r]').value=r.r==null?'':r.r}});var t=m.querySelector('[data-tot]');if(t)t.textContent=F(tot(v))}
  wire(m);var pb=m.querySelector('.vPhI');if(pb&&v.img)pb.innerHTML='<img src="'+v.img+'">';var et=m.querySelector('[data-tot]');if(et){var upd=function(){var cm=Number((m.querySelector('#eCom')||{}).value)||0;et.textContent=F(readRows(m).reduce(function(a,r){return a+r.v},0)+(v.t==='internal'?cm:0))};m.addEventListener('input',upd);upd()}}
 function photoV(id){var o=vFind(id),v=o.v;if(!v)return;
  var body=(v.img?'<img src="'+v.img+'" style="width:100%;border-radius:10px">':'')
   +'<div class="tsB" style="margin-top:10px;flex-wrap:wrap;gap:6px;justify-content:center">'
   +(v.img?'<button type="button" data-pa="save">💾 حفظ إلى الاستوديو</button><button type="button" data-pa="del" class="r">🗑 إزالة الصورة</button>':'')
   +'<label style="cursor:pointer;padding:8px 12px;border-radius:10px;background:#0a2a6b;color:#fff;font-weight:700">🔁 '+(v.img?'استبدال الصورة':'إضافة صورة')+'<input type="file" accept="image/*" data-pa="file" style="display:none"></label></div>';
  var m=modal('📎 صورة السند — '+E(vName(v)),body,null);
  m.addEventListener('click',function(e){var b=e.target.closest('[data-pa]');if(!b)return;
   if(b.dataset.pa==='save'){var an=document.createElement('a');an.href=v.img;an.download='سند-'+(v.d||'')+'.jpg';document.body.appendChild(an);an.click();an.remove();}
   else if(b.dataset.pa==='del'){if(!confirm('إزالة الصورة من هذا السند؟'))return;var dd=db(),x=dd.vouchers.find(function(z){return z.id===id});if(x){delete x.img;save(dd)}m.remove();render();}
  });
  var fi=m.querySelector('input[data-pa=file]');
  if(fi)fi.addEventListener('change',function(){var f=fi.files[0];if(!f)return;var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var k=700/Math.max(im.width,im.height,700),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);var img=c.toDataURL('image/jpeg',.6);var dd=db(),x=dd.vouchers.find(function(z){return z.id===id});if(x){x.img=img;save(dd)}m.remove();render();};im.src=r.result};r.readAsDataURL(f)});
 }
 function delVs(ids){ids=ids.filter(function(i){return !isFx(i)});if(!ids.length){alert('سند فارق الصرف تلقائي؛ احذف الترحيل/الحوالة الأصلية فيُحذف معها.');return}if(!confirm(ids.length>1?'حذف السندات المحددة؟':'حذف هذا السند؟'))return;var d=db();d.vouchers=d.vouchers.filter(function(v){return ids.indexOf(v.id)<0});ids.forEach(clockUnlink);selMode=false;selIds=[];save(d);render()}
 function selAll(){selMode=true;selIds=[].map.call(document.querySelectorAll('#tsPage .tsVC[data-vid]'),function(c){return c.dataset.vid});render()}
 function selBar(){return '<div class="tsSelBar"><span>'+selIds.length+' محدد</span><button data-a="selall">☑ تحديد الكل</button><button data-a="seldel">🗑 حذف المحدد</button><button data-a="selx">إلغاء</button></div>'}
 function accountPeriodRows(id){var d=db(),V=d.vouchers.filter(function(v){return v.acc===id&&v.d>=dFrom&&v.d<=dTo}).sort(function(a,b){return (a.d||'').localeCompare(b.d||'')}),run=0,ng=0,ps=0;var rows=V.map(function(v){var z=tot(v);if(v.dir==='in')ps+=z;else ng+=z;run+=(v.dir==='in'?1:-1)*z;return '<tr><td>'+E(v.d)+'</td><td>'+E(v.n||v.t||'—')+'</td><td>'+(v.dir==='out'?F(z):'')+'</td><td>'+(v.dir==='in'?F(z):'')+'</td><td>'+E(run<0?'عليكم':'لكم')+' '+F(Math.abs(run))+'</td></tr>'}).join('');return {d:d,rows:rows,ng:ng,ps:ps,run:run};}
 function printTasfeerAccount(id,auth){
 var d=db(),a=d.accounts.find(function(x){return x.id===id});if(!a)return;
 var q=accountPeriodRows(id),title=auth?'مصادقة حساب':'كشف حساب',rows=q.rows||'<tr><td colspan="5">لا توجد حركات خلال الفترة المحددة</td></tr>',today=new Date().toLocaleDateString('ar-u-nu-latn');
  PV2.statement({title:title,name:a.name,auth:auth,rows:rows,ng:q.ng,ps:q.ps,run:q.run,unit:unit()});
}
 function moveOrCopyTasfeerAccount(id,target,mode){var d=db(),a=d.accounts.find(function(x){return x.id===id});if(!a||!target)return;if(mode==='move'){a.g=target}else{var cp=JSON.parse(JSON.stringify(a));cp.id='a'+Date.now()+Math.random().toString(36).slice(2,6);cp.g=target;cp.name=a.name+' (نسخة)';var old=d.vouchers.filter(function(v){return v.acc===id});old.forEach(function(v){var cv=JSON.parse(JSON.stringify(v));cv.id='v'+Date.now()+Math.random().toString(36).slice(2,6);cv.acc=cp.id;d.vouchers.push(cv)});d.accounts.push(cp)}save(d);render();}
 function tasfeerAccountMenu(id){var d=db(),a=d.accounts.find(function(x){return x.id===id});if(!a)return;var m=modal('خيارات الحساب — '+E(a.name),'<div class="tsMenu"><button data-m="edit">✏️ تعديل الحساب</button><button data-m="del" class="d">🗑 حذف الحساب</button><button data-m="print">🖨️ طباعة كشف للفترة المحددة</button><button data-m="auth">📝 طباعة مصادقة حساب للفترة المحددة</button><button data-m="copy">📋 نسخ الحساب إلى صندوق آخر</button><button data-m="move">↔ نقل الحساب إلى صندوق آخر</button></div>',null);m.addEventListener('click',function(e){var b=e.target.closest('[data-m]');if(!b)return;var k=b.dataset.m;m.remove();if(k==='edit')accModal(a.g,id);else if(k==='del')A.da(id);else if(k==='print')printTasfeerAccount(id,false);else if(k==='auth')printTasfeerAccount(id,true);else if(k==='copy'||k==='move'){var title=k==='copy'?'نسخ الحساب إلى صندوق آخر':'نقل الحساب إلى صندوق آخر';var choices=d.folders.filter(function(g){return k==='copy'||g.id!==a.g});var x=modal(title,'<div class="tsMenu">'+choices.map(function(g){return '<button data-target="'+E(g.id)+'">📁 '+E(g.name)+'</button>'}).join('')+'</div>',null);x.addEventListener('click',function(ev){var q=ev.target.closest('[data-target]');if(!q)return;moveOrCopyTasfeerAccount(id,q.dataset.target,k);x.remove()})}})}
 function vMenu(id){var m=modal('خيارات السند','<div class="tsMenu"><button data-m="sel">☑ تحديد</button><button data-m="all">☑ تحديد الكل</button><button data-m="print">🖨️ طباعة السند</button><button data-m="view">👁 رؤية السند</button><button data-m="photo">📎 فتح الصورة المرفقة</button><button data-m="img">📷 حفظ صورة السند</button><button data-m="edit">✏️ تعديل السند</button><button data-m="del" class="d">🗑 حذف السند</button></div>',null);
  m.addEventListener('click',function(e){var b=e.target.closest('[data-m]');if(!b)return;var a=b.dataset.m;m.remove();
   if(a==='sel'){selMode=true;selIds=[id];render()}else if(a==='all')selAll();else if(a==='print')printV(id);else if(a==='view')viewV(id);else if(a==='photo')photoV(id);else if(a==='img')imgV(id);else if(a==='edit')editV(id);else if(a==='del')delVs([id])})}
 var CK='smartadmin_clock_entries_v1';
 function ckRead(){try{var l=JSON.parse(localStorage.getItem(CK)||'[]');return Array.isArray(l)?l:[]}catch(e){return []}}
 function ckDone(){try{if(window.__clockSyncAll)window.__clockSyncAll();if(window.__clockRerender)window.__clockRerender()}catch(e){}}
 function clockLink(v,d){try{
  var map={'جملة البيع النهائية':'sale','خرج العمال':'workers','السحب':'withdraw','العملات':'currency'},type=null,kind='';
  if(v.t==='clockacc'){type=map[v.pg];kind='acc'}
  else if(v.t==='receipt'){type='currency';kind='fund'}
  if(!type)return;
  var nm=v.acc?((d.accounts.find(function(a){return a.id===v.acc})||{}).name||''):fname(d,v.f);
  var rows=(v.rows||[]).map(function(r){return {name:r.c,symbol:sym(r.c),amount:r.a,rate:r.r,value:r.v}});
  var L=ckRead();
  L.push({id:'ck'+Date.now()+Math.random().toString(36).slice(2,6),type:type,date:v.d,dir:(v.dir==='out'?'لكم':'عليكم'),amount:tot(v),note:v.n||'',name:nm,rows:rows,specialtyId:v.sp||'',ts:v.id,tsKind:kind});
  localStorage.setItem(CK,JSON.stringify(L));ckDone();
 }catch(e){}}
 function clockUnlink(id){try{var L=ckRead(),M=L.filter(function(x){return x.ts!==id});if(M.length!==L.length){localStorage.setItem(CK,JSON.stringify(M));ckDone()}}catch(e){}}
 function migrateLinkedAccountingDirections(){
  var marker='smartadmin_linked_direction_mig_v2';
  try{
    if(localStorage.getItem(marker))return;
    var d=db(),L=ckRead(),changed=false;
    (d.vouchers||[]).forEach(function(v){
      if(!v||(v.t!=='receipt'&&v.t!=='clockacc'))return;
      var wanted=v.dir==='out'?'لكم':'عليكم';
      L.forEach(function(x){
        if(!x||x.ts!==v.id)return;
        var linked=v.t==='receipt'?(x.type==='currency'&&x.tsKind==='fund'):(x.tsKind==='acc');
        if(linked&&x.dir!==wanted){x.dir=wanted;changed=true;}
      });
    });
    if(changed)localStorage.setItem(CK,JSON.stringify(L));
    localStorage.setItem(marker,'1');
    if(changed)ckDone();
  }catch(e){}
}
setTimeout(migrateLinkedAccountingDirections,0);
function migrateInternalPostingDirections(){
  var marker='smartadmin_internal_posting_mig_v1';
  try{
    if(localStorage.getItem(marker))return;
    var d=db(),changed=false;
    (d.vouchers||[]).forEach(function(v){if(v&&v.t==='internal'&&v.dir!=='out'){v.dir='out';changed=true;}});
    if(changed){save(d);render();}
    localStorage.setItem(marker,'1');
  }catch(e){}
}
setTimeout(migrateInternalPostingDirections,0);
function exch(fid){var d=db(),b=fb(d,fid),C=curs();
  function opts(sel){return C.map(function(c,i){return '<option value="'+E(c.n)+'"'+(i===sel?' selected':'')+'>'+E(c.n)+' — '+E(c.s)+' (الرصيد: '+F(b[c.n]||0)+')</option>'}).join('')}
  var o=modal('💱 صرافة العملات من أرصدة الصندوق',
   '<div class="xCard"><div class="xH">💱 صرافة من أرصدة العملات داخل الصندوق: '+E(fname(d,fid))+'</div>'
   +'<label>العملة المصروفة (من الرصيد المتاح)<select id="xF">'+opts(0)+'</select></label><div class="xAv" id="xAv"></div>'
   +'<label>المبلغ المصروف<input type="number" inputmode="decimal" id="xA" placeholder="أدخل المبلغ"></label>'
   +'<label>سعر الصرف (المبلغ المستلم لكل وحدة مصروفة)<input type="number" inputmode="decimal" id="xR" placeholder="أدخل سعر الصرف"></label>'
   +'<label>العملة المستلمة<select id="xT">'+opts(C.length>1?1:0)+'</select></label>'
   +'<label>المبلغ المستلم (يحسب تلقائيًا)<input id="xO" readonly placeholder="المبلغ الناتج"></label>'
   +''
   +dateHTML()+photoHTML()+'<label>ملاحظات<textarea id="xN" rows="3"></textarea></label></div>',
   function(o){var a=+o.querySelector('#xA').value,r=+o.querySelector('#xR').value,fr=o.querySelector('#xF').value,to=o.querySelector('#xT').value;
    if(!(a>0&&r>0)){alert('أدخل المبلغ وسعر الصرف');return false}if(fr===to){alert('اختر عملتين مختلفتين');return false}
    var d=db();if((fb(d,fid)[fr]||0)<a){alert('لا يمكن صرف مبلغ أكبر من الرصيد المتاح');return false}
    var v={id:'v'+Date.now(),t:'exchange',d:o.querySelector('#vDate').value||td(),f:fid,from:fr,fa:a,to:to,ta:a*r,r:r},n=o.querySelector('#xN').value.trim();if(n)v.n=n;if(o._img)v.img=o._img;
    d.vouchers.push(v);save(d);render()},'💾 حفظ الصرافة','v mr');
  function upd(){var c=o.querySelector('#xF').value;o.querySelector('#xAv').textContent='الرصيد المتاح: '+sym(c)+' '+F(b[c]||0);o.querySelector('#xO').value=(+o.querySelector('#xA').value&&+o.querySelector('#xR').value)?F((+o.querySelector('#xA').value)*(+o.querySelector('#xR').value)):''}
  o.addEventListener('input',upd);o.addEventListener('change',upd);upd();wire(o)}
 function ask(title,val,fn){modal(title,'<label>الاسم<input id="kN" value="'+E(val||'')+'"></label>',function(o){var v=o.querySelector('#kN').value.trim();if(!v){alert('أدخل الاسم');return false}fn(v)})}
 function fEff(v,id){
if(v.t==='receipt'&&v.f===id)return (v.dir==='out'?-1:1)*tot(v);
if(v.t==='fxacc'&&v.inFund&&v.f===id)return (v.dir==='in'?1:-1)*tot(v);
if(v.t==='transfer'){var x=0;if(v.f===id)x-=(v.cd?costTot(v):tot(v));if(v.f2===id)x+=tot(v);return x}
if(v.t==='internal'&&v.f===id)return -Math.abs(tot(v));
return 0}
function fCat(v){return v.t==='exchange'?'exch':v.t==='transfer'?'trans':v.t==='internal'?'hawala':'cash'}
function fCurs(v){if(v.t==='exchange')return [v.from,v.to];return (v.rows||[]).map(function(r){return r.c})}
function fMatch(v,o){if(!o)return true;if(o.cats&&o.cats.indexOf(fCat(v))<0)return false;if(o.curs){var c=fCurs(v);if(!c.some(function(x){return o.curs.indexOf(x)>=0}))return false}return true}
function fundCurTable(d,id,o){
var src=d;if(o&&o.to)src={vouchers:d.vouchers.filter(function(v){return !v.d||v.d<=o.to})};
var b=fb(src,id),C=curs().map(function(c){return c.n});Object.keys(b).forEach(function(k){if(C.indexOf(k)<0)C.push(k)});
if(o&&o.curs)C=C.filter(function(n){return o.curs.indexOf(n)>=0});
var body=C.map(function(n){var v=Math.round((b[n]||0)*1000)/1000,side=v>0?'لكم':v<0?'عليكم':'—',cl=v<0?'red':v>0?'grn':'';
return '<tr><td>'+E(n)+' ('+E(sym(n))+')</td><td class="'+cl+'">'+F(Math.abs(v))+'</td><td class="'+cl+'">'+side+'</td></tr>'}).join('');
return '<div class="pv-acc" style="font-size:16px;margin-top:16px">أرصدة العملات</div><table class="pv-t"><thead><tr><th>العملة</th><th>الرصيد</th><th>الجهة</th></tr></thead><tbody>'+body+'</tbody></table>'}
function fundSel(d,fid,o){return d.vouchers.filter(function(v){return (v.f===fid||v.f2===fid)&&(!o||((!o.from||!v.d||v.d>=o.from)&&(!o.to||!v.d||v.d<=o.to)))&&fMatch(v,o)}).sort(function(a,b){return (a.d||'').localeCompare(b.d||'')})}
function fundCurrencyStatement(d,fd,fid,o,V){
var dm=function(x){var q=String(x||'').split('-');return q.length===3?q[2]+'/'+q[1]+'/'+q[0]:'—'};
function lines(v){var out=[],R=v.rows||[];
if(v.t==='receipt'&&v.f===fid)R.forEach(function(r){out.push({c:r.c,lk:v.dir!=='out',a:+r.a||0,r:r.r==null?1:+r.r,v:+r.v||0,type:v.dir==='out'?'سند إرسال عليكم':'سند قبض لكم'})});
else if(v.t==='exchange'&&v.f===fid){out.push({c:v.from,lk:false,a:+v.fa||0,r:+v.r||0,v:+v.ta||0,type:'صرافة عملات (صرف)'});out.push({c:v.to,lk:true,a:+v.ta||0,r:1,v:+v.ta||0,type:'صرافة عملات (استلام)'})}
else if(v.t==='transfer'){if(v.f===fid)shownRows(v,fid).forEach(function(r){out.push({c:r.c,lk:false,a:+r.a||0,r:r.r==null?1:+r.r,v:+r.v||0,type:'ترحيل بين الصناديق (صادر)'})});if(v.f2===fid)R.forEach(function(r){out.push({c:r.c,lk:true,a:+r.a||0,r:r.r==null?1:+r.r,v:+r.v||0,type:'ترحيل بين الصناديق (وارد)'})})}
else if(v.t==='internal'&&v.f===fid)R.forEach(function(r){out.push({c:r.c,lk:false,a:+r.a||0,r:r.r==null?1:+r.r,v:+r.v||0,type:'حوالة داخلية — إرسال'})});
return out}
function stmtTxt(v){var t=v.t==='exchange'?'صرافة عملات: '+F(v.fa)+' '+E(sym(v.from))+' ← '+F(v.ta)+' '+E(sym(v.to)):vTitle(d,v,fid);return t+(v.n?'<br>'+E(v.n):'')}
var C=curs().map(function(c){return c.n});d.vouchers.forEach(function(v){fCurs(v).forEach(function(x){if(x&&C.indexOf(x)<0)C.push(x)})});
if(o&&o.curs)C=C.filter(function(n){return o.curs.indexOf(n)>=0});
var prev=(o&&o.from)?d.vouchers.filter(function(v){return (v.f===fid||v.f2===fid)&&v.d&&v.d<o.from&&fMatch(v,o)}):[];
var opening=fb({vouchers:prev},fid);
var sections=C.map(function(name){
var run=Math.round((opening[name]||0)*1000)/1000,bal0=run,amtL=0,amtO=0,totL=0,totO=0,rows=[];
if(Math.abs(run)>1e-9)rows.push({open:true,date:dm(o.from),type:'رصيد سابق',bal:run,stmt:'رصيد مرحل قبل بداية الفترة'});
V.forEach(function(v){lines(v).forEach(function(x){if(x.c!==name)return;
run+=x.lk?x.a:-x.a;if(x.lk){amtL+=x.a;totL+=x.v}else{amtO+=x.a;totO+=x.v}
rows.push({date:dm(v.d),type:x.type,dir:x.lk?'لكم':'عليكم',amount:x.a,rate:x.r,value:x.v,bal:Math.round(run*1000)/1000,stmt:stmtTxt(v)})})});
return {heading:'العملة',name:name,sym:sym(name)!==name?sym(name):'',rows:rows,balance:Math.round(run*1000)/1000,bal0:bal0,totalL:totL,totalO:totO,amtL:amtL,amtO:amtO}});
var n=new Date(),pad2=function(x){return String(x).padStart(2,'0')};
var period=(o&&(o.from||o.to))?'خلال الفترة من '+(o.from?dm(o.from):'—')+' إلى '+(o.to?dm(o.to):'—'):'كل الحركات حتى تاريخه';
var catN={cash:'سندات القبض النقدي',hawala:'سندات إرسال الحوالات',exch:'سندات الصرافة',trans:'سندات الترحيل بين الصناديق'};
var cats=(o&&o.cats&&o.cats.length&&o.cats.length<4)?o.cats.map(function(k){return catN[k]}).join('، '):'كل السندات';
window.PV2.currencyStatement({title:'كشف صندوق: '+fd.name,period:period,filterLine:'العملة: '+(C.map(function(c){return c}).join(' | ')||'—')+' | نوع السند: '+cats,header:true,summary:true,summaryTitle:'تجميع أرصدة العملات في الصندوق',sections:sections})}
function statement(fid,auth,o){
if(typeof fid!=='string'||!fid){fid=sub&&sub.k==='fund'?sub.id:''}
var d=db(),fd=d.funds.find(function(x){return x.id===fid});if(!fd)return;
if(!window.PV2||!window.PV2.statement){alert('تعذر تجهيز الطباعة');return}
var V=fundSel(d,fid,o),run=0,ng=0,ps=0,pre='';
if(!auth&&window.PV2.currencyStatement){fundCurrencyStatement(d,fd,fid,o,V);return}
if(o&&o.from){var op=d.vouchers.filter(function(v){return (v.f===fid||v.f2===fid)&&v.d&&v.d<o.from&&fMatch(v,o)}).reduce(function(x,v){return x+fEff(v,fid)},0);
if(Math.abs(op)>1e-9){run=op;pre='<tr><td>'+E(o.from)+'</td><td>رصيد سابق</td><td></td><td></td><td>'+(op<0?'عليكم ':'لكم ')+F(Math.abs(op))+'</td></tr>'}}
var rows=pre+V.map(function(v){var e=fEff(v,fid),det;
if(v.t==='exchange')det='صرافة عملات: '+F(v.fa)+' '+E(sym(v.from))+' ← '+F(v.ta)+' '+E(sym(v.to));
else det=vTitle(d,v,fid);
if(v.n)det+=' — '+E(v.n);
if(e>0)ps+=e;else if(e<0)ng-=e;run+=e;
return '<tr><td>'+E(v.d)+'</td><td>'+det+'</td><td class="red">'+(e<0?F(-e):'')+'</td><td class="grn">'+(e>0?F(e):'')+'</td><td>'+(Math.abs(run)<1e-9?'0':(run<0?'عليكم ':'لكم ')+F(Math.abs(run)))+'</td></tr>'}).join('');
var cur=fundCurTable(d,fid,o),sub2=o&&(o.from||o.to)?'<div class="pv-meta">الفترة من '+E(o.from||'—')+' إلى '+E(o.to||'—')+'</div>':'';
window.PV2.statement({title:auth?'مصادقة صندوق':'كشف صندوق',name:fd.name,auth:auth,rows:rows,ng:ng,ps:ps,run:run,unit:unit(),sub:sub2,extra:auth?'':cur,mid:auth?cur:''})}
function fundPrintDialog(id,auth){
var d=db(),fd=d.funds.find(function(x){return x.id===id});if(!fd)return;
var CATS=[['cash','سندات القبض النقدي (كاش)'],['hawala','سندات إرسال الحوالات'],['exch','سندات العملات المصروفة (صرافة)'],['trans','سندات العملات المرحلة (ترحيل بين الصناديق)']];
var C=curs().map(function(c){return {n:c.n,s:c.s}});d.vouchers.forEach(function(v){fCurs(v).forEach(function(x){if(x&&!C.some(function(c){return c.n===x}))C.push({n:x,s:sym(x)})})});
var row=function(cls,val,lbl){return '<label class="fpR"><input type="checkbox" class="'+cls+'" value="'+E(val)+'" checked><span>'+lbl+'</span></label>'};
var body='<div class="fpD"><div class="fpT">'+(auth?'طباعة مصادقة صندوق':'طباعة كشف زمني')+' — '+E(fd.name)+'</div>'
+'<div class="fpDt"><div><small>من تاريخ</small><input type="date" id="fpFrom" value="'+E(dFrom||'')+'"></div><div><small>إلى تاريخ</small><input type="date" id="fpTo" value="'+E(dTo||'')+'"></div></div>'
+'<div class="fpH">حدد السندات</div>'+CATS.map(function(c){return row('fpC',c[0],E(c[1]))}).join('')
+'<div class="fpH">حدد العملات</div><div class="fpL">'+C.map(function(c){return row('fpU',c.n,E(c.n)+' ('+E(c.s)+')')}).join('')+'</div>'
+'<div class="fpM" id="fpMsg"></div></div>';
var m=modal(auth?'طباعة مصادقة الصندوق':'طباعة كشف الصندوق',body,function(o){var r=read(o);if(!fundSel(db(),id,r).length&&!auth){upd(o);return false}statement(id,auth,r)},'حفظ / طباعة','fpBox');
var x=m.querySelector('.tsAct [data-x]');if(x)x.textContent='خروج';
function read(o){var g=function(c){return [].map.call(o.querySelectorAll('.'+c+':checked'),function(i){return i.value})};return {from:o.querySelector('#fpFrom').value,to:o.querySelector('#fpTo').value,cats:g('fpC'),curs:g('fpU')}}
function upd(o){var n=fundSel(db(),id,read(o)).length,el=o.querySelector('#fpMsg');el.textContent=n?('عدد السندات المطابقة: '+n):'لا توجد سندات مطابقة للاختيارات';el.className='fpM'+(n?'':' bad')}
m.addEventListener('change',function(){upd(m)});upd(m)}
/* صفحة الصندوق: الاسم والترتيب، ومسح الصندوق فقط إذا لم يحتوِ على عملات (سندات مرتبطة به) */
function fundPage(id){
 var d=db(),f=id?d.funds.find(function(x){return x.id===id}):null;
 var nextOrder=d.funds.reduce(function(m,x){return Math.max(m,+x.order||0)},0)+1;
 var hasCur=f?d.vouchers.some(function(v){return v.f===id||v.f2===id}):false;
 var o=modal(f?'تعديل الصندوق':'إضافة صندوق',
  '<label>الاسم<input id="fpN" placeholder="ادخل اسم الصندوق" value="'+E(f?f.name:'')+'"></label>'
  +'<label>الترتيب<input id="fpO" type="number" inputmode="numeric" step="1" value="'+E(f?(f.order!=null?f.order:''):nextOrder)+'"></label>'
  +(f?(hasCur?'<div class="fpM bad" style="margin-top:8px">لا يمكن مسح الصندوق لأنه يحتوي على عملات</div>':'<button type="button" id="fpDel" style="background:#fee2e2;color:#b91c1c;border-radius:10px;padding:10px;font-weight:900;margin-top:8px">🗑 مسح الصندوق</button>'):''),
  function(m){
   var name=m.querySelector('#fpN').value.trim();
   if(!name){toast('أدخل اسم الصندوق');return false}
   var ord=m.querySelector('#fpO').value;ord=ord===''?nextOrder:+ord;
   var dd=db();
   if(f){var x=dd.funds.find(function(z){return z.id===id});if(x){x.name=name;x.order=ord}}
   else dd.funds.push({id:'f'+Date.now(),name:name,order:ord});
   save(dd);render();
  },'💾 حفظ');
 var del=o.querySelector('#fpDel');
 if(del)del.addEventListener('click',function(){
   if(!confirm('مسح هذا الصندوق؟'))return;
   var dd=db();
   if(dd.vouchers.some(function(v){return v.f===id||v.f2===id})){alert('لا يمكن المسح: الصندوق يحتوي على عملات');return}
   dd.funds=dd.funds.filter(function(x){return x.id!==id});save(dd);o.remove();render();
 });
}
function fundPrintMenu(id){var m=modal('كشف الصندوق — '+E(fname(db(),id)),'<div class="tsMenu"><button data-m="print">🖨️ طباعة كشف الصندوق (فترة / عملات / سندات)</button><button data-m="auth">📝 طباعة مصادقة الصندوق</button></div>',null);m.addEventListener('click',function(e){var b=e.target.closest('[data-m]');if(!b)return;var k=b.dataset.m;m.remove();fundPrintDialog(id,k==='auth')})}
var A={
  back:function(){if(selMode){selMode=false;selIds=[];render();return}if(sub){sub=(sub.k==='acc'&&sub.g)?{k:'fol',id:sub.g}:null;render()}else if(tab!=='home'){tab='home';render()}else window.closeTasfeer()},
  'q-internal':function(){voucher('internal')},'q-clock':function(){voucher('clockacc')},'q-receipt':function(){voucher('receipt')},
  rc:function(i){voucher('receipt',i)},sp:function(i){voucher('receipt',i,'إضافة سندات معاملة خاصة للصناديق')},tr:function(i){voucher('transfer',i)},hw:function(i){voucher('internal',i)},ex:exch,ks:fundPrintMenu,gap:gapModal,
  fund:function(i){tab='funds';sub={k:'fund',id:i};render()},
  nf:function(){fundPage()},
  ef:function(i){fundPage(i)},
  nfo:function(){folModal()},efo:function(i){folModal(i)},stat:statsModal,qs:searchModal,
  na:function(g){accModal(g)},ea:function(i){accModal(null,i)},
  accs:function(){tab='accs';sub=null;render()},fol:function(i){tab='accs';sub={k:'fol',id:i};render()},
  acc:function(i){var a=db().accounts.find(function(x){return x.id===i});tab='accs';sub={k:'acc',id:i,g:a&&a.g};render()},
  da:function(i){var d=db(),has=d.vouchers.some(function(v){return v.acc===i});if(!confirm(has?'حذف الحساب وكل سنداته؟':'حذف هذا الحساب؟'))return;d.vouchers=d.vouchers.filter(function(v){if(v.acc===i){clockUnlink(v.id);return false}return true});var a=d.accounts.find(function(x){return x.id===i});d.accounts=d.accounts.filter(function(x){return x.id!==i});save(d);sub=a&&a.g?{k:'fol',id:a.g}:null;render()},
  asc:function(){asc=true;render()},desc:function(){asc=false;render()},dp:function(){dFrom=shiftM(dFrom,-1);dTo=shiftM(dTo,-1);render()},dn:function(){dFrom=shiftM(dFrom,1);dTo=shiftM(dTo,1);render()},
  mc:function(){window.closeTasfeer();try{window.tab('settings',true);window.openSettingsPage('currencies')}catch(e){alert('افتح الإعدادات ثم العملات')}},
  fxset:function(k){var d=db(),key=k==='com'?'comAcc':'fxAcc',title=k==='com'?'حساب عمولة الحوالة':'حساب فارق الصرافة';var cur0=(d.settings||{})[key]||'';
   var opts='<option value="">— بدون —</option>'+(d.accounts||[]).map(function(a){return '<option value="'+E(a.id)+'"'+(cur0===a.id?' selected':'')+'>'+E(a.name)+'</option>'}).join('');
   modal(title,'<label>اختر الحساب<select id="fxSel" style="width:100%">'+opts+'</select></label>',function(o){var v=o.querySelector('#fxSel').value;var dd=db();dd.settings=dd.settings||{};dd.settings[key]=v||'';save(dd);render()},'💾 حفظ')},
  delv:function(i){if(isFx(i)){alert('سند فارق الصرف تلقائي؛ احذف الترحيل/الحوالة الأصلية فيُحذف معها.');return}if(!confirm('حذف هذا السند؟'))return;var d=db();d.vouchers=d.vouchers.filter(function(v){return v.id!==i});clockUnlink(i);save(d);render()},
  reset:function(){if(!confirm('مسح كل بيانات الصرافة (الصناديق والسندات والحسابات)؟'))return;localStorage.removeItem(K);render()}
 };

 A.photo=function(i){photoV(i)};A.tph=function(i){photoV(i)};A.tsh=function(i){shareV(i)};A.tpr=function(i){printV(i)};A.tsprint=function(){tsTopPrint(false)};A.tsauth=function(){tsTopPrint(true)};A.ted=function(i){editV(i)};A.tdl=function(i){A.delv(i)};A.selall=selAll;A.seldel=function(){delVs(selIds.slice())};A.selx=function(){selMode=false;selIds=[];render()};
 var lpT=null,lpDone=false,lpX=0,lpY=0;
 var accLpT=null,accLpDone=false,accLpX=0,accLpY=0;
 document.addEventListener('pointerdown',function(e){accLpDone=false;var c=e.target.closest&&e.target.closest('#tsPage .tsC[data-a=\"acc\"]');if(!c||e.target.closest('.tsOv'))return;accLpX=e.clientX;accLpY=e.clientY;clearTimeout(accLpT);accLpT=setTimeout(function(){accLpT=null;accLpDone=true;if(navigator.vibrate)navigator.vibrate(35);tasfeerAccountMenu(c.dataset.i)},550)});
 ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,function(){if(accLpT){clearTimeout(accLpT);accLpT=null}},true)});
 document.addEventListener('pointermove',function(e){if(accLpT&&(Math.abs(e.clientX-accLpX)>10||Math.abs(e.clientY-accLpY)>10)){clearTimeout(accLpT);accLpT=null}},true);

 document.addEventListener('pointerdown',function(e){lpDone=false;var c=e.target.closest&&e.target.closest('#tsPage .tsVC');if(!c||e.target.closest('.tsOv')||selMode)return;lpX=e.clientX;lpY=e.clientY;clearTimeout(lpT);lpT=setTimeout(function(){lpT=null;lpDone=true;if(navigator.vibrate)navigator.vibrate(35);vMenu(c.dataset.vid)},550)});
 ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,function(){if(lpT){clearTimeout(lpT);lpT=null}})});
 document.addEventListener('pointermove',function(e){if(lpT&&(Math.abs(e.clientX-lpX)>10||Math.abs(e.clientY-lpY)>10)){clearTimeout(lpT);lpT=null}});
 document.addEventListener('contextmenu',function(e){if(e.target.closest&&e.target.closest('#tsPage .tsVC'))e.preventDefault()});
 document.addEventListener('click',function(e){var c=e.target.closest&&e.target.closest('#tsPage .tsVC');if(!c||e.target.closest('.tsOv'))return;
  if(lpDone){lpDone=false;e.preventDefault();e.stopPropagation();return}
  if(selMode){e.preventDefault();e.stopPropagation();var i=selIds.indexOf(c.dataset.vid);if(i>=0)selIds.splice(i,1);else selIds.push(c.dataset.vid);render()}},true);
 document.addEventListener('click',function(e){
  var accountCard=e.target.closest&&e.target.closest('#tsPage .tsC[data-a=\"acc\"]');if(accountCard&&accLpDone){accLpDone=false;e.preventDefault();e.stopImmediatePropagation();return}
  var tb=e.target.closest&&e.target.closest('#tsPage .tsNav button');if(tb){tab=tb.dataset.t;sub=null;selMode=false;selIds=[];render();return}
  var el=e.target.closest&&e.target.closest('#tsPage [data-a]');if(el&&A[el.dataset.a]&&!el.closest('.tsOv'))A[el.dataset.a](el.dataset.i)});
 document.addEventListener('change',function(e){var t=e.target;if(!t.closest||!t.closest('#tsPage'))return;
  if(t.id==='tsCur')cur=t.value;else if(t.id==='tsSpec'){try{data.settings.activeSpecialty=t.value||'all';if(typeof window.save==='function')window.save()}catch(e){}}else if(t.id==='tsSrt')srt=t.value;else if(t.id==='tsFrom')dFrom=t.value||dFrom;else if(t.id==='tsTo')dTo=t.value||dTo;else return;render()});
 window.openTasfeer=function(){tab='home';sub=null;$('tsPage').style.display='flex';document.body.classList.add('ts-open');render()};
 window.closeTasfeer=function(){$('tsPage').style.display='none';document.body.classList.remove('ts-open');try{if(window.__clockRenderHome)window.__clockRenderHome()}catch(e){}};try{if(window.__clockRenderHome)window.__clockRenderHome()}catch(e){}
})();

function showBuyerInvoices(){
  window.invScope='buyer';
  currentFolderId=null;currentFolderCurrency=null;
  tab('invoices',true);
  document.getElementById('headerTitle').textContent='فواتير الشرائي';
  var bb=document.querySelector('.bottom-bar');if(bb)bb.style.display='flex';
  clearNav();renderCurrentView();
}
/* source script: purchase-page-navigation-logic */
function fmtBuyerNum(n){return Number(n||0).toLocaleString('en-US')}
function refreshBuyerStats(){var s=(typeof data!=='undefined'&&data&&data.settings&&data.settings.buyerStats)||{};
  var set=function(id,v){var el=document.getElementById(id);if(!el)return;v=Number(v)||0;
    el.innerHTML=fmtBuyerNum(Math.abs(v))+(v?'<small class="by-dir">'+(v>0?'لكم':'عليكم')+'</small>':'');
    el.style.color='';var it=el.closest('.clock-item');if(it){it.classList.toggle('clock-pay',v>0);it.classList.toggle('clock-debt',v<0)}};
  set('byStatSales',s.sales);set('byStatProfitSeller',s.profitSeller);set('byStatProfitSupplier',s.profitSupplier)}
function buyerGo(t){if(t==='invoices'){showBuyerInvoices()}else openBuyerSub(t)}
function showPurchasePage(){
  currentFolderId=null;currentFolderCurrency=null;
  tab('buyerPage',true);
  document.getElementById('headerTitle').textContent='الشرائي';
  try{if(window.bpSyncSales)window.bpSyncSales()}catch(e){}
  if(typeof refreshBuyerStats==='function')refreshBuyerStats();
  var bb=document.querySelector('.bottom-bar');if(bb)bb.style.display='flex';
  clearNav();
}

/* source script: global-bottom-navigation-logic */
(function(){var nav=document.getElementById('globalBottomNav');if(!nav)return;
function sync(){var home=document.getElementById('home');var purchase=document.getElementById('buyerPage');var pap=document.getElementById('privateAccountsPage');var sub=document.getElementById('fullFilterPage');var visible=((!!home&&home.classList.contains('on'))||(!!purchase&&purchase.classList.contains('on'))||(!!pap&&pap.classList.contains('on')))&&!(sub&&sub.classList.contains('show'))&&!document.body.classList.contains('statement-view');nav.style.setProperty('display',visible?'grid':'none','important');if(visible)document.body.style.setProperty('padding-bottom','calc(66px + env(safe-area-inset-bottom))','important');}
nav.addEventListener('click',function(e){var b=e.target.closest('[data-bottom-route]');if(!b)return;var r=b.getAttribute('data-bottom-route');if(r==='home'){if(typeof showHome==='function')showHome();else if(typeof tab==='function')tab('home')}else if(r==='buyer'){if(typeof showPurchasePage==='function')showPurchasePage();else if(typeof showInvoices==='function')showInvoices();else if(typeof tab==='function')tab('invoices')}else if(r==='private'){if(typeof window.showPrivateAccountsPage==='function')window.showPrivateAccountsPage()}setTimeout(sync,80)});
var obs=new MutationObserver(sync);document.querySelectorAll('.section,#fullFilterPage').forEach(function(x){obs.observe(x,{attributes:true,attributeFilter:['class']})});window.addEventListener('pageshow',sync);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync);setTimeout(sync,0);setTimeout(sync,300);})();

/* source script: global-app-preferences-js */
(function(){
  'use strict';
  var I18N={"إطار التطبيق":"Application frame","إيقاف المفتاح العام يخفي الإطار من التطبيق كله. عند التفعيل تبقى خيارات اللون والشكل والنمط والسمك مستقلة.":"Turning the master switch off hides frames throughout the app. When on, color, shape, line style, and thickness remain independent.","تفعيل خيارات الإطار":"Frame options","يمكن إيقاف أو تفعيل كل خيار بشكل مستقل. عند الإيقاف يعود إلى قيمته الافتراضية مع حفظ اختيارك.":"Each option can be enabled or disabled independently. Turning it off restores the default while keeping your choice.","لون الإطار":"Frame color","شكل الإطار":"Frame shape","نمط خط الإطار":"Border line style","سمك الإطار":"Border thickness","مفعل":"On","متوقف":"Off","لون الثيم المستخدم":"Use current theme color","يتغير تلقائيًا مع الثيم":"Automatically follows the theme","(قديمة)":"(Old)","(نسخة)":"(Copy)","+ مسلم أسبوع":"+ Muslim Week","+ مسلم فلوس":"+ Muslim Money","4 أرقام على الأقل":"At least 4 digits","= الباقي نقد":"= Change in cash","= نقد الباقي":"= Cash change","| الإجمالي عليكم:":"| Total Debit:","| الرصيد:":"| Balance:","| الصافي:":"| Net:","| عليكم:":"| Debit:","أبيض وأسود":"Black and white","أدخل اسم التفصيل":"Enter the detail name","أدخل اسم الصندوق":"Enter the cashbox name","أدخل اسم الفلتر":"Enter the filter name","أدخل الاسم":"Enter the name","أدخل التاريخ واسم البياع قبل الحفظ":"Enter the date and seller's name before saving","أدخل الرمز الحالي":"Enter the current code","أدخل الرمز السري":"Enter the password","أدخل اليوم والتاريخ":"Enter the day and date","أدخل رقم الجدول":"Enter the table number","أدخل رمزاً سرياً (4 أرقام على الأقل)":"Enter a password (at least 4 digits)","أدخل سقفاً أكبر من صفر":"Enter a limit greater than zero","أدخل مبلغ سقف المديونية":"Enter the credit limit amount","أدخل مبلغاً صحيحاً":"Enter a valid amount","أرقام التواصل":"Contact numbers","أرقام التواصل (إنجليزي)":"Contact numbers (English)","أضف النص الرسمي المعتمد ليظهر للمستخدمين. لا يوجد نص قانوني مرفق بهذه النسخة.":"Add the approved official text to display to users. No legal text is attached to this version.","ألوان الطباعة":"Print colors","أمين الصندوق: ........................":"Cashier: ........................","أنشئ مجلداً أولاً لحفظ الفاتورة بداخله":"Create a folder first to save the invoice in it","أوزان الخط":"Font weights","إجراء":"Action","إجراءات الديون في المراقب":"Debt actions per hour","إرسال":"Send","إرسال الرسالة كصورة":"Send message as an image","إرسال بريد إلكتروني":"Send email","إرسال حوالات داخلية من الصناديق على الحسابات":"Send internal transfers from cashboxes to accounts","إرفاق صورة":"Attach image","إزالة الصورة":"Remove image","إضافة التوقيع":"Add signature","إضافة تفصيل":"Add detail","إضافة حساب جديد":"Add new account","إضافة سقف مديونية":"Add credit limit","إضافة صندوق حسابات ديون":"Add debt accounts cashbox","إضافة عملة":"Add currency","إضافة فاتورة جديدة":"Add new invoice","إضافة فلتر اسبوعي":"Add weekly filter","إضافة مجلد حسابات":"Add accounts folder","إظهار قائمة الفواتير المحفوظة عند فتح المجلد":"Show the list of saved invoices when opening the folder","إعدادات الإرسال لهذا الحساب":"Sending settings for this account","إعدادات الطباعة":"Print settings","إغلاق":"Close","إفراغ السلة":"Empty trash","إلغاء":"Cancel","إلى الحساب":"To account","إلى الطابعة":"To printer","إلى تاريخ":"To date","إلى رقم الجوال":"To mobile number","إملاء صوتي":"Voice dictation","إيقاف":"Stop","إيقاف الإرسال":"Stop sending","اختار التخصيص للصفحه":"Select page customization","اختار التخصيص للعملات":"Select currency customization","اختر التطبيق الذي تريد إرسال الرسالة من خلاله":"Choose the app to send the message from","اختر الحساب":"Choose an account","اختر الختم":"Choose a stamp","اختر الشعار":"Choose a logo","اختر العملة لعرض كشف حسابها":"Choose a currency to view its statement","اختر الفلتر الأسبوعي":"Choose a weekly filter","اختر المجلد لحفظ الفاتورة":"Choose a folder to save the invoice","اختر تطبيق الإرسال":"Choose a sending app","اختر حجم الورق ونمط الألوان، ثم افتح الفاتورة واضغط طباعة. قد يعتمد ظهور الألوان على خيار «طباعة الخلفيات» في نافذة الطباعة.":"Choose the paper size and color mode, then open the invoice and tap Print. Color display may depend on the “Print backgrounds” option in the print window.","اختر صورة من جهازك لتكون خلفية عامة لجميع صفحات التطبيق. يمكنك إزالة الصورة والعودة للخلفية الافتراضية.":"Choose an image from your device to use as a general background for all app pages. You can remove the image and return to the default background.","اختيار صورة من الجهاز":"Choose an image from your device","اختيار عملة":"Choose a currency","اختياري":"Optional","ادخل الاسم":"Enter the name","استخدام ترويسة جاهزة":"Use a ready-made letterhead","استعادة":"Restore","استوديو":"Studio","اسحب القائمة للخارج لإغلاقها":"Swipe the menu outward to close it","اسم البيع":"Sale name","اسم الخارج":"Outgoing name","اسم الدين":"Debt name","اسم الصندوق":"Cashbox name","اسم العملة":"Currency name","اسم المؤسسة":"Organization name","اسم المجلد":"Folder name","اسم المرسل":"Sender name","اسم المستلم":"Recipient name","اسمح بالنوافذ المنبثقة":"Allow pop-ups","اسمح بفتح نافذة الطباعة":"Allow the print window to open","اضغط (+) لإضافة تفصيل جديد.":"Tap (+) to add a new detail.","اضغط (+) لإضافة صندوق حسابات.":"Tap (+) to add an account cashbox.","اضغط + لإضافة مجلد":"Tap + to add a folder","اضغط لتعديل التاريخ والوقت":"Tap to edit the date and time","افتح الفلتر أولاً":"Open the filter first","افتح المجلد أولاً لإضافة فاتورة":"Open the folder first to add an invoice","اكتب \"حذف\"":"Type \"Delete\"","اكتب الاسم":"Enter the name","اكتب البيان ويمكنك إضافة عدة سطور":"Enter the description; you can add multiple lines","اكتب للبحث...":"Type to search...","الأحد":"Sunday","الأخ:":"Brother:","الأذونات":"Permissions","الأربعاء":"Wednesday","الإثنين":"Monday","الإجمالي":"Total","الإجمالي لكم:":"Total Credit:","الإجمالي:":"Total:","الإحصائيات":"Statistics","الإسم بالإنجليزية":"Name in English","الإسم بالعربية":"Name in Arabic","الإشعارات":"Notifications","الإصدار 3.3.78":"Version 3.3.78","الإعدادات":"Settings","الاثنين":"Monday","الاخ:":"Brother:","الاداري برو":"Al-Idari Pro","الاسم":"Name","الاسم:":"Name:","الاسم: ........................":"Name: ........................","الاسم: __________":"Name: __________","الباقي":"Remaining","البحث السريع":"Quick Search","البداية":"Home","البريد الإلكتروني للدعم (اختياري)":"Support Email (Optional)","البريد غير صالح":"Invalid email","البيان":"Description","البيان — متعدد الأسطر":"Description — Multiline","البيع نقد":"Cash Sale","التاريخ":"Date","التاريخ:":"Date:","التجزئة":"Retail","التخاصيص":"Allocations","التخصيص":"Allocation","الصرافة":"Reset to Zero","التفاصيل":"Details","التفصيل":"Detail","التنقل الرئيسي":"Main Navigation","التوقيع:":"Signature:","التوقيع: ........................":"Signature: ........................","التوقيع: __________":"Signature: __________","الثلاثاء":"Tuesday","الجمعة":"Friday","الجملة":"Wholesale","الحاسبة":"Calculator","الحساب":"Account","الحساب:":"Account:","الحسابات الخصوصية":"Private","الخروج دون حفظ التعديلات؟":"Exit without saving changes?","الخميس":"Thursday","الديون":"Debts","الرئيسية":"Home","الرجاء إدخال اسم الفلتر":"Please enter a filter name","الرجاء سرعة سداد ماعليكم مع كامل الشكر والاحترام":"Please settle the amount you owe as soon as possible. With thanks and respect.","الرجاء مصادقة الرصيد وموافقتنا بالرد":"Please confirm the balance and reply with your approval","الرجاء مصادقة الرصيد وموافقتنا بالرد.":"Please confirm the balance and reply with your approval.","الرسائل والواتس":"Messages and WhatsApp","الرصيد":"Balance","الرصيد الباقي":"Remaining Balance","الرصيد الفارق":"Balance Difference","الرصيد الكامل":"Full Balance","الرصيد صفر":"Zero Balance","الرصيد لك":"Credit","الرقم":"Number","الرمز":"Code","الرمز الجديد":"New Code","الرمز الحالي":"Current Code","الرمز السري":"Password","الرمز خطأ":"Incorrect Code","السبت":"Saturday","السبت لحقه":"Following Saturday","السحب":"Withdrawal","السحب فلوس":"Withdraw Money","السلة فارغة":"Cart is Empty","الشرائي":"Purchase","الصافي:":"Net:","الصندوق":"Cashbox","الصندوق التلقائي":"Automatic Cashbox","الصندوق التلقائي (سندات التفصيل)":"Automatic Cashbox (Detailed Vouchers)","الصندوق الثابت — الصندوق التلقائي":"Fixed Cashbox — Automatic Cashbox","الضغط المطوّل على الفاتورة":"Long-press the invoice","العملات":"Currencies","العملات والتفصيل":"Currencies and Details","العملة":"Currency","العملة المستلمة":"Currency Received","العملة المصروفة (من الرصيد المتاح)":"Currency Disbursed (from Available Balance)","العمولة":"Commission","العنوان بالإنجليزية":"Address in English","العنوان بالعربية":"Address in Arabic","الفاتورة غير موجودة":"Invoice not found","الفاتورة لم تُربط بالفلتر الأسبوعي: لم يُعثر على فلتر بهذا الاسم":"Invoice not linked to the weekly filter: No filter with this name was found","الفاتورة لم تُربط بالفلتر: تاريخ الفاتورة غير صالح":"Invoice not linked to the filter: Invalid invoice date","الفترة":"Period","الفترة التالية":"Next Period","الفترة السابقة":"Previous Period","الفترة:":"Period:","الفلاتر الأسبوعية":"Weekly Filters","الفلتر الأسبوعي":"Weekly Filter","الفلتر الأسبوعي [اختار الفلتر]":"Weekly Filter [Select Filter]","القات الدين":"Qat Debt","القات خرج":"Qat Disbursement","القات دين":"Qat Debt","القيد على الحساب الحالي":"Entry on the Current Account","القيمة":"Value","الكارت اليومي":"Daily Card","الكل":"All","الكمية":"Quantity","اللغة":"Language","اللغة ومظهر التطبيق":"Language and App Appearance","اللون الأساسي للطباعة":"Primary Print Color","المبلغ":"Amount","المبلغ المستلم (يحسب تلقائيًا)":"Amount Received (calculated automatically)","المبلغ المصروف":"Amount Disbursed","المبلغ والعملة":"Amount and Currency","المتبقي":"Remaining","المجلد مقفل":"Folder Locked","المحترم":"Dear","المستلم: ........................":"Received by: ........................","الملف الشخصي":"Profile","الناتج":"Output","النسخ الاحتياطية":"Backups","النص":"Text","النقد":"Cash","النوع":"Type","الوقت":"Time","اليوم والتاريخ":"Day and Date","بدء تفصيل جديد؟ سيتم فقدان البيانات غير المحفوظة.":"Start a new breakdown? Unsaved data will be lost.","بداية الفترة الجديدة":"Start of the New Period","بدون اسم":"Unnamed","بدون تخصيص":"Unassigned","برنامج الشراء":"Purchase Program","بعد التأكيد":"After Confirmation","بعض الأذونات قد لا تكون مدعومة.":"Some permissions may not be supported.","تأكيد":"Confirm","تأكيد الحذف؟":"Confirm deletion?","تأكيد الرمز":"Confirm Code","تاريخ الفاتورة خارج فترة الفلتر الأسبوعي المحددة":"Invoice date is outside the specified weekly filter period","تاريخ النهاية يجب أن يكون بعد تاريخ البداية":"The end date must be after the start date","تاريخ محدد من نطاق الفلتر":"A date selected from the filter range","تحديث السجل":"Update record","تحديد الإرسال":"Select sending option","تحية طيبة وبعد":"Greetings,","تدرج رمادي":"Grayscale","ترتيب الصندوق":"Sort box","ترتيب المجلد":"Sort folder","ترتيب حسب:":"Sort by:","ترحيل":"Posting","ترويسة المؤسسة":"Organization header","تسجيل الخروج":"Log out","تسديد":"Payment","تشغيل":"Run","تصوير":"Capture","تصوير الورقة وقراءة بياناتها آلياً":"Capture the paper and read its data automatically","تصوير ورقة الفاتورة":"Capture the invoice page","تطبيق الإعدادات العامة على جميع الحسابات":"Apply general settings to all accounts","تظهر هنا ملاحظات القراءة. صحّح الصفوف في الجدول أدناه قبل الحفظ":"Reading notes appear here. Correct the rows in the table below before saving","تعبأ البيانات من الفواتير":"Data is populated from invoices","تعديل":"Edit","تعديل التفصيل":"Edit details","تعديل الحساب":"Edit account","تعديل الصندوق":"Edit box","تعديل الفاتورة":"Edit invoice","تعديل المجلد":"Edit folder","تعديل سند":"Edit voucher","تعذر إنشاء النسخة الاحتياطية":"Could not create backup","تعذر استعادة النسخة: الملف غير صالح":"Could not restore backup: invalid file","تعذر الاستعادة: المجلد الأصلي غير موجود":"Could not restore: original folder not found","تعذر الاستعادة: سجل التفصيل الأصلي غير موجود":"Could not restore: original detail record not found","تعذر الحفظ":"Could not save","تعذر الحفظ؛ تحقق من البيانات":"Could not save; check the data","تعذر الحفظ؛ قد تكون مساحة التخزين ممتلئة. صدّر نسخة احتياطية.":"Could not save; storage may be full. Export a backup.","تعذر تجهيز النسخة:":"Could not prepare backup:","تعذر تحديد المجلد لحفظ الفاتورة":"Could not select a folder to save the invoice","تعذر جلب قائمة النسخ":"Could not retrieve backup list","تعذر حفظ البيانات. تحقق من مساحة التخزين.":"Could not save data. Check storage space.","تعذر حفظ التخزين المحلي:":"Could not save local storage:","تعذر حفظ الصورة":"Could not save image","تعذر حفظ الفاتورة؛ قد تكون مساحة التخزين ممتلئة":"Could not save invoice; storage may be full","تعذر حفظ الفلتر؛ مساحة التخزين قد تكون ممتلئة":"Could not save filter; storage may be full","تعذر حفظ بيانات الفاتورة داخل الفلتر الأسبوعي":"Could not save invoice data in the weekly filter","تعذر قراءة البيانات المحفوظة. احتُفظ بنسخة منها؛ لا تحفظ بيانات جديدة قبل استعادتها.":"Could not read saved data. A copy has been kept; do not save new data before restoring it.","تعذر قراءة التخزين المحلي:":"Could not read local storage:","تعذر قراءة الفلاتر الأسبوعية":"Could not read weekly filters","تعذر قراءة بيانات التطبيق المحفوظة؛ تم الاحتفاظ بها دون استبدالها.":"Could not read saved app data; it has been kept without being replaced.","تعذر قراءة ملف النسخة الاحتياطية":"Could not read backup file","تعذرت الاستعادة":"Could not restore","تعيين رمز":"Set code","تغيير الرمز":"Change code","تفاصيل":"Details","تفاصيل عمود البيع والقات دين والقات خرج":"Details of the Sales, Qat Credit, and Qat Debit columns","تفصيل بدون اسم":"Unnamed detail","تفصيل جديد":"New detail","تفعيل الخاتمة":"Enable closing","تفعيل المقدمة":"Enable introduction","تفعيل خاتمة الرسالة":"Enable message closing","تفعيل سقف المديونية":"Enable credit limit","تفعيل مقدمة الرسالة":"Enable message introduction","تفعيل ميزة تعدد العملات":"Enable multi-currency","تلقائي":"Automatic","تلقائي عند حفظ السند":"Automatic when saving the receipt","تم":"Done","تم إرجاع الحساب التلقائي":"Automatic account restored","تم إفراغ السلة":"Cart emptied","تم إلغاء جميع التعديلات اليدوية":"All manual changes canceled","تم البدء من جديد":"Started over","تم الحفظ":"Saved","تم المسح":"Cleared","تم تحديث الفاتورة داخل المجلد":"Invoice updated in folder","تم تحديث مجاميع المراقب":"Hourly totals updated","تم تطبيق الإعدادات العامة على جميع الحسابات":"General settings applied to all accounts","تم تفعيل إعدادات كل حساب بشكل مستقل":"Individual settings enabled for each account","تم تنزيل الصورة":"Image downloaded","تم حذف الصورة":"Image deleted","تم حذف الفاتورة":"Invoice deleted","تم حفظ إعدادات الفواتير":"Invoice settings saved","تم حفظ البريد":"Email saved","تم حفظ الفاتورة داخل المجلد":"Invoice saved in folder","تم حفظ الفلتر الأسبوعي مع هيكله":"Weekly filter and its structure saved","تم حفظ المعاملة. هل تريد إرسال رسالة للحساب؟":"Transaction saved. Would you like to send a message to the account?","تم رفض المعاملة: ستتجاوز سقف المديونية":"Transaction rejected: it would exceed the credit limit","تم فصل حالة الحساب المحفوظة":"Saved account status disconnected","تم نسخ المعاملة":"Transaction copied","تم نسخ بيانات الفاتورة للمشاركة":"Invoice details copied for sharing","تم نقل المعاملة":"Transaction moved","تمت استعادة":"Restored","تمت استعادة النسخة مع الاحتفاظ بنسخة من البيانات السابقة":"Backup restored, keeping a copy of the previous data","تمت استعادة كل الصفحات؛ سيُعاد تحميل التطبيق":"All pages restored; the app will reload","تمت الاستعادة بنجاح":"Successfully restored","تنبيه":"Alert","تنزيل نسخة محلية":"Download local backup","توقيت الإرسال":"Send time","توقيع":"Signature","توقيع المرسل: ........................":"Sender's signature: ........................","توقيع الموظف: ........................":"Employee's signature: ........................","تُطبّق هذه الإعدادات على الإطارات والأشرطة والحقول والحواف في صفحات التطبيق التي تستخدم عناصر الواجهة المشتركة.":"These settings apply to frames, bars, fields, and borders on app pages that use shared UI components.","جرّب اختيار عملة أخرى أو أضف عملية بهذه العملة":"Try selecting another currency or add a transaction in this currency","جملة البيع النهائية":"Final sales total","جملة الصرف":"Total disbursement","جهة الاتصال لا تحتوي على رقم هاتف":"Contact does not have a phone number","جهة التحويل":"Transfer recipient","جهة الحواله":"Remittance recipient","حاسبة المبلغ":"Amount calculator","حتى اليوم":"Through today","حجم الخط في الطباعة":"Print font size","حجم الورق":"Paper size","حذف":"Delete","حذف التوقيع؟":"Delete signature?","حذف الحساب وكل معاملاته؟":"Delete account and all its transactions?","حذف الختم؟":"Delete stamp?","حذف الرمز؟":"Delete icon?","حذف السطر":"Delete row","حذف الشعار؟":"Delete logo?","حذف المعاملات المحددة؟":"Delete selected transactions?","حذف جميع العناصر من السلة نهائيًا؟ لا يمكن التراجع.":"Permanently remove all items from the cart? This cannot be undone.","حذف صورة":"Delete image","حذف صورة البياع من هذه الفاتورة؟":"Delete the seller's image from this invoice?","حذف فاتورة":"Delete invoice","حذف نهائي":"Permanent deletion","حذف نهائي؟":"Delete permanently?","حذف هذه المعاملة؟":"Delete this transaction?","حساب":"Account","حسابات":"Accounts","حسب الرصيد (لكم أو عليكم)":"By balance (Credit or Debit)","حسناً":"OK","حفظ":"Save","حفظ الإعدادات":"Save settings","حفظ الرابط":"Save link","حفظ القيد":"Save entry","حفظ بيانات التواصل":"Save contact details","حواله":"Transfer","خاتمة الرسالة":"Message closing","ختام طلب السداد":"Payment request closing","ختم":"Stamp","خرج السوق":"Market expenses","خرج العمال":"Workers' expenses","خطأ في العملية":"Transaction error","خطأ: لا يوجد حساب مفتوح":"Error: No open account","درجة وضوح الخلفية:":"Background opacity:","درهم":"Dirham","درهم إماراتي":"UAE dirham","دولار أمريكي":"US dollar","ديون":"Debts","رابط فيديو الشرح":"Video tutorial link","رجوع":"Back","رسائل نصية":"Text messages","رسالة نصية":"Text message","رصيد سابق":"Previous balance","رقم الجدول":"Table number","رقم الحوالة":"Transfer number","رقم الحواله":"Transfer number","رقم المستلم:":"Recipient number:","رقم الهاتف":"Phone number","رقم واتساب مع رمز الدولة":"WhatsApp number with country code","رياض اليافعي":"Riyadh Al-Yafei","ريال سعودي":"Saudi riyal","ريال يمني":"Yemeni rial","سطر جديد":"New line","سعر الصرف":"Exchange rate","سعر الصرف (المبلغ المستلم لكل وحدة مصروفة)":"Exchange rate (amount received per unit disbursed)","سعود":"Saud","سعودي":"Saudi","سقف المديونية":"Debt limit","سلة المحذوفات":"Trash","سنت":"Cent","سند إرسال حوالة":"Transfer dispatch voucher","سند جديد":"New voucher","سند قبض":"Receipt voucher","سند قبض من العملات إلى الصناديق":"Receipt voucher from currencies to cashboxes","سند معاملة":"Transaction voucher","سند معاملة —":"Transaction voucher —","سند من التفصيل":"Detailed voucher","سندات قبض من صفحات المراقب الى الحسابات":"Receipts from the Clock pages to accounts","سنوي":"Annual","سيتم استبدال بيانات كل صفحات التطبيق بمحتوى النسخة. هل تريد المتابعة؟":"All app page data will be replaced with the backup contents. Do you want to continue?","سيتم الإرسال عبر:":"Will be sent via:","سيتم حذف جميع البيانات والبدء من جديد. متابعة؟":"All data will be deleted and the app will start over. Continue?","سيُخصم المبلغ من رصيد العملة المصروفة ويُضاف إلى رصيد العملة المستلمة، ثم يتحدث شريط إجماليات العملات. لا يمكن صرف مبلغ أكبر من الرصيد المتاح.":"The amount will be deducted from the disbursed currency balance and added to the received currency balance, then the currency totals bar will update. You cannot disburse more than the available balance.","شارك رابط التطبيق مع الآخرين من خلال قائمة المشاركة في جهازك.":"Share the app link with others using your device’s share menu.","شعار":"Logo","شهري":"Monthly","صرافة":"Money exchange","صرافة عملات":"Currency exchange","صرف":"Disbursement","صفحات المراقب":"Clock faces","صفحة 1":"Page 1","صفر":"Zero","صناديق الحسابات":"Account funds","صندوق السندات":"Voucher fund","صورة":"Image","صورة البياع":"Seller image","صورة الصندوق":"Fund image","صورة المجلد":"Folder image","صورة المعاملة (إن وُجدت)":"Transaction image (if available)","صورة-بياع-":"Seller image","صيغة (عليه)":"Debit format","صيغة (له)":"Credit format","صيغة الرصيد في الرسالة":"Balance format in message","صيغة المبلغ":"Amount format","صيغة النسخة غير معروفة":"Unknown version format","طباعة فاتورة":"Print invoice","طريقة الإرسال":"Sending method","طريقة الإرسال الافتراضية":"Default sending method","طريقة الاستخدام":"How to use","طريقة الطباعة":"Print method","طريقة عرض المجلدات":"Folder display method","عدد التفصيلات:":"Number of details:","عرض التفصيل":"Show details","عرض الفواتير داخل المجلد":"Show invoices inside folder","عرض المجلدات فقط":"Show folders only","عرض صورة الورقة":"Show document image","عريض":"Wide","علماً أنه لا يوجد لدينا أي أرصدة أخرى خلال الفترة المحددة":"Please note that we have no other balances during the specified period","عليكم":"Debit","عليكم فقط":"Debits only","عليه":"Debit","عليه:":"Debit:","عمان":"Oman","عماني":"Omani","عمود البيع":"Sales column","عمود الكمية":"Quantity column","عن العميل":"About the customer","عند التفعيل، طريقة الإرسال وتوقيته من هذه الصفحة هما المعتمدان لكل الحسابات.":"When enabled, the sending method and timing on this page will apply to all accounts.","عند التفعيل، يتم عرض الشعار كترويسة كاملة":"When enabled, the logo is displayed as a full header","عنصر؛ سيُعاد تحميل التطبيق":"Item; the app will reload","غير متطابقين":"Do not match","فاتورة":"Invoice","فاتورة-":"Invoice-","فارغ":"Empty","فتح":"Open","فتح حاسبة مبلغ السند":"Open voucher amount calculator","فتح واتساب":"Open WhatsApp","فتح ←":"Open ←","فشل إرسال طلب النسخ؛ سيتم تنزيل نسخة محلية":"Failed to send copy request; a local copy will be downloaded","فشل حفظ بيانات التطبيق":"Failed to save app data","فشلت استعادة النسخة":"Failed to restore backup","فلتر أسبوعي":"Weekly filter","فلترة":"Filter","فلس":"Fils","في وضع الصورة تُشارك صورة المعاملة المرفقة إن وُجدت؛ إذا لم توجد صورة، يُستخدم النص.":"In image mode, the attached transaction image is shared if available; otherwise, the text is used.","قائمة الصناديق التي تفتح حسابات العملاء داخلها في صفحة الدين":"List of cash boxes where customer accounts are opened on the Debt page","قبض":"Receipt","قيد إلى حساب":"Post to account","كشف":"Statement","كشف حساب":"Account statement","كشف حساب —":"Account statement —","كشف حسابات":"Account statements","كمية:":"Quantity:","لا ترسل":"Do not send","لا توجد أرصدة":"No balances","لا توجد إعدادات لأنواع البيع في هذا الملف الحالي.":"No sales type settings in this current file.","لا توجد بيانات":"No data","لا توجد تفصيلات في هذه الفترة.":"No details for this period.","لا توجد حركات":"No transactions","لا توجد حركات بهذه العملة":"No transactions in this currency","لا توجد حركات خلال الفترة":"No transactions during this period","لا توجد حركات خلال الفترة المحددة":"No transactions during the selected period","لا توجد حركات ضمن الفترة":"No transactions within this period","لا توجد حركات. اضغط (+)":"No transactions. Tap (+)","لا توجد حسابات أخرى":"No other accounts","لا توجد حسابات أو حركات ضمن الفترة":"No accounts or transactions within this period","لا توجد حسابات في هذه الفترة":"No accounts for this period","لا توجد حسابات وجهة":"No destination accounts","لا توجد حسابات. اضغط (+) لإضافة حساب.":"No accounts. Tap (+) to add an account.","لا توجد سندات":"No vouchers","لا توجد سندات في هذه الفترة":"No vouchers for this period","لا توجد سندات. اضغط (+) للإضافة.":"No vouchers. Tap (+) to add.","لا توجد صناديق أخرى":"No other cash boxes","لا توجد صورة محفوظة لهذه الفاتورة":"No saved image for this invoice","لا توجد عملات":"No currencies","لا توجد عمليات نسخ مسجلة بعد.":"No copy operations recorded yet.","لا توجد فلاتر أسبوعية محفوظة. اضغط (+) لإضافة فلتر.":"No saved weekly filters. Tap (+) to add a filter.","لا توجد فواتير محفوظة في هذا المجلد بعد":"No invoices saved in this folder yet","لا توجد مجلدات":"No folders","لا توجد نسخ مسجلة.":"No copies recorded.","لا نتائج":"No results","لا يوجد مجلدات":"No folders","لكم":"Credit","لكم أو عليكم حسب الرصيد":"Credit or debit depending on the balance","لكم فقط":"Credit only","لكم:":"Credit:","لم يتم العثور على الفلتر الأسبوعي المختار. تحقق من حفظه أولاً.":"The selected weekly filter was not found. Check that it was saved first.","لم يتم العثور على معاملة التفصيل":"Detail transaction not found","لم يُرفق رابط فيديو رسمي. أدخل رابط الشرح المعتمد، أو استخدم البحث عن شرح التطبيق.":"No official video link is attached. Enter the approved tutorial link, or search for an app tutorial.","له":"Credit","له:":"Credit:","لون الثيم":"Theme color","لون النص في الطباعة":"Print text color","مبلغ الحوالة":"Transfer amount","مبلغ العملة":"Currency amount","مبلغ العمولة":"Commission amount","مبلغ:":"Amount:","متعادل":"Balanced","متوازن":"Balanced","متوسط":"Average","مثال: الأسبوع الأول":"Example: First week","مثال: سحب رياض اليافعي":"Example: Riyad Al-Yafai withdrawal","مجلد":"Folder","مجلدات":"Folders","محدد":"Selected","مدير الحسابات":"Account Manager","مسح":"Clear","مسح المجلد":"Delete Folder","مسح جميع البيانات":"Clear All Data","مسلم أسبوع":"Weekly Delivery","مسلم بيع":"Sale Delivered","مسلم فلوس":"Money Delivered","مشاركة أخرى":"More Sharing","مشاركة رابط التطبيق":"Share App Link","مصادقة":"Confirmation","مصادقة حساب —":"Account Confirmation —","مطابق للدولة":"Matches Country","مظهر التطبيق":"App Appearance","معاملة محددة":"Selected Transaction","معاينة الورقة":"Paper Preview","مقدمة الرسالة":"Message Intro","مكان البيع":"Place of Sale","ملاحظات":"Notes","ملاحظات...":"Notes...","ملاحظة":"Note","ملاحظة السحب":"Withdrawal Note","ملاحظة المسلم":"Delivery Note","ملاحظة مسلم أسبوع":"Weekly Delivery Note","ملاحظة:":"Note:","ملف غير صالح أو تعذر حفظه؛ لم تكتمل الاستعادة":"Invalid file or unable to save; restore was not completed","ملونة":"Colored","من تاريخ":"From Date","من حساب":"From Account","من:":"From:","مهندس برمجيات":"Software Engineer","موافق":"OK","ناتج الصرف":"Disbursement Result","نتيجة الحاسبة":"Calculator Result","نحيف":"Thin","نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع":"Please reconcile and confirm the balance below as part of our procedures with all customers and in everyone's best interest","نرجو منكم مطابقة ومصادقة الرصيد أدناه، وذلك كجزء من إجراءاتنا مع كافة العملاء، ولكم منا خالص التقدير.":"Please reconcile and confirm the balance below as part of our procedures with all customers. With sincere appreciation.","نسخ":"Copy","نسخة":"Copy","نسخة فاتورة":"Invoice Copy","نقد الباقي":"Cash Change","نقل":"Transfer","نماذج":"Templates","نموذج إضافة الفاتورة":"Add Invoice Template","نموذج إضافة الفاتورة وجدولها محفوظان ضمن التطبيق. كل فاتورة تُحفظ داخل المجلد الذي أُنشئت فيه، وتدخل ضمن بيانات التطبيق والنسخ الاحتياطي.":"The invoice form and its schedule are saved in the app. Each invoice is saved in the folder where it was created and is included in the app data and backup.","نوع الخط":"Font Type","نوع المعاملة":"Transaction Type","نوع واتساب":"WhatsApp Type","هذا الخيار يغيّر شكل المجلدات فقط، ولا يغيّر عرض الحسابات داخل المجلد.":"This option changes only the appearance of folders; it does not change how accounts are displayed within the folder.","هل أنت متأكد من إلغاء التفصيل؟":"Are you sure you want to cancel the breakdown?","هل أنت متأكد من مسح بيانات هذا الفلتر؟":"Are you sure you want to clear this filter's data?","هل تريد حذف الفاتورة «":"Do you want to delete the invoice «","هللة":"Halala","وأرصتكم لدينا كالتالي":"Your balances with us are as follows","واتساب":"WhatsApp","واتساب الأخضر":"WhatsApp Green","واتساب الأعمال":"WhatsApp Business","واتساب العادي (الأخضر)":"Regular WhatsApp (Green)","وضع التعديل اليدوي مُفعّل":"Manual editing mode is enabled","يمكن تعديل رقم واتساب وبريد الدعم لهذا الجهاز.":"You can edit the WhatsApp number and support email for this device.","يمني":"Yemeni","\u0661. افتح المجلد المطلوب. \u0662. اضغط زر (+) لإضافة فاتورة. \u0663. احفظ بيانات الفاتورة ثم احفظ الجدول. \u0664. اضغط مطولاً على فاتورة محفوظة لإدارة الفاتورة.":"1. Open the desired folder. 2. Tap the (+) button to add an invoice. 3. Save the invoice details, then save the table. 4. Long-press a saved invoice to manage it.","— الصندوق الثابت":"— Fixed Cash Box","↑ تصاعدي":"↑ Ascending","→ رجوع":"→ Back","↓ تنازلي":"↓ Descending","↔ قيد إلى حساب":"↔ Post to Account","↔ نقل":"↔ Transfer","↔ نقل الحساب إلى صندوق آخر":"↔ Transfer Account to Another Cash Box","↔ نقل المحدد":"↔ Transfer Selected","↔ نقل المعاملة إلى حساب آخر":"↔ Transfer Transaction to Another Account","↗️ مشاركة التطبيق":"↗️ Share App","↘️ الخرج فلوس":"↘️ Money Out","− السحب فلوس":"− Cash Withdrawal","− فلوس خرج":"− Money Out","⋯ المزيد":"⋯ More","⏱️ القفل التلقائي":"⏱️ Auto-Lock","⏳ جاري الاستعادة...":"⏳ Restoring...","⏳ جاري القراءة...":"⏳ Reading...","⏳ جارٍ حفظ الصورة في الاستوديو":"⏳ Saving image to gallery","▦ شبكة":"▦ Grid","☀️ فاتح":"☀️ Light","☁️ نسخ احتياطي الآن":"☁️ Back Up Now","☐ تحديد المعاملة":"☐ Select Transaction","☑ إلغاء تحديد":"☑ Deselect","☑ تحديد":"☑ Select","☑ تحديد الكل":"☑ Select All","☑ تحديد الكل في الحساب الحالي":"☑ Select All in Current Account","♻️ استعادة من ملف على الهاتف":"♻️ Restore from a File on Your Phone","⚙️ إعدادات الإرسال العامة":"⚙️ General Sending Settings","⚙️ إعدادات النسخ الاحتياطي":"⚙️ Backup Settings","⚠️ أدخل اسم التفصيل":"⚠️ Enter a detail name","⚠️ اختر تاريخ البداية":"⚠️ Select a start date","⚠️ اختر تاريخ النهاية":"⚠️ Select an end date","⚠️ اسم التفصيل مطلوب":"⚠️ Detail name is required","⚠️ التاريخ إلى مطلوب":"⚠️ End date is required","⚠️ التاريخ من مطلوب":"⚠️ Start date is required","⚠️ تاريخ البداية يجب أن يكون قبل أو يساوي تاريخ النهاية":"⚠️ Start date must be before or equal to the end date","⚠️ غير مدعوم":"⚠️ Not supported","⚪ غير مفعّل":"⚪ Disabled","✅ تم تحديث التفصيل":"✅ Detail updated","✅ تم حفظ إعدادات الرسائل والواتساب":"✅ Message and WhatsApp settings saved","✅ تم حفظ التفصيل":"✅ Detail saved","✅ مسموح":"✅ Allowed","✍️ صيغة الرسائل":"✍️ Message Format","✏️ تخصيص نماذج الرسائل":"✏️ Customize Message Templates","✏️ تعديل":"✏️ Edit","✏️ تعديل اسم الصندوق":"✏️ Edit Cash Box Name","✏️ تعديل الحساب":"✏️ Edit Account","✏️ تعديل السند":"✏️ Edit Voucher","✏️ تعديل المعاملة":"✏️ Edit Transaction","✏️ تم تحميل التفصيل للتعديل":"✏️ Detail loaded for editing","✓ الحالية":"✓ Current","❌ تعذّر":"❌ Failed","❌ رمز خطأ":"❌ Error Code","❌ مرفوض":"❌ Rejected","❤️ عليكم — إرسال":"❤️ Debit — Send","❤️ عليكم — قيد على الحساب":"❤️ Debit — Post to Account","➕ صندوق جديد":"➕ New Cash Box","⬇️ تنزيل نسخة احتياطية إلى الهاتف":"⬇️ Download a backup to phone","⭐ تعيين كافتراضي":"⭐ Set as default","＋ إضافة حساب":"＋ Add account","＋ إضافة سطر":"＋ Add line","＋ إضافة فاتورة إلى مجلد":"＋ Add invoice to folder","＋ حساب جديد...":"＋ New account...","🌍 مفتاح الدولة":"🌍 Country code","🌐 اختيار من القائمة":"🌐 Select from list","🌙 داكن":"🌙 Dark","🌫️ الظلال":"🌫️ Shadows","🏅 لون الإطار":"🏅 Frame color","🏦 فلوس سحب":"🏦 Withdrawal funds","👁 رؤية السند":"👁 View voucher","👁 عرض":"👁 View","👆 تم إلغاء":"👆 Canceled","👆 فتح بالبصمة":"👆 Unlock with fingerprint","👨‍💻 المطوّر":"👨‍💻 Developer","💬 نوع الواتساب المستخدم":"💬 WhatsApp type in use","💬 واتساب الأخضر":"💬 WhatsApp Messenger","💰 الإحصائيات":"💰 Statistics","💰 المسلمه فلوس":"💰 Funds handed over","💱 حساب العملة":"💱 Currency account","💼 واتساب الأعمال":"💼 WhatsApp Business","💾 حفظ":"💾 Save","💾 حفظ الإعدادات":"💾 Save settings","💾 حفظ الملف":"💾 Save file","💾 حفظ الملف الشخصي":"💾 Save profile","💾 حفظ للاستوديو":"💾 Save to gallery","📄 طباعة كشف الحساب":"📄 Print account statement","📅 تعديل التاريخ والوقت":"📅 Edit date and time","📋 تم":"📋 Done","📋 سجل النسخ الاحتياطي":"📋 Backup history","📋 قائمة":"📋 List","📋 نسخ":"📋 Copy","📋 نسخ الحساب إلى صندوق آخر":"📋 Copy account to another cashbox","📋 نسخ المحدد":"📋 Copy selected","📋 نسخ المعاملة إلى حساب آخر":"📋 Copy transaction to another account","📎 فتح الصورة المرفقة":"📎 Open attached image","📐 حجم الصورة":"📐 Image size","📐 سمك الإطار":"📐 Frame thickness","📑 تفصيل":"📑 Details","📒 دفتر الحركات":"📒 Transaction ledger","📝 التنويه":"📝 Note","📝 تفصيل جديد":"📝 New detail","📝 طباعة مصادقة الحساب":"📝 Print account confirmation","📝 طباعة مصادقة حساب للفترة المحددة":"📝 Print account confirmation for selected period","📝 طباعة مصادقة للفترة المحددة":"📝 Print confirmation for selected period","📝 مشاركة كنص":"📝 Share as text","📝 مقدمة الرسالة وخاتمتها":"📝 Message opening and closing","📞 تواصل معنا":"📞 Contact us","📞 للتواصل":"📞 Contact","📤 إرسال الآن":"📤 Send now","📤 تأكيد إرسال الرسالة":"📤 Confirm sending message","📤 حواله":"📤 Transfer","📤 رفع":"📤 Upload","📤 مشاركة":"📤 Share","📤 مشاركة ملف النسخة الاحتياطية":"📤 Share backup file","📥 توريد":"📥 Deposit","📥 صندوق ثابت لاستلام سندات الدين من التفصيل":"📥 Fixed cashbox for receiving debt vouchers from details","📦 النسخ الاحتياطي على الهاتف والملفات":"📦 Back up to phone and files","📨 إرسال الرسائل النصية":"📨 Send text messages","📨 محتوى الرسالة":"📨 Message content","📷 الصورة المرفقة":"📷 Attached image","📷 حفظ صورة السند":"📷 Save voucher image","📷 صورة البياع -":"📷 Seller's photo -","🔄 ترحيل":"🔄 Post","🔄 تغيير الرمز":"🔄 Change code","🔍 بحث سريع":"🔍 Quick search","🔒 إغلاق التعديل اليدوي":"🔒 Turn off manual editing","🔒 المجلد مقفل":"🔒 Folder is locked","🔒 تفعيل قفل التطبيق":"🔒 Enable app lock","🔒 قفل":"🔒 Lock","🔒 قفل المجلد":"🔒 Lock folder","🔒 مقفل":"🔒 Locked","🔓 إزالة القفل":"🔓 Unlock","🔓 تعديل أي بيانات":"🔓 Edit any data","🔓 طلب":"🔓 Request","🔓 فتح":"🔓 Open","🔘 شكل الأزرار":"🔘 Button style","🔢 قفل برمز سري":"🔢 Lock with passcode","🔢 مفتاح الخط للرسائل النصية":"🔢 Text message font key","🕒 إلى المراقب":"🕒 Until","🖨 طباعة":"🖨 Print","🖨️ طباعة السند":"🖨️ Print voucher","🖨️ طباعة سند المعاملة":"🖨️ Print transaction voucher","🖨️ طباعة كشف للفترة المحددة":"🖨️ Print statement for selected period","🖼️ الخلفية":"🖼️ Background","🖼️ فتح الصورة المرفقة":"🖼️ Open attached image","🖼️ مشاركة كصورة":"🖼️ Share as image","🗑 تصفير بيانات الصرافة":"🗑 Clear reset data","🗑 حذف":"🗑 Delete","🗑 حذف الحساب":"🗑 Delete account","🗑 حذف الرمز":"🗑 Delete code","🗑 حذف السند":"🗑 Delete voucher","🗑 حذف الصورة":"🗑 Delete image","🗑 حذف المجلد":"🗑 Delete folder","🗑 حذف المحدد":"🗑 Delete selected","🗑 مسح":"🗑 Clear","🗑️ إفراغ السلة نهائيًا":"🗑️ Empty trash permanently","🗑️ حذف الحساب":"🗑️ Delete account","🗑️ حذف المحدد":"🗑️ Delete selected","🗑️ حذف المعاملة":"🗑️ Delete transaction","🧾 ربط الفواتير بالتطبيق":"🧾 Link invoices to the app","عليكم:":"Debit:","أدخل المبلغ":"Enter amount","إدارة صلاحيات التطبيق":"Manage app permissions","إرسال الرسائل":"Send messages","إضافة مجلد":"Add folder","إلى":"To","اختار تخصيص":"Choose customization","اختر التقرير أو العملية المطلوبة":"Choose the required report or transaction","اسم الأسبوع":"Week name","اكتب \"حذف\" للتأكيد":"Type \"Delete\" to confirm","التطبيق مقفل":"App is locked","الحسابات":"Accounts","الخلفية والإطارات والأزرار":"Backgrounds, frames, and buttons","المراقب":"Clock","السندات":"Vouchers","الصناديق":"Cash boxes","الفواتير":"Invoices","الكشف الكامل":"Full statement","المزيد":"More","النسخ الاحتياطي لجوجل درايف":"Google Drive backup","النسخ الاحتياطي والاستعادة":"Backup and restore","تأكيد الإرسال":"Confirm sending","تاريخ بداية الأسبوع":"Week start date","تاريخ نهاية الأسبوع":"Week end date","تحويل الشراء":"Purchase transfer","تخصيص التطبيق":"Customize app","تخصيص شامل لجميع صفحات التطبيق":"Customize all app pages","ترتيب الأسبوع":"Week order","تواصل معنا":"Contact us","حفظ والعودة إلى الإعدادات":"Save and return to settings","حوالات البيع":"Sales transfers","سياسة الخصوصية":"Privacy policy","سيتم حذف":"Will be deleted","شرح التطبيق على اليوتيوب":"App tutorial on YouTube","شروط الخدمة":"Terms of service","صفر محلي":"Local zero","صورة الأسبوع":"Week image","عن التطبيق":"About the app","فتح صفحة الكشف الكامل":"Open full statement page","فتح صفحة تحويل الشراء":"Open purchase transfer page","فتح صفحة حوالات البيع":"Open sales transfers page","قفل التطبيق":"Lock app","كل شيء نهائياً":"Everything permanently","لا يمكن التراجع.":"Cannot be undone.","لـه":"For him","مشاركة التطبيق":"Share app","يمكنك كتابة أكثر من سطر في البيان":"You can write more than one line in the description","• المجلدات • الحسابات • العمليات • السلة • الإعدادات":"• Folders • Accounts • Transactions • Trash • Settings","☑ الكل":"☑ All","⚠️ تحذير — مسح جميع البيانات":"⚠️ Warning — Erase all data","👁️ عرض الفاتورة":"👁️ View invoice","💾 حفظ نسخة":"💾 Save a copy","📅 التاريخ":"📅 Date","📦 نقل":"📦 Move","📷 عرض صورة البياع":"📷 View the seller's photo","🔤 الأبجدية":"🔤 Alphabetical","🔴 شرح":"🔴 Tutorial","🖨️ طباعة":"🖨️ Print","🗑 حذف نهائي":"🗑 Delete permanently","🗑️ حذف الفاتورة":"🗑️ Delete invoice","🗓️ إضافة أسبوع جديد":"🗓️ Add a new week","🧾 خيارات الفاتورة":"🧾 Invoice options","ريال عماني":"Omani rial","ر.ي":"YER","ر.س":"SAR","ر.ع":"OMR","د.إ":"AED","الصافي":"Net"};
  var STOP={'من':1,'في':1,'إلى':1,'الا':1,'أو':1,'مع':1,'ثم':1,'هو':1,'هي':1,'هذا':1,'هذه':1,'كان':1,'لا':1,'ما':1,'و':1};
  var common=['حساب','حسابات','الصندوق','صندوق','التفصيل','تفصيل','الفاتورة','فاتورة','السند','سند','الديون','دين','العملات','العملة','المبلغ','المتبقي','الرصيد','الاسم','الرقم','التاريخ','تاريخ','الأسبوع','الأسبوعي','الفلتر','فلتر','البداية','النهاية','المبيعات','المصادقة','الكشف','المراقب','القبض','الصرف','سحب','الإضافة','الحفظ','حذف','تعديل','إرسال','تأكيد','إلغاء','الرئيسية','الإعدادات','اللغة','المظهر','الثيم','الخط','الرسائل','الواتساب','المجلد','المجلدات','لكم','عليكم','له','عليه','ر.ي','ر.س','ر.ع','د.إ','الصافي','متعادل'];
  var exact=Object.assign({},I18N);
  var phrases=[];
  Object.keys(I18N).forEach(function(k){if(/[\u0600-\u06ff]/.test(k)&&(/[\s:：،؛!?؟]/.test(k)||k.replace(/[^\u0600-\u06ff]/g,'').length>=7)&&!STOP[k])phrases.push(k);});
  common.forEach(function(k){if(I18N[k]&&!phrases.includes(k))phrases.push(k);});
  phrases.sort(function(a,b){return b.length-a.length;});
  var textStates=new WeakMap(),attrStates=new WeakMap(),observedDocs=new WeakSet(),hookedFrames=new WeakSet();
  var lang='ar';
  function escapeRx(x){return x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
  function tr(raw){
    raw=String(raw==null?'':raw);if(lang!=='en'||!/[\u0600-\u06ff]/.test(raw))return raw;
    var lead=(raw.match(/^\s*/)||[''])[0],trail=(raw.match(/\s*$/)||[''])[0],core=raw.slice(lead.length,raw.length-trail.length||undefined);
    if(Object.prototype.hasOwnProperty.call(exact,core))return lead+exact[core]+trail;
    var out=raw;
    phrases.forEach(function(k){
      if(!k||!out.includes(k))return;
      var replacement=String(I18N[k]||'');if(!replacement)return;
      var rx=new RegExp('(^|[^\\u0600-\\u06ff])'+escapeRx(k)+'(?=$|[^\\u0600-\\u06ff])','g');
      out=out.replace(rx,function(_,pre){return pre+replacement;});
    });
    return out;
  }
  function userTextNode(n){
    var p=n&&n.parentElement;if(!p)return true;
    if(p.closest('script,style,noscript,textarea,code,pre,svg,[contenteditable="true"],[data-user-content],.pname,.folder-card-name,.td-note,.account-name,.customer-name,.person-name,.profile-name,.invoice-name,.detail-name,.user-content,.nm,.sub'))return false;
    if(p.closest('input'))return false;
    return true;
  }
  function processText(n){
    if(!n||n.nodeType!==3||!userTextNode(n))return;
    var cur=n.nodeValue||'',st=textStates.get(n);
    if(st&&cur===st.last){
      if(st.lang!==lang){var next=lang==='en'?tr(st.original):st.original;st.lang=lang;st.last=next;if(cur!==next)n.nodeValue=next;}
      return;
    }
    st={original:cur,lang:lang,last:cur};textStates.set(n,st);
    var next=lang==='en'?tr(cur):cur;st.last=next;if(next!==cur)n.nodeValue=next;
  }
  var ATTRS=['placeholder','title','aria-label','alt','value'];
  function processAttrs(el){
    if(!el||el.nodeType!==1)return;
    var st=attrStates.get(el)||{};
    ATTRS.forEach(function(a){if(!el.hasAttribute(a))return;if(a==='value'&&(el.tagName!=='INPUT'||!(/^(button|submit|reset)$/i.test(el.type||''))))return;var cur=el.getAttribute(a)||'',x=st[a];
      if(x&&cur===x.last){if(x.lang!==lang){var next=lang==='en'?tr(x.original):x.original;x.lang=lang;x.last=next;if(cur!==next)el.setAttribute(a,next);}return;}
      x={original:cur,last:cur,lang:lang};st[a]=x;var next=lang==='en'?tr(cur):cur;x.last=next;if(next!==cur)el.setAttribute(a,next);
    });
    attrStates.set(el,st);
  }
  function translateTree(root,doc){
    if(!root)return;
    if(root.nodeType===3){processText(root);return;}
    if(root.nodeType===1)processAttrs(root);
    var walker=doc.createTreeWalker(root,doc.defaultView.NodeFilter.SHOW_TEXT);
    var n;while((n=walker.nextNode()))processText(n);
    if(root.querySelectorAll)root.querySelectorAll('[placeholder],[title],[aria-label],[alt],input[type="button"][value],input[type="submit"][value],input[type="reset"][value]').forEach(processAttrs);
  }
  function computed(name,fallback){try{return getComputedStyle(document.documentElement).getPropertyValue(name).trim()||fallback;}catch(e){return fallback;}}
  function setRootPrefs(doc){
    try{
      var html=doc.documentElement,body=doc.body;if(!html)return;
      var dir=lang==='en'?'ltr':'rtl',theme=data.settings.dark?'dark':'light';
      if(body)applyDesignToDoc(doc);
      if(html.getAttribute('lang')!==lang)html.setAttribute('lang',lang);
      if(html.getAttribute('dir')!==dir)html.setAttribute('dir',dir);
      if(html.getAttribute('data-app-theme')!==theme)html.setAttribute('data-app-theme',theme);
      html.style.setProperty('--primary',computed('--primary','#1e40af'));
      html.style.setProperty('--primary-dark',computed('--primary-dark','#1e3a8a'));
      html.style.setProperty('--primary-light',computed('--primary-light','rgba(30,64,175,.12)'));
      html.style.setProperty('--accent',computed('--primary','#1e40af'));
      html.style.setProperty('--accent-light',computed('--primary-light','rgba(30,64,175,.12)'));
      html.style.setProperty('--primary-rgb',computed('--primary-rgb','30,64,175'));
      html.style.setProperty('--app-font',computed('--app-font',"'Tajawal',Arial,sans-serif"));
      html.style.setProperty('--app-font-weight',computed('--app-font-weight','500'));
      html.style.setProperty('--base-font-size',computed('--base-font-size','16px'));
      var ap=(typeof data!=='undefined'&&data.settings&&data.settings.appearance)||{};
      var acm={gold:'#b08a36',silver:'#8b929b',copper:'#a76542'},awm={thin:'1px',medium:'2px',thick:'3px'},arm={square:'0px',soft:'6px',rounded:'14px',round:'24px',pill:'999px',circle:'50%'},asm={solid:'solid',dashed:'dashed',dotted:'dotted',double:'double',groove:'groove',ridge:'ridge',inset:'inset',outset:'outset'},abm={classic:'8px',rounded:'14px',simple:'3px'};
      /* الأزرار الأربعة (لون/شكل/نمط/سمك): عند الإيقاف تعود إلى القيمة الافتراضية في كل التطبيق */
      var themeFc=/^#[0-9a-f]{6}$/i.test(String(data.settings.color||''))?String(data.settings.color):'#1e40af';
      var afc=String(ap.frameColor||'gold');if(afc==='theme')afc=themeFc;else if(!/^#[0-9a-f]{6}$/i.test(afc))afc=acm[afc]||acm.gold;
      if(ap.frameColorEnabled===false)afc=themeFc;
      var fthOn=ap.frameThicknessEnabled!==false,frOn=ap.frameShapeEnabled!==false,fstOn=ap.frameStyleEnabled!==false;
      html.style.setProperty('--custom-frame-color',afc);html.style.setProperty('--custom-frame-width',fthOn?(awm[ap.frameThickness]||awm.thin):awm.thin);html.style.setProperty('--custom-frame-radius',frOn?(arm[ap.frameShape]||arm.rounded):'14px');html.style.setProperty('--custom-frame-style',fstOn?(asm[ap.frameStyle]||'solid'):'solid');html.style.setProperty('--custom-button-radius',abm[ap.buttonShape]||abm.classic);
      html.style.colorScheme=data.settings.dark?'dark':'light';
      if(body){body.classList.toggle('dark',!!data.settings.dark);body.classList.toggle('app-en',lang==='en');}
      doc.querySelectorAll('meta[name="theme-color"]').forEach(function(m){m.setAttribute('content',data.settings.dark?'#0f172a':(data.settings.color||'#1e40af'));});
    }catch(e){}
  }
  function injectPrefsStyle(doc){
    try{
      var h=doc.head||doc.documentElement;if(!h)return;
      var id='global-app-preferences-style',st=doc.getElementById(id);if(!st){st=doc.createElement('style');st.id=id;h.appendChild(st);}
      st.textContent='*{font-family:var(--app-font)!important}body{font-weight:var(--app-font-weight,500)!important}button,input,select,textarea{font:inherit!important}html,body{font-size:var(--base-font-size,16px)!important}html[lang="en"],html[lang="en"] body{direction:ltr!important}html[lang="en"] [dir="rtl"]{direction:ltr!important;text-align:left!important}html[lang="en"] .pname,html[lang="en"] .folder-card-name,html[lang="en"] .td-note{direction:auto!important}html[data-app-theme="dark"] body{--bg:#0f172a;--bg2:#1e293b;--text:#f1f5f9;--text2:#cbd5e1;--muted:#94a3b8;--line:#334155;background:#0f172a!important;color:#f1f5f9!important}html[data-app-theme="dark"] body :is(.card,.panel,.box,.section,.sheet,.modal,.form-section,.invoice-card,.filter-panel,.settings-card,.account-card,.table-wrap,.toolbar,.header,.footer){background:#1e293b!important;color:#f1f5f9!important;border-color:#334155!important}html[data-app-theme="dark"] body :is(input,select,textarea){background:#0f172a!important;color:#f1f5f9!important;border-color:#475569!important}html[data-app-theme="dark"] body :is(h1,h2,h3,h4,label,strong,b){color:#f1f5f9!important}html[data-app-theme="dark"] body :is(table,th,td){border-color:#334155!important} .material-icons,.material-icons-outlined,.material-symbols-outlined,.fa,.fas,.far,.fab,[class^="fa-"],[class*=" fa-"]{font-family:initial!important}';
      st.textContent+=`html,body{--ui-bar-bg:linear-gradient(135deg,var(--primary,#1e40af),var(--primary-dark,#1e3a8a));--app-accent:var(--primary,#1e40af)}
body :is(.top,.bottom-bar,.selection-bar,.op-toolbar,.statement-header,.filter-bar,.date-bar,.toolbar,.header,.footer,.ui-appbar,.subTop,.voucher-header,.page-header){background:var(--ui-bar-bg)!important;background-color:var(--primary,#1e40af)!important;color:#fff!important;border-color:var(--primary-dark,#1e3a8a)!important}
body :is([class$="-bar"],[class$="Bar"],.navbar,.tabbar,.page-header,.app-header,.section-header,.totals-bar,.summary-bar,.statement-footer,.currency-row,.filterbar){background:var(--ui-bar-bg)!important;background-color:var(--primary,#1e40af)!important;color:#fff!important;border-color:var(--primary-dark,#1e3a8a)!important}
body :is([class$="-bar"],[class$="Bar"],.navbar,.tabbar,.page-header,.app-header,.section-header,.totals-bar,.summary-bar,.statement-footer,.currency-row,.filterbar) :is(svg,.material-icons,.material-icons-outlined,.material-symbols-outlined,.fa,.fas,.far,[class^="icon"],[class*=" icon"]){color:#fff!important;fill:#fff!important;stroke:#fff!important}
body :is(.fab,.primary,.btn-primary,.save-account,.v-btn-save,.action-btn,.toolbar button,.header button,.date-bar button,.filter-bar button){background:var(--ui-bar-bg)!important;background-color:var(--primary,#1e40af)!important;color:#fff!important;border-color:var(--primary,#1e40af)!important}
body button.action-btn,body button.primary,body button.btn-primary,body button.save-account,body button.v-btn-save,body .toolbar button,body .header button{color:#fff!important;-webkit-text-fill-color:#fff!important}
body :is(.icon,.fa,.fas,.far,.material-icons,.material-icons-outlined,.material-symbols-outlined,svg,svg *){color:var(--primary,#1e40af)!important;fill:var(--primary,#1e40af)!important;stroke:var(--primary,#1e40af)!important}
body :is(.top,.bottom-bar,.selection-bar,.op-toolbar,.statement-header,.filter-bar,.date-bar,.toolbar,.header,.footer,.ui-appbar,.subTop,.voucher-header,.page-header) :is(.icon,.fa,.fas,.far,.material-icons,.material-icons-outlined,.material-symbols-outlined,svg,svg *){color:#fff!important;fill:#fff!important;stroke:#fff!important}
html[data-app-theme="dark"] body :is(.card,.panel,.box,.section,.sheet,.modal,.form-section,.invoice-card,.filter-panel,.settings-card,.account-card,.table-wrap,.content){background:var(--bg2,#1e293b)!important;color:var(--text,#f1f5f9)!important;border-color:var(--line,#334155)!important}
html[data-app-theme="dark"] body :is(input,select,textarea){background:#0f172a!important;color:#f1f5f9!important;border-color:#475569!important}

body :is(.person,.folder-card-v2,.folder-card,.sheet,.settingsCard,.settingsMenu,.settingsItem,.account-modal,.voucher-modal,.voucher-actions,.sm-item,.currency-card,.currency-toggle-card,.field input,.field select,.field textarea,.smallInput,.optionRow,.choice,.radioLabel,.filter-bar,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.table-wrap,.search-box,.search-input,.form-control,.input-group,.settings-titlebar,.settings-header,.settingsSub-header,.top,.bottom-bar,.statement-header,.selection-bar,.op-toolbar,.toolbar,.action-bar,.statement-table,.statement-table th,.statement-table td,.folder-card-icon){border-color:var(--custom-frame-color,#b08a36)!important;border-width:var(--custom-frame-width,1px)!important;border-style:var(--custom-frame-style,solid)!important}
body :is(.person,.folder-card-v2,.folder-card,.sheet,.settingsCard,.settingsMenu,.account-modal,.voucher-modal,.currency-card,.currency-toggle-card,.field input,.field select,.field textarea,.smallInput,.optionRow,.choice,.radioLabel,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.table-wrap,.search-box,.search-input,.form-control,.input-group,.folder-card-icon){border-radius:var(--custom-frame-radius,14px)!important}
body :is(button,.btn,.settingsItem,.radioLabel,.optionRow,.quick-btn-new,.primary,.save-account,.v-btn-save,.fab){border-radius:var(--custom-button-radius,8px)!important}

body.glass-classic{--glass-surface:rgba(255,255,255,.46);--glass-surface-strong:rgba(255,255,255,.62);--glass-outline:rgba(255,255,255,.78);--glass-shadow:0 20px 42px rgba(26,36,51,.18),inset 0 1px 0 rgba(255,255,255,.95);background-color:#dce5ef!important;background-image:radial-gradient(ellipse at 12% 8%,rgba(69,106,157,.30),transparent 44%),radial-gradient(ellipse at 88% 82%,rgba(176,138,54,.34),transparent 45%),linear-gradient(135deg,rgba(198,211,228,.52),rgba(237,228,207,.46),rgba(206,218,233,.52)),var(--custom-background-image,none)!important;background-size:cover,cover,cover,cover!important;background-attachment:fixed!important}
body.glass-classic :is(.person,.folder-card-v2,.folder-card,.sheet,.settingsCard,.settingsMenu,.settingsItem,.account-modal,.voucher-modal,.voucher-actions,.currency-card,.currency-toggle-card,.optionRow,.radioLabel,.choice,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.box,.section,.table-wrap,.search-box,.input-group,.filter-panel,.invoice-card,.account-card,.purchase-card-content,.tsC,.tsBox){background:var(--glass-surface)!important;backdrop-filter:blur(22px) saturate(155%)!important;-webkit-backdrop-filter:blur(22px) saturate(155%)!important;border-color:var(--custom-frame-color,rgba(176,138,54,.56))!important;box-shadow:var(--glass-shadow)!important}
body.glass-classic :is(input,select,textarea,.smallInput,.search-input,.form-control){background:var(--glass-surface-strong)!important;backdrop-filter:blur(14px)!important;-webkit-backdrop-filter:blur(14px)!important;border-color:var(--custom-frame-color,rgba(176,138,54,.45))!important}
body.glass-classic :is(.top,.bottom-bar,.selection-bar,.op-toolbar,.statement-header,.filter-bar,.date-bar,.toolbar,.header,.footer,.ui-appbar,.subTop,.voucher-header,.page-header,.navbar,.tabbar){box-shadow:0 8px 22px rgba(21,34,55,.18),inset 0 1px 0 rgba(255,255,255,.3)!important;border-bottom:1px solid rgba(255,255,255,.35)!important}
body.glass-classic :is(button,.btn,.fab,.action-btn,.primary,.btn-primary,.quick-btn-new,.tsAct button){box-shadow:0 4px 12px rgba(20,32,52,.12),inset 0 1px 0 rgba(255,255,255,.30)}
html[data-app-theme="dark"] body.glass-classic,body.dark.glass-classic{--glass-surface:rgba(20,30,47,.72);--glass-surface-strong:rgba(15,23,42,.82);--glass-outline:rgba(255,255,255,.12);--glass-shadow:0 14px 32px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.08);background-color:#111827!important;background-image:radial-gradient(ellipse at 12% 4%,rgba(255,255,255,.08),transparent 40%),radial-gradient(ellipse at 92% 90%,rgba(176,138,54,.10),transparent 38%),var(--custom-background-image,none)!important}
html[data-app-theme="dark"] body.glass-classic :is(.person,.folder-card-v2,.folder-card,.sheet,.settingsCard,.settingsMenu,.settingsItem,.account-modal,.voucher-modal,.voucher-actions,.currency-card,.currency-toggle-card,.optionRow,.radioLabel,.choice,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.box,.section,.table-wrap,.search-box,.input-group,.filter-panel,.invoice-card,.account-card,.purchase-card-content,.tsC,.tsBox){background:var(--glass-surface)!important;color:var(--text,#f1f5f9)!important;border-color:var(--custom-frame-color,rgba(255,255,255,.14))!important;box-shadow:var(--glass-shadow)!important}
body.custom-shadows-off.glass-classic :is(.person,.folder-card-v2,.folder-card,.sheet,.settingsCard,.settingsMenu,.settingsItem,.account-modal,.voucher-modal,.currency-card,.card,.panel,.table-wrap){box-shadow:none!important}

/* Native viewport sizing for reliable phone and tablet layout */


/* Full frame coverage: cards, transactions, account/cashbox panels, bars, and icon holders */
body :is(
.person,.folder-card-v2,.folder-card,.folder-card-icon,.sheet,.settingsCard,.settingsMenu,.settingsItem,
.account-modal,.voucher-modal,.voucher-header,.voucher-actions,.sm-item,.side-menu,.side-menu-footer,
.currency-card,.currency-toggle-card,.field input,.field select,.field textarea,.smallInput,.optionRow,.choice,.radioLabel,
.filter-bar,.date-bar,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.table-wrap,
.search-box,.search-input,.form-control,.input-group,.settings-titlebar,.settings-header,.settingsSub-header,.top,
.statement-header,.selection-bar,.op-toolbar,.toolbar,.action-bar,.statement-table,.statement-table th,.statement-table td,
.top-icon-btn,.siIcon,.navIcon,.purchase-icon,.purchase-header-icon,.voucher-row,.voucher-balance-bar,.tsC,.tsBox,
.purchase-card,.purchase-header,.purchase-grid,
[class*="transaction"],[class*="Transaction"],[class*="invoice"],[class*="Invoice"],
[class*="account"],[class*="Account"],[class*="cashbox"],[class*="Cashbox"],[class*="cashBox"],[class*="cash-box"],
[class*="currency"],[class*="Currency"],[class*="bar"],[class*="Bar"],
[class*="icon"],[class*="Icon"],[class*="box"],[class*="Box"],[class*="card"],[class*="Card"],
[class*="row"],[class*="Row"],[class*="toolbar"],[class*="Toolbar"],[class*="chip"],[class*="Chip"],
[class*="voucher"],[class*="Voucher"],[class*="operation"],[class*="Operation"],[class*="navIcon"],[class*="siIcon"]
):not([class*="content"]):not([class*="Content"]):not([class*="title"]):not([class*="Title"]):not([class*="text"]):not([class*="Text"]):not([class*="label"]):not([class*="Label"]):not(.toast){
 border-color:var(--custom-frame-color,var(--primary))!important;
 border-width:var(--custom-frame-width,1px)!important;
 border-style:var(--custom-frame-style,solid)!important;
}
body :is(
.person,.folder-card-v2,.folder-card,.folder-card-icon,.sheet,.settingsCard,.settingsMenu,.account-modal,.voucher-modal,
.voucher-header,.voucher-actions,.sm-item,.side-menu,.side-menu-footer,.currency-card,.currency-toggle-card,.optionRow,.choice,
.radioLabel,.filter-bar,.date-bar,.modal-content,.dialog,.popup,.dropdown-menu,.menu-panel,.list-item,.card,.panel,.table-wrap,
.search-box,.input-group,.settings-titlebar,.settings-header,.settingsSub-header,.top,.statement-header,.selection-bar,.op-toolbar,
.toolbar,.action-bar,.statement-table,.top-icon-btn,.siIcon,.navIcon,.purchase-icon,.purchase-header-icon,.voucher-row,
.voucher-balance-bar,.tsC,.tsBox,.purchase-card,.purchase-header,.purchase-grid,
[class*="transaction"],[class*="Transaction"],[class*="invoice"],[class*="Invoice"],
[class*="account"],[class*="Account"],[class*="cashbox"],[class*="Cashbox"],[class*="cashBox"],[class*="cash-box"],
[class*="currency"],[class*="Currency"],[class*="bar"],[class*="Bar"],[class*="icon"],[class*="Icon"],
[class*="box"],[class*="Box"],[class*="card"],[class*="Card"],[class*="row"],[class*="Row"],
[class*="toolbar"],[class*="Toolbar"],[class*="chip"],[class*="Chip"],[class*="voucher"],[class*="Voucher"],
[class*="operation"],[class*="Operation"]
):not(button):not([role="button"]):not(.btn):not(.fab):not(.primary):not(.quick-btn-new):not(.save-account):not(.v-btn-save):not(.toast):not([class*="content"]):not([class*="Content"]):not([class*="title"]):not([class*="Title"]):not([class*="text"]):not([class*="Text"]):not([class*="label"]):not([class*="Label"]){
 border-radius:var(--custom-frame-radius,14px)!important;
}

/* Frame color, width and pattern also cover every control; button corner style stays separately configurable. */
body :is(button,input,select,textarea,[role="button"],[role="tab"],[role="menuitem"]){border-color:var(--custom-frame-color,var(--primary))!important;border-width:var(--custom-frame-width,1px)!important;border-style:var(--custom-frame-style,solid)!important}
body :is(input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),select,textarea){border-radius:var(--custom-frame-radius,14px)!important}

html body :is(button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],.btn):not([data-preserve-button-shape]){border-radius:var(--custom-button-radius,8px)!important}
`;
    }catch(e){}
  }
  function processDoc(doc,isFrame){
    if(!doc||!doc.documentElement)return;
    setRootPrefs(doc);if(isFrame)injectPrefsStyle(doc);
    translateTree(doc.documentElement,doc);
    scanFrames(doc);
    if(observedDocs.has(doc))return;observedDocs.add(doc);
    try{
      var pending=false;
      new MutationObserver(function(records){
        var rootChanged=false;
        records.forEach(function(r){if(r.type==='characterData')processText(r.target);else if(r.type==='attributes'){if(r.target===doc.documentElement||r.target===doc.body)rootChanged=true;else processAttrs(r.target);}else r.addedNodes&&r.addedNodes.forEach(function(n){translateTree(n,doc);});});
        if(rootChanged)setRootPrefs(doc);
        if(!pending){pending=true;setTimeout(function(){pending=false;translateTree(doc.documentElement,doc);scanFrames(doc);},0);}
      }).observe(doc.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['placeholder','title','aria-label','alt','value','dir','lang','class']});
    }catch(e){}
  }
  function hookFrame(fr){
    if(!fr||hookedFrames.has(fr))return;hookedFrames.add(fr);
    fr.addEventListener('load',function(){try{processDoc(fr.contentDocument,true);}catch(e){}});
    try{if(fr.contentDocument&&fr.contentDocument.documentElement)processDoc(fr.contentDocument,true);}catch(e){}
  }
  function scanFrames(doc){try{doc.querySelectorAll('iframe').forEach(hookFrame);}catch(e){}}
  window.__applyGlobalAppPreferences=function(){
    try{lang=(data.settings.lang==='en'?'en':'ar');processDoc(document,false);scanFrames(document);}
    catch(e){console.warn('Global preferences could not be applied',e);}
  };
  // Keep native confirmation dialogs in the selected UI language as well.
  ['alert','confirm','prompt'].forEach(function(name){try{var raw=window[name];if(typeof raw!=='function'||raw.__appI18nWrapped)return;var wrapped=function(message){var args=Array.prototype.slice.call(arguments);if(args.length)args[0]=tr(args[0]);return raw.apply(window,args);};wrapped.__appI18nWrapped=true;window[name]=wrapped;}catch(e){}});
  window.__applyGlobalAppPreferences();
  var appRoot=document.documentElement;
  if(appRoot&&!observedDocs.has(document))processDoc(document,false);
})();

/* source script: western-digit-enforcement */
(function(){
  'use strict';
  var arabicDigits=/[\u0660-\u0669\u06F0-\u06F9\u066B\u066C]/;
  function toWestern(value){
    return String(value==null?'':value)
      .replace(/[\u0660-\u0669\u06F0-\u06F9]/g,function(ch){var c=ch.charCodeAt(0);return String.fromCharCode(c>=0x06F0&&c<=0x06F9?c-0x06F0+48:c-0x0660+48);})
      .replace(/\u066B/g,'.').replace(/\u066C/g,',');
  }
  function normalizeObject(value,seen){
    if(typeof value==='string')return toWestern(value);
    if(!value||typeof value!=='object')return value;
    seen=seen||new WeakSet();if(seen.has(value))return value;seen.add(value);
    if(Array.isArray(value)){for(var i=0;i<value.length;i++)value[i]=normalizeObject(value[i],seen);return value;}
    Object.keys(value).forEach(function(k){try{value[k]=normalizeObject(value[k],seen);}catch(e){}});
    return value;
  }
  function normalizeText(node){
    if(!node||node.nodeType!==3||!arabicDigits.test(node.nodeValue||''))return;
    var p=node.parentElement;if(p&&p.closest&&p.closest('script,style'))return;
    node.nodeValue=toWestern(node.nodeValue);
  }
  function normalizeControl(el){
    if(!el||!(/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName||'')))return;
    try{
      var old=el.value,newValue=toWestern(old);if(old===newValue)return;
      var a=null,b=null;try{a=el.selectionStart;b=el.selectionEnd;}catch(e){}
      el.value=newValue;
      try{if(a!==null&&b!==null&&el.setSelectionRange)el.setSelectionRange(toWestern(old.slice(0,a)).length,toWestern(old.slice(0,b)).length);}catch(e){}
    }catch(e){}
  }
  function normalizeAttributes(el){
    if(!el||el.nodeType!==1||!el.attributes)return;
    for(var i=0;i<el.attributes.length;i++){
      var a=el.attributes[i],n=a.name;
      if((n==='value'||n==='placeholder'||n==='title'||n==='aria-label'||n==='alt'||n==='content'||n.indexOf('data-')===0)&&arabicDigits.test(a.value)){
        try{el.setAttribute(n,toWestern(a.value));}catch(e){}
      }
    }
    normalizeControl(el);
  }
  function normalizeTree(root,doc){
    if(!root)return;
    if(root.nodeType===3){normalizeText(root);return;}
    if(root.nodeType===1){normalizeAttributes(root);if(root.tagName==='IFRAME')watchFrame(root);}
    var tw;try{tw=doc.createTreeWalker(root,doc.defaultView.NodeFilter.SHOW_TEXT);}catch(e){return;}
    var node;while((node=tw.nextNode()))normalizeText(node);
    if(root.querySelectorAll){root.querySelectorAll('input,textarea,select,[title],[aria-label],[placeholder],[alt],[value],[content],[data-value],iframe').forEach(function(el){normalizeAttributes(el);if(el.tagName==='IFRAME')watchFrame(el);});}
  }
  function watchFrame(frame){
    if(!frame||frame.__westernDigitWatch)return;
    frame.__westernDigitWatch=true;
    frame.addEventListener('load',function(){try{observeDoc(frame.contentDocument);}catch(e){}});
    try{if(frame.contentDocument&&frame.contentDocument.documentElement)observeDoc(frame.contentDocument);}catch(e){}
  }
  function observeDoc(doc){
    if(!doc||!doc.documentElement||doc.__westernDigitObserver)return;
    try{Object.defineProperty(doc,'__westernDigitObserver',{value:true,configurable:true});}catch(e){doc.__westernDigitObserver=true;}
    try{
      var styleId='western-digit-style',style=doc.getElementById(styleId);
      if(!style){style=doc.createElement('style');style.id=styleId;style.textContent='html,body,body *{font-variant-numeric:lining-nums tabular-nums!important}';(doc.head||doc.documentElement).appendChild(style);}
    }catch(e){}
    normalizeTree(doc.documentElement,doc);
    function onEdit(ev){normalizeControl(ev.target);}
    doc.addEventListener('input',onEdit,true);
    doc.addEventListener('change',onEdit,true);
    doc.addEventListener('focusin',onEdit,true);
    doc.addEventListener('submit',function(ev){var f=ev.target;if(f&&f.querySelectorAll)f.querySelectorAll('input,textarea,select').forEach(normalizeControl);},true);
    var MO=doc.defaultView&&doc.defaultView.MutationObserver;if(!MO)return;
    var observer=new MO(function(records){records.forEach(function(r){
      if(r.type==='characterData')normalizeText(r.target);
      else if(r.type==='attributes'){var an=r.attributeName||'';if(an==='value'||an==='placeholder'||an==='title'||an==='aria-label'||an==='alt'||an==='content'||an.indexOf('data-')===0)normalizeAttributes(r.target);}
      else if(r.type==='childList')r.addedNodes.forEach(function(n){normalizeTree(n,doc);});
    });});
    observer.observe(doc.documentElement,{subtree:true,childList:true,characterData:true,attributes:true});
    if(doc.querySelectorAll)doc.querySelectorAll('iframe').forEach(watchFrame);
  }
  try{
    if(typeof data!=='undefined'&&data&&typeof data==='object'){
      normalizeObject(data);
      if(typeof save==='function')save();
    }
    if(typeof save==='function'&&!window.__westernDigitSaveWrapped){
      var originalSave=save;
      window.save=function(){try{if(typeof data!=='undefined'&&data)normalizeObject(data);}catch(e){}return originalSave.apply(this,arguments);};
      window.__westernDigitSaveWrapped=true;
    }
  }catch(e){}
  observeDoc(document);
})();

/* source script: inline */
(function(){function runAppearance(){try{if(typeof data!=="undefined"&&data.settings)applyAppearanceSettings();}catch(e){console.warn("appearance settings",e);}}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",runAppearance,{once:true});else runAppearance();})();



(function(){
  function openRequestedSettings(){
    try {
      var params = new URLSearchParams(window.location.search || '');
      if (params.get('page') === 'purchase' && typeof window.showPurchasePage === 'function') {
        setTimeout(function(){ window.showPurchasePage(); try{ history.replaceState(null,'',location.pathname); }catch(_){} }, 0);
      }
      if (params.get('settings') === 'gdriveBackup' && typeof window.openSettingsPage === 'function') {
        setTimeout(function(){ window.openSettingsPage('gdriveBackup', true); }, 350);
      }
    } catch(e) {}
  }
  if (document.readyState === 'complete') openRequestedSettings();
  else window.addEventListener('load', openRequestedSettings, {once:true});
})();


/* ===== طباعة الشرائي: هياكل الجداول + البيانات حسب إعدادات الطباعة (ترويسة/خط/لون/ورق/طريقة الطباعة) ===== */
(function(){
  'use strict';
  var E=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
  var TBL='.by-print{max-width:100%;margin:0 auto}.by-print h2{text-align:center;margin:10px 0 4px;font-size:18px}.by-print h3{margin:14px 0 6px;font-size:15px}.by-print p{text-align:center;margin:0 0 10px;font-size:13px;color:#444}'
    +'.by-print table{width:100%;border-collapse:collapse;margin:8px 0;table-layout:auto}.by-print th,.by-print td{border:1px solid #536174;padding:7px 5px;text-align:center;overflow-wrap:anywhere;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
    +'.by-print th{background:#aebeff;color:#111;font-weight:900}.by-print tfoot td{font-weight:900;background:#f3f5fb}.by-print .kv td:first-child{width:65%;text-align:right}'
    +'.by-print .sign{display:grid;grid-template-columns:1fr 1fr;gap:24px;border-top:1px solid #777;margin-top:28px;padding-top:10px;text-align:center;font-weight:800;line-height:2}';
  window.__buyerPrintDoc=function(title,body,extraCss){
    var s=(typeof data!=='undefined'&&data&&data.settings)||{};
    var head='';
    try{head=(s.showHeaderData===false)?('<div class="doc-title">'+E(title)+'</div>'):buildPrintHeader(title)}catch(err){head='<h2>'+E(title)+'</h2>'}
    var css='';try{css=getPrintCSS()}catch(err){css='@page{size:A4 portrait;margin:10mm}body{font:14px Tahoma,Arial,sans-serif;color:#111;direction:rtl}'}
    var html='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(title)+'</title><style>'+css+TBL+(extraCss||'')+'</style></head><body>'+head+'<div class="by-print">'+body+'</div></body></html>';
    /* طريقة PDF: المحرك الموحد (الورق/الخط/اللون/الحجم من الإعدادات) */
    try{if(window.__printDoc&&window.__printDoc(html))return true}catch(err){console.error(err)}
    /* طريقة الطابعة: طباعة المتصفح عبر إطار مخفي */
    var fr=document.createElement('iframe');
    fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.appendChild(fr);
    var d=fr.contentDocument||fr.contentWindow.document;d.open();d.write(html);d.close();
    try{window.__printGuard&&window.__printGuard(8000)}catch(err){}
    setTimeout(function(){try{fr.contentWindow.focus();fr.contentWindow.print()}catch(err){}setTimeout(function(){fr.remove()},2000)},300);
    return true;
  };
})();

/* ===== الشرائي: تحويل الشراء (جدول لكل أسبوع) + الكشف السنوي ===== */
(function(){
  var IDS={transfer:'buyTransferPage',year:'buyYearPage',sheet:'buyTransferSheet'};
  var TITLES={transfer:'تحويل الشراء',year:'الكشف السنوي'};
  var DAYN=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  var ST={},curWeek=null,sv=null;
  var pad=function(n){return String(n).padStart(2,'0')};
  var iso=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
  var parse=function(s){return new Date(s+'T12:00:00')};
  var disp=function(s){return s?String(s).split('-').reverse().join('/'):'—'};
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
  var fmt=function(n){return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2})};
  var num=function(v){var s=String(v==null?'':v).replace(/[\u0660-\u0669]/g,function(d){return '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669'.indexOf(d)}).replace(/,/g,'');var n=parseFloat(s);return isFinite(n)?n:0};
  var r2=function(n){return Math.round(n*100)/100};
  function saveSoon(){clearTimeout(sv);sv=setTimeout(function(){try{save()}catch(e){}},400)}
  function initState(kind){var y=new Date().getFullYear();ST[kind]={from:y+'-01-01',to:y+'-12-31',by:'date',dir:'desc',spec:'all',sel:{}}}
  function specs(){return (data.settings&&data.settings.buyerSpecialties)||[]}
  function weeks(){return (data.folders||[]).filter(function(f){return f.scope==='buyer'})}
  function annual(){var s=data.settings;if(!Array.isArray(s.buyerAnnual))s.buyerAnnual=[];return s.buyerAnnual}
  function tr(f){if(!f.transfer)f.transfer={};return f.transfer}
  function hid(){var st=data.settings;if(!Array.isArray(st.buyerAnnualHidden))st.buyerAnnualHidden=[];return st.buyerAnnualHidden}
  function isHid(id){return hid().indexOf(id)>=0}
  function unhide(id){var h=hid(),i=h.indexOf(id);if(i>=0)h.splice(i,1)}
  function newId(){return 'ar'+Date.now()+Math.random().toString(36).slice(2,5)}

  /* ---------- حسابات الأسبوع ---------- */
  function daysOf(f){
    var inv={},list=[];
    (f.invoices||[]).forEach(function(i){var d=String(i.initDateISO||i.invoiceDateISO||'');if(d)inv[d]=i});
    if(f.startDate&&f.endDate){for(var d=parse(f.startDate);iso(d)<=f.endDate;d.setDate(d.getDate()+1))list.push(iso(d))}
    Object.keys(inv).forEach(function(d){if(list.indexOf(d)<0)list.push(d)});
    list.sort();
    return list.map(function(d){
      var i=inv[d],q=0;
      if(i&&Array.isArray(i.buyerRows))i.buyerRows.forEach(function(r){q+=num(r.qty)});
      return {date:d,has:!!i,qty:q,buy:i?(+i.buyerTotal||0):0,exp:i?(+i.buyerExpense||0):0};
    });
  }
  function calc(f){
    var t=tr(f),ds=daysOf(f),Q=0,B=0,X=0;
    ds.forEach(function(d){Q+=d.qty;B+=d.buy;X+=d.exp});
    var oldTotal=B+X,oldP=num(t.oldPrice),newP=num(t.newPrice);
    var ex=oldP>0?oldTotal/oldP:0,newTotal=ex*newP;
    var totalExp=newTotal+num(t.rentRada)+num(t.rentShip);
    var sale=num(t.weeklySale),diff=sale-totalExp;
    return {days:ds,qty:Q,buy:B,exp:X,oldTotal:oldTotal,exchange:ex,newTotal:newTotal,totalExp:totalExp,sale:sale,diff:diff,
      state:diff>0?'ربح':diff<0?'خسارة':'متعادل'};
  }

  /* ---------- ربط الأسبوع بالكشف السنوي ---------- */
  window.bpEnsureWeek=function(f){
    if(!f)return;tr(f);
    if(isHid(f.id))return;
    var r=annual().find(function(x){return x.folderId===f.id});
    if(!r)annual().push({id:newId(),folderId:f.id,specialtyId:String(f.specialtyId||''),from:f.startDate||'',to:f.endDate||'',habba:'',buy:'',sell:'',profit:'',diff:''});
    else{r.from=f.startDate||r.from;r.to=f.endDate||r.to;r.specialtyId=String(f.specialtyId||'')}
  };
  function syncWeek(f){
    var c=calc(f),r=annual().find(function(x){return x.folderId===f.id});
    if(!r){unhide(f.id);window.bpEnsureWeek(f);r=annual().find(function(x){return x.folderId===f.id})}
    r.from=f.startDate||'';r.to=f.endDate||'';r.specialtyId=String(f.specialtyId||'');
    if(c.qty===0&&c.totalExp===0&&c.sale===0){r.habba='';r.buy='';r.sell='';r.diff='';r.profit='';return r}
    r.habba=r2(c.qty);r.buy=r2(c.totalExp);r.sell=r2(c.sale);r.diff=r2(c.diff);
    r.profit=c.diff>0?'ربح':c.diff<0?'خسارة':'0';
    return r;
  }
  function hookSales(){try{if(window.bpSyncSales)window.bpSyncSales()}catch(e){}}
  function syncAll(){weeks().forEach(function(f){if(isHid(f.id))return;syncWeek(f)});hookSales()}
  function sendWeek(f){
    syncWeek(f);tr(f).sentAt=Date.now();
    save();var spn=(specs().find(function(x){return String(x.id)===String(f.specialtyId||'')})||{}).name;toast('تم إرسال الأسبوع إلى الكشف السنوي'+(spn?' — '+spn:''));
  }

  /* ---------- قائمة الأسابيع (تحويل الشراء) ---------- */
  function weekRows(){
    var s=ST.transfer;
    var rows=weeks().filter(function(f){
      var a=f.startDate||'',b=f.endDate||a;
      if(s.from&&b&&b<s.from)return false;if(s.to&&a&&a>s.to)return false;
      if(s.spec!=='all'&&String(f.specialtyId||'')!==String(s.spec))return false;
      return true;
    }).map(function(f){
      var c=calc(f);
      return {key:f.id,f:f,title:f.name||'أسبوع',sub:disp(f.startDate)+' ← '+disp(f.endDate)+' · '+(f.invoices||[]).length+' فاتورة',
        total:c.totalExp,sale:c.sale,net:c.diff,state:c.state,qty:c.qty,sortDate:f.startDate||'',sortName:f.name||''};
    });
    rows.sort(function(a,b){
      var c=s.by==='amount'?a.net-b.net:s.by==='name'?String(a.sortName).localeCompare(String(b.sortName),'ar'):(a.sortDate<b.sortDate?-1:a.sortDate>b.sortDate?1:0);
      return s.dir==='asc'?c:-c;
    });
    return rows;
  }
  function dateBar(s){
    return '<div class="date-bar date-range-unified"><button type="button" class="db-arrow" data-act="prev" aria-label="الفترة السابقة">←</button>'
      +'<div class="db-field"><input type="date" data-f="from" value="'+esc(s.from)+'" aria-label="تاريخ البداية"></div><span class="db-sep">إلى</span><div class="db-field"><input type="date" data-f="to" value="'+esc(s.to)+'" aria-label="تاريخ النهاية"></div>'
      +'<button type="button" class="db-arrow" data-act="next" aria-label="الفترة التالية">→</button></div>';
  }
  function topBar(title){return '<div class="bp-top"><button type="button" class="bp-back" data-act="back">رجوع ➜</button><h2>'+esc(title)+'</h2></div>'}

  function renderTransfer(){
    var root=document.querySelector('#'+IDS.transfer+' .bp-root');if(!root)return;
    if(!ST.transfer)initState('transfer');
    var s=ST.transfer,rows=weekRows();
    var selKeys=rows.filter(function(r){return s.sel[r.key]}),base=selKeys.length?selKeys:rows;
    var T=0,S=0,N=0;base.forEach(function(r){T+=r.total;S+=r.sale;N+=r.net});
    var allOn=rows.length>0&&selKeys.length===rows.length;
    var by=[['date','📅 التاريخ'],['amount','💰 الفارق'],['name','🔤 الاسم']];
    var sp='<option value="all"'+(s.spec==='all'?' selected':'')+'>كل التخاصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'"'+(String(x.id)===String(s.spec)?' selected':'')+'>'+esc(x.name)+'</option>'}).join('');
    root.innerHTML=topBar(TITLES.transfer)
     +'<div class="bp-bar bp-sort"><label>ترتيب حسب:</label><select data-f="by">'+by.map(function(o){return '<option value="'+o[0]+'"'+(s.by===o[0]?' selected':'')+'>'+o[1]+'</option>'}).join('')+'</select>'
       +'<button type="button" class="bp-seg'+(s.dir==='asc'?' on':'')+'" data-dir="asc">↑ تصاعدي</button><button type="button" class="bp-seg'+(s.dir==='desc'?' on':'')+'" data-dir="desc">↓ تنازلي</button></div>'
     +dateBar(s)
     +'<div class="bp-bar bp-spec"><select data-f="spec">'+sp+'</select><label class="bp-all"><input type="checkbox" data-act="all"'+(allOn?' checked':'')+'> تحديد الكل</label></div>'
     +'<div class="bp-sum"><div><small>'+(selKeys.length?'المحدد':'الأسابيع')+'</small><b>'+base.length+'</b></div><div><small>الشراء مع الخرج</small><b>'+fmt(T)+'</b></div><div><small>البيع</small><b>'+fmt(S)+'</b></div><div><small>الفارق</small><b class="'+(N<0?'neg':'pos')+'">'+fmt(N)+'</b></div></div>'
     +'<div class="bp-list">'+(rows.length?rows.map(function(r){
        return '<div class="bp-card" data-week="'+esc(r.key)+'"><label class="bp-ck"><input type="checkbox" data-sel="'+esc(r.key)+'"'+(s.sel[r.key]?' checked':'')+'></label>'
         +'<div class="bp-main"><b>🗓️ '+esc(r.title)+'</b><small>'+esc(r.sub)+'</small></div>'
         +'<div class="bp-amt"><b class="'+(r.net<0?'neg':'pos')+'">'+fmt(r.net)+'</b><small>'+r.state+' · حبات '+fmt(r.qty)+'</small></div></div>';
       }).join(''):'')+'</div>'
     +'<button type="button" class="bp-fab" data-act="addweek" aria-label="إضافة أسبوع">+</button>';
  }

  /* ---------- جدول الأسبوع (تحويل الشراء) ---------- */
  function renderSheet(){
    var root=document.querySelector('#'+IDS.sheet+' .bp-root');if(!root)return;
    var f=(data.folders||[]).find(function(x){return x.id===curWeek});
    if(!f){root.innerHTML=topBar('تحويل الشراء')+'<div class="bp-empty"><b>الأسبوع غير موجود</b></div>';return}
    var t=tr(f),c=calc(f);
    var inp=function(k,id){return '<input type="number" inputmode="decimal" id="'+id+'" data-t="'+k+'" value="'+esc(t[k]==null?'':t[k])+'">'};
    var body=c.days.map(function(d){
      var dn=DAYN[parse(d.date).getDay()];
      return '<tr'+(d.has?'':' class="bp-nodata"')+'><td>'+dn+'<br><small>'+disp(d.date)+'</small></td><td>'+(d.has?fmt(d.qty):'')+'</td><td>'+(d.has?fmt(d.buy):'')+'</td><td>'+(d.has?fmt(d.exp):'')+'</td><td>'+(d.has?fmt(d.buy+d.exp):'')+'</td></tr>';
    }).join('');
    root.innerHTML=topBar(f.name||'تحويل الشراء')
     +'<div class="bp-head"><div><b>اسم الأسبوع</b><span>'+esc(f.name||'-')+'</span></div><div><b>رقم الجدول</b><span>'+esc(f.order||'-')+'</span></div><div><b>من تاريخ</b><span>'+disp(f.startDate)+'</span></div><div><b>إلى تاريخ</b><span>'+disp(f.endDate)+'</span></div></div>'
     +'<div class="bp-sech">تفاصيل الأسبوع</div>'
     +'<div class="bp-tw"><table class="bp-tbl"><thead><tr><th>اليوم / التاريخ</th><th>عدد الحبة</th><th>سعر الشرائ</th><th>خرج رداع</th><th>إجمالي الشراء</th></tr></thead><tbody>'+body
       +'<tr class="bp-total"><td>الجملة</td><td id="bs-qty"></td><td id="bs-buy"></td><td id="bs-exp"></td><td id="bs-all"></td></tr></tbody></table></div>'
     +'<div class="bp-sech">تحويل الشراء جديد</div><div class="bp-calc">'
       +'<div class="bp-cr"><span>مبلغ الشراء قديم (جملة الأيام)</span><div class="bp-vb" id="bs-oldTotal">0</div></div>'
       +'<div class="bp-cr"><span>سعر السعودي القديم</span>'+inp('oldPrice','conv-old-price')+'</div>'
       +'<div class="bp-cr"><span>الشراء قديم = مبلغ سعودي على صرف رداع</span><div class="bp-vb blue" id="bs-exchange">0</div></div>'
       +'<div class="bp-cr"><span>سعر شراء السعودي جديد</span>'+inp('newPrice','conv-new-price')+'</div>'
       +'<div class="bp-cr tot"><span>الشراء قديم = الشراء جديد</span><div class="bp-vb green" id="bs-newTotal">0</div></div>'
       +'<div class="bp-formula" id="bs-formula"></div></div>'
     +'<div class="bp-sech">التفصيل النهائي</div><div class="bp-calc">'
       +'<div class="bp-cr"><span>إجمالي الشراء جديد</span><div class="bp-vb" id="bs-finalNew">0</div></div>'
       +'<div class="bp-cr"><span>خرج إجار رداع جديد</span>'+inp('rentRada','final-rent-rada')+'</div>'
       +'<div class="bp-cr"><span>خرج إجار شحن جديد</span>'+inp('rentShip','final-rent-ship')+'</div>'
       +'<div class="bp-cr tot red"><span>إجمالي الشراء مع الخرج جديد</span><div class="bp-vb" id="bs-totalExp">0</div></div>'
       +'<div class="bp-cr"><span>بيع الأسبوع المفصل شحن</span>'+inp('weeklySale','final-weekly-sale')+'</div>'
       +'<div class="bp-cr tot" id="bs-diffRow"><span id="bs-diffLbl">الفارق</span><div class="bp-vb" id="bs-diff">0</div></div></div>'
     +'<div class="bp-acts"><button type="button" class="b-sec" data-act="exit">🚪 خروج</button><button type="button" class="b-red" data-act="clear">🗑️ مسح</button><button type="button" class="b-grn" data-act="share">📤 مشاركة</button><button type="button" class="b-wrn" data-act="editweek">✏️ تعديل</button><button type="button" class="b-pri" data-act="savesheet">💾 حفظ الجدول</button></div>'
     +'<div class="bp-formula" style="margin-top:10px">📊 يتحدث الكشف السنوي (تخصيص هذا الأسبوع) تلقائياً</div>';
    syncWeek(f);updateSheet();
  }
  function updateSheet(){
    var f=(data.folders||[]).find(function(x){return x.id===curWeek});if(!f)return;
    var c=calc(f),set=function(id,v){var e=document.getElementById(id);if(e)e.textContent=v};
    set('bs-qty',fmt(c.qty));set('bs-buy',fmt(c.buy));set('bs-exp',fmt(c.exp));set('bs-all',fmt(c.oldTotal));
    set('bs-oldTotal',fmt(c.oldTotal));set('bs-exchange',fmt(r2(c.exchange)));set('bs-newTotal',fmt(r2(c.newTotal)));
    set('bs-finalNew',fmt(r2(c.newTotal)));set('bs-totalExp',fmt(r2(c.totalExp)));
    var t=tr(f);
    set('bs-formula',num(t.oldPrice)>0?fmt(c.oldTotal)+' ÷ '+fmt(num(t.oldPrice))+' = '+fmt(r2(c.exchange))+' × '+fmt(num(t.newPrice))+' = '+fmt(r2(c.newTotal)):'');
    var dv=document.getElementById('bs-diff'),dl=document.getElementById('bs-diffLbl');
    if(dv){dv.textContent=fmt(r2(Math.abs(c.diff)));dv.className='bp-vb '+(c.diff>0?'green':c.diff<0?'redv':'')}
    if(dl)dl.textContent=c.diff>0?'الفارق (ربح)':c.diff<0?'الفارق (خسارة)':'الفارق';
  }
  function shareText(f){
    var c=calc(f);
    return 'تحويل الشراء — '+(f.name||'')+'\nمن '+disp(f.startDate)+' إلى '+disp(f.endDate)
      +'\nعدد الحبات: '+fmt(c.qty)+'\nمبلغ الشراء قديم: '+fmt(c.oldTotal)+'\nالشراء جديد: '+fmt(r2(c.newTotal))
      +'\nإجمالي الشراء مع الخرج: '+fmt(r2(c.totalExp))+'\nبيع الأسبوع: '+fmt(c.sale)+'\nالفارق ('+c.state+'): '+fmt(r2(Math.abs(c.diff)));
  }

  /* ---------- الكشف السنوي (جدول) ---------- */
  function rowCalc(r){
    var b=String(r.buy==null?'':r.buy).trim(),s=String(r.sell==null?'':r.sell).trim();
    if(b===''&&s===''){r.diff='';r.profit='';return}
    var d=r2(num(s)-num(b));r.diff=d;r.profit=d>0?'ربح':d<0?'خسارة':'0';
  }
  function syncSpec(){
    var ws=weeks();
    annual().forEach(function(r){
      if(!r.folderId)return;
      var f=ws.find(function(x){return x.id===r.folderId});
      if(f)r.specialtyId=String(f.specialtyId||'');
    });
  }
  function visibleRows(){
    var s=ST.year;
    return annual().filter(function(r){
      if(s.spec!=='all'&&String(r.specialtyId||'')!==String(s.spec))return false;
      var a=r.from||r.to||'',b=r.to||r.from||'';
      if(!a&&!b)return true;
      if(s.from&&b<s.from)return false;if(s.to&&a>s.to)return false;return true;
    }).sort(function(x,y){var a=String(x.from||''),b=String(y.from||''),c=a<b?-1:a>b?1:0;return s.dir==='desc'?-c:c});
  }
  function pcol(p){return p==='ربح'?'#16A34A':p==='خسارة'?'#DC2626':'#5C1520'}
  function yearRowHTML(r){
    return '<tr class="yr" data-id="'+esc(r.id)+'"><td><input type="date" data-c="from" value="'+esc(r.from||'')+'"></td><td><input type="date" data-c="to" value="'+esc(r.to||'')+'"></td>'
      +'<td><input type="text" inputmode="numeric" data-c="habba" value="'+esc(r.habba)+'"></td><td><input type="text" inputmode="decimal" data-c="buy" value="'+esc(r.buy)+'"></td><td><input type="text" inputmode="decimal" data-c="sell" value="'+esc(r.sell)+'"></td>'
      +'<td><input type="text" readonly data-c="profit" value="'+esc(r.profit)+'" style="color:'+pcol(r.profit)+';font-weight:800"></td><td><input type="text" readonly data-c="diff" value="'+esc(r.diff)+'"></td>'
      +'<td><button type="button" class="bp-del" data-act="delrow">✖</button></td></tr>';
  }
  function totalsHTML(rows){
    var th=0,tb=0,ts=0,tp=0,tl=0;
    rows.forEach(function(r){th+=num(r.habba);tb+=num(r.buy);ts+=num(r.sell);var d=num(r.diff);if(d>0)tp+=d;else if(d<0)tl+=-d});
    var td=ts-tb,lbl=td>0?'الباقي ربح':td<0?'الباقي خسارة':'الباقي ربح/خسارة',col=td>0?'#16A34A':td<0?'#DC2626':'#5C1520';
    return '<tr class="bp-total"><td colspan="2">الجملة</td><td>'+fmt(th)+'</td><td>'+fmt(tb)+'</td><td>'+fmt(ts)+'</td>'
      +'<td><span class="pos">'+(tp>0?'الربح: '+fmt(r2(tp)):'')+'</span><br><span class="neg">'+(tl>0?'الخسارة: '+fmt(r2(tl)):'')+'</span></td>'
      +'<td style="color:'+col+'"><small>'+lbl+'</small><br>'+fmt(r2(Math.abs(td)))+'</td><td></td></tr>';
  }
  /* ---------- الكشف السنوي: ملف لكل تخصيص ---------- */
  function renderYearFiles(root,s){
    var a=s.from,b=s.to;
    var inRange=function(r){var x=r.from||r.to||'',y=r.to||r.from||'';if(!x&&!y)return true;if(a&&y<a)return false;if(b&&x>b)return false;return true};
    var all=annual().filter(inRange);
    var files=specs().map(function(x){return {id:String(x.id),name:x.name}});
    if(all.some(function(r){return !String(r.specialtyId||'')}))files.push({id:'',name:'بدون تخصيص'});
    var cards=files.map(function(fl){
      var rs=all.filter(function(r){return String(r.specialtyId||'')===fl.id});
      var tb=0,ts=0;rs.forEach(function(r){tb+=num(r.buy);ts+=num(r.sell)});
      var d=r2(ts-tb);
      return '<div class="bp-card'+(s.fsel&&s.fsel[fl.id]?' sel':'')+'" data-yspec="'+esc(fl.id)+'" data-yfile="1"><div class="bp-main"><b>📁 '+esc(fl.name)+'</b><small>'+rs.length+' أسبوع · البيع '+fmt(ts)+' · الشراء '+fmt(tb)+'</small></div>'
        +'<div class="bp-amt"><b class="'+(d<0?'neg':'pos')+'">'+fmt(Math.abs(d))+'</b><small>'+(d>0?'ربح':d<0?'خسارة':'متعادل')+'</small></div></div>';
    }).join('');
    root.innerHTML=topBar(TITLES.year)+dateBar(s)
      +'<div class="bp-list">'+(cards||'')+'</div>';
  }
  function renderYear(){
    var root=document.querySelector('#'+IDS.year+' .bp-root');if(!root)return;
    if(!ST.year)initState('year');
    syncAll();syncSpec();
    var s=ST.year;
    if(!s.open){renderYearFiles(root,s);return}
    var rows=visibleRows();
    var spName=s.spec===''?'بدون تخصيص':((specs().find(function(x){return String(x.id)===String(s.spec)})||{}).name||'');
    var spo='<option value="all"'+(s.spec==='all'?' selected':'')+'>كل التخاصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'"'+(String(x.id)===String(s.spec)?' selected':'')+'>'+esc(x.name)+'</option>'}).join('');
    root.innerHTML=topBar(TITLES.year+(spName?' — '+spName:''))
     +'<div class="bp-bar bp-sort"><label>ترتيب حسب:</label><select data-f="by"><option value="date" selected>📅 التاريخ</option></select>'
       +'<button type="button" class="bp-seg'+(s.dir==='asc'?' on':'')+'" data-dir="asc">↑ تصاعدي</button><button type="button" class="bp-seg'+(s.dir==='desc'?' on':'')+'" data-dir="desc">↓ تنازلي</button></div>'
     +dateBar(s)
     +'<div class="bp-tw"><table class="bp-tbl bp-year"><colgroup><col style="width:15%"><col style="width:15%"><col style="width:9%"><col style="width:15%"><col style="width:15%"><col style="width:13%"><col style="width:13%"><col style="width:42px"></colgroup>'
     +'<thead><tr><th>من</th><th>إلى</th><th>عدد<br>الحبه</th><th>الشراء<br>جديد</th><th>البيع<br>جديد</th><th>ربح/<br>خساره</th><th>الفارق<br>لك/عليك</th><th>حذف</th></tr></thead>'
     +'<tbody id="bpYearBody">'+rows.map(yearRowHTML).join('')+'</tbody><tfoot id="bpYearFoot">'+totalsHTML(rows)+'</tfoot></table></div>'
     +(rows.length?'':'')
     +'<button type="button" class="bp-send" data-act="addrow">+ إضافة صف جديد</button>';
  }

  /* ---------- الأحداث ---------- */
  function rootKind(el){var r=el.closest('.bp-root');return r&&r.parentNode.id}
  function shift(kind,dir){
    var s=ST[kind],f=parse(s.from),t=parse(s.to);
    var full=f.getMonth()===0&&f.getDate()===1&&t.getMonth()===11&&t.getDate()===31&&f.getFullYear()===t.getFullYear();
    if(full){f.setFullYear(f.getFullYear()+dir);t.setFullYear(t.getFullYear()+dir)}
    else{var span=Math.round((t-f)/86400000)+1;f.setDate(f.getDate()+dir*span);t.setDate(t.getDate()+dir*span)}
    s.from=iso(f);s.to=iso(t);s.sel={};s.fsel={};
  }
  function rerender(pid){if(pid===IDS.transfer)renderTransfer();else if(pid===IDS.year)renderYear();else if(pid===IDS.sheet)renderSheet()}

  document.addEventListener('click',function(e){
    var el=e.target.closest&&e.target.closest('.bp-root *');if(!el)return;
    var pid=rootKind(el);if(!pid)return;
    var kind=pid===IDS.year?'year':'transfer';var s=ST[kind];
    var yf=el.closest('[data-yspec]');if(yf&&pid===IDS.year){if(window.__yLP&&Date.now()-window.__yLP<900){e.preventDefault();return}var yk=yf.getAttribute('data-yspec'),fs=ST.year.fsel||(ST.year.fsel={});if(Object.keys(fs).some(function(k){return fs[k]})){if(fs[yk])delete fs[yk];else fs[yk]=true;renderYear();return}ST.year.spec=yk;ST.year.open=true;renderYear();window.scrollTo(0,0);return}
    var b=el.closest('[data-dir]');if(b&&s){s.dir=b.getAttribute('data-dir');rerender(pid);return}
    var a=el.closest('[data-act]');
    if(a){var act=a.getAttribute('data-act');
      if(act==='back'){if(pid===IDS.year&&ST.year&&ST.year.open){ST.year.open=false;renderYear();window.scrollTo(0,0);return}if(pid===IDS.sheet)window.bpSheetBack();else if(window.showPurchasePage)showPurchasePage();return}
      if(act==='prev'||act==='next'){shift(kind,act==='prev'?-1:1);rerender(pid);return}
      if(act==='addweek'){window.invScope='buyer';if(typeof openFolderAdd==='function')openFolderAdd();return}
      if(act==='exit'){window.bpSheetBack();return}
      var f=(data.folders||[]).find(function(x){return x.id===curWeek});
      if(act==='savesheet'){if(f)syncWeek(f);save();toast('تم حفظ الجدول');window.bpSheetBack();return}
      if(act==='send'&&f){sendWeek(f);return}
      if(act==='editweek'&&f){window.invScope='buyer';if(typeof openFolderEdit==='function')openFolderEdit(f.id);return}
      if(act==='share'&&f){var tx=shareText(f);if(navigator.share){navigator.share({text:tx}).catch(function(){})}else if(navigator.clipboard){navigator.clipboard.writeText(tx).then(function(){toast('تم نسخ بيانات الجدول')})}else toast('المشاركة غير مدعومة');return}
      if(act==='clear'&&f){var run=function(){var t=tr(f);['oldPrice','newPrice','rentRada','rentShip','weeklySale'].forEach(function(k){t[k]=''});syncWeek(f);save();renderSheet();toast('تم مسح الإدخال اليدوي')};
        if(typeof customConfirm==='function')customConfirm('مسح بيانات الإدخال اليدوي لهذا الأسبوع؟',run,null,{title:'مسح',icon:'🗑️',danger:true,confirmText:'مسح',cancelText:'إلغاء'});else if(confirm('مسح بيانات الإدخال اليدوي؟'))run();return}
      if(act==='addrow'){annual().push({id:newId(),folderId:'',specialtyId:(ST.year&&ST.year.spec!=='all')?String(ST.year.spec):'',from:'',to:'',habba:'',buy:'',sell:'',profit:'',diff:''});save();renderYear();return}
      if(act==='delrow'){var tr0=el.closest('tr.yr'),id=tr0&&tr0.getAttribute('data-id');
        var list=annual(),idx=list.findIndex(function(x){return x.id===id});
        if(idx>=0){var row=list[idx];
          if(row.folderId){var run2=function(){list.splice(idx,1);if(row.folderId&&!isHid(row.folderId))hid().push(row.folderId);hookSales();save();renderYear()};
            if(typeof customConfirm==='function')customConfirm('حذف صف هذا الأسبوع من الكشف السنوي؟',run2,null,{title:'حذف',icon:'🗑️',danger:true,confirmText:'حذف',cancelText:'إلغاء'});else run2();
          }else{list.splice(idx,1);hookSales();save();renderYear()}
        }return}
      if(act==='all')return;
    }
    if(el.closest('.bp-ck'))return;
    var c=el.closest('[data-week]');if(c){if(window.__yLP&&Date.now()-window.__yLP<900){e.preventDefault();return}window.openBuyerSheet(c.getAttribute('data-week'))}
  });
  document.addEventListener('change',function(e){
    var el=e.target;if(!el.closest||!el.closest('.bp-root'))return;
    var pid=rootKind(el);
    if(pid===IDS.transfer){
      var s=ST.transfer,f=el.getAttribute('data-f');
      if(f){s[f]=el.value||(f==='spec'?'all':s[f]);s.sel={};renderTransfer();return}
      if(el.getAttribute('data-act')==='all'){s.sel={};if(el.checked)weekRows().forEach(function(r){s.sel[r.key]=true});renderTransfer();return}
      var k=el.getAttribute('data-sel');if(k!==null){if(el.checked)s.sel[k]=true;else delete s.sel[k];renderTransfer()}
    }else if(pid===IDS.year){
      var fy=el.getAttribute('data-f');if(fy){ST.year[fy]=el.value||(fy==='spec'?'all':ST.year[fy]);renderYear()}
    }
  });
  document.addEventListener('input',function(e){
    var el=e.target;if(!el.closest||!el.closest('.bp-root'))return;
    var pid=rootKind(el);
    if(pid===IDS.sheet){
      var k=el.getAttribute('data-t');if(!k)return;
      var f=(data.folders||[]).find(function(x){return x.id===curWeek});if(!f)return;
      tr(f)[k]=el.value;syncWeek(f);hookSales();updateSheet();saveSoon();
    }else if(pid===IDS.year){
      var c=el.getAttribute('data-c'),trw=el.closest('tr.yr');if(!c||!trw||el.readOnly)return;
      var r=annual().find(function(x){return x.id===trw.getAttribute('data-id')});if(!r)return;
      r[c]=el.value;
      if(c==='buy'||c==='sell'){rowCalc(r);
        var pi=trw.querySelector('[data-c="profit"]'),di=trw.querySelector('[data-c="diff"]');
        if(pi){pi.value=r.profit;pi.style.color=pcol(r.profit)}if(di)di.value=r.diff;}
      var ft=document.getElementById('bpYearFoot');if(ft)ft.innerHTML=totalsHTML(visibleRows());
      hookSales();saveSoon();
    }
  });

  /* ---------- الضغط المطول على ملف التخصيص: عرض / طباعة ---------- */
  function yearRowsFor(spec){
    var s=ST.year;
    return annual().filter(function(r){
      if(String(r.specialtyId||'')!==String(spec))return false;
      var a=r.from||r.to||'',b=r.to||r.from||'';
      if(!a&&!b)return true;
      if(s.from&&b<s.from)return false;if(s.to&&a>s.to)return false;return true;
    }).sort(function(x,y){return String(x.from||'')<String(y.from||'')?-1:1});
  }
  function yearPrintSection(spec){
    var s=ST.year,rs=yearRowsFor(spec);
    var nm=spec===''?'بدون تخصيص':((specs().find(function(x){return String(x.id)===String(spec)})||{}).name||'');
    var th=0,tb=0,ts=0;
    var body=rs.map(function(r){th+=num(r.habba);tb+=num(r.buy);ts+=num(r.sell);
      return '<tr><td>'+disp(r.from)+'</td><td>'+disp(r.to)+'</td><td>'+esc(r.habba)+'</td><td>'+esc(r.buy)+'</td><td>'+esc(r.sell)+'</td><td>'+esc(r.profit)+'</td><td>'+esc(r.diff)+'</td></tr>'}).join('');
    var net=r2(ts-tb);
    return '<section style="page-break-after:always"><h2>الكشف السنوي — '+esc(nm)+'</h2><p>من '+disp(s.from)+' إلى '+disp(s.to)+'</p>'
      +'<table><thead><tr><th>من</th><th>إلى</th><th>عدد الحبه</th><th>الشراء جديد</th><th>البيع جديد</th><th>ربح/خساره</th><th>الفارق</th></tr></thead><tbody>'
      +(body||'<tr><td colspan="7">لا توجد بيانات</td></tr>')+'</tbody><tfoot><tr><td colspan="2">الجملة</td><td>'+fmt(th)+'</td><td>'+fmt(tb)+'</td><td>'+fmt(ts)+'</td><td colspan="2">'+(net>0?'الباقي ربح: ':net<0?'الباقي خسارة: ':'')+fmt(Math.abs(net))+'</td></tr></tfoot></table></section>';
  }
  function printYears(list){
    window.__buyerPrintDoc('الكشف السنوي',list.map(yearPrintSection).join(''));
  }
  function printYear(spec){printYears([spec])}
  /* شريط علوي بالأزرار يظهر عند الضغط المطول (بدل النافذة السفلية) */
  function lpBar(items,cb,cls){
    var old=document.getElementById('lpMenuBar');if(old)old.remove();
    var bar=document.createElement('div');bar.id='lpMenuBar';bar.className='lp-bar'+(cls?' '+cls:'');
    bar.innerHTML=items.map(function(i){return '<button type="button" data-m="'+i[0]+'">'+i[1]+'</button>'}).join('')+'<button type="button" class="lp-x" data-m="__x" aria-label="إغلاق">'+(cls&&cls.indexOf('lp-multi')>=0?'✕ إغلاق':'✕')+'</button>';
    document.body.appendChild(bar);
    var off=function(){bar.classList.remove('on');setTimeout(function(){bar.remove()},180);document.removeEventListener('pointerdown',outside,true)};
    function outside(e){if(!bar.contains(e.target))off()}
    bar.addEventListener('click',function(e){
      var b=e.target.closest('[data-m]');if(!b)return;
      var m=b.getAttribute('data-m');off();if(m!=='__x')cb(m);
    });
    requestAnimationFrame(function(){bar.classList.add('on')});
    setTimeout(function(){document.addEventListener('pointerdown',outside,true)},450);
  }
  window.lpBar=lpBar;
  function yearTargets(spec){
    var fs=ST.year.fsel||(ST.year.fsel={});
    return fs[spec]?Object.keys(fs).filter(function(k){return fs[k]}):[spec];
  }
  function allYearSpecIds(){
    var ids=specs().map(function(x){return String(x.id)});
    if(annual().some(function(r){return !String(r.specialtyId||'')}))ids.push('');
    return ids;
  }
  function delYearFiles(list){
    var s=ST.year,all=[];
    list.forEach(function(sp){yearRowsFor(sp).forEach(function(r){all.push(r)})});
    if(!all.length){toast('لا توجد صفوف لمسحها في هذه الفترة');return}
    var run=function(){
      var l=annual();
      all.forEach(function(r){var i=l.indexOf(r);if(i>=0){l.splice(i,1);if(r.folderId&&!isHid(r.folderId))hid().push(r.folderId)}});
      s.fsel={};hookSales();save();renderYear();toast('تم مسح '+all.length+' صف من الكشف السنوي');
    };
    var msg='مسح '+all.length+' صف من '+(list.length>1?list.length+' تخاصيص':'هذا التخصيص')+' في الفترة المحددة؟';
    if(typeof customConfirm==='function')customConfirm(msg,run,null,{title:'مسح',icon:'🗑️',danger:true,confirmText:'مسح',cancelText:'إلغاء'});else if(confirm(msg))run();
  }
  function yearFileMenu(spec){
    var s=ST.year,fs=s.fsel||(s.fsel={});
    lpBar([['view','👁️ عرض'],['del','🗑️ مسح'],['sel',fs[spec]?'☑️ إلغاء التحديد':'✅ تحديد'],['all','☑️ تحديد الكل'],['print','🖨️ طباعة']],function(m){
      if(m==='view'){s.spec=spec;s.open=true;renderYear();window.scrollTo(0,0)}
      else if(m==='sel'){if(fs[spec])delete fs[spec];else fs[spec]=true;renderYear()}
      else if(m==='all'){s.fsel={};allYearSpecIds().forEach(function(k){s.fsel[k]=true});renderYear()}
      else if(m==='del')delYearFiles(yearTargets(spec));
      else if(m==='print')printYears(yearTargets(spec));
    },'lp-multi');
  }
  (function(){
    var tm=null,sx=0,sy=0;
    function clr(){if(tm){clearTimeout(tm);tm=null}}
    document.addEventListener('pointerdown',function(e){
      var c=e.target.closest&&e.target.closest('#'+IDS.year+' [data-yfile]');if(!c)return;
      sx=e.clientX;sy=e.clientY;clr();
      tm=setTimeout(function(){tm=null;window.__yLP=Date.now();yearFileMenu(c.getAttribute('data-yspec'))},550);
    });
    document.addEventListener('pointermove',function(e){if(tm&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10))clr()});
    ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,clr)});
    document.addEventListener('contextmenu',function(e){if(e.target.closest&&e.target.closest('#'+IDS.year+' [data-yfile]'))e.preventDefault()});
  })();

  /* ---------- الضغط المطول على أسبوع تحويل الشراء: عرض / تحديد / تحديد الكل / طباعة ---------- */
  function weekPrintHTML(f){
    var c=calc(f),t=tr(f);
    var body=c.days.map(function(d){var dn=DAYN[parse(d.date).getDay()];
      return '<tr><td>'+dn+' '+disp(d.date)+'</td><td>'+(d.has?fmt(d.qty):'')+'</td><td>'+(d.has?fmt(d.buy):'')+'</td><td>'+(d.has?fmt(d.exp):'')+'</td><td>'+(d.has?fmt(d.buy+d.exp):'')+'</td></tr>'}).join('');
    var row=function(a,b){return '<tr><td style="text-align:right">'+a+'</td><td>'+b+'</td></tr>'};
    return '<section style="page-break-after:always"><h2>تحويل الشراء — '+esc(f.name||'')+'</h2><p>من '+disp(f.startDate)+' إلى '+disp(f.endDate)+(f.order?' · رقم الجدول '+esc(f.order):'')+'</p>'
      +'<table><thead><tr><th>اليوم / التاريخ</th><th>عدد الحبة</th><th>سعر الشراء</th><th>خرج رداع</th><th>إجمالي الشراء</th></tr></thead><tbody>'+body
      +'</tbody><tfoot><tr><td>الجملة</td><td>'+fmt(c.qty)+'</td><td>'+fmt(c.buy)+'</td><td>'+fmt(c.exp)+'</td><td>'+fmt(c.oldTotal)+'</td></tr></tfoot></table>'
      +'<h3>تحويل الشراء جديد</h3><table class="kv"><tbody>'
      +row('مبلغ الشراء قديم',fmt(c.oldTotal))+row('سعر السعودي القديم',fmt(num(t.oldPrice)))+row('الشراء قديم = مبلغ سعودي على صرف رداع',fmt(r2(c.exchange)))
      +row('سعر شراء السعودي جديد',fmt(num(t.newPrice)))+row('الشراء قديم = الشراء جديد',fmt(r2(c.newTotal)))+'</tbody></table>'
      +'<h3>التفصيل النهائي</h3><table class="kv"><tbody>'
      +row('خرج إجار رداع جديد',fmt(num(t.rentRada)))+row('خرج إجار شحن جديد',fmt(num(t.rentShip)))+row('إجمالي الشراء مع الخرج جديد',fmt(r2(c.totalExp)))
      +row('بيع الأسبوع المفصل شحن',fmt(c.sale))+row('الفارق ('+c.state+')',fmt(r2(Math.abs(c.diff))))+'</tbody></table></section>';
  }
  function printWeeks(list){
    window.__buyerPrintDoc('تحويل الشراء',list.map(weekPrintHTML).join(''));
  }
  function weekTargets(id){
    var s=ST.transfer,ids=s.sel[id]?Object.keys(s.sel).filter(function(k){return s.sel[k]}):[id];
    return weeks().filter(function(f){return ids.indexOf(f.id)>=0});
  }
  function weekMoveDlg(list){
    var ov=document.createElement('div');ov.className='bq-ov';
    ov.innerHTML='<div class="bq-dlg"><h3>نقل '+list.length+' أسبوع إلى تخصيص</h3><select id="mvW"><option value="">بدون تخصيص</option>'
      +specs().map(function(x){return '<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>'}).join('')+'</select>'
      +'<div class="bq-btns"><button type="button" class="ok" data-d="ok">نقل</button><button type="button" data-d="x">إلغاء</button></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click',function(e){
      if(e.target===ov){ov.remove();return}
      var b=e.target.closest('[data-d]');if(!b)return;
      if(b.getAttribute('data-d')==='ok'){
        var v=ov.querySelector('#mvW').value;
        list.forEach(function(f){f.specialtyId=v;unhide(f.id);syncWeek(f)});
        ST.transfer.sel={};hookSales();save();renderTransfer();toast('تم نقل '+list.length+' أسبوع');
      }
      ov.remove();
    });
  }
  function copyWeeks(list){
    var n=0;
    list.forEach(function(f){
      var c=JSON.parse(JSON.stringify(f));
      c.id=Date.now().toString()+Math.random().toString(36).slice(2,5);
      c.name=(f.name||'أسبوع')+' (نسخة)';c.createdAt=Date.now();delete c.locked;
      if(c.transfer)delete c.transfer.sentAt;
      (c.invoices||[]).forEach(function(i){i.id=(typeof uid==='function'?uid('inv'):'inv'+Date.now()+Math.random().toString(36).slice(2,5))});
      data.folders.push(c);
      try{if(typeof ensureWeeklyFilterForFolder==='function')ensureWeeklyFilterForFolder(c)}catch(e){}
      if(window.bpEnsureWeek)window.bpEnsureWeek(c);
      n++;
    });
    ST.transfer.sel={};syncAll();save();renderTransfer();toast('تم نسخ '+n+' أسبوع');
  }
  function delWeeks(list){
    var run=function(){
      list.forEach(function(f){
        if(typeof addToTrash==='function')addToTrash(f,'folder',f.name);
        data.folders=data.folders.filter(function(x){return x.id!==f.id});
        var a=annual(),i=a.findIndex(function(x){return x.folderId===f.id});if(i>=0)a.splice(i,1);
      });
      ST.transfer.sel={};hookSales();save();renderTransfer();toast('نُقل '+list.length+' أسبوع إلى سلة المحذوفات');
    };
    var msg='نقل '+list.length+' أسبوع إلى سلة المحذوفات؟';
    if(typeof customConfirm==='function')customConfirm(msg,run,null,{title:'مسح',icon:'🗑️',danger:true,confirmText:'مسح',cancelText:'إلغاء'});else if(confirm(msg))run();
  }
  function weekMenu(id){
    var s=ST.transfer;
    lpBar([['view','👁️ عرض'],['del','🗑️ مسح'],['edit','✏️ تعديل'],['sel',s.sel[id]?'☑️ إلغاء التحديد':'✅ تحديد'],['all','☑️ تحديد الكل'],['move','📦 نقل'],['copy','📄 نسخ'],['print','🖨️ طباعة']],function(m){
      var tg=weekTargets(id);
      if(m==='view')window.openBuyerSheet(id);
      else if(m==='edit'){window.invScope='buyer';if(typeof openFolderEdit==='function')openFolderEdit(id)}
      else if(m==='sel'){if(s.sel[id])delete s.sel[id];else s.sel[id]=true;renderTransfer()}
      else if(m==='all'){s.sel={};weekRows().forEach(function(r){s.sel[r.key]=true});renderTransfer()}
      else if(m==='del')delWeeks(tg);
      else if(m==='move')weekMoveDlg(tg);
      else if(m==='copy')copyWeeks(tg);
      else if(m==='print'){
        var fl=tg.slice().sort(function(a,b){return String(a.startDate||'')<String(b.startDate||'')?-1:1});
        if(fl.length)printWeeks(fl);
      }
    },'lp-multi');
  }
  (function(){
    var tm=null,sx=0,sy=0;
    function clr(){if(tm){clearTimeout(tm);tm=null}}
    document.addEventListener('pointerdown',function(e){
      var c=e.target.closest&&e.target.closest('#'+IDS.transfer+' [data-week]');if(!c)return;
      sx=e.clientX;sy=e.clientY;clr();
      tm=setTimeout(function(){tm=null;window.__yLP=Date.now();weekMenu(c.getAttribute('data-week'))},550);
    });
    document.addEventListener('pointermove',function(e){if(tm&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10))clr()});
    ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,clr)});
    document.addEventListener('contextmenu',function(e){if(e.target.closest&&e.target.closest('#'+IDS.transfer+' [data-week]'))e.preventDefault()});
  })();

  /* إبقاء حقل الإدخال ظاهراً فوق لوحة المفاتيح داخل جدول تحويل الشراء */
  document.addEventListener('focusin',function(e){
    var el=e.target;if(!el||el.tagName!=='INPUT'||!el.closest||!el.closest('#'+IDS.sheet))return;
    setTimeout(function(){try{el.scrollIntoView({block:'center',behavior:'smooth'})}catch(x){}},300);
  });

  /* ---------- فتح الصفحات ---------- */
  window.openBuyerSub=function(id){
    var kind=id===IDS.year?'year':'transfer';
    window.invScope='buyer';
    if(!ST[kind])initState(kind);
    if(kind==='year')ST.year.open=false;
    tab(IDS[kind],true);
    var h=document.getElementById('headerTitle');if(h)h.textContent=TITLES[kind];
    clearNav();rerender(IDS[kind]);
  };
  window.openBuyerSheet=function(folderId){
    curWeek=folderId;window.invScope='buyer';
    tab(IDS.sheet,true);
    var h=document.getElementById('headerTitle');if(h)h.textContent='تحويل الشراء';
    clearNav();renderSheet();window.scrollTo(0,0);
  };
  window.bpSheetBack=function(){curWeek=null;window.openBuyerSub(IDS.transfer)};
  window.bpRefresh=function(){
    try{syncAll();saveSoon()}catch(e){}
    if(document.getElementById(IDS.transfer).classList.contains('on'))renderTransfer();
    else if(document.getElementById(IDS.year).classList.contains('on'))renderYear();
    else if(document.getElementById(IDS.sheet).classList.contains('on'))renderSheet();
  };
  var t0=window.tab;
  if(typeof t0==='function')window.tab=function(id){document.body.classList.toggle('bp-sub',id===IDS.transfer||id===IDS.year||id===IDS.sheet);return t0.apply(this,arguments)};
})();

/* ===== المتحكم: حوالات المبيعات + الأرباح والسحوبات ===== */
(function(){
  var PAGES={buySalesPage:{key:'buyerSalesTransfers',title:'حوالات المبيعات',ico:'💸',withType:false},
             buyProfitSellerPage:{key:'buyerProfitSeller',title:'الأرباح والسحوبات',sub:'قسم البائع',ico:'💰',withType:true},
             buyProfitSupplierPage:{key:'buyerProfitSupplier',title:'الأرباح والسحوبات',sub:'قسم المورد',ico:'💰',withType:true}};
  var ST={};
  var pad=function(n){return String(n).padStart(2,'0')};
  var iso=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
  var parse=function(s){return new Date(s+'T12:00:00')};
  var disp=function(s){return s?String(s).split('-').reverse().join('/'):'—'};
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
  var fmt=function(n){return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2})};
  var num=function(v){var s=String(v==null?'':v).replace(/[\u0660-\u0669]/g,function(d){return '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669'.indexOf(d)}).replace(/,/g,'');var n=parseFloat(s);return isFinite(n)?n:0};
  var r2=function(n){return Math.round(n*100)/100};
  function specs(){return (data.settings&&data.settings.buyerSpecialties)||[]}
  function specName(id){var s=specs().find(function(x){return String(x.id)===String(id||'')});return s?s.name:''}
  function list(pid){var s=data.settings;var k=PAGES[pid].key;if(!Array.isArray(s[k]))s[k]=[];return s[k]}
  function initState(pid){var y=new Date().getFullYear();ST[pid]={from:y+'-01-01',to:y+'-12-31',dir:'desc',spec:'all',sel:{}}}
  function newId(){return 'bq'+Date.now()+Math.random().toString(36).slice(2,5)}
  function signed(pid,r){return PAGES[pid].withType&&r.type==='سحب'?-num(r.amount):num(r.amount)}

  /* إجمالي لوحة المتحكم في صفحة الشرائي */
  function updateStats(){
    var s=data.settings;if(!s.buyerStats)s.buyerStats={};
    var t=0;list('buySalesPage').forEach(function(r){t+=r.auto?num(r.amount):-num(r.amount)});s.buyerStats.sales=r2(t);
    var p=0;list('buyProfitSellerPage').forEach(function(r){p+=signed('buyProfitSellerPage',r)});s.buyerStats.profitSeller=r2(p);
    var q=0;list('buyProfitSupplierPage').forEach(function(r){q+=signed('buyProfitSupplierPage',r)});s.buyerStats.profitSupplier=r2(q);
    if(typeof refreshBuyerStats==='function')refreshBuyerStats();
  }
  /* ---------- استقبال تلقائي من الكشف السنوي (نفس التخصيص) ---------- */
  window.bpSyncSales=function(){
    var st=data.settings,l=list('buySalesPage'),ann=Array.isArray(st.buyerAnnual)?st.buyerAnnual:[],keep={};
    ann.forEach(function(r){
      var q=num(r.habba),amt=num(r.sell);
      if(!(amt>0)&&!(q>0))return;
      var id='sy_'+r.id;keep[id]=1;
      var o=l.find(function(x){return x.id===id});
      if(!o){o={id:id,srcRow:r.id};l.push(o)}
      o.from=r.from||'';o.to=r.to||'';o.date=r.from||r.to||'';
      o.dir='لكم';o.qty=r2(q);o.unitPrice=q>0?r2(amt/q):0;o.amount=r2(amt);
      o.specialtyId=String(r.specialtyId||'');o.auto=true;
    });
    for(var i=l.length-1;i>=0;i--){if(l[i].auto&&!keep[l[i].id])l.splice(i,1)}
    /* الفارق (ربح/خسارة) من الكشف السنوي ← يُقسم نصفين: قسم البائع + قسم المورد */
    ['buyProfitSellerPage','buyProfitSupplierPage'].forEach(function(pid){
      var pl=list(pid),pk={};
      ann.forEach(function(r){
        var d=r.diff===''||r.diff==null?0:num(r.diff);
        if(!d)return;
        var id='pf_'+pid+'_'+r.id;pk[id]=1;
        var o=pl.find(function(x){return x.id===id});
        if(!o){o={id:id,srcRow:r.id};pl.push(o)}
        o.auto=true;o.autoProfit=true;
        o.from=r.from||'';o.to=r.to||'';o.date=r.from||r.to||'';
        o.kind=d>0?'ربح':'خسارة';
        o.type=d>0?'ربح':'سحب';
        o.amount=r2(Math.abs(d)/2);
        o.specialtyId=String(r.specialtyId||'');
      });
      for(var j=pl.length-1;j>=0;j--){if(pl[j].autoProfit&&!pk[pl[j].id])pl.splice(j,1)}
    });
    updateStats();
  };
  function rows(pid){
    if(window.bpSyncSales)window.bpSyncSales();
    var s=ST[pid];
    var out=list(pid).filter(function(r){
      var d=r.date||'',d2=r.to||d;
      if(s.from&&d2&&d2<s.from)return false;if(s.to&&d&&d>s.to)return false;
      if(s.spec!=='all'&&String(r.specialtyId||'')!==String(s.spec))return false;return true;
    });
    out.sort(function(a,b){var x=a.date||'',y=b.date||'',c=x<y?-1:x>y?1:0;return s.dir==='asc'?c:-c});
    return out;
  }
  function render(pid){
    var root=document.querySelector('#'+pid+' .bq-root');if(!root)return;
    if(!ST[pid])initState(pid);
    var P=PAGES[pid],s=ST[pid],rs=rows(pid);
    var selRows=rs.filter(function(r){return s.sel[r.id]}),base=selRows.length?selRows:rs;
    var allOn=rs.length>0&&selRows.length===rs.length;
    var sp='<option value="all"'+(s.spec==='all'?' selected':'')+'>كل التخاصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'"'+(String(x.id)===String(s.spec)?' selected':'')+'>'+esc(x.name)+'</option>'}).join('');
    var sum,nl,net,lbl,sub=P.sub?' '+P.sub:'';
    var card=function(v,l,col){return '<div class="bq2-c"><b style="color:'+col+'">'+fmt(v)+'</b><span>'+l+'</span></div>'};
    var debt=0,pay=0;
    if(P.withType){base.forEach(function(r){if(r.type==='سحب')debt+=num(r.amount);else pay+=num(r.amount)})}
    else{base.forEach(function(r){if(r.auto)pay+=num(r.amount);else debt+=num(r.amount)})}
    net=pay-debt;lbl=net>0?'الباقي لكم':net<0?'الباقي عليكم':'لا يوجد رصيد';
    sum=card(debt,'الإجمالي عليكم','#dc2626')+card(pay,'الإجمالي لكم','#15803d')+card(Math.abs(net),lbl,net<0?'#dc2626':net>0?'#15803d':'#0f172a');
    root.innerHTML='<div class="bp-top bq2-top"><button type="button" class="bp-back" data-q="back">رجوع ➜</button><h2>'+esc(P.title)+(P.sub?'<small>'+esc(P.sub)+'</small>':'')+'</h2>'
       +'<button type="button" class="bq2-hb" data-q="print">🖨️ طباعة</button><button type="button" class="bq2-hb" data-q="auth">📝 مصادقة</button></div>'
     +'<div class="bq2-spec"><label>التخاصيص</label><select data-qf="spec">'+sp+'</select><label class="bp-all"><input type="checkbox" data-q="all"'+(allOn?' checked':'')+'> تحديد الكل</label></div>'
     +'<div class="bq2-sum">'+sum+'</div>'
     +'<div class="bp-bar bp-sort"><select data-qf="by"><option value="date" selected>📅 التاريخ</option></select>'
       +'<button type="button" class="bp-seg'+(s.dir==='asc'?' on':'')+'" data-qdir="asc">↑ تصاعدي</button><button type="button" class="bp-seg'+(s.dir==='desc'?' on':'')+'" data-qdir="desc">↓ تنازلي</button></div>'
     +'<div class="date-bar date-range-unified"><button type="button" class="db-arrow" data-q="prev" aria-label="الفترة السابقة">←</button><div class="db-field"><input type="date" data-qf="from" value="'+esc(s.from)+'" aria-label="تاريخ البداية"></div><span class="db-sep">إلى</span><div class="db-field"><input type="date" data-qf="to" value="'+esc(s.to)+'" aria-label="تاريخ النهاية"></div><button type="button" class="db-arrow" data-q="next" aria-label="الفترة التالية">→</button></div>'
     +'<div class="bp-list">'+(rs.length?rs.map(function(r){
        var isSales=pid==='buySalesPage',sel=!!s.sel[r.id];
        var tag=P.withType?'<span class="bq-tag '+(r.type==='سحب'?'draw':'prof')+'">'+esc(r.type==='سحب'?'سحب':'ربح')+'</span>':'<span class="bq-tag draw">عليكم</span>';
        var sn=specName(r.specialtyId);
        var open='<div class="bp-card'+(sel?' sel':'')+'" data-qid="'+esc(r.id)+'">'+(isSales?'':'<label class="bp-ck"><input type="checkbox" data-qsel="'+esc(r.id)+'"'+(sel?' checked':'')+'></label>');
        if(r.autoProfit){
          var loss=r.kind==='خسارة';
          return open
            +'<div class="bp-main"><b>'+P.ico+' '+esc(sn||'بدون تخصيص')+' من '+disp(r.from)+' ← إلى '+disp(r.to)+'</b>'
            +'<small><span class="bq-tag '+(loss?'draw':'prof')+'">'+(loss?'عليكم':'لكم')+'</span> '+(loss?'خسارة':'ربح')+' · نصف فارق الأسبوع من الكشف السنوي</small></div>'
            +'<div class="bp-amt"><b class="'+(loss?'neg':'pos')+'">'+fmt(num(r.amount))+'</b><small>ريال</small></div></div>';
        }
        if(r.auto){
          return open
            +'<div class="bp-main"><b>'+P.ico+' من '+disp(r.from)+' ← إلى '+disp(r.to)+'<span class="bq-tag prof">لكم</span></b>'
            +'<small>عدد حبات '+fmt(r.qty)+' · بمبلغ بيعي '+fmt(r.unitPrice)+' · '+esc(sn||'بدون تخصيص')+'</small></div>'
            +'<div class="bp-amt"><b class="pos">'+fmt(num(r.amount))+'</b><small>إجمالي المبلغ البيع</small></div></div>';
        }
        return open
          +'<div class="bp-main"><b>'+P.ico+' '+disp(r.date)+tag+(r.img?' <span title="صورة مرفقة">📎</span>':'')+'</b><small>'+esc(sn||'بدون تخصيص')+((r.sender||r.receiver)?' · '+esc(r.sender||'—')+' ← '+esc(r.receiver||'—'):'')+(r.refNo?' · #'+esc(r.refNo):'')+(r.note?' · '+esc(r.note):'')+'</small></div>'
          +'<div class="bp-amt"><b class="'+(isSales||signed(pid,r)<0?'neg':'pos')+'">'+fmt(num(r.amount))+'</b></div></div>';
       }).join(''):'')+'</div>'
     +'<button type="button" class="bp-fab" data-q="add" aria-label="إضافة">+</button>';
  }
  function printPage(pid,auth,ids){
    var P=PAGES[pid],s=ST[pid],rs=rows(pid),debt=0,pay=0;
    if(ids&&ids.length)rs=rs.filter(function(r){return ids.indexOf(r.id)>=0});
    var body=rs.map(function(r){
      var a=num(r.amount),isD=P.withType?r.type==='سحب':!r.auto;if(isD)debt+=a;else pay+=a;
      return '<tr><td>'+disp(r.auto?r.from:r.date)+(r.auto?' → '+disp(r.to):'')+'</td><td>'+esc(specName(r.specialtyId)||'بدون تخصيص')+'</td><td>'+(P.withType?(isD?'سحب':'ربح'):(isD?'عليكم':'لكم'))+'</td><td>'+fmt(a)+'</td><td>'+esc(r.note||'')+'</td></tr>';
    }).join('')||'<tr><td colspan="5">لا توجد عناصر في هذه الفترة</td></tr>';
    var net=pay-debt,isVoucher=!!(ids&&ids.length);
    var ttl=(auth?'مصادقة':isVoucher?'سند معاملات':'كشف')+' — '+P.title+(P.sub?' — '+P.sub:'');
    var h='<p>الفترة: '+disp(s.from)+' إلى '+disp(s.to)+'</p>'
      +'<table><thead><tr><th>التاريخ</th><th>التخصيص</th><th>النوع</th><th>المبلغ</th><th>البيان</th></tr></thead><tbody>'+body+'</tbody>'
      +'<tfoot><tr><td colspan="3">الإجمالي عليكم: '+fmt(debt)+' | الإجمالي لكم: '+fmt(pay)+'</td><td colspan="2">'+(net>0?'الباقي لكم':net<0?'الباقي عليكم':'لا يوجد رصيد')+': '+fmt(Math.abs(net))+'</td></tr></tfoot></table>'
      +(auth?'<div class="sign"><span>الطرف الأول<br>الاسم: __________<br>التوقيع: __________</span><span>الطرف الثاني<br>الاسم: __________<br>التوقيع: __________</span></div>':'');
    window.__buyerPrintDoc(ttl,h);
  }
  /* ---------- نافذة إضافة/تعديل حوالة بيعية (تصميم سند الحوالة) ---------- */
  var SD_CUR=[['YER','ر.ي'],['SAR','ر.س'],['OMR','ر.ع'],['AED','د.إ'],['USD','$']];
  function salesDialog(id){
    var pid='buySalesPage',s=ST[pid];
    var r=id?list(pid).find(function(x){return x.id===id}):null;
    var saved=(r&&r.cur)||{};
    if(r&&!r.cur&&num(r.amount)>0)saved={YER:{a:r.amount,r:1}};
    var spSel=(r&&r.specialtyId)||(s.spec!=='all'?s.spec:'');
    var img=(r&&r.img)||'';
    var ov=document.createElement('div');ov.className='sd-ov';
    var spOpts='<option value="">بدون تخصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'"'+(String(x.id)===String(spSel)?' selected':'')+'>'+esc(x.name)+'</option>'}).join('');
    var rowsH=SD_CUR.map(function(c){var v=saved[c[0]]||{};
      return '<tr><td class="sd-cn">'+c[1]+'</td><td><input class="sd-in" inputmode="decimal" data-sa="'+c[0]+'" value="'+esc(v.a==null?'':v.a)+'"></td><td><input class="sd-in" inputmode="decimal" data-sr="'+c[0]+'" value="'+esc(v.r==null?1:v.r)+'"></td></tr>'}).join('');
    ov.innerHTML='<div class="sd-win">'
      +'<div class="sd-head"><button type="button" class="sd-x" data-d="cancel" aria-label="إغلاق">✕</button><h3>'+(r?'تعديل':'إضافة')+' سند حوالة بيعية</h3></div>'
      +'<div class="sd-body">'
        +'<div class="sd-top"><div class="sd-f sd-date"><label>التاريخ</label><div class="sd-dw"><input type="date" id="sdD" class="sd-in" value="'+esc((r&&r.date)||iso(new Date()))+'"><span class="sd-ic">📅</span></div></div>'
        +'<button type="button" class="sd-photo" id="sdPh">'+(img?'<img src="'+img+'" alt="">':'📷<span>صورة</span>')+'</button><input type="file" accept="image/*" id="sdFile" hidden></div>'
        +'<div class="sd-f"><label>التخصيص</label><select id="sdS" class="sd-in">'+spOpts+'</select></div>'
        +'<div class="sd-grid"><div class="sd-f"><label>اسم المرسل</label><input id="sdSn" class="sd-in" value="'+esc((r&&r.sender)||'')+'"></div>'
          +'<div class="sd-f"><label>اسم المستلم</label><input id="sdRc" class="sd-in" value="'+esc((r&&r.receiver)||'')+'"></div>'
          +'<div class="sd-f"><label>رقم الحوالة</label><input id="sdNo" class="sd-in" value="'+esc((r&&r.refNo)||'')+'"></div>'
          +'<div class="sd-f"><label>جهة الحوالة</label><input id="sdEn" class="sd-in" value="'+esc((r&&r.entity)||'')+'"></div></div>'
        +'<table class="sd-tbl"><thead><tr><th>العملة</th><th>المبلغ</th><th>سعر الصرف</th></tr></thead><tbody>'+rowsH+'</tbody></table>'
        +'<div class="sd-bot"><div class="sd-f"><label>مبلغ العمولة</label><input id="sdCm" class="sd-in" inputmode="decimal" value="'+esc((r&&r.commission)||'')+'"></div>'
          +'<div class="sd-res"><span>ناتج الصرف + العمولة</span><b id="sdRes">0</b></div></div>'
        +'<div class="sd-f"><label>البيان</label><textarea id="sdN" class="sd-in sd-ta">'+esc((r&&r.note)||'')+'</textarea></div>'
      +'</div>'
      +'<div class="sd-foot"><button type="button" class="sd-b" data-d="ok">حفظ</button><button type="button" class="sd-b" data-d="cancel">إلغاء</button>'+(r?'<button type="button" class="sd-b del" data-d="del">حذف</button>':'')+'</div></div>';
    document.body.appendChild(ov);
    var q=function(sel){return ov.querySelector(sel)};
    function total(){
      var sum=0,cur={};
      SD_CUR.forEach(function(c){var a=num(q('[data-sa="'+c[0]+'"]').value),rt=num(q('[data-sr="'+c[0]+'"]').value);if(!(rt>0))rt=1;
        if(a>0){sum+=a*rt;cur[c[0]]={a:a,r:rt}}});
      var cm=num(q('#sdCm').value);
      return {total:r2(sum+cm),cur:cur,cm:cm};
    }
    function upd(){q('#sdRes').textContent=fmt(total().total)}
    ov.addEventListener('input',upd);upd();
    q('#sdPh').addEventListener('click',function(){q('#sdFile').click()});
    q('#sdFile').addEventListener('change',function(){
      var f=this.files&&this.files[0];if(!f)return;
      var fr=new FileReader();
      fr.onload=function(){var im=new Image();im.onload=function(){
        var m=640,k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');
        c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);
        img=c.toDataURL('image/jpeg',.6);q('#sdPh').innerHTML='<img src="'+img+'" alt="">';
      };im.src=fr.result};
      fr.readAsDataURL(f);
    });
    var close=function(){ov.remove()};
    ov.addEventListener('click',function(e){
      var b=e.target.closest('[data-d]');if(!b)return;var a=b.getAttribute('data-d');
      if(a==='cancel'){close();return}
      if(a==='del'){var run=function(){var l=list(pid),i=l.findIndex(function(x){return x.id===id});if(i>=0)l.splice(i,1);save();updateStats();close();render(pid)};
        if(typeof customConfirm==='function')customConfirm('حذف هذا السجل؟',run,null,{title:'حذف',icon:'🗑️',danger:true,confirmText:'حذف',cancelText:'إلغاء'});else run();return}
      if(a==='ok'){
        var T=total();
        if(!(T.total>0)){if(typeof toast==='function')toast('أدخل مبلغاً صحيحاً');return}
        var o=r||{id:newId()};
        o.dir='عليكم';o.date=q('#sdD').value||iso(new Date());o.amount=T.total;o.cur=T.cur;o.commission=T.cm;
        o.specialtyId=q('#sdS').value;o.note=q('#sdN').value.trim();
        o.sender=q('#sdSn').value.trim();o.receiver=q('#sdRc').value.trim();o.refNo=q('#sdNo').value.trim();o.entity=q('#sdEn').value.trim();
        o.img=img||'';
        if(!r)list(pid).push(o);
        save();updateStats();close();render(pid);
      }
    });
  }
  /* ---------- الضغط المطول على حوالة بيعية: شريط علوي بالإجراءات ---------- */
  function targets(pid,id){
    var s=ST[pid],ids=s.sel[id]?Object.keys(s.sel).filter(function(k){return s.sel[k]}):[id];
    return list(pid).filter(function(r){return ids.indexOf(r.id)>=0});
  }
  function noteAuto(){if(typeof toast==='function')toast('هذا السجل يتحدث تلقائياً من الكشف السنوي')}
  function viewRec(pid,id){
    var r=list(pid).find(function(x){return x.id===id});if(!r)return;
    var row=function(a,b){return b===''||b==null?'':'<div class="vw-r"><span>'+a+'</span><b>'+b+'</b></div>'};
    var cur=r.cur?SD_CUR.filter(function(c){return r.cur[c[0]]}).map(function(c){return '<div class="vw-r"><span>'+c[1]+'</span><b>'+fmt(r.cur[c[0]].a)+' × '+fmt(r.cur[c[0]].r)+'</b></div>'}).join(''):'';
    var ov=document.createElement('div');ov.className='bq-ov';
    var isS=pid==='buySalesPage',Pg=PAGES[pid];
    var typ=isS?(r.auto?'لكم':'عليكم'):(r.autoProfit?(r.kind==='خسارة'?'عليكم (خسارة)':'لكم (ربح)'):(r.type==='سحب'?'سحب (عليكم)':'ربح (لكم)'));
    ov.innerHTML='<div class="bq-dlg"><h3>'+(r.auto?'من الكشف السنوي':(isS?'حوالة بيعية':esc(Pg.title+(Pg.sub?' — '+Pg.sub:''))))+'</h3>'
      +row('النوع',typ)+row('التاريخ',r.auto?disp(r.from)+' ← '+disp(r.to):disp(r.date))
      +row('التخصيص',esc(specName(r.specialtyId)||'بدون تخصيص'))+row('المرسل',esc(r.sender||''))+row('المستلم',esc(r.receiver||''))
      +row('رقم الحوالة',esc(r.refNo||''))+row('جهة الحوالة',esc(r.entity||''))+cur+row('العمولة',r.commission?fmt(r.commission):'')
      +row('المبلغ',fmt(num(r.amount)))+row('البيان',esc(r.note||''))
      +'<div class="bq-btns"><button type="button" data-d="x">إغلاق</button></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click',function(e){if(e.target===ov||e.target.closest('[data-d]'))ov.remove()});
  }
  function viewImg(r){
    if(!r||!r.img){if(typeof toast==='function')toast('لا توجد صورة مرفقة بهذه المعاملة');return}
    var ov=document.createElement('div');ov.className='sd-img';
    ov.innerHTML='<button type="button" class="sd-x">✕</button><img src="'+r.img+'" alt="">';
    document.body.appendChild(ov);ov.addEventListener('click',function(){ov.remove()});
  }
  function moveDlg(pid,recs){
    var ov=document.createElement('div');ov.className='bq-ov';
    ov.innerHTML='<div class="bq-dlg"><h3>نقل '+recs.length+' معاملة إلى تخصيص</h3><select id="mvS"><option value="">بدون تخصيص</option>'
      +specs().map(function(x){return '<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>'}).join('')+'</select>'
      +'<div class="bq-btns"><button type="button" class="ok" data-d="ok">نقل</button><button type="button" data-d="x">إلغاء</button></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click',function(e){
      if(e.target===ov){ov.remove();return}
      var b=e.target.closest('[data-d]');if(!b)return;
      if(b.getAttribute('data-d')==='ok'){var v=ov.querySelector('#mvS').value;recs.forEach(function(r){r.specialtyId=v});save();updateStats();ST[pid].sel={};render(pid)}
      ov.remove();
    });
  }
  function recMenu(pid,id){
    var s=ST[pid],cur=list(pid).find(function(x){return x.id===id});if(!cur)return;
    var items=[['view','👁️ عرض'],['del','🗑️ مسح'],['edit','✏️ تعديل'],['sel',s.sel[id]?'☑️ إلغاء التحديد':'✅ تحديد'],['all','☑️ تحديد الكل'],['move','📦 نقل'],['copy','📄 نسخ'],['print','🖨️ طباعة']];
    if(cur.img)items.push(['img','🖼️ عرض الصورة المرفقة']);
    window.lpBar(items,function(m){
      var recs=targets(pid,id),man=recs.filter(function(r){return !r.auto});
      if(m==='view')viewRec(pid,id);
      else if(m==='edit'){if(cur.auto)noteAuto();else dialog(pid,id)}
      else if(m==='sel'){if(s.sel[id])delete s.sel[id];else s.sel[id]=true;render(pid)}
      else if(m==='all'){s.sel={};rows(pid).forEach(function(r){s.sel[r.id]=true});render(pid)}
      else if(m==='print')printPage(pid,false,recs.map(function(r){return r.id}));
      else if(m==='img')viewImg(cur);
      else if(m==='del'){
        if(!man.length){noteAuto();return}
        var run=function(){var l=list(pid);man.forEach(function(r){var i=l.indexOf(r);if(i>=0)l.splice(i,1)});s.sel={};save();updateStats();render(pid)};
        if(typeof customConfirm==='function')customConfirm('حذف '+man.length+' معاملة؟',run,null,{title:'حذف',icon:'🗑️',danger:true,confirmText:'حذف',cancelText:'إلغاء'});else run();
      }
      else if(m==='copy'){
        if(!man.length){noteAuto();return}
        man.forEach(function(r){var c=JSON.parse(JSON.stringify(r));c.id=newId();list(pid).push(c)});
        s.sel={};save();updateStats();render(pid);if(typeof toast==='function')toast('تم نسخ '+man.length+' معاملة');
      }
      else if(m==='move'){if(!man.length){noteAuto();return}moveDlg(pid,man)}
    },'lp-multi');
  }
  (function(){
    var tm=null,sx=0,sy=0;
    function clr(){if(tm){clearTimeout(tm);tm=null}}
    document.addEventListener('pointerdown',function(e){
      var c=e.target.closest&&e.target.closest('.bq-root [data-qid]');if(!c||!PAGES[pidOf(c)])return;
      sx=e.clientX;sy=e.clientY;clr();
      tm=setTimeout(function(){tm=null;window.__qLP=Date.now();recMenu(pidOf(c),c.getAttribute('data-qid'))},550);
    });
    document.addEventListener('pointermove',function(e){if(tm&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10))clr()});
    ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,clr)});
    document.addEventListener('contextmenu',function(e){if(e.target.closest&&e.target.closest('.bq-root [data-qid]'))e.preventDefault()});
  })();
  function dialog(pid,id){
    if(pid==='buySalesPage')return salesDialog(id);
    var P=PAGES[pid],r=id?list(pid).find(function(x){return x.id===id}):null;
    var s=ST[pid];
    var spSel=(r&&r.specialtyId)||(s.spec!=='all'?s.spec:'');
    var ov=document.createElement('div');ov.className='bq-ov';
    ov.innerHTML='<div class="bq-dlg"><h3>'+(r?'تعديل':'إضافة')+' — '+esc(P.title)+(P.sub?' '+esc(P.sub):'')+'</h3>'
      +'<label>التاريخ</label><input type="date" id="bqD" value="'+esc((r&&r.date)||iso(new Date()))+'">'
      +(P.withType?'<label>النوع</label><select id="bqT"><option value="ربح"'+(!r||r.type!=='سحب'?' selected':'')+'>ربح</option><option value="سحب"'+(r&&r.type==='سحب'?' selected':'')+'>سحب</option></select>':'')
      +'<label>المبلغ</label><input type="number" inputmode="decimal" id="bqA" value="'+esc(r?r.amount:'')+'">'
      +'<label>التخصيص</label><select id="bqS"><option value="">بدون تخصيص</option>'+specs().map(function(x){return '<option value="'+esc(x.id)+'"'+(String(x.id)===String(spSel)?' selected':'')+'>'+esc(x.name)+'</option>'}).join('')+'</select>'
      +'<label>البيان</label><textarea id="bqN">'+esc((r&&r.note)||'')+'</textarea>'
      +'<div class="bq-btns"><button type="button" class="ok" data-d="ok">حفظ</button>'+(r?'<button type="button" class="del" data-d="del">حذف</button>':'')+'<button type="button" data-d="cancel">إلغاء</button></div></div>';
    document.body.appendChild(ov);
    var close=function(){ov.remove()};
    ov.addEventListener('click',function(e){
      if(e.target===ov){close();return}
      var b=e.target.closest('[data-d]');if(!b)return;var a=b.getAttribute('data-d');
      if(a==='cancel'){close();return}
      if(a==='del'){var run=function(){var l=list(pid),i=l.findIndex(function(x){return x.id===id});if(i>=0)l.splice(i,1);save();updateStats();close();render(pid)};
        if(typeof customConfirm==='function')customConfirm('حذف هذا السجل؟',run,null,{title:'حذف',icon:'🗑️',danger:true,confirmText:'حذف',cancelText:'إلغاء'});else run();return}
      if(a==='ok'){
        var amt=num(ov.querySelector('#bqA').value);
        if(!(amt>0)){if(typeof toast==='function')toast('أدخل مبلغاً صحيحاً');return}
        var o=r||{id:newId()};
        o.date=ov.querySelector('#bqD').value||iso(new Date());o.amount=amt;
        o.specialtyId=ov.querySelector('#bqS').value;o.note=ov.querySelector('#bqN').value.trim();
        if(P.withType)o.type=ov.querySelector('#bqT').value;
        if(!r)list(pid).push(o);
        save();updateStats();close();render(pid);
      }
    });
  }
  function shift(pid,dir){
    var s=ST[pid],f=parse(s.from),t=parse(s.to);
    var full=f.getMonth()===0&&f.getDate()===1&&t.getMonth()===11&&t.getDate()===31&&f.getFullYear()===t.getFullYear();
    if(full){f.setFullYear(f.getFullYear()+dir);t.setFullYear(t.getFullYear()+dir)}
    else{var span=Math.round((t-f)/86400000)+1;f.setDate(f.getDate()+dir*span);t.setDate(t.getDate()+dir*span)}
    s.from=iso(f);s.to=iso(t);s.sel={};
  }
  function pidOf(el){var r=el.closest('.bq-root');return r&&r.parentNode.id}
  document.addEventListener('click',function(e){
    var el=e.target.closest&&e.target.closest('.bq-root *');if(!el)return;
    var pid=pidOf(el);if(!pid||!PAGES[pid])return;var s=ST[pid];
    var d=el.closest('[data-qdir]');if(d){s.dir=d.getAttribute('data-qdir');render(pid);return}
    var a=el.closest('[data-q]');
    if(a){var act=a.getAttribute('data-q');
      if(act==='back'){if(window.showPurchasePage)showPurchasePage();return}
      if(act==='prev'||act==='next'){shift(pid,act==='prev'?-1:1);render(pid);return}
      if(act==='add'){dialog(pid,null);return}
      if(act==='print'){printPage(pid,false);return}
      if(act==='auth'){printPage(pid,true);return}
      if(act==='all')return;
    }
    if(el.closest('.bp-ck'))return;
    var c=el.closest('[data-qid]');if(c){var rid=c.getAttribute('data-qid'),rec=list(pid).find(function(x){return x.id===rid});
      if(window.__qLP&&Date.now()-window.__qLP<900)return;if(Object.keys(s.sel).some(function(k){return s.sel[k]})){if(s.sel[rid])delete s.sel[rid];else s.sel[rid]=true;render(pid);return}
      if(rec&&rec.auto){if(typeof toast==='function')toast('يتحدث تلقائياً من الكشف السنوي');return}
      dialog(pid,rid)}
  });
  document.addEventListener('change',function(e){
    var el=e.target;if(!el.closest||!el.closest('.bq-root'))return;
    var pid=pidOf(el);if(!pid||!PAGES[pid])return;var s=ST[pid];
    var f=el.getAttribute('data-qf');
    if(f){if(f!=='by')s[f]=el.value||(f==='spec'?'all':s[f]);s.sel={};render(pid);return}
    if(el.getAttribute('data-q')==='all'){s.sel={};if(el.checked)rows(pid).forEach(function(r){s.sel[r.id]=true});render(pid);return}
    var k=el.getAttribute('data-qsel');if(k!==null){if(el.checked)s.sel[k]=true;else delete s.sel[k];render(pid)}
  });
  var open0=window.openBuyerSub;
  window.openBuyerSub=function(id){
    if(!PAGES[id])return open0.apply(this,arguments);
    window.invScope='buyer';
    if(!ST[id])initState(id);
    render(id);
    document.body.classList.add('bp-sub');
    tab(id,true);
    var h=document.getElementById('headerTitle');if(h)h.textContent=PAGES[id].title;
    if(typeof clearNav==='function')clearNav();
  };
  var rf0=window.bpRefresh;
  window.bpRefresh=function(){
    for(var id in PAGES){var e=document.getElementById(id);if(e&&e.classList.contains('on')){render(id);return}}
    if(rf0)return rf0.apply(this,arguments);
  };
  var t1=window.tab;
  if(typeof t1==='function')window.tab=function(id){
    var r=t1.apply(this,arguments);
    if(PAGES[id])document.body.classList.add('bp-sub');
    return r;
  };
})();

/* ===== الأشرطة ثابتة: صفحات الشرائي بتخطيط عمودي ثابت، وصفحة الفواتير بنقل أشرطة المجلد خارج منطقة التمرير ===== */
(function(){
  var BAR_SORT=function(k){return k.matches&&(k.matches('.date-bar')||(k.querySelector&&k.querySelector(':scope select[onchange]')&&k.getBoundingClientRect().height<=72)||k.matches('.cur-tabs,.currency-tabs'))};
  function holder(){
    var cv=document.getElementById('currentView');if(!cv||!cv.parentNode)return null;
    var h=document.getElementById('cvBars');
    if(!h){h=document.createElement('div');h.id='cvBars';h.className='cv-bars';cv.parentNode.insertBefore(h,cv)}
    return h;
  }
  function moveBars(){
    var sec=document.getElementById('invoices');if(!sec||!sec.classList.contains('on'))return;
    var cv=document.getElementById('currentView'),h=holder();if(!cv||!h)return;
    var kids=Array.prototype.slice.call(cv.children),lead=[];
    for(var i=0;i<kids.length;i++){if(BAR_SORT(kids[i]))lead.push(kids[i]);else break}
    if(!lead.length)return;
    h.innerHTML='';
    lead.forEach(function(el){h.appendChild(el)});
  }
  function wrap(){
    if(typeof window.renderCurrentView!=='function'||window.renderCurrentView.__cvw)return;
    var orig=window.renderCurrentView;
    var w=function(){var h=document.getElementById('cvBars');if(h)h.innerHTML='';var r=orig.apply(this,arguments);try{moveBars()}catch(e){}return r};
    w.__cvw=1;window.renderCurrentView=w;
  }
  function init(){
    wrap();
    var cv=document.getElementById('currentView');
    if(cv){new MutationObserver(function(){try{moveBars()}catch(e){}}).observe(cv,{childList:true})}
    setTimeout(function(){try{moveBars()}catch(e){}},300);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* اقتراح الأسماء المتكررة في نوافذ الإدخال: تُجمع الأسماء من البيانات المحفوظة وتُعرض كقائمة اقتراحات عند التركيز على حقل نصي */
(function(){
 if(window.__nameSugg)return;window.__nameSugg=1;
 var KEY=/name|acc|cust|client|person|holder|debt|دين|اسم|حساب|عميل|مورد|صندوق|مندوب/i;
 var SKIP=/amount|مبلغ|سعر|رقم|phone|tel|هاتف|rate|date|تاريخ|search|بحث|note|بيان|pass|code|rate/i;
 var cache={at:0,list:[]},seen=0,counts={},n=0;
 function add(s){s=String(s==null?'':s).trim().replace(/\s+/g,' ');if(s.length<2||s.length>60||/\d{3,}/.test(s))return;counts[s]=(counts[s]||0)+1}
 function walk(o,depth,inKey){
  if(o==null||depth>14||seen>2000000)return;seen++;
  if(typeof o==='string'){if(inKey)add(o);return}
  if(Array.isArray(o)){o.forEach(function(x){walk(x,depth+1,inKey)});return}
  if(typeof o==='object'){Object.keys(o).forEach(function(k){walk(o[k],depth+1,KEY.test(k))})}
 }
 function collect(){
  if(Date.now()-cache.at<3000)return cache.list;
  counts={};seen=0;
  try{if(typeof data!=='undefined')walk(data,0,false)}catch(e){}
  try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i),v=localStorage.getItem(k);if(!v||v.length>3000000||(v[0]!=='{'&&v[0]!=='['))continue;try{walk(JSON.parse(v),0,false)}catch(e){}}}catch(e){}
  cache={at:Date.now(),list:Object.keys(counts).sort(function(a,b){return counts[b]-counts[a]||a.localeCompare(b,'ar')}).slice(0,12)};
  return cache.list;
 }
 function eligible(el){
  if(!el||el.tagName!=='INPUT')return false;
  var t=(el.type||'text').toLowerCase();if(t!=='text'&&t!=='search')return false;
  if(el.readOnly||el.disabled)return false;
  if(/numeric|decimal|tel/.test(el.getAttribute('inputmode')||''))return false;
  if(el.getAttribute('list')&&!el.dataset.nameSuggOwn)return false;
  var s=(el.id||'')+' '+(el.name||'')+' '+(el.placeholder||'')+' '+(el.getAttribute('aria-label')||'');
  return !SKIP.test(s);
 }
 function attach(el){
  if(!eligible(el))return;
  var names=collect();if(!names.length)return;
  var dl=el.dataset.nameSuggOwn&&document.getElementById(el.dataset.nameSuggOwn);
  if(!dl){dl=document.createElement('datalist');dl.id='nameSugg'+(++n);document.body.appendChild(dl);el.dataset.nameSuggOwn=dl.id;el.setAttribute('list',dl.id)}
  dl.innerHTML=names.map(function(x){return '<option value="'+x.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')+'">'}).join('');
 }
 document.addEventListener('focusin',function(e){try{attach(e.target)}catch(err){}},true);
})();

/* قائمة نسخ / لصق / تحديد لكل حقول الإدخال (نصوص وأرقام): بالزر الأيمن أو الضغط المطوّل على الجوال */
(function(){
 if(window.__inputMenu)return;window.__inputMenu=1;
 var menu=null,timer=null,SKIPT=/^(checkbox|radio|button|submit|file|range|color|date|time|datetime-local|month|week|hidden|image|reset)$/i;
 function msg(t){if(typeof toast==='function')toast(t)}
 function hide(){if(menu){menu.remove();menu=null}}
 function field(t){return t&&(t.tagName==='TEXTAREA'||(t.tagName==='INPUT'&&!SKIPT.test(t.type||'text')&&!t.readOnly||t.tagName==='INPUT'&&t.readOnly&&!SKIPT.test(t.type||'text')))?t:null}
 function fire(el){el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))}
 function selText(el){try{var s=el.selectionStart,e=el.selectionEnd;if(s!=null&&e!=null&&s!==e)return el.value.slice(s,e)}catch(x){}return el.value||''}
 function fallbackCopy(txt){var ta=document.createElement('textarea');ta.value=txt;ta.style.cssText='position:fixed;opacity:0;top:0;left:0';document.body.appendChild(ta);ta.select();var ok=false;try{ok=document.execCommand('copy')}catch(x){}ta.remove();return ok}
 function doCopy(el){var txt=selText(el);el.focus();
  var p=(navigator.clipboard&&navigator.clipboard.writeText)?navigator.clipboard.writeText(txt):Promise.reject();
  p.catch(function(){if(!fallbackCopy(txt))msg('تعذر النسخ')}).then(function(){msg('تم النسخ')});}
 function doSelect(el){el.focus();try{el.select()}catch(x){}}
 function insertAt(el,txt){el.focus();
  if(el.type==='number'||el.selectionStart==null){el.value=(el.value||'')+txt}
  else{var s=el.selectionStart,e=el.selectionEnd;el.value=el.value.slice(0,s)+txt+el.value.slice(e);var pos=s+txt.length;try{el.setSelectionRange(pos,pos)}catch(x){}}
  fire(el)}
 function doPaste(el){el.focus();
  if(!(navigator.clipboard&&navigator.clipboard.readText)){msg('اضغط مطولًا ثم اختر لصق من النظام');return}
  navigator.clipboard.readText().then(function(t){if(!t){msg('الحافظة فارغة');return}insertAt(el,el.type==='number'?t.trim():t)}).catch(function(){msg('السماح بالوصول للحافظة مطلوب، أو استخدم اللصق من النظام')})}
 function btn(label,fn){var b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='display:block;width:100%;min-height:40px;padding:8px 14px;border:0;background:transparent;font-weight:800;font-size:15px;font-family:Tajawal,Tahoma,sans-serif;text-align:right;cursor:pointer;color:#111';b.onmouseenter=function(){b.style.background='#eef2ff'};b.onmouseleave=function(){b.style.background='transparent'};b.onclick=function(ev){ev.stopPropagation();fn();hide()};return b}
 function show(el,x,y){hide();menu=document.createElement('div');menu.setAttribute('role','menu');
  menu.style.cssText='position:fixed;z-index:2147483000;min-width:150px;background:#fff;border:1px solid #cbd5e1;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.2);direction:rtl;overflow:hidden;padding:4px 0';
  menu.appendChild(btn('تحديد الكل',function(){doSelect(el)}));
  menu.appendChild(btn('نسخ',function(){doCopy(el)}));
  menu.appendChild(btn('لصق',function(){doPaste(el)}));
  document.body.appendChild(menu);
  var w=menu.offsetWidth,h=menu.offsetHeight;menu.style.left=Math.max(4,Math.min(x,innerWidth-w-4))+'px';menu.style.top=Math.max(4,Math.min(y,innerHeight-h-4))+'px';}
 document.addEventListener('contextmenu',function(e){var el=field(e.target);if(!el)return;e.preventDefault();show(el,e.clientX,e.clientY)},true);
 document.addEventListener('touchstart',function(e){var el=field(e.target);if(!el)return;var t=e.touches[0],x=t.clientX,y=t.clientY;clearTimeout(timer);timer=setTimeout(function(){show(el,x,y)},550)},{passive:true,capture:true});
 ['touchmove','touchend','touchcancel'].forEach(function(ev){document.addEventListener(ev,function(){clearTimeout(timer)},{passive:true,capture:true})});
 document.addEventListener('pointerdown',function(e){if(menu&&!menu.contains(e.target))hide()},true);
 document.addEventListener('keydown',function(e){if(e.key==='Escape')hide()},true);
 window.addEventListener('scroll',hide,true);
})();

/* تحويل الأرقام إلى إنجليزية (0-9) في كل مكان: القيم والتخزين والطباعة */
(function(){
 function toW(x){return String(x==null?'':x).replace(/[\u0660-\u0669]/g,function(c){return String.fromCharCode(c.charCodeAt(0)-1584)}).replace(/[\u06F0-\u06F9]/g,function(c){return String.fromCharCode(c.charCodeAt(0)-1728)})}
 window.__toWestern=toW;
 /* كل كتابة في التخزين المحلي تمر بالتحويل، والقيم القديمة تُصحَّح مرة واحدة */
 try{
  var _set=Storage.prototype.setItem;
  Storage.prototype.setItem=function(k,v){return _set.call(this,k,toW(v))};
  for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i),v=localStorage.getItem(k);if(v&&/[\u0660-\u0669\u06F0-\u06F9]/.test(v)){_set.call(localStorage,k,toW(v));}}
 }catch(e){}
})();
/* حفظ موضع المؤشر: إذا أعاد التطبيق كتابة قيمة الحقل وهو مفتوح (مثلاً عند تنسيق الأرقام أو النصوص) يبقى المؤشر في مكانه بدل القفز إلى النهاية */
(function(){
 function guard(proto){
  var desc=Object.getOwnPropertyDescriptor(proto,'value');
  if(!desc||!desc.set)return;
  Object.defineProperty(proto,'value',{configurable:true,enumerable:desc.enumerable,get:desc.get,set:function(v){
   v=window.__toWestern?window.__toWestern(v):v;
   if(document.activeElement!==this)return desc.set.call(this,v);
   var s=null;try{s=this.selectionStart}catch(x){}
   var before=desc.get.call(this);
   desc.set.call(this,v);
   var after=desc.get.call(this);
   if(s===null||before===after)return;
   try{var p=Math.min(s,after.length);this.setSelectionRange(p,p)}catch(x){}
  }});
 }
 try{guard(HTMLInputElement.prototype);guard(HTMLTextAreaElement.prototype)}catch(e){}
})();

/* إخفاء زر الإضافة (+) في الصفحة الرئيسية فقط؛ يبقى ظاهراً في الفواتير وباقي الصفحات */
(function(){
 function init(){
  var st=document.createElement('style');
  st.textContent='body.fab-home-hidden:not(.full-filter-open) .fab{display:none!important}';
  document.head.appendChild(st);
  var home=document.getElementById('home');
  function sync(){document.body.classList.toggle('fab-home-hidden',!!home&&home.classList.contains('on'))}
  if(home&&window.MutationObserver)new MutationObserver(sync).observe(home,{attributes:true,attributeFilter:['class']});
  sync();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
