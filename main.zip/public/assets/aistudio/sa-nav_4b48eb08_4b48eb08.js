/* Optional navigation helper compatibility entry point. */
window.SmartAdminNavigation = window.SmartAdminNavigation || {};
