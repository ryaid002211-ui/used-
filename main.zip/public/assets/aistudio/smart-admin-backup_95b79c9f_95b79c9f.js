/* النسخ الاحتياطي الموحد للإداري برو: يجمع بيانات كل الصفحات من localStorage المشترك. */
(function () {
  'use strict';
  const FORMAT = 'smart-admin-unified-backup';
  const SECRET_KEY = /(access.?token|refresh.?token|oauth.?token|bio_cred|credential_secret)/i;
  function collectStorage() {
    const storage = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || SECRET_KEY.test(key)) continue;
      try {
        const value = localStorage.getItem(key);
        if (typeof value === 'string') storage[key] = value;
      } catch (e) { console.warn('تعذر تضمين عنصر في النسخة الموحدة:', key, e); }
    }
    return storage;
  }
  window.SmartAdminBackup = {
    create: function () {
      return { format: FORMAT, version: 2, createdAt: new Date().toISOString(),
        scope: ['index.html', 'AL365.html', 'HA7.html', 'TS1.html', 'T.html'],
        storage: collectStorage() };
    },
    restore: function (backup) {
      if (!backup || backup.format !== FORMAT || !backup.storage ||
          typeof backup.storage !== 'object' || Array.isArray(backup.storage)) {
        throw new Error('ملف النسخة الموحدة غير صالح أو غير مدعوم');
      }
      const entries = Object.entries(backup.storage);
      if (!entries.length) throw new Error('النسخة لا تحتوي على بيانات');
      for (const [key, value] of entries) {
        if (typeof key !== 'string' || typeof value !== 'string') throw new Error('بنية بيانات النسخة غير صالحة');
      }
      let restored = 0;
      for (const [key, value] of entries) {
        if (SECRET_KEY.test(key)) continue;
        localStorage.setItem(key, value);
        restored++;
      }
      return restored;
    }
  };
})();
