package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ClockDetailScreen(
    section: ClockSection,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val haptic = LocalHapticFeedback.current

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var search by remember { mutableStateOf("") }
    var sortField by remember { mutableStateOf("date") } // date, name, amount
    var sortAsc by remember { mutableStateOf(true) }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingCurrencyEntry by remember { mutableStateOf<ClockEntry?>(null) }
    var showCurrencyOpDialog by remember { mutableStateOf<String?>(null) } // "receipt" or "exchange"
    var selectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    val specMap = remember(uiState.settings.specialties) {
        uiState.settings.specialties.associate { it.id to it.name }
    }
    val entries = remember(uiState.snapshot.clockEntries, section, uiState.settings.activeSpecialty, fromDate, toDate, search) {
        uiState.snapshot.clockEntries
            .filter { it.section == section }
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.activeSpecialty) }
            .filter { e ->
                val d = e.date.ifBlank { e.to }
                (fromDate.isBlank() || d.isBlank() || d >= fromDate) &&
                    (toDate.isBlank() || d.isBlank() || d <= toDate)
            }
            .filter { e ->
                search.isBlank() || e.name.contains(search, true) || e.note.contains(search, true)
            }
            .sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
    }

    val running = remember(entries) { ClockCalculator.runningBalances(entries) }
    val sortedEntries = remember(entries, sortField, sortAsc) {
        val base = when (sortField) {
            "name" -> entries.sortedBy { it.note.ifBlank { it.name } }
            "amount" -> entries.sortedBy { abs(it.amount) }
            else -> entries
        }
        if (sortAsc) base else base.reversed()
    }
    val credit = remember(entries) { entries.filter { it.dir != "عليكم" }.sumOf { abs(it.amount) } }
    val debit = remember(entries) { entries.filter { it.dir == "عليكم" }.sumOf { abs(it.amount) } }
    val net = credit - debit

    Scaffold(
        topBar = {
            DebtsTopLuxuryBar(
                title = if (uiState.settings.lang == "en") section.labelEn else section.labelAr,
                onBack = onBack,
                actions = {
                    DebtsHeaderActionButton(
                        label = strings.print,
                        icon = Icons.Default.Print,
                        onClick = {
                            val html = PrintReportBuilders.buildClockLedgerHtml(section, entries, fromDate, toDate, false, uiState.settings)
                            viewModel.printHtmlReport(activity, section.labelAr, html)
                        },
                        testTag = "clock_print_btn"
                    )
                    DebtsHeaderActionButton(
                        label = strings.auth,
                        icon = Icons.Default.Verified,
                        onClick = {
                            val html = PrintReportBuilders.buildClockLedgerHtml(section, entries, fromDate, toDate, true, uiState.settings)
                            viewModel.printHtmlReport(activity, "مصادقة ${section.labelAr}", html)
                        },
                        testTag = "clock_auth_btn"
                    )
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (section == ClockSection.CURRENCY) editingCurrencyEntry = ClockEntry(section = ClockSection.CURRENCY)
                    else showAddDialog = true
                },
                modifier = Modifier.testTag("clock_add_entry_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.t("إضافة قيد", "Add Entry"))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpecialtyFilterBar(
                    specialties = uiState.settings.specialties,
                    selectedId = uiState.settings.activeSpecialty,
                    onSelect = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty
                )
                Text(
                    text = "${strings.t("الحركات", "Entries")}: ${entries.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DateRangeBar(fromDate, toDate, onRangeChange = { f, t -> fromDate = f; toDate = t })

            if (section == ClockSection.CURRENCY) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { showCurrencyOpDialog = "receipt" },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.t("حوالة من العملات", "Remittance"))
                    }
                    FilledTonalButton(
                        onClick = { showCurrencyOpDialog = "exchange" },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.CurrencyExchange, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.t("مصارفة عملة", "Exchange"))
                    }
                }
                ClockCurrencyStripBar(
                    entries = entries,
                    currencies = uiState.settings.currencies
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryStatCard(strings.credit, fmt(credit), AppColors.CreditGreen, Modifier.weight(1f))
                    SummaryStatCard(strings.debit, fmt(debit), AppColors.DebitRed, Modifier.weight(1f))
                    SummaryStatCard(
                        strings.net,
                        fmt(abs(net)),
                        if (net >= 0) AppColors.CreditGreen else AppColors.DebitRed,
                        Modifier.weight(1f)
                    )
                }
            }

            if (selectMode) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { selectedIds = entries.filter { it.tsVoucherId.isBlank() }.map { it.id }.toSet() },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text("☑ تحديد الكل", fontSize = 12.sp) }
                    Button(
                        onClick = {
                            val toDel = entries.filter { it.id in selectedIds && it.tsVoucherId.isBlank() }
                            if (toDel.isNotEmpty()) viewModel.deleteClockEntries(toDel)
                            selectedIds = emptySet()
                            selectMode = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppColors.DebitRed),
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text("🗑 حذف (${selectedIds.size})", fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = { selectedIds = emptySet(); selectMode = false },
                        modifier = Modifier.heightIn(min = 44.dp)
                    ) { Text("إلغاء", fontSize = 12.sp) }
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text(strings.t("بحث في الحركات...", "Search entries...")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("date" to "التاريخ", "name" to "الأبجدية", "amount" to "المبلغ").forEach { (k, lbl) ->
                    FilterChip(
                        selected = sortField == k,
                        onClick = {
                            if (sortField == k) sortAsc = !sortAsc else { sortField = k; sortAsc = true }
                        },
                        label = { Text(lbl) }
                    )
                }
                FilterChip(
                    selected = !sortAsc,
                    onClick = { sortAsc = !sortAsc },
                    label = { Text(if (sortAsc) "↑" else "↓") }
                )
            }

            if (sortedEntries.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Timeline,
                    title = strings.t("لا توجد حركات ضمن الفترة المحددة", "No Entries in Period")
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(sortedEntries, key = { it.id }) { e ->
                        val isCred = e.dir != "عليكم"
                        val bal = running[e.id] ?: 0.0
                        val isSel = e.id in selectedIds
                        val rows = remember(e) { clockEntryRows(e) }
                        val spName = specMap[e.specialtyId] ?: ""
                        val headerTitle = remember(e, section, spName) { clockOriginTitle(e, section, specMap) }
                        val per = if (e.to.isNotBlank() && e.to != e.date) {
                            "من ${DateHelper.displaySlash(e.date)} إلى ${DateHelper.displaySlash(e.to)}"
                        } else DateHelper.displaySlash(e.date)

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) Color(0xFFE0F2FE) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (isSel) Color(0xFF0284C7) else Color(0xFFD8AE52).copy(alpha = 0.7f)),
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (selectMode) {
                                            if (e.tsVoucherId.isNotBlank()) {
                                                viewModel.emitMessage("سند مرتبط بالصرافة — يُحذف من قسم الصرافة")
                                            } else {
                                                selectedIds = if (isSel) selectedIds - e.id else selectedIds + e.id
                                            }
                                        } else if (section == ClockSection.CURRENCY) {
                                            when {
                                                e.srcDetailId.isNotBlank() -> viewModel.emitMessage("سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً")
                                                e.tsVoucherId.isNotBlank() -> viewModel.emitMessage("سند مرتبط بالصرافة — عدّله من قسم الصرافة")
                                                else -> editingCurrencyEntry = e
                                            }
                                        }
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        selectMode = true
                                        if (e.tsVoucherId.isBlank()) selectedIds = selectedIds + e.id
                                    }
                                )
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = headerTitle,
                                        color = if (isCred) AppColors.CreditGreen else AppColors.DebitRed,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = per,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (section == ClockSection.CURRENCY && rows.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF8FAFC),
                                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(Modifier.fillMaxWidth()) {
                                            Row(Modifier.fillMaxWidth().background(Color(0xFFE2E8F0)).padding(vertical = 4.dp, horizontal = 4.dp)) {
                                                Text("اسم العملة", fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                                Text("مبلغ العملة", fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                                Text("سعر الصرف", fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.9f))
                                                Text("ناتج الصرف", fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                            }
                                            rows.forEach { r ->
                                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp)) {
                                                    Text(r.cur, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                                    Text(fmt(r.a), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                                    Text(fmt(r.r), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.9f))
                                                    Text(fmt(r.a * r.r), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                                }
                                            }
                                        }
                                    }
                                }

                                if (e.note.isNotBlank()) {
                                    Text("البيان: ${e.note}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                                if (spName.isNotBlank()) {
                                    Text("التخصيص: $spName", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        CreditDebitPill(isCredit = isCred)
                                        if (e.img.isNotBlank()) {
                                            Icon(Icons.Default.Photo, contentDescription = "صورة مرفقة", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        }
                                        Text(
                                            "${strings.t("الرصيد", "Bal")}: ${fmt(bal)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            "الإجمالي: ${fmt(e.amount)}",
                                            fontWeight = FontWeight.Black,
                                            color = if (isCred) AppColors.CreditGreen else AppColors.DebitRed
                                        )
                                        if (!e.auto && e.tsVoucherId.isBlank()) {
                                            IconButton(
                                                onClick = { viewModel.deleteClockEntry(e) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Non-currency manual entry dialog
    if (showAddDialog && section != ClockSection.CURRENCY) {
        var dir by remember { mutableStateOf(if (section == ClockSection.WITHDRAW) "عليكم" else "لكم") }
        var amtStr by remember { mutableStateOf("") }
        var name by remember { mutableStateOf("") }
        var date by remember { mutableStateOf(DateHelper.todayIso()) }
        var note by remember { mutableStateOf("") }
        var entrySpecId by remember(uiState.settings.activeSpecialty) {
            mutableStateOf(if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty)
        }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(strings.t("قيد يدوي في ${section.labelAr}", "Add Manual Entry")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = dir == "لكم", onClick = { dir = "لكم" }, label = { Text(strings.credit) })
                        FilterChip(selected = dir == "عليكم", onClick = { dir = "عليكم" }, label = { Text(strings.debit) })
                    }
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = entrySpecId,
                        onAssign = { entrySpecId = it },
                        onAddSpecialty = { n, w -> viewModel.addHomeSpecialty(n, w) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = strings.amount, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.t("الاسم / العنوان", "Title")) }, modifier = Modifier.fillMaxWidth())
                    ClickableDateField(
                        value = date,
                        onDatePicked = { date = it },
                        label = strings.date,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "clock_entry_date_input"
                    )
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.note) }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val a = num(amtStr)
                    if (a > 0.0) {
                        viewModel.saveClockEntry(
                            ClockEntry(
                                section = section,
                                specialtyId = entrySpecId,
                                dir = dir,
                                amount = a,
                                name = name.trim(),
                                date = date.trim(),
                                time = DateHelper.nowTime(),
                                note = note.trim(),
                                auto = false
                            )
                        )
                        showAddDialog = false
                    }
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) } }
        )
    }

    editingCurrencyEntry?.let { entry ->
        val isNew = entry.name.isBlank() && entry.rows.isEmpty() && entry.amount == 0.0
        ClockCurrencyEntryDialog(
            existing = if (isNew) null else entry,
            uiState = uiState,
            viewModel = viewModel,
            onDismiss = { editingCurrencyEntry = null }
        )
    }

    showCurrencyOpDialog?.let { kind ->
        ClockCurrencyOperationDialog(
            kind = kind,
            uiState = uiState,
            viewModel = viewModel,
            onDismiss = { showCurrencyOpDialog = null }
        )
    }
}
