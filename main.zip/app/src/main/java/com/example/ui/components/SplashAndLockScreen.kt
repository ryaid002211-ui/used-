package com.example.ui.components

import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.domain.AppLockSettings
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import kotlinx.coroutines.delay

/**
 * Faithful Jetpack Compose recreation of index.html animated splash screen.
 */
@Composable
fun LuxurySplashOverlay(onFinished: () -> Unit) {
    val strings = LocalAppStrings.current
    val infinite = rememberInfiniteTransition(label = "splash_anim")
    val spinDeg by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "orbit_spin"
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )

    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val steps = 36
        for (i in 1..steps) {
            progress = i / steps.toFloat()
            delay(50L)
        }
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF102E6B), AppColors.NavyDeep, Color(0xFF041232))
                )
            )
            .clickable { onFinished() }
            .testTag("luxury_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Decorative Aurora rings
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.42f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(AppColors.GoldAccent.copy(alpha = 0.16f), Color.Transparent),
                    center = center,
                    radius = size.minDimension * 0.45f
                ),
                center = center,
                radius = size.minDimension * 0.45f
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(horizontal = 32.dp)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(164.dp)) {
                Canvas(
                    modifier = Modifier
                        .size(160.dp)
                        .rotate(spinDeg)
                ) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(AppColors.GoldAccent, Color.Transparent, AppColors.GoldLight, Color.Transparent)
                        ),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }
                Box(
                    modifier = Modifier
                        .size((118 * pulse).dp)
                        .clip(CircleShape)
                        .background(AppColors.NavyDeep)
                        .padding(4.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_launcher_icon_1795414648124),
                        contentDescription = strings.appTitle,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(Modifier.height(26.dp))

            Text(
                text = strings.appTitle,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = AppColors.GoldLight
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = strings.appSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.78f)
            )

            Spacer(Modifier.height(34.dp))

            LinearProgressIndicator(
                progress = { progress },
                color = AppColors.GoldAccent,
                trackColor = Color.White.copy(alpha = 0.16f),
                modifier = Modifier
                    .width(200.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
            )
        }
    }
}

@Composable
fun AppLockScreen(
    lockSettings: AppLockSettings,
    onVerifyPin: (String) -> Boolean,
    onBiometricSuccess: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var entered by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    val targetLen = lockSettings.pin.length.coerceAtLeast(4)

    fun triggerBiometric() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && lockSettings.biometric) {
            val activity = context.findActivityOrNull() ?: return
            try {
                val prompt = BiometricPrompt.Builder(activity)
                    .setTitle(strings.appTitle)
                    .setSubtitle(strings.t("افتح القفل بالبصمة", "Unlock with Biometrics"))
                    .setNegativeButton(
                        strings.t("استخدام الرمز", "Use PIN"),
                        ContextCompat.getMainExecutor(activity)
                    ) { _, _ -> }
                    .build()
                prompt.authenticate(
                    CancellationSignal(),
                    ContextCompat.getMainExecutor(activity),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            onBiometricSuccess()
                        }
                    }
                )
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(lockSettings.biometric) {
        if (lockSettings.biometric) triggerBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(AppColors.NavyDeep, Color(0xFF0A193A)))
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(AppColors.GoldAccent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = AppColors.GoldLight, modifier = Modifier.size(34.dp))
            }

            Text(
                text = strings.t("التطبيق مقفل", "App Locked"),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(targetLen) { idx ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (idx < entered.length) AppColors.GoldAccent
                                else Color.White.copy(alpha = 0.25f)
                            )
                    )
                }
            }

            if (errorMsg.isNotBlank()) {
                Text(errorMsg, color = AppColors.DebitRedDark, style = MaterialTheme.typography.bodySmall)
            }

            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("BIO", "0", "DEL")
            )

            keys.forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    row.forEach { k ->
                        when (k) {
                            "BIO" -> {
                                if (lockSettings.biometric && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    FilledTonalButton(
                                        onClick = { triggerBiometric() },
                                        shape = CircleShape,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(62.dp)
                                    ) {
                                        Icon(Icons.Default.Fingerprint, contentDescription = "Biometric")
                                    }
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                            "DEL" -> {
                                FilledTonalButton(
                                    onClick = { if (entered.isNotEmpty()) entered = entered.dropLast(1) },
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = strings.delete)
                                }
                            }
                            else -> {
                                ElevatedButton(
                                    onClick = {
                                        errorMsg = ""
                                        if (entered.length < targetLen) {
                                            entered += k
                                            if (entered.length == targetLen) {
                                                if (!onVerifyPin(entered)) {
                                                    errorMsg = strings.t("الرمز غير صحيح", "Incorrect PIN")
                                                    entered = ""
                                                }
                                            }
                                        }
                                    },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.14f),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                        .testTag("pin_key_$k")
                                ) {
                                    Text(k, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

tailrec fun Context.findActivityOrNull(): android.app.Activity? = when (this) {
    is android.app.Activity -> this
    is ContextWrapper -> baseContext.findActivityOrNull()
    else -> null
}
