package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

private val CurDark = Color(0xFF0B0D12)
private val CurGold = Color(0xFFC5B17E)

internal fun clockEntryRows(e: ClockEntry): List<TsRowCurrency> {
    if (e.rows.isNotEmpty()) return e.rows
    if (e.cur.isNotBlank() && e.curAmount > 0.0) return listOf(TsRowCurrency(e.cur, e.curAmount, e.curRate))
    return emptyList()
}

private fun isUsdCurrencyName(name: String, symbol: String = ""): Boolean {
    val v = name.lowercase()
    val s = symbol.lowercase()
    return v.contains("دولار") || v.contains("usd") || s == "$" || s == "usd"
}

private fun normalizedCurrencyKey(name: String, symbol: String = ""): String {
    val t = "${name.lowercase()} ${symbol.lowercase()}"
    return when {
        t.contains("يمني") || t.contains("yer") || t.contains("ر.ي") -> "يمني"
        t.contains("سعودي") || t.contains("sar") || t.contains("ر.س") -> "سعودي"
        t.contains("عماني") || t.contains("omr") || t.contains("ر.ع") -> "عماني"
        t.contains("درهم") || t.contains("aed") -> "درهم"
        else -> name.ifBlank { symbol }.trim().lowercase()
    }
}

private fun currencyRank(name: String): Int = when {
    name.contains("يمني") -> 0
    name.contains("سعودي") -> 1
    name.contains("عماني") -> 2
    name.contains("درهم") -> 3
    else -> 4
}

internal fun clockOriginTitle(
    e: ClockEntry,
    section: ClockSection,
    specMap: Map<String, String>
): String {
    val isDebt = e.dir == "عليكم"
    val nm = e.name.ifBlank { e.note.ifBlank { section.labelAr } }
    if (e.srcDetailId.isNotBlank() && !isDebt) {
        val spName = specMap[e.specialtyId] ?: ""
        return "لكم من ${e.name.ifBlank { "التفصيل" }}${if (spName.isNotBlank()) " + $spName" else ""}"
    }
    if (e.tsVoucherId.isNotBlank() && isDebt) {
        val base = when (section) {
            ClockSection.CURRENCY -> if (e.tsKind == "acc") "عليكم من المراقب الصرافة قبض حسابات" else "عليكم من المراقب الصرافة قبض صناديق"
            ClockSection.WORKERS -> "عليكم من المراقب الصرافة قبض حسابات"
            else -> "عليكم من المراقب قبض حسابات"
        }
        return if (e.name.isNotBlank()) "$base — ${e.name}" else base
    }
    return if (section == ClockSection.CURRENCY) {
        if (isDebt) "عليكم إلى $nm" else "لكم من $nm"
    } else {
        "${if (isDebt) "عليكم" else "لكم"} ($nm)"
    }
}

@Composable
internal fun ClockCurrencyStripBar(
    entries: List<ClockEntry>,
    currencies: List<AppCurrency>
) {
    data class CellAcc(var pay: Double = 0.0, var debt: Double = 0.0) {
        val net: Double get() = pay - debt
    }

    val (cells, totalAll) = remember(entries, currencies) {
        val sortedCfg = currencies
            .filter { !isUsdCurrencyName(it.name, it.symbol) }
            .sortedWith(compareBy<AppCurrency> { currencyRank(it.name) }.thenBy { it.name })
        val byKey = linkedMapOf<String, CellAcc>()
        val meta = linkedMapOf<String, String>()
        sortedCfg.forEach { c ->
            val k = normalizedCurrencyKey(c.name, c.symbol)
            if (k !in byKey) {
                byKey[k] = CellAcc()
                meta[k] = if (c.symbol.isNotBlank() && c.symbol != c.name) "${c.name} (${c.symbol})" else c.name
            }
        }
        var total = 0.0
        entries.forEach { e ->
            val isDebt = e.dir == "عليكم"
            val rows = clockEntryRows(e)
            var entryResult = 0.0
            rows.forEach { r ->
                if (!isUsdCurrencyName(r.cur)) {
                    val rk = normalizedCurrencyKey(r.cur)
                    val acc = byKey.getOrPut(rk) {
                        meta[rk] = r.cur
                        CellAcc()
                    }
                    val amt = abs(r.a)
                    if (isDebt) acc.debt += amt else acc.pay += amt
                    entryResult += abs(r.a * r.r)
                }
            }
            val signed = if (rows.isNotEmpty()) {
                if (isDebt) -entryResult else entryResult
            } else {
                if (isDebt) -abs(e.amount) else abs(e.amount)
            }
            total += signed
        }
        val list = byKey.entries.map { (k, acc) -> Triple(meta[k] ?: k, acc.pay, acc.debt) }
        list to total
    }

    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        cells.forEach { (label, pay, debt) ->
            val net = pay - debt
            val dirTxt = when {
                net > 1e-9 -> "لكم"
                net < -1e-9 -> "عليكم"
                else -> ""
            }
            val col = when {
                net > 1e-9 -> AppColors.CreditGreen
                net < -1e-9 -> AppColors.DebitRed
                else -> Color(0xFF475569)
            }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFAF6EC),
                border = BorderStroke(1.dp, CurGold),
                modifier = Modifier.widthIn(min = 128.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color(0xFF0F172A))
                    Text("لكم: ${fmt(pay)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppColors.CreditGreen)
                    Text("عليكم: ${fmt(debt)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppColors.DebitRed)
                    Text("الباقي: ${fmt(abs(net))}${if (dirTxt.isNotBlank()) " $dirTxt" else ""}", fontSize = 11.sp, fontWeight = FontWeight.Black, color = col)
                }
            }
        }
        val totalCol = when {
            totalAll > 1e-9 -> AppColors.CreditGreen
            totalAll < -1e-9 -> AppColors.DebitRed
            else -> Color(0xFF475569)
        }
        val totalDir = when {
            totalAll > 1e-9 -> "لكم"
            totalAll < -1e-9 -> "عليكم"
            else -> "متعادل"
        }
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = CurDark,
            border = BorderStroke(1.2.dp, CurGold),
            modifier = Modifier.widthIn(min = 148.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("الناتج لجميع العملات", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                Text(fmt(abs(totalAll)), fontWeight = FontWeight.Black, fontSize = 16.sp, color = totalCol)
                Text(totalDir, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CurGold)
            }
        }
    }
}

@Composable
internal fun ClockCurrencyEntryDialog(
    existing: ClockEntry?,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val currencies = uiState.settings.currencies
    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var dir by remember { mutableStateOf(existing?.dir?.ifBlank { "لكم" } ?: "لكم") }
    var specialtyId by remember {
        mutableStateOf(
            existing?.specialtyId ?: if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty
        )
    }
    var activeCur by remember { mutableStateOf(currencies.firstOrNull()?.name ?: "") }
    var errMsg by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    val existingRows = remember(existing?.id) { existing?.let(::clockEntryRows) ?: emptyList() }
    val amountsMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            existingRows.forEach { put(it.cur, rawNumberString(it.a)) }
        }
    }
    val ratesMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { c ->
                val ex = existingRows.firstOrNull { it.cur == c.name }?.r
                put(c.name, rawNumberString(ex ?: if (c.buyRate > 0.0) c.buyRate else 1.0))
            }
        }
    }

    val collectedRows = currencies.mapNotNull { c ->
        val a = num(amountsMap[c.name] ?: "")
        if (a <= 0.0) null
        else TsRowCurrency(
            cur = c.name,
            a = a,
            r = num(ratesMap[c.name] ?: "").let { if (it > 0.0) it else 1.0 }
        )
    }
    val totalVal = collectedRows.sumOf { it.a * it.r }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { imgPath = it }
    }

    TsModalShell(
        title = if (existing != null) "تعديل سند معاملة: العملات" else "سند معاملة: العملات",
        confirmLabel = "💾 حفظ",
        onDismiss = onDismiss,
        testTag = "clock_currency_entry_dialog",
        onConfirm = {
            if (collectedRows.isEmpty()) {
                errMsg = "أدخل مبلغ عملة واحدة على الأقل"
                return@TsModalShell
            }
            val first = collectedRows.first()
            val entry = (existing ?: ClockEntry(
                section = ClockSection.CURRENCY,
                time = DateHelper.nowTime(),
                auto = false
            )).copy(
                section = ClockSection.CURRENCY,
                specialtyId = specialtyId,
                dir = dir,
                amount = totalVal,
                name = name.trim(),
                date = date,
                note = note.trim(),
                img = imgPath,
                rows = collectedRows,
                cur = first.cur,
                curAmount = first.a,
                curRate = first.r,
                auto = false
            )
            viewModel.saveClockEntry(entry)
            onDismiss()
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("اسم السند") },
            placeholder = { Text("مثال: سحب رياض اليافعي") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        SpecialtyAssignDropdown(
            specialties = uiState.settings.specialties,
            selectedId = specialtyId,
            onAssign = { specialtyId = it },
            onAddSpecialty = { n, w -> viewModel.addHomeSpecialty(n, w) },
            modifier = Modifier.fillMaxWidth()
        )

        // All configured currencies quick buttons/chips
        if (currencies.isNotEmpty()) {
            Text("اختر العملات (جميع العملات المضافة):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                currencies.forEach { c ->
                    val filled = num(amountsMap[c.name] ?: "") > 0.0
                    val selected = activeCur == c.name
                    Surface(
                        onClick = { activeCur = c.name },
                        shape = RoundedCornerShape(50),
                        color = if (filled) Color(0xFFDCFCE7) else if (selected) CurDark else Color.White,
                        border = BorderStroke(1.dp, if (filled) AppColors.CreditGreen else CurGold),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Text(
                            text = if (c.symbol.isNotBlank() && c.symbol != c.name) "${c.name} (${c.symbol})" else c.name,
                            color = if (filled) Color(0xFF14532D) else if (selected) Color.White else Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // 4-column table: اسم العملة | مبلغ العملة | سعر الصرف | ناتج صرف العملة
        Surface(shape = RoundedCornerShape(10.dp), color = Color.White, border = BorderStroke(1.dp, CurGold), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().background(CurDark).padding(vertical = 8.dp, horizontal = 4.dp)) {
                    Text("العملة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.9f))
                    Text("مبلغ العملة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1.3f))
                    Text("سعر الصرف", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Text("ناتج الصرف", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                }
                currencies.forEachIndexed { idx, c ->
                    if (idx > 0) HorizontalDivider(color = Color(0xFFE2E8F0))
                    val aStr = amountsMap[c.name] ?: ""
                    val rStr = ratesMap[c.name] ?: "1"
                    val rowVal = num(aStr) * num(rStr).let { if (it > 0) it else 1.0 }
                    Row(
                        modifier = Modifier.fillMaxWidth().background(if (activeCur == c.name) Color(0xFFFFFBEB) else Color.White).padding(horizontal = 4.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(c.symbol.ifBlank { c.name }, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.9f))
                        WesternNumberField(value = aStr, onValueChange = { amountsMap[c.name] = it; activeCur = c.name }, label = "", modifier = Modifier.weight(1.3f))
                        WesternNumberField(value = rStr, onValueChange = { ratesMap[c.name] = it }, label = "", modifier = Modifier.weight(1f))
                        Text(fmt(rowVal), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Surface(shape = RoundedCornerShape(10.dp), color = Color.White, border = BorderStroke(1.dp, CurGold), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الجملة", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                Text(fmt(totalVal), fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
            }
        }

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("البيان") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    val lines = note.split("\n").toMutableList()
                    if (lines.isNotEmpty()) lines.removeAt(lines.lastIndex)
                    note = lines.joinToString("\n")
                },
                modifier = Modifier.weight(1f).heightIn(min = 44.dp)
            ) { Text("حذف السطر") }
            OutlinedButton(
                onClick = { note = note.trimEnd() + "\n" },
                modifier = Modifier.weight(1f).heightIn(min = 44.dp)
            ) { Text("+ إضافة سطر") }
        }

        TsDirectionToggleRow(
            dir = if (dir == "عليكم") "out" else "in",
            onDirChange = { dir = if (it == "out") "عليكم" else "لكم" },
            inLabel = "لكم",
            outLabel = "عليكم"
        )

        if (existing != null) {
            OutlinedButton(
                onClick = { confirmDelete = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AppColors.DebitRed),
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) { Text("🗑 حذف", fontWeight = FontWeight.Bold) }
        }
        if (errMsg.isNotBlank()) Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
    }

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = "حذف هذا السند؟",
            message = "سيتم نقل السند إلى سلة المهملات.",
            confirmText = "حذف",
            onConfirm = { viewModel.deleteClockEntry(existing); onDismiss() },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
internal fun ClockCurrencyOperationDialog(
    kind: String, // "receipt" or "exchange"
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val currencies = uiState.settings.currencies
    var cur by remember { mutableStateOf(currencies.firstOrNull()?.name ?: "ريال يمني") }
    var toCur by remember { mutableStateOf(currencies.getOrNull(1)?.name ?: currencies.firstOrNull()?.name ?: "ريال سعودي") }
    var amtStr by remember { mutableStateOf("") }
    var rateStr by remember {
        mutableStateOf(
            rawNumberString(currencies.firstOrNull()?.let { if (kind == "receipt") it.sellRate else it.buyRate }?.takeIf { it > 0 } ?: 1.0)
        )
    }
    var accName by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errMsg by remember { mutableStateOf("") }

    TsModalShell(
        title = if (kind == "receipt") strings.t("حوالة من رصيد العملات", "Currency Remittance")
        else strings.t("مصارفة عملة", "Currency Exchange"),
        confirmLabel = strings.save,
        onDismiss = onDismiss,
        testTag = "clock_currency_op_dialog",
        onConfirm = {
            val a = num(amtStr)
            val r = num(rateStr).let { if (it > 0) it else 1.0 }
            if (a <= 0.0) {
                errMsg = "أدخل مبلغاً صحيحاً"
                return@TsModalShell
            }
            val sp = if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty
            if (kind == "receipt") {
                viewModel.saveCurrencyReceipt(
                    CurrencyReceipt(toAccountName = accName.trim(), currency = cur, amount = a, rate = r, date = date, note = note.trim())
                )
                viewModel.saveClockEntry(
                    ClockEntry(
                        section = ClockSection.CURRENCY,
                        specialtyId = sp,
                        dir = "عليكم",
                        amount = a * r,
                        name = accName.trim().ifBlank { "حوالة $cur" },
                        date = date,
                        time = DateHelper.nowTime(),
                        note = note.trim(),
                        img = imgPath,
                        rows = listOf(TsRowCurrency(cur = cur, a = a, r = r)),
                        cur = cur,
                        curAmount = a,
                        curRate = r,
                        auto = false
                    )
                )
            } else {
                viewModel.saveCurrencyExchange(
                    CurrencyExchangeOp(fromCurrency = cur, fromAmount = a, toCurrency = toCur, rate = r, toAmount = a * r, date = date, note = note.trim())
                )
            }
            onDismiss()
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        // All configured currencies buttons
        Text("اختر العملة (جميع العملات):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            currencies.forEach { c ->
                val sel = cur == c.name
                Surface(
                    onClick = {
                        cur = c.name
                        val defaultR = if (kind == "receipt") c.sellRate else c.buyRate
                        if (defaultR > 0.0) rateStr = rawNumberString(defaultR)
                    },
                    shape = RoundedCornerShape(50),
                    color = if (sel) CurDark else Color.White,
                    border = BorderStroke(1.dp, CurGold),
                    modifier = Modifier.heightIn(min = 40.dp)
                ) {
                    Text(
                        text = if (c.symbol.isNotBlank() && c.symbol != c.name) "${c.name} (${c.symbol})" else c.name,
                        color = if (sel) Color.White else Color(0xFF0F172A),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (kind == "exchange") {
            Text("إلى عملة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                currencies.forEach { c ->
                    val sel = toCur == c.name
                    Surface(
                        onClick = { toCur = c.name },
                        shape = RoundedCornerShape(50),
                        color = if (sel) CurDark else Color.White,
                        border = BorderStroke(1.dp, CurGold),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Text(
                            text = if (c.symbol.isNotBlank() && c.symbol != c.name) "${c.name} (${c.symbol})" else c.name,
                            color = if (sel) Color.White else Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        } else {
            OutlinedTextField(value = accName, onValueChange = { accName = it }, label = { Text("إلى حساب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = strings.amount, modifier = Modifier.weight(1f))
            WesternNumberField(value = rateStr, onValueChange = { rateStr = it }, label = "سعر الصرف", modifier = Modifier.weight(1f))
        }

        val previewTot = num(amtStr) * num(rateStr).let { if (it > 0) it else 1.0 }
        Surface(shape = RoundedCornerShape(10.dp), color = Color.White, border = BorderStroke(1.dp, CurGold), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الناتج", fontWeight = FontWeight.Bold)
                Text(fmt(previewTot), fontWeight = FontWeight.Black)
            }
        }

        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.note) }, modifier = Modifier.fillMaxWidth())
        if (errMsg.isNotBlank()) Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
    }
}
