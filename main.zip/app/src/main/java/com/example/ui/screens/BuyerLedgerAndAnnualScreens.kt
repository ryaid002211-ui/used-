package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BuyerAnnualScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    val strings = com.example.ui.theme.LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortAsc by remember { mutableStateOf(true) }
    var selectedFolderId by remember { mutableStateOf<String?>(null) }
    var selectedFolderIds by remember { mutableStateOf(setOf<String>()) }
    var longPressFolder by remember { mutableStateOf<BuyerAnnualFolder?>(null) }
    var confirmDeleteFolders by remember { mutableStateOf<List<BuyerAnnualFolder>>(emptyList()) }

    val allAnnuals = remember(uiState.snapshot.buyerAnnualFolders, uiState.settings.buyerActiveSpecialty) {
        uiState.snapshot.buyerAnnualFolders.filter {
            matchesSpecialtyFilter(it.specialtyId, uiState.settings.buyerActiveSpecialty)
        }
    }

    val activeFolder = remember(allAnnuals, selectedFolderId) {
        selectedFolderId?.let { id -> allAnnuals.firstOrNull { it.id == id } }
    }

    if (activeFolder != null) {
        BuyerAnnualFolderTablePane(
            folder = activeFolder,
            fromDate = fromDate,
            toDate = toDate,
            sortAsc = sortAsc,
            uiState = uiState,
            viewModel = viewModel,
            onRangeChange = { f, t -> fromDate = f; toDate = t },
            onSortDirChange = { sortAsc = it },
            onBackToFolders = { selectedFolderId = null }
        )
        return
    }

    BackHandler(onBack = onBack)

    fun rowsInRangeFor(af: BuyerAnnualFolder): List<BuyerAnnualRow> = af.rows.filter { r ->
        val a = r.from.ifBlank { r.to }
        val b = r.to.ifBlank { r.from }
        if (a.isBlank() && b.isBlank()) true
        else (fromDate.isBlank() || b >= fromDate) && (toDate.isBlank() || a <= toDate)
    }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = strings.t("الكشف السنوي", "Annual Summary"),
                onBack = onBack,
                actions = {
                    if (selectedFolderIds.isNotEmpty()) {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.SelectAll,
                            contentDescription = strings.selectAll,
                            onClick = {
                                selectedFolderIds = if (selectedFolderIds.size == allAnnuals.size) emptySet()
                                else allAnnuals.map { it.id }.toSet()
                            }
                        )
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Print,
                            contentDescription = strings.print,
                            onClick = {
                                val chosen = allAnnuals.filter { it.id in selectedFolderIds }
                                viewModel.printHtmlReport(
                                    activity,
                                    strings.t("الكشف السنوي", "Annual Summary"),
                                    PrintReportBuilders.buildBuyerAnnualHtml(chosen, uiState.settings)
                                )
                            }
                        )
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Delete,
                            contentDescription = strings.delete,
                            tint = MaterialTheme.colorScheme.error,
                            onClick = {
                                confirmDeleteFolders = allAnnuals.filter { it.id in selectedFolderIds }
                            }
                        )
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Close,
                            contentDescription = strings.cancel,
                            onClick = { selectedFolderIds = emptySet() }
                        )
                    } else {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Print,
                            contentDescription = strings.print,
                            onClick = {
                                viewModel.printHtmlReport(
                                    activity,
                                    strings.t("الكشف السنوي", "Annual Summary"),
                                    PrintReportBuilders.buildBuyerAnnualHtml(allAnnuals, uiState.settings)
                                )
                            }
                        )
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Sync,
                            contentDescription = strings.t("مزامنة", "Sync"),
                            onClick = { viewModel.syncBuyerEcosystem() }
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            LuxuryDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t; selectedFolderIds = emptySet() }
            )

            if (allAnnuals.isEmpty()) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        Icons.Default.CalendarMonth,
                        strings.t("لا توجد كشوفات سنوية", "No Annual Records"),
                        strings.t("تتولّد الكشوفات السنوية تلقائياً من جداول تحويل الشراء", "Annual sheets sync automatically from purchase conversion")
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(allAnnuals, key = { it.id }) { af ->
                        val rowsInRange = remember(af.rows, fromDate, toDate) { rowsInRangeFor(af) }
                        val totBuy = remember(rowsInRange) { rowsInRange.sumOf { it.buy } }
                        val totSell = remember(rowsInRange) { rowsInRange.sumOf { it.sell } }
                        val totDiff = totSell - totBuy
                        val isSel = af.id in selectedFolderIds
                        val diffCol = if (totDiff >= 0) creditColor(uiState.settings.dark) else debitColor(uiState.settings.dark)
                        val statusText = when {
                            totDiff > 1e-6 -> strings.t("ربح", "Profit")
                            totDiff < -1e-6 -> strings.t("خسارة", "Loss")
                            else -> strings.t("متعادل", "Balanced")
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else Color.Transparent,
                            border = BorderStroke(
                                if (isSel) 1.5.dp else 1.dp,
                                if (isSel) MaterialTheme.colorScheme.primary else LuxuryPalette.Gold.copy(alpha = 0.55f)
                            ),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        if (selectedFolderIds.isNotEmpty()) {
                                            selectedFolderIds = if (isSel) selectedFolderIds - af.id else selectedFolderIds + af.id
                                        } else {
                                            selectedFolderId = af.id
                                        }
                                    },
                                    onLongClick = { longPressFolder = af }
                                )
                                .testTag("annual_folder_card_${af.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LuxuryPalette.creamBrush(uiState.settings.dark))
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isSel) Icons.Default.CheckBox else Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = if (isSel) MaterialTheme.colorScheme.primary else Color(0xFFEAB308),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = af.name.ifBlank { strings.t("بدون تخصص", "General") },
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = "${rowsInRange.size} ${strings.t("أسبوع", "weeks")} · ${strings.t("البيع", "Sell")} ${fmt(totSell, 0)} · ${strings.t("الشراء", "Buy")} ${fmt(totBuy, 0)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = fmt(abs(totDiff), 0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = diffCol
                                    )
                                    Text(
                                        text = statusText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    longPressFolder?.let { af ->
        val isSel = af.id in selectedFolderIds
        val targetList = remember(af, selectedFolderIds, allAnnuals) {
            if (isSel && selectedFolderIds.isNotEmpty()) allAnnuals.filter { it.id in selectedFolderIds }
            else listOf(af)
        }
        AlertDialog(
            onDismissRequest = { longPressFolder = null },
            title = { Text(af.name.ifBlank { strings.t("بدون تخصص", "General") }, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = { selectedFolderId = af.id; longPressFolder = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("👁️ عرض", "View"), modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        onClick = {
                            confirmDeleteFolders = targetList
                            longPressFolder = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("🗑️ مسح", "Delete"), color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        onClick = {
                            selectedFolderIds = if (isSel) selectedFolderIds - af.id else selectedFolderIds + af.id
                            longPressFolder = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (isSel) strings.t("☑️ إلغاء التحديد", "Deselect") else strings.t("✅ تحديد", "Select"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    TextButton(
                        onClick = {
                            selectedFolderIds = allAnnuals.map { it.id }.toSet()
                            longPressFolder = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("☑️ تحديد الكل", "Select All"), modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        onClick = {
                            viewModel.printHtmlReport(
                                activity,
                                strings.t("الكشف السنوي", "Annual Summary"),
                                PrintReportBuilders.buildBuyerAnnualHtml(targetList, uiState.settings)
                            )
                            longPressFolder = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("🖨️ طباعة", "Print"), modifier = Modifier.fillMaxWidth()) }
                }
            },
            confirmButton = {
                TextButton(onClick = { longPressFolder = null }) { Text(strings.close) }
            }
        )
    }

    if (confirmDeleteFolders.isNotEmpty()) {
        val rowCount = confirmDeleteFolders.sumOf { rowsInRangeFor(it).size }
        ConfirmActionDialog(
            title = strings.t("مسح", "Delete"),
            message = strings.t(
                "مسح $rowCount صف من ${if (confirmDeleteFolders.size > 1) "${confirmDeleteFolders.size} تخاصيص" else "هذا التخصيص"} في الفترة المحددة؟",
                "Clear $rowCount rows in the selected date range?"
            ),
            confirmText = strings.delete,
            onConfirm = {
                confirmDeleteFolders.forEach { af ->
                    val toDeleteIds = rowsInRangeFor(af).map { it.id }.toSet()
                    val remaining = af.rows.filterNot { it.id in toDeleteIds }
                    af.rows.filter { it.id in toDeleteIds && it.autoKey.startsWith("ts:") }.forEach { r ->
                        viewModel.deleteBuyerTransferSheet(r.autoKey.removePrefix("ts:"))
                    }
                    viewModel.saveBuyerAnnualFolder(af.copy(rows = remaining))
                }
                selectedFolderIds = emptySet()
                confirmDeleteFolders = emptyList()
            },
            onDismiss = { confirmDeleteFolders = emptyList() }
        )
    }
}

private data class EditableAnnualRowState(
    val id: String,
    val from: String,
    val to: String,
    val day: String,
    val name: String,
    val habbaStr: String,
    val buyStr: String,
    val sellStr: String,
    val autoKey: String
)

@Composable
private fun BuyerAnnualFolderTablePane(
    folder: BuyerAnnualFolder,
    fromDate: String,
    toDate: String,
    sortAsc: Boolean,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onRangeChange: (String, String) -> Unit,
    onSortDirChange: (Boolean) -> Unit,
    onBackToFolders: () -> Unit
) {
    BackHandler(onBack = onBackToFolders)
    val strings = com.example.ui.theme.LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()

    fun toEditList(src: List<BuyerAnnualRow>) = src.map { r ->
        EditableAnnualRowState(
            id = r.id,
            from = r.from,
            to = r.to,
            day = r.day,
            name = r.name,
            habbaStr = if (r.habba != 0.0) rawNumberString(r.habba, 0) else "",
            buyStr = if (r.buy != 0.0 || r.sell != 0.0) rawNumberString(r.buy, 2) else "",
            sellStr = if (r.sell != 0.0) rawNumberString(r.sell, 2) else "",
            autoKey = r.autoKey
        )
    }

    var localRows by remember(folder.id) { mutableStateOf(toEditList(folder.rows)) }
    LaunchedEffect(folder.id, folder.rows.map { it.id }) {
        val existingMap = localRows.associateBy { it.id }
        localRows = folder.rows.map { r -> existingMap[r.id] ?: toEditList(listOf(r)).first() }
    }

    fun persistDraftRows(updated: List<EditableAnnualRowState>) {
        val domainRows = updated.map { r ->
            val buy = num(r.buyStr)
            val sell = num(r.sellStr)
            val diff = WesternDigits.round2(sell - buy)
            val pLabel = when {
                r.buyStr.isBlank() && r.sellStr.isBlank() -> "0"
                diff > 1e-6 -> "ربح"
                diff < -1e-6 -> "خسارة"
                else -> "0"
            }
            BuyerAnnualRow(
                id = r.id,
                from = r.from,
                to = r.to,
                day = r.day.ifBlank { if (r.from.isNotBlank()) DateHelper.dayNameAr(r.from) else "" },
                name = r.name,
                buy = buy,
                sell = sell,
                habba = num(r.habbaStr),
                diff = diff,
                profitLabel = pLabel,
                autoKey = r.autoKey
            )
        }
        viewModel.saveBuyerAnnualFolder(folder.copy(rows = domainRows))
    }

    fun persistRowEdit(edited: EditableAnnualRowState, allUpdated: List<EditableAnnualRowState>) {
        if (edited.autoKey.startsWith("ts:")) {
            val tsId = edited.autoKey.removePrefix("ts:")
            val ts = uiState.snapshot.buyerTransfers.firstOrNull { it.id == tsId }
            if (ts != null) {
                viewModel.saveBuyerTransferSheet(
                    ts.copy(
                        fromDate = edited.from,
                        toDate = edited.to,
                        habbaCount = num(edited.habbaStr),
                        weeklySale = num(edited.sellStr)
                    )
                )
                return
            }
        }
        persistDraftRows(allUpdated)
    }

    val visibleRows = remember(localRows, fromDate, toDate, sortAsc) {
        val filtered = localRows.filter { r ->
            val a = r.from.ifBlank { r.to }
            val b = r.to.ifBlank { r.from }
            if (a.isBlank() && b.isBlank()) true
            else (fromDate.isBlank() || b >= fromDate) && (toDate.isBlank() || a <= toDate)
        }
        val sorted = filtered.sortedBy { it.from }
        if (sortAsc) sorted else sorted.reversed()
    }

    var datePickerTarget by remember { mutableStateOf<Pair<String, String>?>(null) } // rowId to "from"|"to"
    var confirmDeleteRow by remember { mutableStateOf<EditableAnnualRowState?>(null) }
    var pendingSaveRowId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pendingSaveRowId, localRows) {
        val idToSave = pendingSaveRowId ?: return@LaunchedEffect
        delay(450L)
        val edited = localRows.firstOrNull { it.id == idToSave }
        if (edited != null) {
            persistRowEdit(edited, localRows)
        }
        pendingSaveRowId = null
    }

    // Totals matching totalsHTML() in app.js
    val totHabba = visibleRows.sumOf { num(it.habbaStr) }
    val totBuy = visibleRows.sumOf { num(it.buyStr) }
    val totSell = visibleRows.sumOf { num(it.sellStr) }
    var totProfit = 0.0
    var totLoss = 0.0
    visibleRows.forEach { r ->
        val d = num(r.sellStr) - num(r.buyStr)
        if (d > 0) totProfit += d else if (d < 0) totLoss += -d
    }
    val netDiff = totSell - totBuy
    val netLabel = when {
        netDiff > 1e-6 -> strings.t("الباقي ربح", "Net Profit")
        netDiff < -1e-6 -> strings.t("الباقي خسارة", "Net Loss")
        else -> strings.t("الباقي ربح/خسارة", "Net P/L")
    }
    val netCol = when {
        netDiff > 1e-6 -> Color(0xFF16A34A)
        netDiff < -1e-6 -> Color(0xFFDC2626)
        else -> MaterialTheme.colorScheme.primary
    }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = "${strings.t("الكشف السنوي", "Annual Summary")} — ${folder.name.ifBlank { strings.t("بدون تخصص", "General") }}",
                onBack = onBackToFolders,
                actions = {
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Print,
                        contentDescription = strings.print,
                        onClick = {
                            viewModel.printHtmlReport(
                                activity,
                                folder.name,
                                PrintReportBuilders.buildBuyerAnnualHtml(listOf(folder), uiState.settings)
                            )
                        }
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LuxurySortBar(
                options = listOf("date" to strings.t("📅 التاريخ", "📅 Date")),
                selected = "date",
                sortAsc = sortAsc,
                onSelect = {},
                onDirectionChange = onSortDirChange
            )

            LuxuryDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = onRangeChange
            )

            // 8-Column Horizontally Scrollable Table matching bp-tbl bp-year
            val hScroll = rememberScrollState()
            val vScroll = rememberScrollState()
            val tblHeadBg = MaterialTheme.colorScheme.primary
            val tblBorder = MaterialTheme.colorScheme.outlineVariant
            val footerBg = if (uiState.settings.dark) Color(0xFF1F2937) else Color(0xFFF1F5F9)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .horizontalScroll(hScroll)
                    .border(1.dp, tblBorder, RoundedCornerShape(10.dp))
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier
                        .background(tblHeadBg)
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.from, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.to, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("عدد الحبه", "Units"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(72.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("الشراء جديد", "New Buy"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("البيع جديد", "New Sell"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("ربح/خساره", "P / L"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(84.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("الفارق لك/عليك", "Diff"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(96.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.delete, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(48.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(vScroll)
                ) {
                    visibleRows.forEach { row ->
                        val hasNumbers = row.buyStr.isNotBlank() || row.sellStr.isNotBlank()
                        val rowDiff = num(row.sellStr) - num(row.buyStr)
                        val rowProfitLabel = when {
                            !hasNumbers -> ""
                            rowDiff > 1e-6 -> "ربح"
                            rowDiff < -1e-6 -> "خسارة"
                            else -> "0"
                        }
                        val rowProfitCol = when (rowProfitLabel) {
                            "ربح" -> Color(0xFF16A34A)
                            "خسارة" -> Color(0xFFDC2626)
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                        val isAuto = row.autoKey.startsWith("ts:")
                        HorizontalDivider(color = tblBorder)
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(vertical = 5.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            // من
                            AnnualDateCell(
                                iso = row.from,
                                onClick = { datePickerTarget = row.id to "from" },
                                modifier = Modifier.width(99.dp)
                            )
                            // إلى
                            AnnualDateCell(
                                iso = row.to,
                                onClick = { datePickerTarget = row.id to "to" },
                                modifier = Modifier.width(99.dp)
                            )
                            // عدد الحبه
                            AnnualNumericCell(
                                value = row.habbaStr,
                                readOnly = false,
                                onValueChange = { v ->
                                    localRows = localRows.map { if (it.id == row.id) it.copy(habbaStr = WesternDigits.cleanNumericInput(v)) else it }
                                    pendingSaveRowId = row.id
                                },
                                modifier = Modifier.width(69.dp)
                            )
                            // الشراء جديد (readOnly when linked to weekly transfer sheet, editable for manual rows)
                            AnnualNumericCell(
                                value = row.buyStr,
                                readOnly = isAuto,
                                onValueChange = { v ->
                                    if (!isAuto) {
                                        localRows = localRows.map { if (it.id == row.id) it.copy(buyStr = WesternDigits.cleanNumericInput(v)) else it }
                                        pendingSaveRowId = row.id
                                    }
                                },
                                modifier = Modifier.width(99.dp)
                            )
                            // البيع جديد
                            AnnualNumericCell(
                                value = row.sellStr,
                                readOnly = false,
                                onValueChange = { v ->
                                    localRows = localRows.map { if (it.id == row.id) it.copy(sellStr = WesternDigits.cleanNumericInput(v)) else it }
                                    pendingSaveRowId = row.id
                                },
                                modifier = Modifier.width(99.dp)
                            )
                            // ربح / خساره
                            Box(
                                modifier = Modifier
                                    .width(81.dp)
                                    .heightIn(min = 38.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = rowProfitLabel,
                                    color = rowProfitCol,
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            // الفارق لك / عليك
                            Box(
                                modifier = Modifier
                                    .width(93.dp)
                                    .heightIn(min = 38.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (hasNumbers) fmt(rowDiff, 2) else "",
                                    color = rowProfitCol,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                            // حذف
                            Box(
                                modifier = Modifier.width(45.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(
                                    onClick = { confirmDeleteRow = row },
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Text("✖", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Footer Total Row matching totalsHTML()
                HorizontalDivider(color = tblBorder, thickness = 1.5.dp)
                Row(
                    modifier = Modifier
                        .background(footerBg)
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.t("الجملة", "Total"),
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.width(204.dp),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(fmt(totHabba, 0), fontWeight = FontWeight.Black, modifier = Modifier.width(72.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(fmt(totBuy, 2), fontWeight = FontWeight.Black, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(fmt(totSell, 2), fontWeight = FontWeight.Black, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Column(modifier = Modifier.width(84.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (totProfit > 0) Text("${strings.t("الربح", "P")}: ${fmt(totProfit, 0)}", color = Color(0xFF16A34A), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        if (totLoss > 0) Text("${strings.t("الخسارة", "L")}: ${fmt(totLoss, 0)}", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    }
                    Column(modifier = Modifier.width(96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(netLabel, color = netCol, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text(fmt(abs(netDiff), 2), color = netCol, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(Modifier.width(48.dp))
                }
            }

            Button(
                onClick = {
                    val newRow = EditableAnnualRowState(
                        id = newId("ar"),
                        from = DateHelper.todayIso(),
                        to = DateHelper.todayIso(),
                        day = DateHelper.dayNameAr(DateHelper.todayIso()),
                        name = "",
                        habbaStr = "",
                        buyStr = "",
                        sellStr = "",
                        autoKey = ""
                    )
                    val updated = localRows + newRow
                    localRows = updated
                    persistDraftRows(updated)
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("annual_add_row_btn")
            ) {
                Text(strings.t("+ إضافة صف جديد", "+ Add New Row"), fontWeight = FontWeight.Bold)
            }
        }
    }

    datePickerTarget?.let { (rowId, field) ->
        val row = localRows.firstOrNull { it.id == rowId }
        val initIso = if (field == "from") row?.from.orEmpty() else row?.to.orEmpty()
        AppDatePickerDialog(
            initialIso = initIso.ifBlank { DateHelper.todayIso() },
            onPicked = { newIso ->
                val updated = localRows.map { r ->
                    if (r.id == rowId) {
                        if (field == "from") r.copy(from = newIso, day = DateHelper.dayNameAr(newIso))
                        else r.copy(to = newIso)
                    } else r
                }
                localRows = updated
                updated.firstOrNull { it.id == rowId }?.let { persistRowEdit(it, updated) }
                datePickerTarget = null
            },
            onDismiss = { datePickerTarget = null }
        )
    }

    confirmDeleteRow?.let { row ->
        ConfirmActionDialog(
            title = strings.delete,
            message = if (row.autoKey.startsWith("ts:")) {
                strings.t("حذف صف هذا الأسبوع من الكشف السنوي؟", "Delete this week's row from the Annual Summary?")
            } else {
                strings.t("حذف هذا الصف من الكشف السنوي؟", "Delete this row?")
            },
            confirmText = strings.delete,
            onConfirm = {
                val updated = localRows.filterNot { it.id == row.id }
                localRows = updated
                if (row.autoKey.startsWith("ts:")) {
                    viewModel.deleteBuyerTransferSheet(row.autoKey.removePrefix("ts:"))
                } else {
                    persistDraftRows(updated)
                }
                confirmDeleteRow = null
            },
            onDismiss = { confirmDeleteRow = null }
        )
    }
}

@Composable
private fun AnnualDateCell(
    iso: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.heightIn(min = 38.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
            Text(
                text = if (iso.isNotBlank()) DateHelper.displaySlash(iso) else "📅",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun AnnualNumericCell(
    value: String,
    readOnly: Boolean,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .heightIn(min = 38.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (readOnly) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                else MaterialTheme.colorScheme.surface
            )
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            readOnly = readOnly,
            singleLine = true,
            textStyle = TextStyle(
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun BuyerControllerLedgerScreen(
    mode: String, // "sales", "seller", "supplier"
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = com.example.ui.theme.LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortAsc by remember { mutableStateOf(false) }
    var selectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    var showEntryDialog by remember { mutableStateOf(false) }
    var editingSale by remember { mutableStateOf<BuyerSaleEntry?>(null) }
    var editingProfit by remember { mutableStateOf<BuyerProfitEntry?>(null) }
    var viewingSale by remember { mutableStateOf<BuyerSaleEntry?>(null) }
    var viewingProfit by remember { mutableStateOf<BuyerProfitEntry?>(null) }
    var moveSaleTarget by remember { mutableStateOf<BuyerSaleEntry?>(null) }
    var moveProfitTarget by remember { mutableStateOf<BuyerProfitEntry?>(null) }
    var previewPhotoPath by remember { mutableStateOf<String?>(null) }
    var pendingDeleteSale by remember { mutableStateOf<BuyerSaleEntry?>(null) }
    var pendingDeleteProfit by remember { mutableStateOf<BuyerProfitEntry?>(null) }

    val title = when (mode) {
        "sales" -> strings.t("حوالات المبيعات", "Sales Remittances")
        "seller" -> strings.t("الأرباح والسحوبات — البائع", "Seller Split (50%)")
        else -> strings.t("الأرباح والسحوبات — المورد", "Supplier Split (50%)")
    }

    val specMap = remember(uiState.settings.buyerSpecialties) {
        uiState.settings.buyerSpecialties.associate { it.id to it.name }
    }
    val filteredSales = remember(uiState.snapshot.buyerSales, uiState.settings.buyerActiveSpecialty, fromDate, toDate, sortAsc) {
        val list = uiState.snapshot.buyerSales
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.buyerActiveSpecialty) }
            .filter { (fromDate.isBlank() || it.date >= fromDate) && (toDate.isBlank() || it.date <= toDate) }
            .sortedWith(compareBy<BuyerSaleEntry> { it.date }.thenBy { it.id })
        if (sortAsc) list else list.reversed()
    }
    val filteredProfits = remember(uiState.snapshot.buyerProfits, mode, uiState.settings.buyerActiveSpecialty, fromDate, toDate, sortAsc) {
        val list = uiState.snapshot.buyerProfits
            .filter { it.target == mode }
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.buyerActiveSpecialty) }
            .filter { (fromDate.isBlank() || it.date >= fromDate) && (toDate.isBlank() || it.date <= toDate) }
            .sortedWith(compareBy<BuyerProfitEntry> { it.date }.thenBy { it.id })
        if (sortAsc) list else list.reversed()
    }
    val ledgerStats = remember(mode, filteredSales, filteredProfits) {
        if (mode == "sales") {
            val cred = filteredSales.filter { it.dir == "لكم" }.sumOf { it.amount }
            val deb = filteredSales.filter { it.dir != "لكم" }.sumOf { it.amount }
            Triple(cred, deb, cred - deb)
        } else {
            val plus = filteredProfits.filter { it.type != "سحب" && it.kind != "خسارة" }.sumOf { it.amount }
            val minus = filteredProfits.filter { it.type == "سحب" || it.kind == "خسارة" }.sumOf { it.amount }
            Triple(plus, minus, plus - minus)
        }
    }

    Scaffold(
        topBar = {
            if (selectMode) {
                TopAppBar(
                    title = { Text("${selectedIds.size} ${strings.t("محدد", "selected")}") },
                    navigationIcon = {
                        IconButton(onClick = { selectMode = false; selectedIds = emptySet() }) {
                            Icon(Icons.Default.Close, contentDescription = strings.cancel)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            val allIds = if (mode == "sales") filteredSales.map { it.id } else filteredProfits.map { it.id }
                            selectedIds = if (selectedIds.size == allIds.size) emptySet() else allIds.toSet()
                        }) {
                            Icon(Icons.Default.SelectAll, contentDescription = strings.selectAll)
                        }
                        IconButton(onClick = {
                            val selSales = if (mode == "sales") filteredSales.filter { it.id in selectedIds } else emptyList()
                            val selProfits = if (mode != "sales") filteredProfits.filter { it.id in selectedIds } else emptyList()
                            val html = PrintReportBuilders.buildBuyerControllerLedgerHtml(
                                mode = mode,
                                sales = selSales,
                                profits = selProfits,
                                specialties = uiState.settings.buyerSpecialties,
                                settings = uiState.settings
                            )
                            viewModel.printHtmlReport(activity, "$title (محدد)", html)
                        }) {
                            Icon(Icons.Default.Print, contentDescription = strings.print)
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                        }
                    },
                    actions = {
                        IconButton(onClick = { selectMode = true }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.Checklist, contentDescription = strings.t("تحديد", "Select"))
                        }
                        IconButton(
                            onClick = {
                                val html = PrintReportBuilders.buildBuyerControllerLedgerHtml(
                                    mode = mode,
                                    sales = filteredSales,
                                    profits = filteredProfits,
                                    specialties = uiState.settings.buyerSpecialties,
                                    settings = uiState.settings
                                )
                                viewModel.printHtmlReport(activity, title, html)
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = strings.print)
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editingSale = null; editingProfit = null; showEntryDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = strings.t("إضافة قيد", "Add Entry"))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpecialtyFilterBar(
                    specialties = uiState.settings.buyerSpecialties,
                    selectedId = uiState.settings.buyerActiveSpecialty,
                    onSelect = viewModel::setBuyerSpecialty,
                    onAddSpecialty = { n, w -> viewModel.addBuyerSpecialty(n, w) },
                    showWorkersAmount = false,
                    modifier = Modifier.weight(1f, fill = false)
                )
                FilterChip(
                    selected = sortAsc,
                    onClick = { sortAsc = !sortAsc },
                    label = { Text(if (sortAsc) "↑ أقدم" else "↓ أحدث") }
                )
            }

            DateRangeBar(
                fromDate = fromDate.ifBlank { DateHelper.yearStartIso() },
                toDate = toDate.ifBlank { DateHelper.yearEndIso() },
                onRangeChange = { f, t -> fromDate = f; toDate = t }
            )
            if (fromDate.isNotBlank() || toDate.isNotBlank()) {
                TextButton(
                    onClick = { fromDate = ""; toDate = "" },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Text(strings.t("عرض كل التواريخ", "Show All Dates"))
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryStatCard(
                    if (mode == "sales") strings.credit else strings.t("الأرباح", "Profits"),
                    fmt(ledgerStats.first, 2),
                    creditColor(uiState.settings.dark),
                    Modifier.weight(1f)
                )
                SummaryStatCard(
                    if (mode == "sales") strings.debit else strings.t("السحوبات", "Draws"),
                    fmt(ledgerStats.second, 2),
                    debitColor(uiState.settings.dark),
                    Modifier.weight(1f)
                )
                SummaryStatCard(
                    strings.net,
                    fmt(abs(ledgerStats.third), 2),
                    if (ledgerStats.third >= 0) creditColor(uiState.settings.dark) else debitColor(uiState.settings.dark),
                    Modifier.weight(1f)
                )
            }

            if ((mode == "sales" && filteredSales.isEmpty()) || (mode != "sales" && filteredProfits.isEmpty())) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        icon = Icons.Default.ReceiptLong,
                        title = strings.t("لا توجد قيود ضمن هذا التخصيص", "No Entries Found")
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    if (mode == "sales") {
                        items(filteredSales, key = { it.id }) { s ->
                            val isCred = s.dir == "لكم"
                            val isSel = s.id in selectedIds
                            val spName = specMap[s.specialtyId] ?: ""
                            val amountCol = if (isCred) creditColor(uiState.settings.dark) else debitColor(uiState.settings.dark)
                            var menuOpen by remember { mutableStateOf(false) }

                            StyledAppCard(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .combinedClickable(
                                        onClick = {
                                            if (selectMode) {
                                                selectedIds = if (isSel) selectedIds - s.id else selectedIds + s.id
                                            } else {
                                                viewingSale = s
                                            }
                                        },
                                        onLongClick = {
                                            selectMode = true
                                            selectedIds = selectedIds + s.id
                                        }
                                    )
                            ) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                CreditDebitPill(isCredit = isCred)
                                                Text(s.note.ifBlank { s.entity.ifBlank { s.sender } }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            Text(
                                                "${DateHelper.displaySlash(s.date)}${if (spName.isNotBlank()) " • $spName" else ""}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (s.img.isNotBlank() && File(s.img).exists()) {
                                            Image(
                                                painter = rememberAsyncImagePainter(File(s.img)),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).clickable { previewPhotoPath = s.img }
                                            )
                                            Spacer(Modifier.width(6.dp))
                                        }
                                        Text(fmt(s.amount, 2), fontWeight = FontWeight.Bold, color = amountCol)
                                        Box {
                                            IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(48.dp)) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "Options")
                                            }
                                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                                DropdownMenuItem(
                                                    text = { Text(strings.t("عرض التفاصيل", "View Details")) },
                                                    leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                                                    onClick = { menuOpen = false; viewingSale = s }
                                                )
                                                if (!s.auto) {
                                                    DropdownMenuItem(
                                                        text = { Text(strings.edit) },
                                                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                                                        onClick = { menuOpen = false; editingSale = s; editingProfit = null; showEntryDialog = true }
                                                    )
                                                    DropdownMenuItem(
                                                        text = { Text(strings.t("نسخ القيد", "Duplicate")) },
                                                        leadingIcon = { Icon(Icons.Default.FileCopy, contentDescription = null) },
                                                        onClick = {
                                                            menuOpen = false
                                                            viewModel.saveBuyerSaleEntry(
                                                                s.copy(id = newId("bse"))
                                                            )
                                                        }
                                                    )
                                                    DropdownMenuItem(
                                                        text = { Text(strings.t("نقل لتخصيص آخر", "Move Specialty")) },
                                                        leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) },
                                                        onClick = { menuOpen = false; moveSaleTarget = s }
                                                    )
                                                    DropdownMenuItem(
                                                        text = { Text(strings.delete, color = MaterialTheme.colorScheme.error) },
                                                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                        onClick = { menuOpen = false; pendingDeleteSale = s }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    val metaParts = listOfNotNull(
                                        s.sender.takeIf { it.isNotBlank() }?.let { "${strings.t("المرسل", "From")}: $it" },
                                        s.receiver.takeIf { it.isNotBlank() }?.let { "${strings.t("المستلم", "To")}: $it" },
                                        s.entity.takeIf { it.isNotBlank() }?.let { "${strings.t("الجهة", "Entity")}: $it" },
                                        s.refNo.takeIf { it.isNotBlank() }?.let { "${strings.t("رقم", "Ref")}: $it" },
                                        s.commission.takeIf { it > 0.0 }?.let { "${strings.t("عمولة", "Fee")}: ${fmt(it, 2)}" }
                                    )
                                    if (metaParts.isNotEmpty() || s.curBreakdown.isNotEmpty()) {
                                        HorizontalDivider()
                                        if (metaParts.isNotEmpty()) {
                                            Text(
                                                text = metaParts.joinToString(" • "),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (s.curBreakdown.isNotEmpty()) {
                                            Text(
                                                text = s.curBreakdown.entries.joinToString(" | ") { (k, v) ->
                                                    "$k: ${fmt(v.first, 2)} × ${fmt(v.second, 2)}"
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        items(filteredProfits, key = { it.id }) { p ->
                            val isPlus = p.type != "سحب" && p.kind != "خسارة"
                            val isSel = p.id in selectedIds
                            val spName = specMap[p.specialtyId] ?: ""
                            val amountCol = if (isPlus) creditColor(uiState.settings.dark) else debitColor(uiState.settings.dark)
                            var menuOpen by remember { mutableStateOf(false) }

                            StyledAppCard(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .combinedClickable(
                                        onClick = {
                                            if (selectMode) {
                                                selectedIds = if (isSel) selectedIds - p.id else selectedIds + p.id
                                            } else {
                                                viewingProfit = p
                                            }
                                        },
                                        onLongClick = {
                                            selectMode = true
                                            selectedIds = selectedIds + p.id
                                        }
                                    )
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            CreditDebitPill(isCredit = isPlus, labelCredit = p.type, labelDebit = p.type)
                                            Text(p.note.ifBlank { p.type }, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                        Text(
                                            "${DateHelper.displaySlash(p.date)}${if (spName.isNotBlank()) " • $spName" else ""}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(fmt(p.amount, 2), fontWeight = FontWeight.Bold, color = amountCol)
                                    Box {
                                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(48.dp)) {
                                            Icon(Icons.Default.MoreVert, contentDescription = "Options")
                                        }
                                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                            DropdownMenuItem(
                                                text = { Text(strings.t("عرض التفاصيل", "View Details")) },
                                                leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                                                onClick = { menuOpen = false; viewingProfit = p }
                                            )
                                            if (!p.autoProfit) {
                                                DropdownMenuItem(
                                                    text = { Text(strings.edit) },
                                                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                                                    onClick = { menuOpen = false; editingProfit = p; editingSale = null; showEntryDialog = true }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(strings.t("نسخ القيد", "Duplicate")) },
                                                    leadingIcon = { Icon(Icons.Default.FileCopy, contentDescription = null) },
                                                    onClick = {
                                                        menuOpen = false
                                                        viewModel.saveBuyerProfitEntry(
                                                            p.copy(id = newId("bpe"))
                                                        )
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(strings.t("نقل لتخصيص آخر", "Move Specialty")) },
                                                    leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) },
                                                    onClick = { menuOpen = false; moveProfitTarget = p }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(strings.delete, color = MaterialTheme.colorScheme.error) },
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                    onClick = { menuOpen = false; pendingDeleteProfit = p }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEntryDialog) {
        BuyerLedgerEntryDialog(
            mode = mode,
            existingSale = editingSale,
            existingProfit = editingProfit,
            uiState = uiState,
            viewModel = viewModel,
            onDismiss = { showEntryDialog = false; editingSale = null; editingProfit = null }
        )
    }

    viewingSale?.let { s ->
        AlertDialog(
            onDismissRequest = { viewingSale = null },
            title = { Text(strings.t("تفاصيل الحوالة", "Remittance Details"), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${strings.date}: ${DateHelper.displaySlash(s.date)}")
                    Text("${strings.amount}: ${fmt(s.amount, 2)} (${s.dir})", fontWeight = FontWeight.Bold)
                    if (s.sender.isNotBlank()) Text("${strings.t("المرسل", "From")}: ${s.sender}")
                    if (s.receiver.isNotBlank()) Text("${strings.t("المستلم", "To")}: ${s.receiver}")
                    if (s.entity.isNotBlank()) Text("${strings.t("الجهة", "Entity")}: ${s.entity}")
                    if (s.refNo.isNotBlank()) Text("${strings.t("المرجع", "Ref")}: ${s.refNo}")
                    if (s.commission > 0) Text("${strings.t("العمولة", "Fee")}: ${fmt(s.commission, 2)}")
                    if (s.note.isNotBlank()) Text("${strings.note}: ${s.note}")
                    if (s.curBreakdown.isNotEmpty()) {
                        HorizontalDivider()
                        s.curBreakdown.forEach { (k, v) ->
                            Text("$k: ${fmt(v.first, 2)} × ${fmt(v.second, 2)} = ${fmt(v.first * v.second, 2)}")
                        }
                    }
                    if (s.img.isNotBlank() && File(s.img).exists()) {
                        OutlinedButton(onClick = { previewPhotoPath = s.img }) {
                            Text(strings.t("عرض الصورة المرفقة", "View Attached Photo"))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { viewingSale = null }) { Text(strings.close) } }
        )
    }

    viewingProfit?.let { p ->
        AlertDialog(
            onDismissRequest = { viewingProfit = null },
            title = { Text(strings.t("تفاصيل القيد", "Record Details"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${strings.date}: ${DateHelper.displaySlash(p.date)}")
                    Text("${strings.t("النوع", "Type")}: ${p.type}")
                    Text("${strings.amount}: ${fmt(p.amount, 2)}", fontWeight = FontWeight.Bold)
                    if (p.note.isNotBlank()) Text("${strings.note}: ${p.note}")
                }
            },
            confirmButton = { TextButton(onClick = { viewingProfit = null }) { Text(strings.close) } }
        )
    }

    moveSaleTarget?.let { s ->
        AlertDialog(
            onDismissRequest = { moveSaleTarget = null },
            title = { Text(strings.t("نقل إلى تخصيص", "Move to Specialty")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.saveBuyerSaleEntry(s.copy(specialtyId = "")); moveSaleTarget = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("بدون تخصيص", "General")) }
                    uiState.settings.buyerSpecialties.forEach { sp ->
                        OutlinedButton(
                            onClick = { viewModel.saveBuyerSaleEntry(s.copy(specialtyId = sp.id)); moveSaleTarget = null },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(sp.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveSaleTarget = null }) { Text(strings.cancel) } }
        )
    }

    moveProfitTarget?.let { p ->
        AlertDialog(
            onDismissRequest = { moveProfitTarget = null },
            title = { Text(strings.t("نقل إلى تخصيص", "Move to Specialty")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.saveBuyerProfitEntry(p.copy(specialtyId = "")); moveProfitTarget = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("بدون تخصيص", "General")) }
                    uiState.settings.buyerSpecialties.forEach { sp ->
                        OutlinedButton(
                            onClick = { viewModel.saveBuyerProfitEntry(p.copy(specialtyId = sp.id)); moveProfitTarget = null },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(sp.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveProfitTarget = null }) { Text(strings.cancel) } }
        )
    }

    previewPhotoPath?.let { p ->
        AppImageViewerDialog(imagePath = p, onSaveToGallery = { viewModel.saveImageToGallery(p) }, onDismiss = { previewPhotoPath = null })
    }

    pendingDeleteSale?.let { s ->
        ConfirmActionDialog(
            title = strings.delete,
            message = strings.t("هل تريد حذف هذه الحوالة؟", "Delete this remittance?"),
            confirmText = strings.delete,
            onConfirm = { viewModel.deleteBuyerSaleEntry(s.id) },
            onDismiss = { pendingDeleteSale = null }
        )
    }

    pendingDeleteProfit?.let { p ->
        ConfirmActionDialog(
            title = strings.delete,
            message = strings.t("هل تريد حذف هذا القيد؟", "Delete this entry?"),
            confirmText = strings.delete,
            onConfirm = { viewModel.deleteBuyerProfitEntry(p.id) },
            onDismiss = { pendingDeleteProfit = null }
        )
    }
}

@Composable
private fun BuyerLedgerEntryDialog(
    mode: String,
    existingSale: BuyerSaleEntry? = null,
    existingProfit: BuyerProfitEntry? = null,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val strings = com.example.ui.theme.LocalAppStrings.current
    var amtStr by remember(existingSale, existingProfit) {
        val init = existingSale?.amount ?: existingProfit?.amount ?: 0.0
        mutableStateOf(if (init > 0) rawNumberString(init, 2) else "")
    }
    var note by remember(existingSale, existingProfit) {
        mutableStateOf(existingSale?.note ?: existingProfit?.note ?: "")
    }
    var date by remember(existingSale, existingProfit) {
        mutableStateOf(existingSale?.date ?: existingProfit?.date ?: DateHelper.todayIso())
    }
    var isWithdraw by remember(existingProfit) { mutableStateOf((existingProfit?.type ?: "سحب") == "سحب") }
    var saleDir by remember(existingSale) { mutableStateOf(existingSale?.dir ?: "عليكم") }
    var sender by remember(existingSale) { mutableStateOf(existingSale?.sender ?: "") }
    var receiver by remember(existingSale) { mutableStateOf(existingSale?.receiver ?: "") }
    var entity by remember(existingSale) { mutableStateOf(existingSale?.entity ?: "") }
    var refNo by remember(existingSale) { mutableStateOf(existingSale?.refNo ?: "") }
    var commissionStr by remember(existingSale) {
        mutableStateOf(if ((existingSale?.commission ?: 0.0) > 0) rawNumberString(existingSale!!.commission, 2) else "")
    }
    var imgPath by remember(existingSale) { mutableStateOf(existingSale?.img ?: "") }
    var useMultiCurrency by remember(existingSale) { mutableStateOf(existingSale?.curBreakdown?.isNotEmpty() == true) }

    val imgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path -> imgPath = path }
    }

    val currencies = remember(uiState.settings.currencies) {
        uiState.settings.currencies.take(5).ifEmpty {
            listOf(
                AppCurrency("ريال يمني", "ر.ي", 1.0, 1.0, isDefault = true),
                AppCurrency("ريال سعودي", "ر.س", 1.0, 1.0),
                AppCurrency("ريال عماني", "ر.ع", 1.0, 1.0),
                AppCurrency("درهم إماراتي", "د.إ", 1.0, 1.0),
                AppCurrency("دولار أمريكي", "$", 1.0, 1.0)
            )
        }
    }
    val curAmounts = remember(existingSale) {
        mutableStateMapOf<String, String>().apply {
            existingSale?.curBreakdown?.forEach { (k, v) -> put(k, rawNumberString(v.first, 2)) }
        }
    }
    val curRates = remember(currencies, existingSale) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { c ->
                val ex = existingSale?.curBreakdown?.get(c.name)?.second ?: (if (c.sellRate > 0) c.sellRate else 1.0)
                put(c.name, rawNumberString(ex, 4))
            }
        }
    }
    val multiCurTotal = currencies.sumOf { c ->
        val a = num(curAmounts[c.name])
        val r = num(curRates[c.name]).let { if (it > 0.0) it else 1.0 }
        a * r
    }

    var entrySpecId by remember(existingSale, existingProfit, uiState.settings.buyerActiveSpecialty) {
        mutableStateOf(
            existingSale?.specialtyId ?: existingProfit?.specialtyId ?: (
                if (uiState.settings.buyerActiveSpecialty in listOf("all", "none")) ""
                else uiState.settings.buyerActiveSpecialty
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    existingSale != null -> strings.t("تعديل حوالة المبيعات", "Edit Remittance")
                    existingProfit != null -> strings.t("تعديل قيد الأرباح", "Edit Profit Entry")
                    mode == "sales" -> strings.t("حوالة مبيعات جديدة", "New Sales Remittance")
                    else -> strings.t("تسجيل سحب / ربح", "New Profit / Withdrawal")
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (mode == "sales") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = saleDir == "عليكم", onClick = { saleDir = "عليكم" }, label = { Text("عليكم (حوالة)") })
                        FilterChip(selected = saleDir == "لكم", onClick = { saleDir = "لكم" }, label = { Text("لكم (قبض)") })
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = isWithdraw, onClick = { isWithdraw = true }, label = { Text(strings.t("سحب", "Withdrawal")) })
                        FilterChip(selected = !isWithdraw, onClick = { isWithdraw = false }, label = { Text(strings.t("ربح", "Profit")) })
                    }
                }
                SpecialtyAssignDropdown(
                    specialties = uiState.settings.buyerSpecialties,
                    selectedId = entrySpecId,
                    onAssign = { entrySpecId = it },
                    onAddSpecialty = { n, w -> viewModel.addBuyerSpecialty(n, w) },
                    showWorkersAmount = false,
                    modifier = Modifier.fillMaxWidth()
                )
                ClickableDateField(
                    value = date,
                    onDatePicked = { date = it },
                    label = strings.date,
                    modifier = Modifier.fillMaxWidth()
                )

                if (mode == "sales") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.t("تفصيل بالعملات الخمس", "5-Currency Breakdown"), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        Switch(checked = useMultiCurrency, onCheckedChange = { useMultiCurrency = it })
                    }
                    if (useMultiCurrency) {
                        currencies.forEach { c ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                WesternNumberField(
                                    value = curAmounts[c.name] ?: "",
                                    onValueChange = { curAmounts[c.name] = it },
                                    label = c.name,
                                    modifier = Modifier.weight(1.2f)
                                )
                                WesternNumberField(
                                    value = curRates[c.name] ?: "1",
                                    onValueChange = { curRates[c.name] = it },
                                    label = strings.t("الصرف", "Rate"),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Text(
                            text = "${strings.total}: ${fmt(multiCurTotal, 2)}",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = strings.amount, modifier = Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = sender, onValueChange = { sender = it }, label = { Text(strings.t("المرسل", "Sender")) }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = receiver, onValueChange = { receiver = it }, label = { Text(strings.t("المستلم", "Receiver")) }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = entity, onValueChange = { entity = it }, label = { Text(strings.t("الجهة/الصراف", "Entity")) }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = refNo, onValueChange = { refNo = it }, label = { Text(strings.t("رقم الحوالة", "Ref #")) }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    WesternNumberField(value = commissionStr, onValueChange = { commissionStr = it }, label = strings.t("العمولة (اختياري)", "Commission"), modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { imgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (imgPath.isNotBlank()) strings.t("تم إرفاق صورة السند", "Photo Attached") else strings.t("إرفاق صورة السند", "Attach Photo"))
                    }
                } else {
                    WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = strings.amount, modifier = Modifier.fillMaxWidth())
                }

                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.note) }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val effectiveAmt = if (mode == "sales" && useMultiCurrency) multiCurTotal else num(amtStr)
                    if (effectiveAmt > 0) {
                        if (mode == "sales") {
                            val breakdown = if (useMultiCurrency) {
                                currencies.mapNotNull { c ->
                                    val a = num(curAmounts[c.name])
                                    if (a > 0.0) c.name to (a to num(curRates[c.name]).let { if (it > 0) it else 1.0 })
                                    else null
                                }.toMap()
                            } else emptyMap()
                            viewModel.saveBuyerSaleEntry(
                                (existingSale ?: BuyerSaleEntry()).copy(
                                    dir = saleDir,
                                    date = date.ifBlank { DateHelper.todayIso() },
                                    amount = effectiveAmt,
                                    specialtyId = entrySpecId,
                                    note = note.trim().ifBlank { "حوالة مبيعات" },
                                    sender = sender.trim(),
                                    receiver = receiver.trim(),
                                    entity = entity.trim(),
                                    refNo = refNo.trim(),
                                    commission = num(commissionStr),
                                    curBreakdown = breakdown,
                                    img = imgPath,
                                    auto = false
                                )
                            )
                        } else {
                            viewModel.saveBuyerProfitEntry(
                                (existingProfit ?: BuyerProfitEntry()).copy(
                                    target = mode,
                                    type = if (isWithdraw) "سحب" else "ربح",
                                    kind = if (isWithdraw) "سحب" else "ربح",
                                    date = date.ifBlank { DateHelper.todayIso() },
                                    amount = effectiveAmt,
                                    specialtyId = entrySpecId,
                                    note = note.trim().ifBlank { if (isWithdraw) "سحب" else "ربح" },
                                    autoProfit = false
                                )
                            )
                        }
                        onDismiss()
                    }
                }
            ) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}
