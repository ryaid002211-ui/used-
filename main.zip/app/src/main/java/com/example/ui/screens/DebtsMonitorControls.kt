package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

enum class DebtSortField(val labelAr: String, val labelEn: String) {
    DATE("التاريخ", "Date"),
    NAME("الأبجدية", "Name"),
    AMOUNT("المبلغ", "Amount")
}

enum class DebtSortDir { ASC, DESC }

data class DebtTotals(
    val pay: Double = 0.0,   // لكم
    val debt: Double = 0.0   // عليكم
) {
    val net: Double get() = pay - debt // positive => لكم, negative => عليكم
}

private val LuxuryHeaderBg = Color(0xFF0B0D12)
private val LuxuryBandBg = Color(0xFF10131A)
private val LuxuryGoldBorder = Color(0xFFD8AE52)

@Composable
fun DebtsTopLuxuryBar(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    Surface(
        color = Color.Transparent,
        shadowElevation = tokens.elevation,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.background(tokens.barBrush).statusBarsPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    onClick = onBack,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = tokens.barButtonBg,
                    border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                    modifier = Modifier
                        .heightIn(min = 44.dp)
                        .testTag("debts_back_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = strings.close,
                            tint = tokens.barAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.t("رجوع", "Back"),
                            color = tokens.barContent,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = title,
                    color = tokens.barContent,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    content = actions
                )
            }
            if (tokens.frameEnabled && tokens.frameStyle != "none") {
                HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
            }
        }
    }
}

@Composable
fun DebtsHeaderActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String = ""
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = tokens.barButtonBg,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
        modifier = Modifier
            .heightIn(min = 42.dp)
            .let { if (testTag.isNotBlank()) it.testTag(testTag) else it }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = label, tint = tokens.barAccent, modifier = Modifier.size(16.dp))
            if (label.isNotBlank()) {
                Text(
                    text = label,
                    color = tokens.barContent,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun DebtsControlStrip(
    specialties: List<Specialty>,
    activeSpecialty: String,
    onSelectSpecialty: (String) -> Unit,
    onAddSpecialty: (String, Double) -> Unit,
    selectAllChecked: Boolean,
    onToggleSelectAll: () -> Unit,
    totals: DebtTotals,
    sortField: DebtSortField,
    sortDir: DebtSortDir,
    onSortFieldChange: (DebtSortField) -> Unit,
    onSortDirChange: (DebtSortDir) -> Unit,
    fromDate: String,
    toDate: String,
    onRangeChange: (String, String) -> Unit
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    var showSortDropdown by remember { mutableStateOf(false) }
    var pickingDateTarget by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius),
            color = Color.Transparent,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(tokens.darkTileBrush)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.heightIn(min = 36.dp)
                ) {
                    Text(
                        text = strings.t("التخاصيص", "Specialties"),
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    SpecialtyFilterBar(
                        specialties = specialties,
                        selectedId = activeSpecialty,
                        onSelect = onSelectSpecialty,
                        onAddSpecialty = onAddSpecialty,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Surface(
                    onClick = onToggleSelectAll,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = if (selectAllChecked) tokens.barAccent else MaterialTheme.colorScheme.surface,
                    border = if (tokens.frameEnabled) BorderStroke(1.dp, if (selectAllChecked) tokens.borderColor else MaterialTheme.colorScheme.outline) else null,
                    modifier = Modifier
                        .heightIn(min = 40.dp)
                        .testTag("debts_select_all_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = strings.t("تحديد الكل", "Select All"),
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = if (selectAllChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = null,
                            tint = if (selectAllChecked) MaterialTheme.colorScheme.primary else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Row 2: 3 Summary Cards (الإجمالي عليكم | الإجمالي لكم | الباقي عليكم/لكم)
        val net = totals.net
        val netLabel = when {
            net > 1e-9 -> strings.t("الباقي لكم", "Net Credit")
            net < -1e-9 -> strings.t("الباقي عليكم", "Net Debt")
            else -> strings.t("لا يوجد رصيد", "Balanced")
        }
        val netColor = when {
            net < -1e-9 -> if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
            net > 1e-9 -> if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
            else -> MaterialTheme.colorScheme.onSurface
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DebtsTopSummaryCard(
                title = strings.t("الإجمالي عليكم", "Total Debit"),
                value = fmt(totals.debt),
                valueColor = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed,
                modifier = Modifier.weight(1f)
            )
            DebtsTopSummaryCard(
                title = strings.t("الإجمالي لكم", "Total Credit"),
                value = fmt(totals.pay),
                valueColor = if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen,
                modifier = Modifier.weight(1f)
            )
            DebtsTopSummaryCard(
                title = netLabel,
                value = fmt(abs(net)),
                valueColor = netColor,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3: Sort Strip
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius),
            color = Color.Transparent,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(tokens.darkTileBrush)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Text(
                        text = strings.t("ترتيب حسب:", "Sort:"),
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp)
                    )
                }

                Box {
                    Surface(
                        onClick = { showSortDropdown = true },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.heightIn(min = 38.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(18.dp))
                            Text(
                                text = strings.t(sortField.labelAr, sortField.labelEn),
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    DropdownMenu(expanded = showSortDropdown, onDismissRequest = { showSortDropdown = false }) {
                        DebtSortField.entries.forEach { sf ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        strings.t(sf.labelAr, sf.labelEn),
                                        fontWeight = if (sf == sortField) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        when (sf) {
                                            DebtSortField.DATE -> Icons.Default.CalendarMonth
                                            DebtSortField.NAME -> Icons.Default.SortByAlpha
                                            DebtSortField.AMOUNT -> Icons.Default.Payments
                                        },
                                        contentDescription = null
                                    )
                                },
                                onClick = {
                                    onSortFieldChange(sf)
                                    showSortDropdown = false
                                }
                            )
                        }
                    }
                }

                Surface(
                    onClick = { onSortDirChange(DebtSortDir.ASC) },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = if (sortDir == DebtSortDir.ASC) tokens.barButtonBg else MaterialTheme.colorScheme.surface,
                    border = if (tokens.frameEnabled) BorderStroke(1.dp, if (sortDir == DebtSortDir.ASC) tokens.barAccent else MaterialTheme.colorScheme.outline) else null,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 7.dp)) {
                        Text(
                            text = "↑ ${strings.t("تصاعدي", "Asc")}",
                            color = if (sortDir == DebtSortDir.ASC) tokens.barContent else MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }

                Surface(
                    onClick = { onSortDirChange(DebtSortDir.DESC) },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = if (sortDir == DebtSortDir.DESC) tokens.barButtonBg else MaterialTheme.colorScheme.surface,
                    border = if (tokens.frameEnabled) BorderStroke(1.dp, if (sortDir == DebtSortDir.DESC) tokens.barAccent else MaterialTheme.colorScheme.outline) else null,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 7.dp)) {
                        Text(
                            text = "↓ ${strings.t("تنازلي", "Desc")}",
                            color = if (sortDir == DebtSortDir.DESC) tokens.barContent else MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Row 4: Date Range Strip
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius),
            color = Color.Transparent,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(tokens.darkTileBrush)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    onClick = {
                        val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, -1)
                        onRangeChange(nf, nt)
                    },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = tokens.barButtonBg,
                    border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("debts_date_prev")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.t("الفترة السابقة", "Previous"),
                            tint = tokens.barContent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Surface(
                    onClick = { pickingDateTarget = "from" },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)) else null,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 42.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = DateHelper.displaySlash(fromDate),
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }

                Text(
                    text = strings.to,
                    color = tokens.darkTileContent,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    onClick = { pickingDateTarget = "to" },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)) else null,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 42.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = DateHelper.displaySlash(toDate),
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }

                Surface(
                    onClick = {
                        val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, 1)
                        onRangeChange(nf, nt)
                    },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = tokens.barButtonBg,
                    border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("debts_date_next")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = strings.t("الفترة التالية", "Next"),
                            tint = tokens.barContent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    pickingDateTarget?.let { target ->
        val currentIso = if (target == "from") fromDate else toDate
        IsoDatePickerDialog(
            initialIso = currentIso,
            onPicked = { pickedIso ->
                if (target == "from") {
                    if (pickedIso > toDate) onRangeChange(toDate, pickedIso) else onRangeChange(pickedIso, toDate)
                } else {
                    if (pickedIso < fromDate) onRangeChange(pickedIso, fromDate) else onRangeChange(fromDate, pickedIso)
                }
                pickingDateTarget = null
            },
            onDismiss = { pickingDateTarget = null }
        )
    }
}

@Composable
private fun DebtsTopSummaryCard(
    title: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = valueColor,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun DebtsSectionBand(
    title: String,
    icon: ImageVector? = null
) {
    val tokens = LocalFrameTokens.current
    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = tokens.barAccent, modifier = Modifier.size(18.dp))
            }
            Text(
                text = title,
                color = tokens.darkTileContent,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DebtCashboxCard(
    title: String,
    totals: DebtTotals,
    imagePath: String = "",
    isAutoBox: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onEditClick: (() -> Unit)? = null
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val haptic = LocalHapticFeedback.current
    val bgColor = if (settings.dark) {
        MaterialTheme.colorScheme.surfaceContainerLow
    } else {
        tokens.cardTop
    }
    val borderColor = tokens.borderColor
    val net = totals.net
    val netLabel = when {
        net > 1e-9 -> strings.t("لكم", "Credit")
        net < -1e-9 -> strings.t("عليكم", "Debt")
        else -> strings.t("متعادل", "Even")
    }
    val netColor = when {
        net > 1e-9 -> if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
        net < -1e-9 -> if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
        else -> Color(0xFF64748B)
    }

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = bgColor,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(tokens.borderWidth.coerceAtLeast(1.dp), borderColor) else null,
        tonalElevation = tokens.elevation,
        shadowElevation = tokens.elevation,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(tokens.cornerRadius))
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (imagePath.isNotBlank() && File(imagePath).exists()) {
                    Image(
                        painter = rememberAsyncImagePainter(File(imagePath)),
                        contentDescription = title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(tokens.iconTileRadius))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(tokens.iconTileRadius))
                            .background(tokens.iconTileBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isAutoBox) Icons.Default.MoveToInbox else Icons.Default.Inbox,
                            contentDescription = null,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Text(
                    text = title,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.t("لكم", "Credit"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = fmt(totals.pay),
                        color = if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.t("عليكم", "Debit"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = fmt(totals.debt),
                        color = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.t("الباقي", "Balance"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = fmt(abs(net)),
                        color = netColor,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = netLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (onEditClick != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    OutlinedButton(
                        onClick = onEditClick,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = LuxuryGoldBorder)
                        Spacer(Modifier.width(5.dp))
                        Text(strings.t("تعديل", "Edit"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun IsoDatePickerDialog(
    initialIso: String,
    onPicked: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AppDatePickerDialog(
        initialIso = initialIso,
        onPicked = onPicked,
        onDismiss = onDismiss
    )
}

@Composable
fun DebtCashboxEditDialog(
    existing: DebtCashbox?,
    defaultOrder: Int,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var orderStr by remember { mutableStateOf((existing?.order ?: defaultOrder).toString()) }
    var imgPath by remember { mutableStateOf(existing?.imagePath ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { imgPath = it }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing != null) strings.t("تعديل الصندوق", "Edit Cashbox")
                else strings.t("إضافة صندوق حسابات ديون", "Add Debt Cashbox"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.t("اسم الصندوق *", "Cashbox Name *")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                WesternNumberField(
                    value = orderStr,
                    onValueChange = { orderStr = it },
                    label = strings.t("ترتيب الصندوق", "Sort Order"),
                    allowDecimal = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("صورة الصندوق", "Cashbox Image"))
                    }
                    if (imgPath.isNotBlank() && File(imgPath).exists()) {
                        Image(
                            painter = rememberAsyncImagePainter(File(imgPath)),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(8.dp))
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (existing != null) {
                    TextButton(
                        onClick = { confirmDelete = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text(strings.delete) }
                }
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            val box = existing?.copy(
                                name = name.trim(),
                                order = num(orderStr).toInt().coerceAtLeast(1),
                                imagePath = imgPath
                            ) ?: DebtCashbox(
                                name = name.trim(),
                                order = num(orderStr).toInt().coerceAtLeast(1),
                                imagePath = imgPath
                            )
                            viewModel.saveDebtCashbox(box)
                            onDismiss()
                        } else {
                            viewModel.emitMessage(strings.t("أدخل اسم الصندوق", "Enter cashbox name"))
                        }
                    }
                ) { Text(strings.save) }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = strings.t("حذف الصندوق", "Delete Cashbox"),
            message = strings.t("تأكيد حذف الصندوق وجميع حساباته ومعاملاته؟", "Delete cashbox and all its accounts and vouchers?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deleteDebtCashbox(existing.id)
                onDismiss()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
fun DebtAccountEditDialog(
    cashboxId: String,
    existing: DebtAccount?,
    viewModel: SmartAdminViewModel,
    onDeleted: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var limitEnabled by remember { mutableStateOf(existing?.limitEnabled ?: false) }
    var limitAmt by remember {
        mutableStateOf(if (existing != null && existing.limitAmount > 0.0) WesternDigits.rawNumberString(existing.limitAmount) else "")
    }
    var sendTiming by remember { mutableStateOf(existing?.messageSend ?: "confirm") }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing != null) strings.t("تعديل الحساب", "Edit Account")
                else strings.t("إضافة حساب جديد", "Add Account"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.t("الاسم *", "Name *")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = WesternDigits.toWestern(it) },
                    label = { Text(strings.t("رقم الهاتف", "Phone")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { limitEnabled = !limitEnabled }) {
                    Checkbox(checked = limitEnabled, onCheckedChange = { limitEnabled = it })
                    Text(strings.t("تفعيل سقف المديونية", "Enable Debt Cap"))
                }
                if (limitEnabled) {
                    WesternNumberField(
                        value = limitAmt,
                        onValueChange = { limitAmt = it },
                        label = strings.t("سقف المديونية", "Debt Cap Amount"),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text(strings.t("تحديد الإرسال", "Send Message Timing"), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "auto" to strings.t("تلقائي", "Auto"),
                        "confirm" to strings.t("بعد التأكيد", "Confirm"),
                        "never" to strings.t("لا ترسل", "Never")
                    ).forEach { (key, lbl) ->
                        FilterChip(
                            selected = sendTiming == key,
                            onClick = { sendTiming = key },
                            label = { Text(lbl, maxLines = 1) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (existing != null) {
                    TextButton(
                        onClick = { confirmDelete = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text(strings.delete) }
                }
                Button(
                    onClick = {
                        val trimmed = name.trim()
                        val limVal = if (limitEnabled) num(limitAmt) else 0.0
                        if (trimmed.isBlank()) {
                            viewModel.emitMessage(strings.t("أدخل الاسم", "Enter name"))
                            return@Button
                        }
                        if (limitEnabled && limVal <= 0.0) {
                            viewModel.emitMessage(strings.t("أدخل سقفاً أكبر من صفر", "Enter cap greater than 0"))
                            return@Button
                        }
                        val acc = existing?.copy(
                            name = trimmed,
                            phone = phone.trim(),
                            limitEnabled = limitEnabled,
                            limitAmount = limVal,
                            messageSend = sendTiming
                        ) ?: DebtAccount(
                            cashboxId = cashboxId,
                            name = trimmed,
                            phone = phone.trim(),
                            limitEnabled = limitEnabled,
                            limitAmount = limVal,
                            messageSend = sendTiming
                        )
                        viewModel.saveDebtAccount(acc)
                        onDismiss()
                    }
                ) { Text(strings.save) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = strings.t("حذف الحساب", "Delete Account"),
            message = strings.t("حذف الحساب وكل معاملاته؟", "Delete account and all its transactions?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deleteDebtAccount(existing)
                onDeleted()
                onDismiss()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
fun DebtVoucherEditDialog(
    account: DebtAccount,
    existing: DebtVoucher?,
    defaultSpecialtyId: String,
    specialties: List<Specialty>,
    currencies: List<AppCurrency>,
    defaultCurrency: String,
    viewModel: SmartAdminViewModel,
    onSavedAskMessage: (voucher: DebtVoucher, newNet: Double) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var vType by remember { mutableStateOf(existing?.type ?: "debt") }
    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var amtStr by remember { mutableStateOf(if (existing != null) WesternDigits.rawNumberString(existing.amount) else "") }
    var currency by remember { mutableStateOf(existing?.currency?.ifBlank { defaultCurrency } ?: (currencies.firstOrNull()?.name ?: defaultCurrency)) }
    var spId by remember { mutableStateOf(existing?.specialtyId?.ifBlank { defaultSpecialtyId } ?: defaultSpecialtyId) }
    val noteLines = remember {
        mutableStateListOf<String>().apply {
            val split = existing?.note?.split('\n')?.map { it }?.filter { it.isNotBlank() }.orEmpty()
            if (split.isEmpty()) add("") else addAll(split)
        }
    }
    var imgPath by remember { mutableStateOf(existing?.imagePath ?: "") }
    var showCalc by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { imgPath = it }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing != null) strings.t("تعديل سند", "Edit Voucher")
                else strings.t("سند جديد", "New Voucher"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                errorMsg?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = err,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = WesternDigits.toWestern(it) },
                    label = { Text(strings.date) },
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = strings.date)
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                WesternNumberField(
                    value = amtStr,
                    onValueChange = { amtStr = it; errorMsg = null },
                    label = strings.amount,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = { showCalc = true },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Calculate, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.t("فتح الحاسبة", "Open Calculator"), fontWeight = FontWeight.Bold)
                }

                SpecialtyAssignDropdown(
                    specialties = specialties,
                    selectedId = spId,
                    onAssign = { spId = it },
                    onAddSpecialty = { n, w -> viewModel.addHomeSpecialty(n, w) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    strings.t("البيان — متعدد الأسطر", "Statement (Multi-line)"),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                noteLines.forEachIndexed { idx, line ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = line,
                            onValueChange = { noteLines[idx] = it },
                            placeholder = { Text(strings.t("اكتب البيان...", "Write statement...")) },
                            modifier = Modifier.weight(1f)
                        )
                        if (noteLines.size > 1) {
                            IconButton(onClick = { noteLines.removeAt(idx) }, modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                OutlinedButton(
                    onClick = { noteLines.add("") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.t("إضافة سطر", "Add Line"))
                }

                OutlinedButton(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                ) {
                    Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (imgPath.isNotBlank()) strings.t("تغيير الصورة المرفقة", "Change Attached Photo") else strings.t("إرفاق صورة", "Attach Photo"))
                }
                if (imgPath.isNotBlank() && File(imgPath).exists()) {
                    Image(
                        painter = rememberAsyncImagePainter(File(imgPath)),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp))
                    )
                }

                Text(strings.t("النوع", "Type"), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = vType == "debt",
                        onClick = { vType = "debt"; errorMsg = null },
                        label = { Text(strings.t("عليه (دين)", "Debt (عليه)")) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = vType == "pay",
                        onClick = { vType = "pay"; errorMsg = null },
                        label = { Text(strings.t("له (سداد)", "Payment (له)")) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = num(amtStr)
                if (a <= 0.0) {
                    errorMsg = strings.t("أدخل مبلغاً صحيحاً", "Enter valid amount")
                    return@Button
                }
                val combinedNote = noteLines.map { it.trim() }.filter { it.isNotBlank() }.joinToString("\n")
                val voucher = existing?.copy(
                    specialtyId = spId,
                    type = vType,
                    amount = a,
                    currency = currency,
                    note = combinedNote,
                    date = date.trim().ifBlank { DateHelper.todayIso() },
                    imagePath = imgPath
                ) ?: DebtVoucher(
                    accountId = account.id,
                    specialtyId = spId,
                    type = vType,
                    amount = a,
                    currency = currency,
                    note = combinedNote,
                    date = date.trim().ifBlank { DateHelper.todayIso() },
                    time = DateHelper.nowTime(),
                    imagePath = imgPath
                )
                val err = viewModel.validateAndSaveDebtVoucher(account, voucher) { newNet ->
                    if (existing == null) onSavedAskMessage(voucher, newNet)
                }
                if (err != null) {
                    errorMsg = err
                } else {
                    onDismiss()
                }
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )

    if (showCalc) {
        CalculatorDialog(
            initialValue = amtStr,
            onResult = { amtStr = it; errorMsg = null },
            onDismiss = { showCalc = false }
        )
    }
    if (showDatePicker) {
        IsoDatePickerDialog(
            initialIso = date,
            onPicked = { date = it; showDatePicker = false },
            onDismiss = { showDatePicker = false }
        )
    }
}

@Composable
fun DebtMenuActionButton(
    text: String,
    icon: ImageVector,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val bg = if (isDestructive) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer
    val fg = if (isDestructive) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = bg,
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Text(text = text, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
