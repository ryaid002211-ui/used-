package com.example.data

import android.app.Activity
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.domain.*
import java.lang.ref.WeakReference

/**
 * Generates A4/A3/A5/Thermal HTML print documents honoring Profile Header/Logo/Stamp/Signature
 * and the full PV2 + Luxury Print styling (15 styles, 10 templates, button/col/modern templates,
 * per-role colors, paper tint, background watermark, and frames), then sends to Android PrintManager.
 */
object PdfPrintManager {

    private var activeWebViewRef: WeakReference<WebView>? = null

    private data class LuxStyleDef(
        val thBg: String,
        val thFg: String,
        val paperBg: String,
        val textColor: String,
        val borderColor: String,
        val boxShadow: String
    )

    private val LUX_STYLES: Map<String, LuxStyleDef> = mapOf(
        "neu" to LuxStyleDef("#e0e5ec", "#374151", "#e0e5ec", "#171717", "#c9ced8", "2px 2px 5px #bcc3cd,-2px -2px 5px #fff"),
        "skeu" to LuxStyleDef("linear-gradient(#f7f7f7,#cfcfcf)", "#222222", "#ffffff", "#171717", "#7a7a7a", "0 1px 2px rgba(0,0,0,.35)"),
        "glass" to LuxStyleDef("rgba(255,255,255,.6)", "#111111", "rgba(255,255,255,.4)", "#171717", "#94a3b8", "0 4px 12px rgba(0,0,0,.08)"),
        "fluent" to LuxStyleDef("#f3f3f3", "#201f1e", "#ffffff", "#171717", "#c8c6c4", "none"),
        "flat" to LuxStyleDef("#334155", "#ffffff", "#ffffff", "#171717", "#334155", "none"),
        "m3" to LuxStyleDef("#ede6f7", "#1d1b20", "#fef7ff", "#171717", "#79747e", "none"),
        "minimal" to LuxStyleDef("#ffffff", "#111111", "#ffffff", "#171717", "#d1d5db", "none"),
        "neobrut" to LuxStyleDef("#ffe600", "#000000", "#ffffff", "#000000", "#000000", "4px 4px 0 #000"),
        "luxury" to LuxStyleDef("#1c1917", "#d4af37", "#fffbeb", "#171717", "#b8860b", "none"),
        "bento" to LuxStyleDef("#f1f5f9", "#0f172a", "#ffffff", "#171717", "#cbd5e1", "0 1px 3px rgba(0,0,0,.06)"),
        "editorial" to LuxStyleDef("#ffffff", "#111111", "#ffffff", "#111111", "#111111", "none"),
        "classic" to LuxStyleDef("#e8dcc0", "#4a3b1f", "#fffdf5", "#171717", "#7c5e2b", "none"),
        "futuristic" to LuxStyleDef("#0b1220", "#22d3ee", "#0f172a", "#e2e8f0", "#22d3ee", "0 0 6px rgba(34,211,238,.4)"),
        "3d" to LuxStyleDef("linear-gradient(#94a3b8,#475569)", "#ffffff", "#ffffff", "#171717", "#334155", "0 3px 0 #94a3b8"),
        "hybrid" to LuxStyleDef("#dbeafe", "#1e3a8a", "#ffffff", "#171717", "#3b82f6", "0 1px 2px rgba(0,0,0,.1)")
    )

    private fun resolveTplOverride(lux: LuxuryPrintSettings): LuxuryPrintSettings {
        val on = lux.on
        val overridden = when (lux.tpl) {
            "1" -> lux.copy(style = "luxury", shape = "corners", line = "solid", btn = "classic", shadow = "on", thick = "medium")
            "2" -> lux.copy(style = "glass", shape = "rounded", line = "solid", btn = "rounded", shadow = "on", thick = "thin")
            "3" -> lux.copy(style = "minimal", shape = "soft", line = "solid", btn = "simple", shadow = "off", thick = "thin")
            "4" -> lux.copy(style = "neobrut", shape = "box", line = "solid", btn = "simple", shadow = "on", thick = "thick")
            "5" -> lux.copy(style = "bento", shape = "rounded", line = "solid", btn = "rounded", shadow = "on", thick = "thin")
            "6" -> lux.copy(style = "m3", shape = "corners", line = "solid", btn = "rounded", shadow = "off", thick = "medium")
            "7" -> lux.copy(style = "futuristic", shape = "soft", line = "dotted", btn = "simple", shadow = "on", thick = "thin")
            "8" -> lux.copy(style = "editorial", shape = "box", line = "double", btn = "simple", shadow = "off", thick = "thin")
            "9" -> lux.copy(style = "classic", shape = "box", line = "double", btn = "classic", shadow = "off", thick = "medium")
            "10" -> lux.copy(style = "hybrid", shape = "rounded", line = "dashed", btn = "rounded", shadow = "on", thick = "medium")
            else -> lux
        }
        return overridden.copy(on = on)
    }

    private fun normalizeStyleKey(raw: String): String = when (raw.lowercase()) {
        "neumorphism" -> "neu"
        "skeuomorphism" -> "skeu"
        "glassmorphism" -> "glass"
        "material3" -> "m3"
        "neobrutalism" -> "neobrut"
        "ui3d" -> "3d"
        else -> raw.lowercase()
    }

    private fun hexToRgb(hex: String): Triple<Int, Int, Int> {
        var h = hex.trim().removePrefix("#")
        if (h.length == 3) h = h.map { "$it$it" }.joinToString("")
        val parsed = h.toLongOrNull(16) ?: 0xFFFFFFL
        return Triple(
            ((parsed shr 16) and 0xFF).toInt(),
            ((parsed shr 8) and 0xFF).toInt(),
            (parsed and 0xFF).toInt()
        )
    }

    fun printHtml(
        activity: Activity,
        jobName: String,
        bodyHtml: String,
        settings: AppSettings,
        isVoucher: Boolean = false
    ) {
        val ps = settings.printing
        val lux = resolveTplOverride(ps.lux)
        val paper = if (isVoucher) ps.paperVoucher else ps.paperStatement
        val isThermal = paper == "58" || paper == "80"
        val marginStr = if (isThermal) "4mm" else "10mm"

        val pageCss = when (paper) {
            "a3" -> "@page{size:A3 portrait;margin:$marginStr;}"
            "a5" -> "@page{size:A5 portrait;margin:$marginStr;}"
            "58" -> "@page{size:58mm auto;margin:2mm;}"
            "80" -> "@page{size:80mm auto;margin:3mm;}"
            else -> "@page{size:A4 portrait;margin:$marginStr;}"
        }

        val fontCss = when (ps.printFont.lowercase()) {
            "cairo" -> "'Cairo','Tajawal',Arial,Tahoma,sans-serif"
            "honor" -> "'Honor Sans','Cairo','Tajawal',sans-serif"
            "arial" -> "Arial,'Tajawal','Cairo',sans-serif"
            "tahoma" -> "Tahoma,'Tajawal','Cairo',sans-serif"
            "times" -> "'Times New Roman','Cairo',serif"
            else -> "'Tajawal','Cairo',Arial,Tahoma,sans-serif"
        }

        val scale = ps.printFontScale.coerceIn(75, 150) / 100.0
        val bodyFontPx = 14.0 * scale

        var baseCol = if (lux.on) "#aebeff" else ps.printColor.ifBlank { "#aebeff" }
        if (!lux.on && ps.printColorMode == "bw") {
            baseCol = "#e8e8e8"
        }
        val colorFilter = when {
            lux.on -> ""
            ps.printColorMode == "gray" -> "filter:grayscale(100%);"
            ps.printColorMode == "bw" -> "filter:grayscale(100%) contrast(140%);"
            else -> ""
        }
        val bodyTextCol = if (lux.on) "#171717" else ps.printTextColor.ifBlank { "#171717" }

        val basePrintCss = buildBasePrintCss(
            pageCss = pageCss,
            fontCss = fontCss,
            bodyFontPx = bodyFontPx,
            bodyTextCol = bodyTextCol,
            tableHeadColor = baseCol,
            colorFilter = colorFilter
        )

        val extraLuxCss = if (lux.on) buildLuxCss(lux, generic = true) else ""

        val headerHtml = buildProfileHeader(settings)
        val processedBody = if (lux.on && luxNeedsMark(lux)) luxMarkHtml(bodyHtml) else bodyHtml

        val showFallbackFooter = !processedBody.contains("pv-foot") && (ps.showPrintDate || ps.showPrintTime)
        val fallbackFooter = if (showFallbackFooter) {
            val d = if (ps.showPrintDate) DateHelper.displaySlash(DateHelper.todayIso()) else ""
            val t = if (ps.showPrintTime) DateHelper.nowTime() else ""
            "<div class='print-meta'>تاريخ الطباعة: $d $t</div>"
        } else ""

        val westernHtml = WesternDigits.toWestern(
            """
            <!doctype html>
            <html lang="${settings.lang}" dir="${if (settings.lang == "en") "ltr" else "rtl"}">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1">
              <title>${esc(jobName)}</title>
              <style>
                $basePrintCss
                $extraLuxCss
              </style>
            </head>
            <body>
              $headerHtml
              $processedBody
              $fallbackFooter
            </body>
            </html>
            """.trimIndent()
        )

        val webView = WebView(activity)
        activeWebViewRef = WeakReference(webView)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = view.createPrintDocumentAdapter(jobName)
                val attrs = PrintAttributes.Builder()
                    .setMediaSize(
                        when (paper) {
                            "a3" -> PrintAttributes.MediaSize.ISO_A3
                            "a5" -> PrintAttributes.MediaSize.ISO_A5
                            else -> PrintAttributes.MediaSize.ISO_A4
                        }
                    )
                    .setColorMode(
                        if (lux.on || ps.printColorMode == "color") PrintAttributes.COLOR_MODE_COLOR
                        else PrintAttributes.COLOR_MODE_MONOCHROME
                    )
                    .build()
                printManager.print(jobName, adapter, attrs)
            }
        }
        webView.loadDataWithBaseURL(null, westernHtml, "text/html", "UTF-8", null)
    }

    private fun buildBasePrintCss(
        pageCss: String,
        fontCss: String,
        bodyFontPx: Double,
        bodyTextCol: String,
        tableHeadColor: String,
        colorFilter: String
    ): String = """
        $pageCss
        *{box-sizing:border-box}
        html,body{max-width:100%;background:#fff}
        body{font-family:$fontCss;color:$bodyTextCol;font-size:${bodyFontPx}px;line-height:1.5;margin:0;padding:4mm;-webkit-print-color-adjust:exact;print-color-adjust:exact;$colorFilter}
        .company-header,.print-profile-header{display:grid;grid-template-columns:minmax(0,1fr) 95px minmax(0,1fr);gap:10px;align-items:center;border-bottom:2px solid #222;padding:0 4px 8px;margin:0 0 9px;width:100%;break-inside:avoid;page-break-inside:avoid}
        .company-side{font-size:12px;line-height:1.45}.company-side.ar,.profile-ar{text-align:right;direction:rtl;font-weight:800}.company-side.en,.profile-en{text-align:left;direction:ltr;font-weight:800}.company-side .name{font-size:15px;font-weight:900}
        .company-logo{display:block;margin:auto;object-fit:contain}
        .full-image-header,.print-profile-header.full{display:block;margin:0 0 9px;padding:0 0 8px;border-bottom:2px solid #222}
        .full-header-image,.print-profile-header.full img{display:block!important;width:100%!important;max-width:100%!important;height:auto;max-height:120px;object-fit:contain;margin:0 auto!important}
        .doc-title{display:block;width:max-content;max-width:100%;min-width:175px;text-align:center;margin:7px auto 10px;padding:6px 26px;border:1.5px solid #333;border-radius:2px;font-size:18px;font-weight:900;background:#fff;color:#111}
        .pv{width:100%;margin:0 auto}
        .pv-title{width:max-content;max-width:100%;min-width:170px;margin:10px auto 6px;padding:6px 26px;border:1.5px solid #444;font-size:18px;font-weight:900;text-align:center;background:#fff;color:#111}
        .pv-title.green{background:#e5f7eb;border-color:#3f8f5b;color:#185d39;border-radius:6px}
        .pv-title.blue{background:#fff}
        .pv-meta{text-align:center;font-size:12px;color:#555;margin:6px 0 10px}
        .pv-meta.bold{font-weight:900;color:#222;font-size:13px}
        .pv-who{display:flex;justify-content:space-between;gap:10px;font-weight:900;font-size:15px;margin:10px 4px}
        .pv-c{text-align:center;margin:8px 0;font-weight:700}
        .pv-r{text-align:right;margin:14px 4px 0;font-weight:700}
        .pv-acc{text-align:center;font-size:20px;font-weight:900;margin:8px 0 12px;padding-bottom:4px;border-bottom:3px dotted #222;width:max-content;max-width:100%;margin-left:auto;margin-right:auto;min-width:50%}
        table.pv-t{width:100%;border-collapse:collapse;margin:8px 0 0;border:2px solid #1f2937}
        .pv-t th,.pv-t td{border:1.5px solid #1f2937;padding:6px 5px;text-align:center;overflow-wrap:anywhere;font-weight:700;font-size:12px}
        .pv-t th{background:$tableHeadColor;color:#111;font-weight:900}
        .pv-t tr.pv-sum td{background:$tableHeadColor;color:#111;font-weight:900}
        .red,.debt,.neg{color:#b42335;font-weight:800}.grn,.pay,.pos{color:#16824a;font-weight:800}.blu{color:#1e3a8a;font-weight:800}
        .pv-bal{border:1.5px solid #536174;border-top:0;padding:10px;text-align:center;font-size:16px;font-weight:900}
        .pv-foot{display:grid;grid-template-columns:1fr 1fr 1fr;align-items:center;font-size:10px;color:#666;border-top:1px solid #999;margin-top:14px;padding-top:6px;text-align:center;break-inside:avoid}
        .pv-foot span:first-child{text-align:right}.pv-foot span:last-child{text-align:left}
        .pv-foot img,.vc-stamp img{object-fit:contain;vertical-align:middle}
        .pv-sign{display:grid;grid-template-columns:1fr 1fr;gap:24px;border-top:1px solid #777;margin-top:22px;padding-top:10px;text-align:center;font-weight:800;line-height:2.1;break-inside:avoid}
        .vc{border:1.5px solid #7b203d;padding:12px;border-radius:4px}
        .vc-w{display:flex;border:2px solid #4a1520;border-radius:10px;overflow:hidden;margin:8px 0;background:#f8f8fb}
        .vc-wt{flex:1;padding:9px;text-align:center;font-weight:900}
        .vc-wl{padding:9px 12px;border-right:2px solid #4a1520;font-weight:900;color:#16824a;background:#fff;white-space:nowrap}
        .vc-dh{margin-top:10px;padding:8px;text-align:center;background:#6b1736;color:#fff;font-weight:900;border-radius:10px 10px 0 0}
        table.vc-t{width:100%;border-collapse:collapse;border:2px solid #6b1736}
        .vc-t td{border:1px solid #6b1736;padding:8px 6px;text-align:center;font-weight:900;width:34%}
        .vc-t td.vc-c{background:#6b1736;color:#fff;width:32%}
        .vc-tot{border:2px solid #4a1520;border-radius:10px;padding:10px;text-align:center;font-weight:900;margin-top:12px;font-size:16px}
        .vc-note{margin:8px 0;font-weight:800}
        .vc-sign{display:flex;justify-content:space-between;margin-top:24px;font-size:12px;font-weight:700}
        .vc-stamp{text-align:left;margin-top:8px}
        .hw-lab{text-align:right;font-weight:900;margin:12px 0 4px}
        .hw-amt{display:grid;grid-template-columns:minmax(0,1fr) 38%;gap:10px;margin-bottom:12px}
        .hw-amt div{border:1.5px solid #222;padding:12px;text-align:center;font-weight:900;font-size:16px}
        .hw-amt .hw-b{background:#a9c8f5}
        table.hw-t{width:100%;border-collapse:collapse;border:1.5px solid #222}
        .hw-t th,.hw-t td{border:1px solid #222;padding:9px 6px;text-align:center;font-weight:900}
        .hw-t th{width:17%;background:#f8fafc;color:#111}
        .hw-t td.red{color:#c0182b}
        .hw-s{display:flex;justify-content:space-between;margin-top:36px;font-weight:900;font-size:13px;padding:0 20px}
        .tx-who{display:flex;align-items:baseline;gap:10px;margin:14px 6px;font-weight:900;font-size:16px}
        .tx-who .nm{flex:1;text-align:center;border-bottom:3px dotted #222;font-size:20px}
        .tx{width:82%;margin:14px auto 0;border-right:3px solid #000;border-left:3px solid #000;border-bottom:3px solid #000}
        .tx div{border-top:3px solid #000;padding:18px 12px;font-weight:900;font-size:20px;text-align:right}
        .cs-t{width:100%;max-width:100%;border-collapse:collapse;table-layout:auto}
        .cs-t th,.cs-t td{white-space:normal;overflow-wrap:break-word;font-size:11px;padding:4px 4px;text-align:center;border:1.5px solid #1f2937}
        .cs-t td:first-child,.cs-t td.grn,.cs-t td.red{white-space:nowrap}
        .cs-t td.cs-stmt{white-space:normal;text-align:right;font-weight:700;min-width:60px}
        .pv-cur{font-weight:900;font-size:13px;margin:12px 0 4px}
        .by-print{max-width:100%;margin:0 auto}
        .by-print h2{text-align:center;margin:10px 0 4px;font-size:18px}
        .by-print h3{margin:12px 0 6px;font-size:14px}
        .by-print p{text-align:center;margin:0 0 10px;font-size:13px;color:#444}
        .by-print table{width:100%;border-collapse:collapse;margin:8px 0;table-layout:auto}
        .by-print th,.by-print td{border:1px solid #536174;padding:7px 5px;text-align:center;overflow-wrap:anywhere;font-size:12px}
        .by-print th{background:$tableHeadColor;color:#111;font-weight:900}
        .by-print tfoot td{font-weight:900;background:#f3f5fb}
        .by-print .kv td:first-child{width:65%;text-align:right;font-weight:700}
        .pdoc{width:100%}
        .doc-head{text-align:center;border-bottom:2px solid #6B1A2F;padding-bottom:6px;margin-bottom:8px}
        .nf-doc-title{font-size:18px;font-weight:900;color:#4A1520}
        .doc-sub{font-size:13px;font-weight:700;color:#6B1A2F;margin-top:2px}
        .header-info{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px}
        .header-info .item{border:1px solid #E8D8DD;border-radius:6px;background:#F5F0F1;padding:5px 4px;text-align:center;font-size:10px;color:#7B6B6B;font-weight:600}
        .header-info .item b{display:block;font-size:9px;color:#9E8E8E;margin-bottom:2px}
        .header-info .item span{font-size:12px;font-weight:800;color:#1A1A2E}
        .sec{background:#6B1A2F;color:#fff;text-align:center;padding:5px;border-radius:4px;font-size:12px;font-weight:900;margin:8px 0 4px;break-after:avoid}
        .tw{margin-bottom:6px}
        .data-table{width:100%;border-collapse:collapse;font-size:10.5px}
        .data-table th,.data-table td{border:1px solid #E8D8DD;padding:4px 3px;text-align:center;vertical-align:middle;font-weight:600;color:#1A1A2E;background:#fff}
        .data-table th{background:#6B1A2F;color:#fff;font-weight:800;font-size:10px;border-color:#6B1A2F}
        .data-table .day-col{background:#F5F0F1;font-weight:800;color:#4A1520}
        .data-table .total-row td{background:#F5E1E7;font-weight:900;color:#4A1520;border-top:2px solid #6B1A2F}
        .calc-box{border:1px solid #E8D8DD;border-radius:6px;padding:4px 10px;margin-top:4px;break-inside:avoid}
        .calc-row{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:4px 0;border-bottom:1px dashed #E8D8DD}
        .calc-row:last-child{border-bottom:0}
        .calc-row .lbl{font-size:11px;font-weight:700;color:#7B6B6B;flex:1}
        .calc-row .val-box{min-width:110px;text-align:center;font-weight:800;font-size:12px;border:1px solid #E8D8DD;border-radius:4px;padding:2px 8px;color:#1A1A2E}
        .calc-row.total{font-weight:900;border-top:2px solid #F5E1E7;margin-top:3px;padding-top:6px}
        .highlight-red{color:#E53935!important}.highlight-green{color:#43A047!important}.highlight-blue{color:#1E88E5!important}
        .df-print .meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin:8px 0;font-weight:700}
        .sum{display:flex;flex-wrap:wrap;gap:10px;justify-content:space-around;margin:10px 0;padding:8px;border:1.5px solid #444;border-radius:8px;font-weight:bold}
        .print-meta{text-align:left;font-size:10px;color:#64748b;margin-top:12px}
    """.trimIndent()

    private fun buildLuxCss(L: LuxuryPrintSettings, generic: Boolean): String {
        val styleKey = normalizeStyleKey(L.style)
        val s = LUX_STYLES[styleKey] ?: LUX_STYLES.getValue("minimal")
        val bc = s.borderColor
        val luxPaper = L.paperColor.ifBlank { s.paperBg }
        val luxText = L.txtColor.ifBlank { s.textColor }
        val th = when (L.thick) {
            "thin" -> "1px"
            "thick" -> "3px"
            else -> "1.5px"
        }
        val ln = L.line.ifBlank { "solid" }
        val rad = when (L.shape) {
            "soft" -> "4px"
            "rounded" -> "10px"
            "corners", "round" -> "18px"
            "capsule", "pill" -> "999px"
            "circle" -> "50%"
            else -> "0"
        }
        val brad = if (rad == "50%") "18px" else rad
        val shadowCss = if (L.shadow == "on") {
            if (s.boxShadow == "none") "0 1px 3px rgba(0,0,0,.25)" else s.boxShadow
        } else "none"
        val btn = when (L.btn) {
            "classic" -> "outline:2px double $bc;outline-offset:-4px;"
            "rounded" -> "border-radius:8px;"
            else -> ""
        }
        val hf = if (styleKey == "editorial") "font-family:Georgia,serif!important;" else ""

        val tb = mutableListOf(".pv-t", ".cs-t", ".vc-t", ".hw-t", ".print-table", "table.statement", ".df-print table", ".by-print table", ".data-table")
        if (generic) tb.add("table")
        val cellsTh = tb.joinToString(",") { "$it th" }
        val cellsTd = tb.joinToString(",") { "$it td" }
        val sumRs = listOf("tr.pv-sum", "tr.total-row", "tr.remaining-row", "tr.summary", "tfoot tr")
        val sumCells = sumRs.flatMap { r -> tb.map { b -> "$b $r td,$b $r th" } }.joinToString(",")
        val hdSel = ".pv-title,.doc-title,.paper-title,.voucher-headline,.vc-dh,.nf-doc-title,.sec"
        val bxSel = ".pv-bal,.vc-tot,.vc-w,.hw-amt div,.tx,.voucher-total,.paper-balance,.summary-line,.df-total,.voucher-words,.vc,.calc-box"

        val btnTCss = when (L.btnT) {
            "pill" -> "$cellsTh,$hdSel{border-radius:999px!important}"
            "grad" -> "$cellsTh,$hdSel{background:linear-gradient(135deg,#1e293b,#64748b)!important;color:#fff!important}"
            "outline" -> "$cellsTh,$hdSel{background:transparent!important;color:inherit!important;border:2px solid currentColor!important}"
            "raised" -> "$cellsTh,$hdSel{box-shadow:0 3px 0 rgba(0,0,0,.35)!important}"
            "glass" -> "$cellsTh,$hdSel{background:rgba(255,255,255,.55)!important;border-radius:12px!important}"
            "neon" -> "$cellsTh,$hdSel{background:#0f172a!important;color:#22d3ee!important;box-shadow:0 0 8px #22d3ee!important}"
            else -> ""
        }
        val colTCss = when (L.colT) {
            "zebra" -> ".pv-t tbody tr:nth-child(even) td,.by-print tbody tr:nth-child(even) td{background:#f8fafc!important}"
            "firstAccent" -> ".pv-t td:first-child,.by-print td:first-child{font-weight:900!important;background:#eef2ff!important}"
            "vsep" -> ".pv-t th,.pv-t td{border-top:none!important;border-bottom:none!important}"
            "hsep" -> ".pv-t th,.pv-t td{border-left:none!important;border-right:none!important}"
            "gold" -> ".pv-t th,.pv-t td,.cs-t th,.cs-t td{border-color:#c9a227!important}"
            "tint" -> ".pv-t td:nth-child(3),.pv-t td:nth-child(4){background:#ecfdf5!important}.pv-t td:nth-child(5),.pv-t td:nth-child(6){background:#fef2f2!important}"
            else -> ""
        }
        val modTCss = when (L.modT) {
            "rowcards" -> ".pv-t{border-collapse:separate!important;border-spacing:0 6px!important}.pv-t th,.pv-t td{border-radius:8px!important}"
            "floating" -> ".pv-t{box-shadow:0 8px 24px rgba(15,23,42,.12)!important;border-radius:14px!important}"
            "gradbar" -> ".pv-title,.pv-cur,.sec{background:linear-gradient(90deg,#0f172a,#334155)!important;color:#fff!important;border-radius:10px!important}"
            "pillsum" -> ".pv-t tr.pv-sum td:first-child{border-radius:999px!important}"
            "mono" -> ".pv-t th,.pv-t td{background:#fff!important;color:#111!important;border-color:#111!important}"
            "dark" -> ".pv-t th,.pv-t td{background:#0b1220!important;color:#e2e8f0!important;border-color:#334155!important}"
            else -> ""
        }

        val totBases = listOf("tr.pv-sum", "tr.total-row", "tr.remaining-row", "tr.summary", ".pv-bal", ".vc-tot", ".calc-row.total", ".df-total")
        val totSel = totBases.joinToString(",") { "html body $it,html body $it *" }
        val totNumSel = totBases.joinToString(",") { "html body $it .lx-n,html body $it .lx-nl,html body $it .lx-no" }

        val textOverrideCss = buildString {
            append("html body,html body *{color:$luxText!important}")
            if (L.txtLColor.isNotBlank()) append("html body .lx-wl{color:${L.txtLColor}!important}")
            if (L.numLColor.isNotBlank()) append("html body .lx-nl{color:${L.numLColor}!important}")
            if (L.txtOColor.isNotBlank()) append("html body .lx-wo{color:${L.txtOColor}!important}")
            if (L.numOColor.isNotBlank()) append("html body .lx-no{color:${L.numOColor}!important}")
            if (L.txtTColor.isNotBlank()) append("$totSel{color:${L.txtTColor}!important}")
            if (L.numTColor.isNotBlank()) append("$totNumSel{color:${L.numTColor}!important}")
        }

        val bgUrl = if (L.bgPath.isNotBlank()) ImageStorageHelper.toBase64DataUrl(L.bgPath) else ""
        val bgCss = if (bgUrl.isNotBlank()) {
            val op = L.clear.coerceIn(0, 100) / 100.0
            val (r, g, b) = hexToRgb(luxPaper)
            val ov = "rgba($r,$g,$b,${1.0 - op})"
            "body{background:linear-gradient($ov,$ov),url(\"$bgUrl\") center/cover no-repeat fixed!important}"
        } else ""

        val frameCss = when (L.frame) {
            "thin" -> "html body{box-sizing:border-box!important;border:1.5px solid $bc!important;border-radius:$brad!important;padding-top:6px!important;padding-bottom:6px!important}"
            "thick" -> "html body{box-sizing:border-box!important;border:3px solid $bc!important;border-radius:$brad!important;padding-top:6px!important;padding-bottom:6px!important}"
            "double" -> "html body{box-sizing:border-box!important;border:5px double $bc!important;border-radius:$brad!important;padding-top:6px!important;padding-bottom:6px!important}"
            else -> ""
        }

        return """
            html,body{background-color:$luxPaper!important;color:$luxText!important}
            body,body *{border-color:$bc}
            *{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
            $cellsTh,$cellsTd{border:$th $ln $bc!important;border-radius:$rad!important;background:${s.paperBg}!important;color:$luxText!important;box-shadow:$shadowCss!important}
            $cellsTh{background:${s.thBg}!important;color:${s.thFg}!important;$btn$hf}
            $sumCells{background:${s.thBg}!important;color:${s.thFg}!important}
            ${tb.joinToString(",")}{border:2px $ln $bc!important;border-radius:$rad}
            $hdSel{background:${s.thBg}!important;color:${s.thFg}!important;border:$th $ln $bc!important;border-radius:$brad!important;box-shadow:$shadowCss!important;$hf}
            $bxSel{border:$th $ln $bc!important;border-radius:$brad!important;background:${s.paperBg}!important;color:${s.textColor}!important;box-shadow:$shadowCss!important}
            .tx div{border-top:$th $ln $bc!important}
            .vc-wl{border-right:$th $ln $bc!important;background:${s.paperBg}!important;color:${s.textColor}!important}
            .hw-amt div.hw-b,.vc-t td.vc-c{background:${s.thBg}!important;color:${s.thFg}!important}
            .company-header,.print-profile-header,.full-image-header{border-bottom:2px $ln $bc!important}
            .pv-foot,.pv-sign{border-top-color:$bc!important}
            .pv-acc,.tx-who .nm{border-bottom-color:$bc!important}
            $btnTCss
            $colTCss
            $modTCss
            $textOverrideCss
            $bgCss
            $frameCss
        """.trimIndent()
    }

    private fun luxNeedsMark(L: LuxuryPrintSettings): Boolean =
        L.txtLColor.isNotBlank() || L.txtOColor.isNotBlank() || L.txtTColor.isNotBlank() ||
            L.numLColor.isNotBlank() || L.numOColor.isNotBlank() || L.numTColor.isNotBlank()

    private val VOID_TAGS = setOf("br", "img", "hr", "input", "meta", "link", "col", "area", "base", "source", "wbr")
    private val TAG_OR_COMMENT = Regex("""<!--[\s\S]*?-->|<[^>]+>""")
    private val TOKEN_REGEX = Regex("""(\d[\d,]*(?:\.\d+)?(?:[/:]\d+)*)|([\u0621-\u064A]+)""")
    private val CL_L = Regex("""(^|\s)(grn|pay|pos|green)(\s|$)""")
    private val CL_O = Regex("""(^|\s)(red|debt|neg|df-amount)(\s|$)""")
    private val CL_T = Regex("""(^|\s)(pv-sum|total-row|remaining-row|summary|vc-tot|pv-bal|voucher-total|df-total|calc-row total)(\s|$)""")

    private fun luxMarkHtml(html: String): String {
        val stack = mutableListOf<Triple<String, String, Boolean>>() // tagName, side (L/O/""), isTot
        var skipTag = ""
        val out = StringBuilder(html.length + 512)
        var lastEnd = 0

        fun processTextSegment(text: String) {
            if (skipTag.isNotEmpty() || text.isEmpty() || !text.any { it.isDigit() || it in '\u0621'..'\u064A' }) {
                out.append(text)
                return
            }
            val ctx = stack.lastOrNull()
            val anc = ctx?.second ?: ""
            val tot = ctx?.third ?: false

            // Avoid matching HTML entities like &nbsp;
            val entityRegex = Regex("""&#?\w+;""")
            var pos = 0
            for (ent in entityRegex.findAll(text)) {
                if (ent.range.first > pos) {
                    out.append(markPlainPieces(text.substring(pos, ent.range.first), anc, tot))
                }
                out.append(ent.value)
                pos = ent.range.last + 1
            }
            if (pos < text.length) {
                out.append(markPlainPieces(text.substring(pos), anc, tot))
            }
        }

        for (match in TAG_OR_COMMENT.findAll(html)) {
            if (match.range.first > lastEnd) {
                processTextSegment(html.substring(lastEnd, match.range.first))
            }
            val tag = match.value
            out.append(tag)
            lastEnd = match.range.last + 1

            val closeMatch = Regex("""^</([a-zA-Z][\w:-]*)""").find(tag)
            if (closeMatch != null) {
                val nm = closeMatch.groupValues[1].lowercase()
                if (skipTag == nm) {
                    skipTag = ""
                } else if (skipTag.isEmpty()) {
                    val idx = stack.indexOfLast { it.first == nm }
                    if (idx >= 0) {
                        while (stack.size > idx) stack.removeAt(stack.lastIndex)
                    }
                }
                continue
            }

            val openMatch = Regex("""^<([a-zA-Z][\w:-]*)([^>]*)>$""").find(tag)
            if (openMatch != null && skipTag.isEmpty()) {
                val nm = openMatch.groupValues[1].lowercase()
                if (nm == "script" || nm == "style" || nm == "title" || nm == "textarea") {
                    skipTag = nm
                } else if (nm !in VOID_TAGS && !tag.trimEnd().endsWith("/>")) {
                    val attrs = openMatch.groupValues[2]
                    val clsMatch = Regex("""class\s*=\s*(?:"([^"]*)"|'([^']*)')""").find(attrs)
                    val cls = clsMatch?.let { it.groupValues[1].ifEmpty { it.groupValues[2] } } ?: ""
                    val side = when {
                        CL_L.containsMatchIn(cls) -> "L"
                        CL_O.containsMatchIn(cls) -> "O"
                        else -> ""
                    }
                    val isTot = CL_T.containsMatchIn(cls)
                    val parent = stack.lastOrNull()
                    stack.add(Triple(nm, side.ifEmpty { parent?.second ?: "" }, isTot || (parent?.third == true)))
                }
            }
        }
        if (lastEnd < html.length) {
            processTextSegment(html.substring(lastEnd))
        }
        return out.toString()
    }

    private fun markPlainPieces(seg: String, anc: String, tot: Boolean): String {
        data class Tok(val start: Int, val end: Int, val kind: Char, val side: String, var css: String = "")
        val toks = mutableListOf<Tok>()
        val sides = mutableListOf<String>()
        for (m in TOKEN_REGEX.findAll(seg)) {
            val g1 = m.groupValues[1]
            val g2 = m.groupValues[2]
            if (g1.isNotEmpty()) {
                if ('/' in g1 || ':' in g1) continue
                toks.add(Tok(m.range.first, m.range.last + 1, 'n', ""))
            } else if (g2.isNotEmpty()) {
                val side = when (g2) {
                    "لكم", "له" -> "L"
                    "عليكم", "عليه" -> "O"
                    else -> ""
                }
                if (side.isNotEmpty()) {
                    toks.add(Tok(m.range.first, m.range.last + 1, 'w', side))
                    sides.add(side)
                }
            }
        }
        if (toks.isEmpty()) return seg
        val uniq = sides.distinct()
        var cur = ""
        toks.forEachIndexed { idx, tok ->
            if (tok.kind == 'w') {
                cur = tok.side
                tok.css = if (tok.side == "L") "lx-wl" else "lx-wo"
            } else {
                var s = anc
                if (uniq.size == 1) s = uniq[0]
                else if (uniq.size > 1) {
                    s = cur
                    if (s.isEmpty()) {
                        s = toks.drop(idx + 1).firstOrNull { it.kind == 'w' }?.side ?: ""
                    }
                }
                tok.css = if (s.isNotEmpty() || tot) {
                    "lx-n" + if (s.isNotEmpty()) " lx-n${s.lowercase()}" else ""
                } else ""
            }
        }

        val sb = StringBuilder(seg.length + 32)
        var p = 0
        for (tok in toks) {
            if (tok.css.isEmpty()) continue
            if (tok.start > p) sb.append(seg, p, tok.start)
            sb.append("<span class=\"").append(tok.css).append("\">").append(seg, tok.start, tok.end).append("</span>")
            p = tok.end
        }
        if (p == 0) return seg
        if (p < seg.length) sb.append(seg, p, seg.length)
        return sb.toString()
    }

    private fun buildProfileHeader(settings: AppSettings): String {
        if (!settings.printing.showHeaderData) return ""
        val p = settings.profile
        val logoB64 = ImageStorageHelper.toBase64DataUrl(p.logoPath)
        val hasAr = p.nameAr.isNotBlank() || p.addressAr.isNotBlank() || p.contacts.isNotBlank()
        val hasEn = p.nameEn.isNotBlank() || p.addressEn.isNotBlank() || p.contactsEn.isNotBlank()
        if (!hasAr && !hasEn && logoB64.isBlank()) return ""

        if (p.useFullHeader && logoB64.isNotBlank()) {
            return "<div class='full-image-header print-profile-header full'><img class='full-header-image' src='$logoB64' alt='ترويسة'/></div>"
        }

        val arSide = listOf(p.nameAr, p.addressAr, p.contacts)
            .filter { it.isNotBlank() }
            .mapIndexed { idx, txt -> if (idx == 0) "<div class='name'>${esc(txt)}</div>" else esc(txt) }
            .joinToString("<br>")

        val enSide = listOf(p.nameEn, p.addressEn, p.contactsEn)
            .filter { it.isNotBlank() }
            .mapIndexed { idx, txt -> if (idx == 0) "<div class='name'>${esc(txt)}</div>" else esc(txt) }
            .joinToString("<br>")

        val lw = (86.0 * p.logoSize.coerceIn(0.4, 2.5)).toInt()
        val lh = (72.0 * p.logoSize.coerceIn(0.4, 2.5)).toInt()
        val logoHtml = if (logoB64.isNotBlank()) {
            "<img class='company-logo' src='$logoB64' style='width:${lw}px;height:${lh}px;' alt='شعار'/>"
        } else "<span></span>"

        return """
            <div class='company-header'>
              <div class='company-side ar'>$arSide</div>
              <div>$logoHtml</div>
              <div class='company-side en'>$enSide</div>
            </div>
        """.trimIndent()
    }

    fun buildStampHtml(settings: AppSettings, mode: String): String {
        val p = settings.profile
        val stampB64 = ImageStorageHelper.toBase64DataUrl(p.stampPath)
        val signB64 = ImageStorageHelper.toBase64DataUrl(p.signPath)
        if (mode == "none") return ""
        val showStamp = (mode == "stamp" || mode == "all") && stampB64.isNotBlank()
        val showSign = (mode == "sign" || mode == "all") && signB64.isNotBlank()
        if (!showStamp && !showSign) return ""

        val stampW = (100.0 * p.stampSize.coerceIn(0.4, 2.5)).toInt()
        val stampH = (65.0 * p.stampSize.coerceIn(0.4, 2.5)).toInt()
        val signW = (100.0 * p.signSize.coerceIn(0.4, 2.5)).toInt()
        val signH = (55.0 * p.signSize.coerceIn(0.4, 2.5)).toInt()

        return buildString {
            if (showStamp) {
                append("<img src='$stampB64' style='max-width:${stampW}px;max-height:${stampH}px;' alt='ختم'/>")
            }
            if (showSign) {
                append("<img src='$signB64' style='max-width:${signW}px;max-height:${signH}px;margin-inline-start:6px;' alt='توقيع'/>")
            }
        }
    }

    fun buildFootHtml(settings: AppSettings, stampMode: String): String {
        val ps = settings.printing
        val dt = buildString {
            if (ps.showPrintDate) append(DateHelper.todayIso())
            if (ps.showPrintDate && ps.showPrintTime) append(" ")
            if (ps.showPrintTime) append(DateHelper.nowTime())
        }
        val st = buildStampHtml(settings, stampMode)
        return "<div class='pv-foot'><span>صفحة 1</span><span>${esc(dt)}</span><span>$st</span></div>"
    }

    fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")
}
