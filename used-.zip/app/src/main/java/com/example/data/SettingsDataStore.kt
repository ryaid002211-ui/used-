package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.settingsDataStore by preferencesDataStore(name = "smart_admin_settings")

class SettingsDataStore(private val context: Context) {

    private val KEY_SETTINGS = stringPreferencesKey("app_settings_json")

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val raw = prefs[KEY_SETTINGS]
        if (raw.isNullOrBlank()) AppSettings() else decode(raw)
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[KEY_SETTINGS]?.let { decode(it) } ?: AppSettings()
            val updated = transform(current)
            prefs[KEY_SETTINGS] = encode(updated)
        }
    }

    suspend fun replace(settings: AppSettings) {
        context.settingsDataStore.edit { prefs ->
            prefs[KEY_SETTINGS] = encode(settings)
        }
    }

    fun encode(s: AppSettings): String = JSONObject().apply {
        put("lang", s.lang)
        put("dark", s.dark)
        put("primaryColorHex", s.primaryColorHex)
        put("fontFamily", s.fontFamily)
        put("fontWeight", s.fontWeight)
        put("fontSize", s.fontSize)
        put("viewMode", s.viewMode)
        put("multiCurrency", s.multiCurrency)
        put("defaultCurrency", s.defaultCurrency)
        put("showInvoicesInFolders", s.showInvoicesInFolders)
        put("longPressActions", s.longPressActions)
        put("activeSpecialty", s.activeSpecialty)
        put("buyerActiveSpecialty", s.buyerActiveSpecialty)
        put("fixedDebtCashboxId", s.fixedDebtCashboxId)
        put("tasfeerFxAccId", s.tasfeerFxAccId)
        put("tasfeerComAccId", s.tasfeerComAccId)
        put("tasfeerPass", s.tasfeerPass)
        put("youtubeUrl", s.youtubeUrl)
        put("supportPhone", s.supportPhone)
        put("supportEmail", s.supportEmail)
        put("termsText", s.termsText)
        put("privacyText", s.privacyText)
        put("currencies", JSONArray().apply {
            s.currencies.forEach { c ->
                put(JSONObject().apply {
                    put("name", c.name); put("symbol", c.symbol)
                    put("sellRate", c.sellRate); put("buyRate", c.buyRate)
                    put("fraction", c.fraction); put("isDefault", c.isDefault)
                    put("subUnit", c.subUnit)
                })
            }
        })
        put("specialties", JSONArray().apply {
            s.specialties.forEach { sp ->
                put(JSONObject().apply { put("id", sp.id); put("name", sp.name); put("workersAmount", sp.workersAmount) })
            }
        })
        put("buyerSpecialties", JSONArray().apply {
            s.buyerSpecialties.forEach { sp ->
                put(JSONObject().apply { put("id", sp.id); put("name", sp.name); put("workersAmount", sp.workersAmount) })
            }
        })
        put("profile", JSONObject().apply {
            put("nameAr", s.profile.nameAr); put("nameEn", s.profile.nameEn)
            put("addressAr", s.profile.addressAr); put("addressEn", s.profile.addressEn)
            put("contacts", s.profile.contacts); put("contactsEn", s.profile.contactsEn)
            put("useFullHeader", s.profile.useFullHeader)
            put("logoPath", s.profile.logoPath); put("stampPath", s.profile.stampPath); put("signPath", s.profile.signPath)
            put("logoSize", s.profile.logoSize); put("signSize", s.profile.signSize); put("stampSize", s.profile.stampSize)
        })
        put("appearance", JSONObject().apply {
            put("designType", s.appearance.designType)
            put("frameEnabled", s.appearance.frameEnabled)
            put("frameColorEnabled", s.appearance.frameColorEnabled)
            put("frameShapeEnabled", s.appearance.frameShapeEnabled)
            put("frameStyleEnabled", s.appearance.frameStyleEnabled)
            put("frameThicknessEnabled", s.appearance.frameThicknessEnabled)
            put("frameColor", s.appearance.frameColor)
            put("frameShape", s.appearance.frameShape)
            put("frameStyle", s.appearance.frameStyle)
            put("frameThickness", s.appearance.frameThickness)
            put("buttonShape", s.appearance.buttonShape)
            put("shadows", s.appearance.shadows)
            put("backgroundPath", s.appearance.backgroundPath)
            put("backgroundOpacity", s.appearance.backgroundOpacity)
        })
        put("messages", JSONObject().apply {
            put("sendMethod", s.messages.sendMethod); put("sendWhen", s.messages.sendWhen)
            put("globalMessageSettings", s.messages.globalMessageSettings)
            put("msgIntroEnabled", s.messages.msgIntroEnabled); put("msgIntro", s.messages.msgIntro)
            put("msgEndEnabled", s.messages.msgEndEnabled); put("msgEnd", s.messages.msgEnd)
            put("payEnd", s.messages.payEnd); put("msgFormatDebt", s.messages.msgFormatDebt)
            put("msgFormatPay", s.messages.msgFormatPay); put("messageFormat", s.messages.messageFormat)
            put("messageContent", s.messages.messageContent); put("sendDest", s.messages.sendDest)
            put("waType", s.messages.waType); put("countryCode", s.messages.countryCode)
            put("lineKey", s.messages.lineKey); put("imageSize", s.messages.imageSize)
            put("paTiming", s.messages.paTiming)
        })
        put("printing", JSONObject().apply {
            put("printMethod", s.printing.printMethod)
            put("paperStatement", s.printing.paperStatement); put("paperVoucher", s.printing.paperVoucher)
            put("saleSortBy", s.printing.saleSortBy); put("saleSortDir", s.printing.saleSortDir)
            put("printColorMode", s.printing.printColorMode); put("printColor", s.printing.printColor)
            put("printFont", s.printing.printFont); put("printFontScale", s.printing.printFontScale)
            put("printTextColor", s.printing.printTextColor)
            put("currencyStmtHeader", s.printing.currencyStmtHeader); put("currencyStmtSummary", s.printing.currencyStmtSummary)
            s.printing.currencyStmtList?.let { put("currencyStmtList", JSONArray(it)) }
            put("showHeaderData", s.printing.showHeaderData); put("repeatHeader", s.printing.repeatHeader)
            put("showPrintDate", s.printing.showPrintDate); put("showPrintTime", s.printing.showPrintTime)
            put("showAccountNote", s.printing.showAccountNote); put("showPhone", s.printing.showPhone)
            put("addNoteOnStatement", s.printing.addNoteOnStatement)
            put("stampSettings", JSONObject().apply {
                put("vouchers", s.printing.stampSettings.vouchers)
                put("invoices", s.printing.stampSettings.invoices)
                put("statement", s.printing.stampSettings.statement)
                put("balance", s.printing.stampSettings.balance)
            })
            put("lux", JSONObject().apply {
                val l = s.printing.lux
                put("on", l.on); put("tpl", l.tpl); put("style", l.style); put("shape", l.shape)
                put("line", l.line); put("btn", l.btn); put("btnT", l.btnT); put("colT", l.colT)
                put("modT", l.modT); put("shadow", l.shadow); put("thick", l.thick)
                put("txtColor", l.txtColor); put("txtLColor", l.txtLColor); put("numLColor", l.numLColor)
                put("txtOColor", l.txtOColor); put("numOColor", l.numOColor)
                put("txtTColor", l.txtTColor); put("numTColor", l.numTColor)
                put("paperColor", l.paperColor); put("frame", l.frame); put("bgPath", l.bgPath); put("clear", l.clear)
            })
        })
        put("appLock", JSONObject().apply {
            put("enabled", s.appLock.enabled)
            put("pin", s.appLock.pin)
            put("biometric", s.appLock.biometric)
            put("autoLock", s.appLock.autoLock)
        })
        put("gdriveBackup", JSONObject().apply {
            val g = s.gdriveBackup
            put("connected", g.connected)
            put("email", g.email)
            put("dataEnabled", g.dataEnabled)
            put("dataInterval", g.dataInterval)
            put("imagesBackupEnabled", g.imagesBackupEnabled)
            put("imagesInterval", g.imagesInterval)
            put("wifiOnly", g.wifiOnly)
            put("backupOnExit", g.backupOnExit)
            put("lastDataBackup", g.lastDataBackup)
            put("backupHistory", JSONArray().apply {
                g.backupHistory.take(30).forEach { h ->
                    put(JSONObject().apply {
                        put("filename", h.filename)
                        put("dateIso", h.dateIso)
                        put("sizeBytes", h.sizeBytes)
                        put("fileId", h.fileId)
                    })
                }
            })
        })
        put("savedNames", JSONArray(s.savedNames))
    }.toString()

    fun decode(raw: String): AppSettings {
        return try {
            val o = JSONObject(raw)
            val curArr = o.optJSONArray("currencies")
            val currencies = if (curArr != null && curArr.length() > 0) {
                (0 until curArr.length()).map { i ->
                    val c = curArr.getJSONObject(i)
                    AppCurrency(
                        name = c.optString("name"),
                        symbol = c.optString("symbol"),
                        sellRate = c.optDouble("sellRate", 1.0),
                        buyRate = c.optDouble("buyRate", 1.0),
                        fraction = c.optDouble("fraction", 1.0),
                        isDefault = c.optBoolean("isDefault", false),
                        subUnit = c.optString("subUnit")
                    )
                }
            } else AppSettings.defaultCurrencies()

            fun decSpecs(arr: JSONArray?): List<Specialty> {
                if (arr == null) return emptyList()
                return (0 until arr.length()).map { i ->
                    val sp = arr.getJSONObject(i)
                    Specialty(sp.optString("id"), sp.optString("name"), sp.optDouble("workersAmount", 0.0))
                }
            }

            val pObj = o.optJSONObject("profile")
            val profile = if (pObj != null) ProfileSettings(
                nameAr = pObj.optString("nameAr"), nameEn = pObj.optString("nameEn"),
                addressAr = pObj.optString("addressAr"), addressEn = pObj.optString("addressEn"),
                contacts = pObj.optString("contacts"), contactsEn = pObj.optString("contactsEn"),
                useFullHeader = pObj.optBoolean("useFullHeader"),
                logoPath = pObj.optString("logoPath"), stampPath = pObj.optString("stampPath"), signPath = pObj.optString("signPath"),
                logoSize = pObj.optDouble("logoSize", 1.0), signSize = pObj.optDouble("signSize", 1.0), stampSize = pObj.optDouble("stampSize", 1.0)
            ) else ProfileSettings()

            val aObj = o.optJSONObject("appearance")
            val appearance = if (aObj != null) AppearanceSettings(
                designType = aObj.optString("designType", "glassmorphism"),
                frameEnabled = aObj.optBoolean("frameEnabled", true),
                frameColorEnabled = aObj.optBoolean("frameColorEnabled", true),
                frameShapeEnabled = aObj.optBoolean("frameShapeEnabled", true),
                frameStyleEnabled = aObj.optBoolean("frameStyleEnabled", true),
                frameThicknessEnabled = aObj.optBoolean("frameThicknessEnabled", true),
                frameColor = aObj.optString("frameColor", "gold"),
                frameShape = aObj.optString("frameShape", "rounded"),
                frameStyle = aObj.optString("frameStyle", "solid"),
                frameThickness = aObj.optString("frameThickness", "thin"),
                buttonShape = aObj.optString("buttonShape", "classic"),
                shadows = aObj.optBoolean("shadows", true),
                backgroundPath = aObj.optString("backgroundPath"),
                backgroundOpacity = aObj.optInt("backgroundOpacity", 100)
            ) else AppearanceSettings()

            val mObj = o.optJSONObject("messages")
            val messages = if (mObj != null) MessageSettings(
                sendMethod = mObj.optString("sendMethod", "whatsapp"),
                sendWhen = mObj.optString("sendWhen", "confirm"),
                globalMessageSettings = mObj.optBoolean("globalMessageSettings", true),
                msgIntroEnabled = mObj.optBoolean("msgIntroEnabled", true),
                msgIntro = mObj.optString("msgIntro"),
                msgEndEnabled = mObj.optBoolean("msgEndEnabled", true),
                msgEnd = mObj.optString("msgEnd"),
                payEnd = mObj.optString("payEnd", "الرجاء سرعة سداد ماعليكم مع كامل الشكر والاحترام"),
                msgFormatDebt = mObj.optString("msgFormatDebt", "عليكم"),
                msgFormatPay = mObj.optString("msgFormatPay", "الرصيد لك"),
                messageFormat = mObj.optString("messageFormat", "both"),
                messageContent = mObj.optString("messageContent", "text"),
                sendDest = mObj.optString("sendDest", "phone"),
                waType = mObj.optString("waType", "business"),
                countryCode = mObj.optString("countryCode", "+967"),
                lineKey = mObj.optString("lineKey", "empty"),
                imageSize = mObj.optDouble("imageSize", 1.0),
                paTiming = mObj.optString("paTiming", "confirm")
            ) else MessageSettings()

            val prObj = o.optJSONObject("printing")
            val printing = if (prObj != null) {
                val stObj = prObj.optJSONObject("stampSettings")
                val lxObj = prObj.optJSONObject("lux")
                val stmtArr = prObj.optJSONArray("currencyStmtList")
                PrintSettings(
                    printMethod = prObj.optString("printMethod", "pdf"),
                    paperStatement = prObj.optString("paperStatement", "a4"),
                    paperVoucher = prObj.optString("paperVoucher", "a4"),
                    saleSortBy = prObj.optString("saleSortBy", "date"),
                    saleSortDir = prObj.optString("saleSortDir", "asc"),
                    printColorMode = prObj.optString("printColorMode", "color"),
                    printColor = prObj.optString("printColor", "#6B1A2F"),
                    printFont = prObj.optString("printFont", "cairo"),
                    printFontScale = prObj.optInt("printFontScale", 100),
                    printTextColor = prObj.optString("printTextColor", "#111111"),
                    currencyStmtHeader = prObj.optBoolean("currencyStmtHeader", true),
                    currencyStmtSummary = prObj.optBoolean("currencyStmtSummary", true),
                    currencyStmtList = stmtArr?.let { a -> (0 until a.length()).map { a.optString(it) } },
                    showHeaderData = prObj.optBoolean("showHeaderData", true),
                    repeatHeader = prObj.optBoolean("repeatHeader", true),
                    showPrintDate = prObj.optBoolean("showPrintDate", true),
                    showPrintTime = prObj.optBoolean("showPrintTime", true),
                    showAccountNote = prObj.optBoolean("showAccountNote", false),
                    showPhone = prObj.optBoolean("showPhone", false),
                    addNoteOnStatement = prObj.optBoolean("addNoteOnStatement", false),
                    stampSettings = if (stObj != null) StampSettings(
                        vouchers = stObj.optString("vouchers", "sign"),
                        invoices = stObj.optString("invoices", "sign"),
                        statement = stObj.optString("statement", "sign"),
                        balance = stObj.optString("balance", "sign")
                    ) else StampSettings(),
                    lux = if (lxObj != null) LuxuryPrintSettings(
                        on = lxObj.optBoolean("on", false),
                        tpl = lxObj.optString("tpl"),
                        style = lxObj.optString("style", "minimal"),
                        shape = lxObj.optString("shape", "box"),
                        line = lxObj.optString("line", "solid"),
                        btn = lxObj.optString("btn", "simple"),
                        btnT = lxObj.optString("btnT"),
                        colT = lxObj.optString("colT"),
                        modT = lxObj.optString("modT"),
                        shadow = lxObj.optString("shadow", "off"),
                        thick = lxObj.optString("thick", "medium"),
                        txtColor = lxObj.optString("txtColor", "#111827"),
                        txtLColor = lxObj.optString("txtLColor", "#15803d"),
                        numLColor = lxObj.optString("numLColor", "#15803d"),
                        txtOColor = lxObj.optString("txtOColor", "#dc2626"),
                        numOColor = lxObj.optString("numOColor", "#dc2626"),
                        txtTColor = lxObj.optString("txtTColor", "#0f172a"),
                        numTColor = lxObj.optString("numTColor", "#0f172a"),
                        paperColor = lxObj.optString("paperColor", "#ffffff"),
                        frame = lxObj.optString("frame"),
                        bgPath = lxObj.optString("bgPath"),
                        clear = lxObj.optInt("clear", 100)
                    ) else LuxuryPrintSettings()
                )
            } else PrintSettings()

            val lockObj = o.optJSONObject("appLock")
            val lock = if (lockObj != null) AppLockSettings(
                enabled = lockObj.optBoolean("enabled", false),
                pin = lockObj.optString("pin"),
                biometric = lockObj.optBoolean("biometric", false),
                autoLock = lockObj.optString("autoLock", "1m")
            ) else AppLockSettings()

            val gObj = o.optJSONObject("gdriveBackup")
            val gdriveBackup = if (gObj != null) {
                val hArr = gObj.optJSONArray("backupHistory")
                val hist = if (hArr != null) (0 until hArr.length()).map { i ->
                    val ho = hArr.getJSONObject(i)
                    DriveBackupHistoryItem(
                        filename = ho.optString("filename"),
                        dateIso = ho.optString("dateIso"),
                        sizeBytes = ho.optLong("sizeBytes", 0L),
                        fileId = ho.optString("fileId")
                    )
                } else emptyList()
                DriveBackupSettings(
                    connected = gObj.optBoolean("connected", false),
                    email = gObj.optString("email"),
                    dataEnabled = gObj.optBoolean("dataEnabled", true),
                    dataInterval = gObj.optString("dataInterval", "24h"),
                    imagesBackupEnabled = gObj.optBoolean("imagesBackupEnabled", false),
                    imagesInterval = gObj.optString("imagesInterval", "daily"),
                    wifiOnly = gObj.optBoolean("wifiOnly", false),
                    backupOnExit = gObj.optBoolean("backupOnExit", false),
                    lastDataBackup = gObj.optLong("lastDataBackup", 0L),
                    backupHistory = hist
                )
            } else DriveBackupSettings()

            AppSettings(
                lang = o.optString("lang", "ar"),
                dark = o.optBoolean("dark", false),
                primaryColorHex = o.optString("primaryColorHex", "#1e40af"),
                fontFamily = o.optString("fontFamily", "tajawal"),
                fontWeight = o.optString("fontWeight", "medium"),
                fontSize = o.optString("fontSize", "medium"),
                viewMode = o.optString("viewMode", "list"),
                multiCurrency = o.optBoolean("multiCurrency", true),
                defaultCurrency = o.optString("defaultCurrency", "ر.ي"),
                showInvoicesInFolders = o.optBoolean("showInvoicesInFolders", true),
                longPressActions = o.optBoolean("longPressActions", true),
                activeSpecialty = o.optString("activeSpecialty", "all"),
                buyerActiveSpecialty = o.optString("buyerActiveSpecialty", "all"),
                fixedDebtCashboxId = o.optString("fixedDebtCashboxId"),
                tasfeerFxAccId = o.optString("tasfeerFxAccId"),
                tasfeerComAccId = o.optString("tasfeerComAccId"),
                tasfeerPass = o.optString("tasfeerPass"),
                youtubeUrl = o.optString("youtubeUrl"),
                supportPhone = o.optString("supportPhone", "967773544574"),
                supportEmail = o.optString("supportEmail"),
                termsText = o.optString("termsText"),
                privacyText = o.optString("privacyText"),
                currencies = currencies,
                specialties = decSpecs(o.optJSONArray("specialties")),
                buyerSpecialties = decSpecs(o.optJSONArray("buyerSpecialties")),
                profile = profile,
                appearance = appearance,
                messages = messages,
                printing = printing,
                appLock = lock,
                gdriveBackup = gdriveBackup,
                savedNames = o.optJSONArray("savedNames")?.let { arr ->
                    (0 until arr.length()).mapNotNull { i -> arr.optString(i)?.takeIf { it.isNotBlank() } }
                } ?: emptyList()
            )
        } catch (_: Exception) {
            AppSettings()
        }
    }
}
