package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SmartAdminDao {

    // Week Folders & Invoices
    @Query("SELECT * FROM week_folders ORDER BY sortOrder ASC, createdAt DESC")
    fun observeWeekFolders(): Flow<List<WeekFolderEntity>>

    @Query("SELECT * FROM week_folders")
    suspend fun getWeekFolders(): List<WeekFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeekFolder(entity: WeekFolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeekFolders(entities: List<WeekFolderEntity>)

    @Query("DELETE FROM week_folders WHERE id = :id")
    suspend fun deleteWeekFolder(id: String)

    @Query("SELECT * FROM folder_invoices ORDER BY initDateISO ASC, createdAt ASC")
    fun observeInvoices(): Flow<List<FolderInvoiceEntity>>

    @Query("SELECT * FROM folder_invoices")
    suspend fun getInvoices(): List<FolderInvoiceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoice(entity: FolderInvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoices(entities: List<FolderInvoiceEntity>)

    @Query("DELETE FROM folder_invoices WHERE id = :id")
    suspend fun deleteInvoice(id: String)

    @Query("DELETE FROM folder_invoices WHERE folderId = :folderId")
    suspend fun deleteInvoicesForFolder(folderId: String)

    // Weekly Filters & Details
    @Query("SELECT * FROM weekly_filters ORDER BY fromDate DESC, updatedAt DESC")
    fun observeWeeklyFilters(): Flow<List<WeeklyFilterEntity>>

    @Query("SELECT * FROM weekly_filters")
    suspend fun getWeeklyFilters(): List<WeeklyFilterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeeklyFilter(entity: WeeklyFilterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeeklyFilters(entities: List<WeeklyFilterEntity>)

    @Query("DELETE FROM weekly_filters WHERE id = :id")
    suspend fun deleteWeeklyFilter(id: String)

    @Query("SELECT * FROM detail_records ORDER BY initDateFrom DESC, updatedAt DESC")
    fun observeDetails(): Flow<List<DetailRecordEntity>>

    @Query("SELECT * FROM detail_records")
    suspend fun getDetails(): List<DetailRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDetail(entity: DetailRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDetails(entities: List<DetailRecordEntity>)

    @Query("DELETE FROM detail_records WHERE id = :id")
    suspend fun deleteDetail(id: String)

    // Clock
    @Query("SELECT * FROM clock_entries ORDER BY date DESC, sentStamp DESC")
    fun observeClockEntries(): Flow<List<ClockEntryEntity>>

    @Query("SELECT * FROM clock_entries")
    suspend fun getClockEntries(): List<ClockEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertClockEntry(entity: ClockEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertClockEntries(entities: List<ClockEntryEntity>)

    @Query("DELETE FROM clock_entries WHERE id = :id")
    suspend fun deleteClockEntry(id: String)

    @Query("DELETE FROM clock_entries WHERE srcDetailId = :detailId")
    suspend fun deleteClockEntriesForDetail(detailId: String)

    @Query("DELETE FROM clock_entries WHERE tsVoucherId = :tsVoucherId")
    suspend fun deleteClockEntriesByTsVoucher(tsVoucherId: String)

    // Debts
    @Query("SELECT * FROM debt_cashboxes ORDER BY sortOrder ASC, createdAt DESC")
    fun observeDebtCashboxes(): Flow<List<DebtCashboxEntity>>

    @Query("SELECT * FROM debt_cashboxes")
    suspend fun getDebtCashboxes(): List<DebtCashboxEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtCashbox(entity: DebtCashboxEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtCashboxes(entities: List<DebtCashboxEntity>)

    @Query("DELETE FROM debt_cashboxes WHERE id = :id")
    suspend fun deleteDebtCashbox(id: String)

    @Query("SELECT * FROM debt_accounts ORDER BY createdAt DESC")
    fun observeDebtAccounts(): Flow<List<DebtAccountEntity>>

    @Query("SELECT * FROM debt_accounts")
    suspend fun getDebtAccounts(): List<DebtAccountEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtAccount(entity: DebtAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtAccounts(entities: List<DebtAccountEntity>)

    @Query("DELETE FROM debt_accounts WHERE id = :id")
    suspend fun deleteDebtAccount(id: String)

    @Query("SELECT * FROM debt_vouchers ORDER BY date DESC, createdAt DESC")
    fun observeDebtVouchers(): Flow<List<DebtVoucherEntity>>

    @Query("SELECT * FROM debt_vouchers")
    suspend fun getDebtVouchers(): List<DebtVoucherEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtVoucher(entity: DebtVoucherEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDebtVouchers(entities: List<DebtVoucherEntity>)

    @Query("DELETE FROM debt_vouchers WHERE id = :id")
    suspend fun deleteDebtVoucher(id: String)

    // Currency Strip
    @Query("SELECT * FROM currency_receipts ORDER BY date DESC, createdAt DESC")
    fun observeCurrencyReceipts(): Flow<List<CurrencyReceiptEntity>>

    @Query("SELECT * FROM currency_receipts")
    suspend fun getCurrencyReceipts(): List<CurrencyReceiptEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCurrencyReceipt(entity: CurrencyReceiptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCurrencyReceipts(entities: List<CurrencyReceiptEntity>)

    @Query("DELETE FROM currency_receipts WHERE id = :id")
    suspend fun deleteCurrencyReceipt(id: String)

    @Query("SELECT * FROM currency_exchanges ORDER BY date DESC, createdAt DESC")
    fun observeCurrencyExchanges(): Flow<List<CurrencyExchangeEntity>>

    @Query("SELECT * FROM currency_exchanges")
    suspend fun getCurrencyExchanges(): List<CurrencyExchangeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCurrencyExchange(entity: CurrencyExchangeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCurrencyExchanges(entities: List<CurrencyExchangeEntity>)

    @Query("DELETE FROM currency_exchanges WHERE id = :id")
    suspend fun deleteCurrencyExchange(id: String)

    // Tasfeer
    @Query("SELECT * FROM ts_folders")
    fun observeTsFolders(): Flow<List<TsFolderEntity>>

    @Query("SELECT * FROM ts_folders")
    suspend fun getTsFolders(): List<TsFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsFolder(entity: TsFolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsFolders(entities: List<TsFolderEntity>)

    @Query("DELETE FROM ts_folders WHERE id = :id")
    suspend fun deleteTsFolder(id: String)

    @Query("SELECT * FROM ts_accounts")
    fun observeTsAccounts(): Flow<List<TsAccountEntity>>

    @Query("SELECT * FROM ts_accounts")
    suspend fun getTsAccounts(): List<TsAccountEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsAccount(entity: TsAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsAccounts(entities: List<TsAccountEntity>)

    @Query("DELETE FROM ts_accounts WHERE id = :id")
    suspend fun deleteTsAccount(id: String)

    @Query("SELECT * FROM ts_funds")
    fun observeTsFunds(): Flow<List<TsFundEntity>>

    @Query("SELECT * FROM ts_funds")
    suspend fun getTsFunds(): List<TsFundEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsFund(entity: TsFundEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsFunds(entities: List<TsFundEntity>)

    @Query("DELETE FROM ts_funds WHERE id = :id")
    suspend fun deleteTsFund(id: String)

    @Query("SELECT * FROM ts_vouchers ORDER BY date DESC, createdAt DESC")
    fun observeTsVouchers(): Flow<List<TsVoucherEntity>>

    @Query("SELECT * FROM ts_vouchers")
    suspend fun getTsVouchers(): List<TsVoucherEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsVoucher(entity: TsVoucherEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTsVouchers(entities: List<TsVoucherEntity>)

    @Query("DELETE FROM ts_vouchers WHERE id = :id")
    suspend fun deleteTsVoucher(id: String)

    @Query("DELETE FROM ts_vouchers WHERE accId = :accId")
    suspend fun deleteTsVouchersByAccId(accId: String)

    // Private Accounts
    @Query("SELECT * FROM private_folders ORDER BY createdAt DESC")
    fun observePrivateFolders(): Flow<List<PrivateFolderEntity>>

    @Query("SELECT * FROM private_folders")
    suspend fun getPrivateFolders(): List<PrivateFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateFolder(entity: PrivateFolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateFolders(entities: List<PrivateFolderEntity>)

    @Query("DELETE FROM private_folders WHERE id = :id")
    suspend fun deletePrivateFolder(id: String)

    @Query("SELECT * FROM private_accounts ORDER BY createdAt DESC")
    fun observePrivateAccounts(): Flow<List<PrivateAccountEntity>>

    @Query("SELECT * FROM private_accounts")
    suspend fun getPrivateAccounts(): List<PrivateAccountEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateAccount(entity: PrivateAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateAccounts(entities: List<PrivateAccountEntity>)

    @Query("DELETE FROM private_accounts WHERE id = :id")
    suspend fun deletePrivateAccount(id: String)

    @Query("SELECT * FROM private_txs ORDER BY date ASC, createdAt ASC")
    fun observePrivateTxs(): Flow<List<PrivateTxEntity>>

    @Query("SELECT * FROM private_txs")
    suspend fun getPrivateTxs(): List<PrivateTxEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateTx(entity: PrivateTxEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrivateTxs(entities: List<PrivateTxEntity>)

    @Query("DELETE FROM private_txs WHERE id = :id")
    suspend fun deletePrivateTx(id: String)

    @Query("DELETE FROM private_txs WHERE accountId = :accountId")
    suspend fun deletePrivateTxsForAccount(accountId: String)

    // Buyer
    @Query("SELECT * FROM buyer_transfers ORDER BY fromDate DESC, updatedAt DESC")
    fun observeBuyerTransfers(): Flow<List<BuyerTransferEntity>>

    @Query("SELECT * FROM buyer_transfers")
    suspend fun getBuyerTransfers(): List<BuyerTransferEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerTransfer(entity: BuyerTransferEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerTransfers(entities: List<BuyerTransferEntity>)

    @Query("DELETE FROM buyer_transfers WHERE id = :id")
    suspend fun deleteBuyerTransfer(id: String)

    @Query("SELECT * FROM buyer_annual_folders ORDER BY updatedAt DESC")
    fun observeBuyerAnnualFolders(): Flow<List<BuyerAnnualFolderEntity>>

    @Query("SELECT * FROM buyer_annual_folders")
    suspend fun getBuyerAnnualFolders(): List<BuyerAnnualFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerAnnualFolder(entity: BuyerAnnualFolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerAnnualFolders(entities: List<BuyerAnnualFolderEntity>)

    @Query("DELETE FROM buyer_annual_folders")
    suspend fun clearBuyerAnnualFolders()

    @Query("SELECT * FROM buyer_sales ORDER BY date DESC")
    fun observeBuyerSales(): Flow<List<BuyerSaleEntity>>

    @Query("SELECT * FROM buyer_sales")
    suspend fun getBuyerSales(): List<BuyerSaleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerSale(entity: BuyerSaleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerSales(entities: List<BuyerSaleEntity>)

    @Query("DELETE FROM buyer_sales WHERE id = :id")
    suspend fun deleteBuyerSale(id: String)

    @Query("DELETE FROM buyer_sales WHERE auto = 1")
    suspend fun clearAutoBuyerSales()

    @Query("SELECT * FROM buyer_profits ORDER BY date DESC")
    fun observeBuyerProfits(): Flow<List<BuyerProfitEntity>>

    @Query("SELECT * FROM buyer_profits")
    suspend fun getBuyerProfits(): List<BuyerProfitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerProfit(entity: BuyerProfitEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBuyerProfits(entities: List<BuyerProfitEntity>)

    @Query("DELETE FROM buyer_profits WHERE id = :id")
    suspend fun deleteBuyerProfit(id: String)

    @Query("DELETE FROM buyer_profits WHERE autoProfit = 1")
    suspend fun clearAutoBuyerProfits()

    // Trash
    @Query("SELECT * FROM trash_items ORDER BY deletedAt DESC")
    fun observeTrash(): Flow<List<TrashItemEntity>>

    @Query("SELECT * FROM trash_items")
    suspend fun getTrash(): List<TrashItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrash(entity: TrashItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrashAll(entities: List<TrashItemEntity>)

    @Query("DELETE FROM trash_items WHERE id = :id")
    suspend fun deleteTrash(id: String)

    @Query("DELETE FROM trash_items")
    suspend fun emptyTrash()

    // Full clear for restore / reset
    @Query("DELETE FROM week_folders") suspend fun clearWeekFolders()
    @Query("DELETE FROM folder_invoices") suspend fun clearInvoices()
    @Query("DELETE FROM weekly_filters") suspend fun clearWeeklyFilters()
    @Query("DELETE FROM detail_records") suspend fun clearDetails()
    @Query("DELETE FROM clock_entries") suspend fun clearClockEntries()
    @Query("DELETE FROM debt_cashboxes") suspend fun clearDebtCashboxes()
    @Query("DELETE FROM debt_accounts") suspend fun clearDebtAccounts()
    @Query("DELETE FROM debt_vouchers") suspend fun clearDebtVouchers()
    @Query("DELETE FROM currency_receipts") suspend fun clearCurrencyReceipts()
    @Query("DELETE FROM currency_exchanges") suspend fun clearCurrencyExchanges()
    @Query("DELETE FROM ts_folders") suspend fun clearTsFolders()
    @Query("DELETE FROM ts_accounts") suspend fun clearTsAccounts()
    @Query("DELETE FROM ts_funds") suspend fun clearTsFunds()
    @Query("DELETE FROM ts_vouchers") suspend fun clearTsVouchers()
    @Query("DELETE FROM private_folders") suspend fun clearPrivateFolders()
    @Query("DELETE FROM private_accounts") suspend fun clearPrivateAccounts()
    @Query("DELETE FROM private_txs") suspend fun clearPrivateTxs()
    @Query("DELETE FROM buyer_transfers") suspend fun clearBuyerTransfers()
    @Query("DELETE FROM buyer_sales") suspend fun clearBuyerSales()
    @Query("DELETE FROM buyer_profits") suspend fun clearBuyerProfits()
}
