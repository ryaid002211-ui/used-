package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "week_folders")
data class WeekFolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val imagePath: String,
    val note: String,
    val sortOrder: Int,
    val scope: String,
    val startDate: String,
    val endDate: String,
    val specialtyId: String,
    val locked: Boolean,
    val createdAt: Long
)

@Entity(tableName = "folder_invoices")
data class FolderInvoiceEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val invoiceKind: String,
    val initDate: String,
    val initDateISO: String,
    val initSeller: String,
    val initPlace: String,
    val initWeeklyFilter: String,
    val initNo: String,
    val note: String,
    val specialtyId: String,
    val sellerPhotoPath: String,
    val invoicePaperPhotoPath: String,
    val formDataJson: String,
    val buyerRowsJson: String,
    val buyerTotal: Double,
    val buyerExpense: Double,
    val buyerNet: Double,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "weekly_filters")
data class WeeklyFilterEntity(
    @PrimaryKey val id: String,
    val name: String,
    val fromDate: String,
    val toDate: String,
    val sourceFolderId: String,
    val specialtyId: String,
    val payloadJson: String,
    val updatedAt: Long
)

@Entity(tableName = "detail_records")
data class DetailRecordEntity(
    @PrimaryKey val id: String,
    val autoFilterId: String,
    val sourceFolderId: String,
    val specialtyId: String,
    val initDetail: String,
    val initDateFrom: String,
    val initDateTo: String,
    val initNo: String,
    val initFilter: String,
    val note: String,
    val formDataJson: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "clock_entries")
data class ClockEntryEntity(
    @PrimaryKey val id: String,
    val section: String,
    val srcDetailId: String,
    val specialtyId: String,
    val dir: String,
    val amount: Double,
    val name: String,
    val date: String,
    val time: String,
    val fromDate: String,
    val toDate: String,
    val note: String,
    val days: Int,
    val qty: Double,
    val cur: String,
    val curAmount: Double,
    val curRate: Double,
    val kind: String,
    val subRowsJson: String,
    val rowsJson: String,
    val img: String,
    val tsVoucherId: String,
    val tsKind: String,
    val auto: Boolean,
    val sentStamp: Long
)

@Entity(tableName = "debt_cashboxes")
data class DebtCashboxEntity(
    @PrimaryKey val id: String,
    val name: String,
    val imagePath: String,
    val note: String,
    val sortOrder: Int,
    val locked: Boolean,
    val createdAt: Long
)

@Entity(tableName = "debt_accounts")
data class DebtAccountEntity(
    @PrimaryKey val id: String,
    val cashboxId: String,
    val name: String,
    val phone: String,
    val limitEnabled: Boolean,
    val limitAmount: Double,
    val messageSend: String,
    val createdAt: Long
)

@Entity(tableName = "debt_vouchers")
data class DebtVoucherEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val specialtyId: String,
    val type: String,
    val amount: Double,
    val currency: String,
    val note: String,
    val date: String,
    val time: String,
    val imagePath: String,
    val autoSourceKey: String,
    val createdAt: Long
)

@Entity(tableName = "currency_receipts")
data class CurrencyReceiptEntity(
    @PrimaryKey val id: String,
    val fromFundId: String,
    val toAccountId: String,
    val toAccountName: String,
    val currency: String,
    val amount: Double,
    val rate: Double,
    val fee: Double,
    val date: String,
    val note: String,
    val createdAt: Long
)

@Entity(tableName = "currency_exchanges")
data class CurrencyExchangeEntity(
    @PrimaryKey val id: String,
    val fromCurrency: String,
    val fromAmount: Double,
    val toCurrency: String,
    val rate: Double,
    val toAmount: Double,
    val date: String,
    val note: String,
    val createdAt: Long
)

@Entity(tableName = "ts_folders")
data class TsFolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val parentId: String,
    val img: String,
    val sortOrder: Int
)

@Entity(tableName = "ts_accounts")
data class TsAccountEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val name: String,
    val phone: String,
    val img: String,
    val limitAmount: Double
)

@Entity(tableName = "ts_funds")
data class TsFundEntity(
    @PrimaryKey val id: String,
    val name: String,
    val img: String,
    val sortOrder: Int
)

@Entity(tableName = "ts_vouchers")
data class TsVoucherEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val dir: String,
    val date: String,
    val time: String,
    val accId: String,
    val fundId: String,
    val fromFundId: String,
    val toFundId: String,
    val note: String,
    val img: String,
    val cur: String,
    val amount: Double,
    val rate: Double,
    val rowsJson: String,
    val fromCur: String,
    val fromAmt: Double,
    val toCur: String,
    val toAmt: Double,
    val sender: String,
    val receiver: String,
    val dest: String,
    val transferNo: String,
    val com: Double,
    val comCur: String,
    val pg: String,
    val specialtyId: String,
    val srcClockId: String,
    val createdAt: Long
)

@Entity(tableName = "private_folders")
data class PrivateFolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val img: String,
    val createdAt: Long
)

@Entity(tableName = "private_accounts")
data class PrivateAccountEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val name: String,
    val phone: String,
    val cap: Double,
    val send: String,
    val img: String,
    val createdAt: Long
)

@Entity(tableName = "private_txs")
data class PrivateTxEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val currency: String,
    val date: String,
    val time: String,
    val amount: Double,
    val type: String,
    val linesJson: String,
    val img: String,
    val xfer: Boolean,
    val createdAt: Long
)

@Entity(tableName = "buyer_transfers")
data class BuyerTransferEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val specialtyId: String,
    val name: String,
    val fromDate: String,
    val toDate: String,
    val rowsJson: String,
    val oldPrice: Double,
    val newPrice: Double,
    val rentRada: Double,
    val rentShip: Double,
    val weeklySale: Double,
    val habbaCount: Double,
    val diffAccountName: String,
    val diffNote: String,
    val updatedAt: Long
)

@Entity(tableName = "buyer_annual_folders")
data class BuyerAnnualFolderEntity(
    @PrimaryKey val id: String,
    val specialtyId: String,
    val name: String,
    val rowsJson: String,
    val updatedAt: Long
)

@Entity(tableName = "buyer_sales")
data class BuyerSaleEntity(
    @PrimaryKey val id: String,
    val dir: String,
    val date: String,
    val fromDate: String,
    val toDate: String,
    val amount: Double,
    val qty: Double,
    val unitPrice: Double,
    val specialtyId: String,
    val note: String,
    val sender: String,
    val receiver: String,
    val refNo: String,
    val entity: String,
    val commission: Double,
    val curMapJson: String,
    val img: String,
    val auto: Boolean,
    val autoKey: String
)

@Entity(tableName = "buyer_profits")
data class BuyerProfitEntity(
    @PrimaryKey val id: String,
    val target: String,
    val type: String,
    val kind: String,
    val date: String,
    val fromDate: String,
    val toDate: String,
    val amount: Double,
    val specialtyId: String,
    val note: String,
    val autoProfit: Boolean,
    val autoKey: String
)

@Entity(tableName = "trash_items")
data class TrashItemEntity(
    @PrimaryKey val id: String,
    val type: String,
    val name: String,
    val parentId: String,
    val payloadJson: String,
    val deletedAt: String
)
