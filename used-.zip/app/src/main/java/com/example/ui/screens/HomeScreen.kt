package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.SmartAdminUiState
import kotlin.math.abs

@Composable
fun HomeScreen(
    uiState: SmartAdminUiState,
    onOpenDrawer: () -> Unit,
    onToggleLang: () -> Unit,
    onToggleDark: () -> Unit,
    onSelectSpecialty: (String) -> Unit,
    onAddSpecialty: ((String, Double) -> Unit)? = null,
    onOpenClockSection: (ClockSection) -> Unit,
    onOpenTasfeer: () -> Unit,
    onOpenFolders: () -> Unit,
    onOpenWeeklyFilters: () -> Unit,
    onOpenDetails: () -> Unit,
    onOpenDebtCashboxes: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val settings = uiState.settings
    val snap = uiState.snapshot

    val filteredClock = remember(snap.clockEntries, settings.activeSpecialty) {
        when (settings.activeSpecialty) {
            "all", "" -> snap.clockEntries
            "none" -> snap.clockEntries.filter { it.specialtyId.isBlank() }
            else -> snap.clockEntries.filter { it.specialtyId == settings.activeSpecialty }
        }
    }

    val saleNet = remember(filteredClock) { ClockCalculator.sectionTotal(filteredClock, ClockSection.SALE) }
    val workersNet = remember(filteredClock) { ClockCalculator.sectionTotal(filteredClock, ClockSection.WORKERS) }
    val withdrawNet = remember(filteredClock) { ClockCalculator.sectionTotal(filteredClock, ClockSection.WITHDRAW) }
    val debtsNet = remember(filteredClock) { ClockCalculator.sectionTotal(filteredClock, ClockSection.DEBTS) }
    val currencyNet = remember(filteredClock) { ClockCalculator.sectionTotal(filteredClock, ClockSection.CURRENCY) }
    val gapSummary = uiState.tasfeerState.gapSummary
    val brandTitle = settings.profile.nameAr.ifBlank { strings.appTitle }

    Column(modifier = Modifier.fillMaxSize()) {
        LuxuryMainTopBar(
            title = brandTitle,
            onMenuClick = onOpenDrawer,
            menuTestTag = "drawer_menu_button",
            secondaryIcon = if (settings.dark) Icons.Default.LightMode else Icons.Default.DarkMode,
            secondaryDesc = "Theme",
            secondaryTestTag = "toggle_dark_btn",
            onSecondaryClick = onToggleDark,
            extraActions = {
                LuxuryHeaderIconBtn(
                    icon = Icons.Default.Translate,
                    contentDescription = "Language",
                    onClick = onToggleLang,
                    tint = tokens.barContent,
                    testTag = "toggle_lang_btn"
                )
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top 3 Dark Luxury Shortcut Tiles matching admin.html
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LuxuryDarkQuickTile(
                    icon = Icons.Default.ReceiptLong,
                    label = strings.invoices,
                    badgeTint = Color(0xFF0284C7),
                    badgeText = "${snap.weekFolders.count { it.scope == FolderScope.HOME }}",
                    onClick = onOpenFolders,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_invoices_btn")
                )
                LuxuryDarkQuickTile(
                    icon = Icons.Default.CalendarMonth,
                    label = strings.weeklyFilter,
                    badgeTint = Color(0xFFDC2626),
                    badgeText = "${snap.weeklyFilters.size}",
                    onClick = onOpenWeeklyFilters,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_weekly_btn")
                )
                LuxuryDarkQuickTile(
                    icon = Icons.Default.Settings,
                    label = strings.detail,
                    badgeTint = Color(0xFF475569),
                    badgeText = "${snap.details.size}",
                    onClick = onOpenDetails,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_detail_btn")
                )
            }

            // Specialty Bar + Quick Cashboxes action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LuxurySpecialtyHeaderBar(
                    specialties = settings.specialties,
                    selectedId = settings.activeSpecialty,
                    onSelect = onSelectSpecialty,
                    onAddSpecialty = { name, amt -> onAddSpecialty?.invoke(name, amt) },
                    showWorkersAmount = true,
                    showManageButton = false,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    onClick = onOpenDebtCashboxes,
                    shape = RoundedCornerShape(tokens.cornerRadius),
                    color = Color.Transparent,
                    border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(tokens.borderWidth.coerceAtLeast(1.dp), tokens.borderColor) else null,
                    modifier = Modifier
                        .heightIn(min = 52.dp)
                        .testTag("home_debt_cashboxes_btn")
                ) {
                    Row(
                        modifier = Modifier
                            .background(tokens.darkTileBrush)
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = tokens.barAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.t("الصناديق", "Cashboxes"),
                            color = tokens.darkTileContent,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // المراقب Container Box matching #homeClock / #buyerClock
            Surface(
                shape = RoundedCornerShape(tokens.cornerRadius),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = strings.clockTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    val clockCards = listOf(
                        ClockCardSpec(
                            title = strings.finalSale,
                            value = fmt(abs(saleNet)),
                            badge = if (saleNet >= 0) strings.credit else strings.debit,
                            isCredit = saleNet >= 0,
                            icon = Icons.Default.PointOfSale,
                            tag = "clock_card_sale",
                            onClick = { onOpenClockSection(ClockSection.SALE) }
                        ),
                        ClockCardSpec(
                            title = strings.workersOut,
                            value = fmt(abs(workersNet)),
                            badge = if (workersNet >= 0) strings.credit else strings.debit,
                            isCredit = workersNet >= 0,
                            icon = Icons.Default.Engineering,
                            tag = "clock_card_workers",
                            onClick = { onOpenClockSection(ClockSection.WORKERS) }
                        ),
                        ClockCardSpec(
                            title = strings.withdrawals,
                            value = fmt(abs(withdrawNet)),
                            badge = if (withdrawNet >= 0) strings.credit else strings.debit,
                            isCredit = withdrawNet >= 0,
                            icon = Icons.Default.Payments,
                            tag = "clock_card_withdraw",
                            onClick = { onOpenClockSection(ClockSection.WITHDRAW) }
                        ),
                        ClockCardSpec(
                            title = strings.debts,
                            value = fmt(abs(debtsNet)),
                            badge = if (debtsNet >= 0) strings.credit else strings.debit,
                            isCredit = debtsNet >= 0,
                            icon = Icons.AutoMirrored.Filled.ReceiptLong,
                            tag = "clock_card_debts",
                            onClick = { onOpenClockSection(ClockSection.DEBTS) }
                        ),
                        ClockCardSpec(
                            title = strings.currencies,
                            value = fmt(abs(currencyNet)),
                            badge = if (currencyNet >= 0) strings.credit else strings.debit,
                            isCredit = currencyNet >= 0,
                            icon = Icons.Default.CurrencyExchange,
                            tag = "clock_card_currency",
                            onClick = { onOpenClockSection(ClockSection.CURRENCY) }
                        ),
                        ClockCardSpec(
                            title = strings.tasfeer,
                            value = fmt(abs(gapSummary.gap)),
                            badge = when (gapSummary.side) {
                                "acc" -> strings.t("للمحاسبين", "Accounts")
                                "fund" -> strings.t("للموردين", "Suppliers")
                                else -> strings.matching
                            },
                            isCredit = gapSummary.side != "acc",
                            icon = Icons.Default.AccountBalance,
                            tag = "clock_card_tasfeer",
                            onClick = onOpenTasfeer
                        )
                    )

                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val cols = if (maxWidth > 480.dp) 3 else 2
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            clockCards.chunked(cols).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowItems.forEach { card ->
                                        ClockSummaryCard(
                                            spec = card,
                                            isDark = settings.dark,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (rowItems.size < cols) {
                                        repeat(cols - rowItems.size) {
                                            Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Treasury Snapshot Card
            Surface(
                onClick = onOpenTasfeer,
                shape = RoundedCornerShape(tokens.cornerRadius),
                color = Color.Transparent,
                border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(tokens.borderWidth.coerceAtLeast(1.dp), tokens.borderColor) else null,
                shadowElevation = tokens.elevation,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.cardBrush)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.t("ملخص الخزينة والديون", "Treasury & Debts Snapshot"),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = strings.t(
                                "الحسابات: ${fmt(gapSummary.accountsTotal)} • الصناديق: ${fmt(gapSummary.fundsTotal)}",
                                "Accounts: ${fmt(gapSummary.accountsTotal)} • Funds: ${fmt(gapSummary.fundsTotal)}"
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        Icons.Default.ArrowOutward,
                        contentDescription = strings.tasfeer,
                        tint = tokens.iconTileTint
                    )
                }
            }
        }
    }
}

private data class ClockCardSpec(
    val title: String,
    val value: String,
    val badge: String,
    val isCredit: Boolean,
    val icon: ImageVector,
    val tag: String,
    val onClick: () -> Unit
)

@Composable
private fun ClockSummaryCard(
    spec: ClockCardSpec,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    val valueColor = when {
        spec.badge == "متطابق" || spec.badge == "Matched" -> MaterialTheme.colorScheme.onSurface
        spec.isCredit && isDark -> AppColors.CreditGreenDark
        spec.isCredit -> AppColors.CreditGreen
        isDark -> AppColors.DebitRedDark
        else -> AppColors.DebitRed
    }

    Surface(
        onClick = spec.onClick,
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(tokens.borderWidth.coerceAtLeast(1.dp), tokens.borderColor) else null,
        shadowElevation = tokens.elevation,
        modifier = modifier
            .heightIn(min = 104.dp)
            .testTag(spec.tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.cardBrush)
                .padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = spec.title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = spec.value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = valueColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = spec.badge,
                style = MaterialTheme.typography.labelSmall,
                color = valueColor,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}
