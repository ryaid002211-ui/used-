package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

private val TsDarkHeader = Color(0xFF0B0D12)
private val TsCreamBg = Color(0xFFFAF6EC)
private val TsGoldBorder = Color(0xFFC5B17E)

@Composable
internal fun TsModalShell(
    title: String,
    onDismiss: () -> Unit,
    confirmLabel: String? = null,
    onConfirm: (() -> Unit)? = null,
    cancelLabel: String = "إلغاء",
    testTag: String = "ts_modal_dialog",
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .widthIn(max = 560.dp)
                .heightIn(max = 760.dp)
                .testTag(testTag),
            shape = RoundedCornerShape(18.dp),
            color = TsCreamBg,
            border = BorderStroke(1.5.dp, TsGoldBorder),
            shadowElevation = 12.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Black luxury modal header matching screenshots
                Surface(color = TsDarkHeader, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1F242D),
                            border = BorderStroke(1.dp, TsGoldBorder.copy(alpha = 0.6f)),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = cancelLabel,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = content
                )

                HorizontalDivider(color = TsGoldBorder.copy(alpha = 0.4f))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (onConfirm != null && confirmLabel != null) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFECEAE2),
                                contentColor = Color(0xFF334155)
                            ),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Text(cancelLabel, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onConfirm,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0B0D12),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Text(confirmLabel, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0B0D12),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun TsDateAndPhotoHeader(
    date: String,
    onDateChange: (String) -> Unit,
    imgPath: String,
    onImgPicked: (String) -> Unit,
    viewModel: SmartAdminViewModel
) {
    val strings = LocalAppStrings.current
    var showPicker by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { onImgPicked(it) }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Dashed Photo box
        Surface(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFFDF2F4),
            border = BorderStroke(1.5.dp, Color(0xFFD8B4B8)),
            modifier = Modifier.size(72.dp)
        ) {
            if (imgPath.isNotBlank() && File(imgPath).exists()) {
                Image(
                    painter = rememberAsyncImagePainter(File(imgPath)),
                    contentDescription = strings.t("صورة السند", "Voucher Photo"),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.PhotoCamera,
                        contentDescription = strings.t("صورة", "Photo"),
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        strings.t("صورة", "Photo"),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                strings.date,
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF475569),
                fontWeight = FontWeight.Bold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    onClick = { showPicker = true },
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, TsGoldBorder),
                    modifier = Modifier.heightIn(min = 44.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = strings.date,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = DateHelper.displaySlash(date),
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    if (showPicker) {
        IsoDatePickerDialog(
            initialIso = date,
            onPicked = { onDateChange(it); showPicker = false },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
internal fun TsDropdownField(
    label: String,
    selectedText: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF334155),
            fontWeight = FontWeight.Bold
        )
        Box {
            Surface(
                onClick = { expanded = true },
                shape = RoundedCornerShape(10.dp),
                color = Color.White,
                border = BorderStroke(1.2.dp, TsGoldBorder),
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = selectedText,
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF334155))
                }
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { (id, text) ->
                    DropdownMenuItem(
                        text = { Text(text, fontWeight = FontWeight.Bold) },
                        onClick = { onSelect(id); expanded = false }
                    )
                }
            }
        }
    }
}

@Composable
internal fun TsDirectionToggleRow(
    dir: String,
    onDirChange: (String) -> Unit,
    inLabel: String,
    outLabel: String
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val inSelected = dir != "out"
        Surface(
            onClick = { onDirChange("in") },
            shape = RoundedCornerShape(12.dp),
            color = if (inSelected) Color(0xFFDCFCE7) else Color.White,
            border = BorderStroke(1.5.dp, if (inSelected) Color(0xFF16A34A) else Color(0xFFCBD5E1)),
            modifier = Modifier.weight(1f).heightIn(min = 52.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                RadioButton(selected = inSelected, onClick = null)
                Spacer(Modifier.width(4.dp))
                Text(inLabel, color = Color(0xFF14532D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
        Surface(
            onClick = { onDirChange("out") },
            shape = RoundedCornerShape(12.dp),
            color = if (!inSelected) Color(0xFFFEE2E2) else Color.White,
            border = BorderStroke(1.5.dp, if (!inSelected) Color(0xFFDC2626) else Color(0xFFCBD5E1)),
            modifier = Modifier.weight(1f).heightIn(min = 52.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                RadioButton(selected = !inSelected, onClick = null)
                Spacer(Modifier.width(4.dp))
                Text(outLabel, color = Color(0xFF7F1D1D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
internal fun TsCurrencyRowsTable(
    currencies: List<AppCurrency>,
    amountsMap: MutableMap<String, String>,
    ratesMap: MutableMap<String, String>,
    rateHeaderLabel: String,
    rateFixedMode: String? = null // "buy", "sell", or null (editable)
) {
    var activeCur by remember { mutableStateOf(currencies.firstOrNull()?.name ?: "") }
    val strings = LocalAppStrings.current

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Quick Currency Buttons Strip containing ALL currencies
        if (currencies.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                currencies.forEach { c ->
                    val hasAmt = num(amountsMap[c.name] ?: "") > 0.0
                    val isActive = activeCur == c.name
                    Surface(
                        onClick = { activeCur = c.name },
                        shape = RoundedCornerShape(50),
                        color = when {
                            hasAmt -> Color(0xFFDCFCE7)
                            isActive -> TsDarkHeader
                            else -> Color.White
                        },
                        border = BorderStroke(
                            1.dp,
                            when {
                                hasAmt -> Color(0xFF16A34A)
                                isActive -> TsGoldBorder
                                else -> TsGoldBorder.copy(alpha = 0.7f)
                            }
                        ),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Text(
                            text = if (c.symbol.isNotBlank() && c.symbol != c.name) "${c.name} (${c.symbol})" else c.name,
                            color = when {
                                hasAmt -> Color(0xFF14532D)
                                isActive -> Color.White
                                else -> Color(0xFF0F172A)
                            },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // All Currencies Input Table
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White,
            border = BorderStroke(1.dp, TsGoldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth().background(TsDarkHeader).padding(vertical = 8.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        strings.t("العملة", "Currency"),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.9f),
                        fontSize = 12.sp
                    )
                    Text(
                        strings.amount,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1.6f),
                        fontSize = 12.sp
                    )
                    Text(
                        rateHeaderLabel,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                        fontSize = 12.sp
                    )
                }

                currencies.forEachIndexed { idx, c ->
                    if (idx > 0) HorizontalDivider(color = Color(0xFFE2E8F0))
                    val symLabel = c.symbol.ifBlank { c.name }
                    val amtText = amountsMap[c.name] ?: ""
                    val rateText = ratesMap[c.name] ?: when (rateFixedMode) {
                        "buy" -> rawNumberString(if (c.buyRate > 0.0) c.buyRate else 1.0)
                        "sell" -> rawNumberString(if (c.sellRate > 0.0) c.sellRate else 1.0)
                        else -> "1"
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (activeCur == c.name) Color(0xFFFFFBEB) else Color.White)
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = symLabel,
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(0.9f)
                        )
                        WesternNumberField(
                            value = amtText,
                            onValueChange = { amountsMap[c.name] = it; activeCur = c.name },
                            label = "",
                            modifier = Modifier.weight(1.6f)
                        )
                        if (rateFixedMode != null) {
                            Text(
                                text = rateText,
                                color = Color(0xFF0F172A),
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            WesternNumberField(
                                value = rateText,
                                onValueChange = { ratesMap[c.name] = it },
                                label = "",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun collectTsRows(
    currencies: List<AppCurrency>,
    amountsMap: Map<String, String>,
    ratesMap: Map<String, String>,
    rateFixedMode: String?
): List<TsRowCurrency> {
    return currencies.mapNotNull { c ->
        val a = num(amountsMap[c.name] ?: "")
        if (a <= 0.0) null
        else {
            val r = when (rateFixedMode) {
                "buy" -> if (c.buyRate > 0.0) c.buyRate else 1.0
                "sell" -> if (c.sellRate > 0.0) c.sellRate else 1.0
                else -> num(ratesMap[c.name] ?: "").let { if (it > 0.0) it else 1.0 }
            }
            TsRowCurrency(cur = c.name, a = a, r = r)
        }
    }
}

@Composable
internal fun TsFxPreviewBox(diff: Double) {
    val color = when {
        diff > 0.005 -> AppColors.CreditGreen
        diff < -0.005 -> AppColors.DebitRed
        else -> Color(0xFF64748B)
    }
    val txt = when {
        diff > 0.005 -> "ربح ${fmt(abs(diff))}"
        diff < -0.005 -> "خسارة ${fmt(abs(diff))}"
        else -> "0"
    }
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.White,
        border = BorderStroke(1.dp, TsGoldBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("فارق الصرف المتوقع", fontWeight = FontWeight.Bold, color = Color(0xFF334155))
            Text(txt, fontWeight = FontWeight.Black, color = color)
        }
    }
}

@Composable
fun TsCurrenciesToFundsDialog(
    initialFundId: String? = null,
    titleOverride: String? = null,
    existing: TsVoucher? = null,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val currencies = uiState.settings.currencies
    val specialties = uiState.settings.specialties

    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var fundId by remember { mutableStateOf(existing?.fundId?.ifBlank { null } ?: initialFundId ?: snap.tsFunds.firstOrNull()?.id ?: "") }
    var specialtyId by remember { mutableStateOf(existing?.specialtyId ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var dir by remember { mutableStateOf(existing?.dir?.ifBlank { "in" } ?: "in") }
    var errMsg by remember { mutableStateOf("") }

    val amountsMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            existing?.rows?.forEach { put(it.cur, rawNumberString(it.a)) }
        }
    }
    val ratesMap = remember(existing?.id, dir) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { c ->
                val exRate = existing?.rows?.firstOrNull { it.cur == c.name }?.r
                val r = exRate ?: if (dir == "out") c.sellRate else c.buyRate
                put(c.name, rawNumberString(if (r > 0.0) r else 1.0))
            }
        }
    }

    val rateMode = if (dir == "out") "sell" else "buy"
    val previewRows = collectTsRows(currencies, amountsMap, ratesMap, if (existing != null) null else rateMode)
    val totalSum = previewRows.sumOf { it.a * it.r }
    val expectedFx = remember(previewRows, fundId, dir) {
        if (dir == "out" && previewRows.isNotEmpty()) {
            TasfeerFxEngine.previewExpectedFxDiff(
                existingVouchers = snap.tsVouchers,
                funds = snap.tsFunds,
                currencies = currencies,
                kind = "receipt",
                fundId = fundId,
                rows = previewRows,
                editingVoucherId = existing?.id
            )
        } else 0.0
    }

    TsModalShell(
        title = titleOverride ?: if (existing != null) "تعديل سند قبض من العملات" else "سند قبض من العملات إلى الصناديق",
        confirmLabel = if (existing != null) "حفظ التعديل" else "حفظ",
        onDismiss = onDismiss,
        testTag = "ts_receipt_dialog",
        onConfirm = {
            if (fundId.isBlank()) {
                errMsg = "أضف صندوقاً أولاً"
                return@TsModalShell
            }
            if (previewRows.isEmpty()) {
                errMsg = "أدخل مبلغ عملة واحدة على الأقل"
                return@TsModalShell
            }
            val voucher = (existing ?: TsVoucher(
                kind = "receipt",
                time = DateHelper.nowTime()
            )).copy(
                kind = "receipt",
                dir = dir,
                date = date,
                fundId = fundId,
                specialtyId = specialtyId,
                note = note.trim(),
                img = imgPath,
                rows = previewRows,
                cur = previewRows.first().cur,
                amount = previewRows.first().a,
                rate = previewRows.first().r
            )
            val err = viewModel.saveTsVoucherWithValidation(voucher) { onDismiss() }
            if (err != null) errMsg = err
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        TsDropdownField(
            label = "الصندوق",
            selectedText = snap.tsFunds.firstOrNull { it.id == fundId }?.name ?: "اختر الصندوق",
            options = snap.tsFunds.map { it.id to it.name },
            onSelect = { fundId = it }
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsDropdownField(
                label = "اختار التخصيص للعملات",
                selectedText = specialties.firstOrNull { it.id == specialtyId }?.name ?: "بدون تخصيص",
                options = listOf("" to "بدون تخصيص") + specialties.map { it.id to it.name },
                onSelect = { specialtyId = it },
                modifier = Modifier.weight(1f)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("البيان", style = MaterialTheme.typography.labelMedium, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    placeholder = { Text("البيان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        TsCurrencyRowsTable(
            currencies = currencies,
            amountsMap = amountsMap,
            ratesMap = ratesMap,
            rateHeaderLabel = if (dir == "out") "سعر البيع" else "سعر الشراء",
            rateFixedMode = if (existing != null) null else rateMode
        )

        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White,
            border = BorderStroke(1.dp, TsGoldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(if (dir == "out") "اجمالي ناتج الصرف" else "اجمالي ناتج القبض", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                Text(fmt(totalSum), fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
            }
        }

        if (dir == "out" && previewRows.isNotEmpty()) {
            TsFxPreviewBox(expectedFx)
        }

        TsDirectionToggleRow(
            dir = dir,
            onDirChange = { dir = it },
            inLabel = "💚 لكم – استلام",
            outLabel = "❤️ عليكم – إرسال"
        )

        if (errMsg.isNotBlank()) {
            Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TsClockToAccountDialog(
    existing: TsVoucher? = null,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val specialties = uiState.settings.specialties
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val pages = listOf("جملة البيع النهائية", "خرج العمال", "السحب", "الديون", "العملات")

    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var pg by remember { mutableStateOf(existing?.pg?.ifBlank { pages.first() } ?: pages.first()) }
    var specialtyId by remember { mutableStateOf(existing?.specialtyId ?: "") }
    var accId by remember { mutableStateOf(existing?.accId ?: "") }
    var newAccName by remember { mutableStateOf("") }
    var amtStr by remember {
        mutableStateOf(
            if (existing != null) rawNumberString(TasfeerFxEngine.voucherTotalBase(existing, baseCur)) else ""
        )
    }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var dir by remember { mutableStateOf(existing?.dir?.ifBlank { "in" } ?: "in") }
    var errMsg by remember { mutableStateOf("") }

    TsModalShell(
        title = if (existing != null) "تعديل سند المراقب إلى الحسابات" else "سند قبض من صفحات المراقب إلى الحسابات",
        confirmLabel = if (existing != null) "حفظ التعديل" else "حفظ",
        onDismiss = onDismiss,
        testTag = "ts_clockacc_dialog",
        onConfirm = {
            val a = num(amtStr)
            if (a <= 0.0) {
                errMsg = "أدخل المبلغ"
                return@TsModalShell
            }
            if (accId.isBlank()) {
                errMsg = "اختر الحساب"
                return@TsModalShell
            }
            if (accId == "__new" && newAccName.isBlank()) {
                errMsg = "أدخل اسم الحساب الجديد"
                return@TsModalShell
            }
            val row = TsRowCurrency(cur = baseCur, a = a, r = 1.0)
            val voucher = (existing ?: TsVoucher(
                kind = "clockacc",
                time = DateHelper.nowTime()
            )).copy(
                kind = "clockacc",
                dir = dir,
                date = date,
                accId = if (accId == "__new") "" else accId,
                pg = pg,
                specialtyId = specialtyId,
                note = note.trim(),
                img = imgPath,
                rows = listOf(row),
                cur = baseCur,
                amount = a,
                rate = 1.0
            )
            val err = viewModel.saveTsVoucherWithValidation(
                v = voucher,
                newAccountName = if (accId == "__new") newAccName.trim() else ""
            ) { onDismiss() }
            if (err != null) errMsg = err
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsDropdownField(
                label = "اختار التخصيص للصفحه",
                selectedText = specialties.firstOrNull { it.id == specialtyId }?.name ?: "بدون تخصيص",
                options = listOf("" to "بدون تخصيص") + specialties.map { it.id to it.name },
                onSelect = { specialtyId = it },
                modifier = Modifier.weight(1f)
            )
            TsDropdownField(
                label = "صفحات المراقب",
                selectedText = pg,
                options = pages.map { it to it },
                onSelect = { pg = it },
                modifier = Modifier.weight(1f)
            )
        }

        val accLabel = when (accId) {
            "" -> "اختر الحساب"
            "__new" -> "＋ حساب جديد..."
            else -> snap.tsAccounts.firstOrNull { it.id == accId }?.name ?: "اختر الحساب"
        }
        TsDropdownField(
            label = "الحساب",
            selectedText = accLabel,
            options = snap.tsAccounts.map { it.id to it.name } + ("__new" to "＋ حساب جديد..."),
            onSelect = { accId = it }
        )

        if (accId == "__new") {
            NameSuggestTextField(
                value = newAccName,
                onValueChange = { newAccName = it },
                label = "اسم الحساب الجديد",
                modifier = Modifier.fillMaxWidth()
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("المبلغ الإجمالي", style = MaterialTheme.typography.labelMedium, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
            WesternNumberField(
                value = amtStr,
                onValueChange = { amtStr = it },
                label = "",
                modifier = Modifier.fillMaxWidth()
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("البيان", style = MaterialTheme.typography.labelMedium, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        TsDirectionToggleRow(
            dir = dir,
            onDirChange = { dir = it },
            inLabel = "💚 لكم – قيد للحساب",
            outLabel = "❤️ عليكم – قيد على الحساب"
        )

        if (errMsg.isNotBlank()) {
            Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TsInternalTransferDialog(
    initialFundId: String? = null,
    existing: TsVoucher? = null,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val currencies = uiState.settings.currencies

    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var fundId by remember { mutableStateOf(existing?.fromFundId?.ifBlank { null } ?: initialFundId ?: snap.tsFunds.firstOrNull()?.id ?: "") }
    var accId by remember { mutableStateOf(existing?.accId ?: "") }
    var newAccName by remember { mutableStateOf("") }
    var sender by remember { mutableStateOf(existing?.sender ?: "") }
    var receiver by remember { mutableStateOf(existing?.receiver ?: "") }
    var transferNo by remember { mutableStateOf(existing?.transferNo ?: "") }
    var dest by remember { mutableStateOf(existing?.dest ?: "") }
    var comStr by remember { mutableStateOf(if (existing != null && existing.com > 0.0) rawNumberString(existing.com) else "") }
    var errMsg by remember { mutableStateOf("") }

    val amountsMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            existing?.rows?.forEach { put(it.cur, rawNumberString(it.a)) }
        }
    }
    val ratesMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { c ->
                val exRate = existing?.rows?.firstOrNull { it.cur == c.name }?.r
                val r = exRate ?: c.sellRate
                put(c.name, rawNumberString(if (r > 0.0) r else 1.0))
            }
        }
    }

    val previewRows = collectTsRows(currencies, amountsMap, ratesMap, if (existing != null) null else "sell")
    val comVal = num(comStr).coerceAtLeast(0.0)
    val totalWithCom = previewRows.sumOf { it.a * it.r } + comVal
    val expectedFx = remember(previewRows, fundId) {
        if (previewRows.isNotEmpty()) {
            TasfeerFxEngine.previewExpectedFxDiff(
                existingVouchers = snap.tsVouchers,
                funds = snap.tsFunds,
                currencies = currencies,
                kind = "internal",
                fundId = fundId,
                rows = previewRows,
                editingVoucherId = existing?.id
            )
        } else 0.0
    }

    TsModalShell(
        title = if (existing != null) "تعديل الحوالة الداخلية" else "سند إرسال واستلام حوالة داخلية",
        confirmLabel = if (existing != null) "حفظ التعديل" else "حفظ",
        onDismiss = onDismiss,
        testTag = "ts_internal_dialog",
        onConfirm = {
            if (fundId.isBlank()) {
                errMsg = "أضف صندوقاً أولاً"
                return@TsModalShell
            }
            if (accId.isBlank()) {
                errMsg = "اختر الحساب"
                return@TsModalShell
            }
            if (accId == "__new" && newAccName.isBlank()) {
                errMsg = "أدخل اسم الحساب الجديد"
                return@TsModalShell
            }
            if (previewRows.isEmpty()) {
                errMsg = "أدخل مبلغ عملة واحدة على الأقل"
                return@TsModalShell
            }
            val voucher = (existing ?: TsVoucher(
                kind = "internal",
                dir = "out",
                time = DateHelper.nowTime()
            )).copy(
                kind = "internal",
                dir = "out",
                date = date,
                fromFundId = fundId,
                accId = if (accId == "__new") "" else accId,
                sender = sender.trim(),
                receiver = receiver.trim(),
                transferNo = transferNo.trim(),
                dest = dest.trim(),
                com = comVal,
                img = imgPath,
                rows = previewRows,
                cur = previewRows.first().cur,
                amount = previewRows.first().a,
                rate = previewRows.first().r
            )
            val err = viewModel.saveTsVoucherWithValidation(
                v = voucher,
                newAccountName = if (accId == "__new") newAccName.trim() else ""
            ) { onDismiss() }
            if (err != null) errMsg = err
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val accLabel = when (accId) {
                "" -> "اختر الحساب"
                "__new" -> "＋ حساب جديد..."
                else -> snap.tsAccounts.firstOrNull { it.id == accId }?.name ?: "اختر الحساب"
            }
            TsDropdownField(
                label = "الحساب",
                selectedText = accLabel,
                options = snap.tsAccounts.map { it.id to it.name } + ("__new" to "＋ حساب جديد..."),
                onSelect = { accId = it },
                modifier = Modifier.weight(1f)
            )
            TsDropdownField(
                label = "الصندوق",
                selectedText = snap.tsFunds.firstOrNull { it.id == fundId }?.name ?: "اختر الصندوق",
                options = snap.tsFunds.map { it.id to it.name },
                onSelect = { fundId = it },
                modifier = Modifier.weight(1f)
            )
        }

        if (accId == "__new") {
            NameSuggestTextField(
                value = newAccName,
                onValueChange = { newAccName = it },
                label = "اسم الحساب الجديد",
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 4 metadata inputs (Sender, Receiver, TransferNo, Dest) matching Screenshot 2
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NameSuggestTextField(
                value = sender,
                onValueChange = { sender = it },
                label = "اسم المرسل",
                modifier = Modifier.weight(1f)
            )
            NameSuggestTextField(
                value = receiver,
                onValueChange = { receiver = it },
                label = "اسم المستلم",
                modifier = Modifier.weight(1f)
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = transferNo,
                onValueChange = { transferNo = WesternDigits.toWestern(it) },
                label = { Text("رقم الحواله", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = dest,
                onValueChange = { dest = it },
                label = { Text("جهة الحواله", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        TsCurrencyRowsTable(
            currencies = currencies,
            amountsMap = amountsMap,
            ratesMap = ratesMap,
            rateHeaderLabel = "سعر البيع",
            rateFixedMode = if (existing != null) null else "sell"
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("مبلغ العمولة", style = MaterialTheme.typography.labelMedium, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                WesternNumberField(
                    value = comStr,
                    onValueChange = { comStr = it },
                    label = "",
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White,
                border = BorderStroke(1.dp, TsGoldBorder),
                modifier = Modifier.weight(1f).heightIn(min = 56.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ناتج الصرف + العمولة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Text(fmt(totalWithCom), fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                }
            }
        }

        if (previewRows.isNotEmpty()) {
            TsFxPreviewBox(expectedFx)
        }

        if (errMsg.isNotBlank()) {
            Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TsTransferDialog(
    initialFundId: String? = null,
    existing: TsVoucher? = null,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val currencies = uiState.settings.currencies

    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var fromFundId by remember { mutableStateOf(existing?.fromFundId?.ifBlank { null } ?: initialFundId ?: snap.tsFunds.firstOrNull()?.id ?: "") }
    var toFundId by remember {
        mutableStateOf(
            existing?.toFundId?.ifBlank { null }
                ?: snap.tsFunds.firstOrNull { it.id != fromFundId }?.id
                ?: snap.tsFunds.firstOrNull()?.id
                ?: ""
        )
    }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var errMsg by remember { mutableStateOf("") }

    val amountsMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            existing?.rows?.forEach { put(it.cur, rawNumberString(it.a)) }
        }
    }
    val ratesMap = remember(existing?.id) {
        mutableStateMapOf<String, String>().apply {
            currencies.forEach { c ->
                val exRate = existing?.rows?.firstOrNull { it.cur == c.name }?.r
                put(c.name, rawNumberString(exRate ?: 1.0))
            }
        }
    }

    val previewRows = collectTsRows(currencies, amountsMap, ratesMap, null)
    val totalSum = previewRows.sumOf { it.a * it.r }
    val expectedFx = remember(previewRows, fromFundId) {
        if (previewRows.isNotEmpty()) {
            TasfeerFxEngine.previewExpectedFxDiff(
                existingVouchers = snap.tsVouchers,
                funds = snap.tsFunds,
                currencies = currencies,
                kind = "transfer",
                fundId = fromFundId,
                rows = previewRows,
                editingVoucherId = existing?.id
            )
        } else 0.0
    }

    TsModalShell(
        title = if (existing != null) "تعديل الترحيل بين الصناديق" else "سند ترحيل إلى صندوق آخر",
        confirmLabel = if (existing != null) "حفظ التعديل" else "حفظ",
        onDismiss = onDismiss,
        testTag = "ts_transfer_dialog",
        onConfirm = {
            if (fromFundId == toFundId) {
                errMsg = "اختر صندوقين مختلفين"
                return@TsModalShell
            }
            if (previewRows.isEmpty()) {
                errMsg = "أدخل مبلغ عملة واحدة على الأقل"
                return@TsModalShell
            }
            val voucher = (existing ?: TsVoucher(
                kind = "transfer",
                dir = "out",
                time = DateHelper.nowTime()
            )).copy(
                kind = "transfer",
                dir = "out",
                date = date,
                fromFundId = fromFundId,
                toFundId = toFundId,
                note = note.trim(),
                img = imgPath,
                rows = previewRows,
                cur = previewRows.first().cur,
                amount = previewRows.first().a,
                rate = previewRows.first().r
            )
            val err = viewModel.saveTsVoucherWithValidation(voucher) { onDismiss() }
            if (err != null) errMsg = err
        }
    ) {
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsDropdownField(
                label = "من صندوق",
                selectedText = snap.tsFunds.firstOrNull { it.id == fromFundId }?.name ?: "اختر",
                options = snap.tsFunds.map { it.id to it.name },
                onSelect = { fromFundId = it },
                modifier = Modifier.weight(1f)
            )
            TsDropdownField(
                label = "إلى صندوق",
                selectedText = snap.tsFunds.firstOrNull { it.id == toFundId }?.name ?: "اختر",
                options = snap.tsFunds.map { it.id to it.name },
                onSelect = { toFundId = it },
                modifier = Modifier.weight(1f)
            )
        }

        TsCurrencyRowsTable(
            currencies = currencies,
            amountsMap = amountsMap,
            ratesMap = ratesMap,
            rateHeaderLabel = "سعر الصرف",
            rateFixedMode = null
        )

        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White,
            border = BorderStroke(1.dp, TsGoldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("اجمالي ناتج الترحيل", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                Text(fmt(totalSum), fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
            }
        }

        if (previewRows.isNotEmpty()) {
            TsFxPreviewBox(expectedFx)
        }

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("البيان") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (errMsg.isNotBlank()) {
            Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TsExchangeDialog(
    fundId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val currencies = uiState.settings.currencies
    val tsState = uiState.tasfeerState
    val fundName = snap.tsFunds.firstOrNull { it.id == fundId }?.name ?: ""

    var fromCur by remember { mutableStateOf(currencies.firstOrNull()?.name ?: "ريال يمني") }
    var toCur by remember { mutableStateOf(currencies.getOrNull(1)?.name ?: currencies.firstOrNull()?.name ?: "ريال سعودي") }
    var amtStr by remember { mutableStateOf("") }
    var rateStr by remember { mutableStateOf("1") }
    var date by remember { mutableStateOf(DateHelper.todayIso()) }
    var imgPath by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errMsg by remember { mutableStateOf("") }

    val availableFrom = tsState.fundCurrencyQty[fundId to fromCur] ?: 0.0
    val outAmt = num(amtStr) * num(rateStr).let { if (it > 0) it else 0.0 }

    TsModalShell(
        title = "💱 صرافة العملات من أرصدة الصندوق",
        confirmLabel = "💾 حفظ الصرافة",
        onDismiss = onDismiss,
        testTag = "ts_exchange_dialog",
        onConfirm = {
            val a = num(amtStr)
            val r = num(rateStr)
            if (a <= 0.0 || r <= 0.0) {
                errMsg = "أدخل المبلغ وسعر الصرف"
                return@TsModalShell
            }
            if (fromCur == toCur) {
                errMsg = "اختر عملتين مختلفتين"
                return@TsModalShell
            }
            val voucher = TsVoucher(
                kind = "exchange",
                dir = "out",
                date = date,
                time = DateHelper.nowTime(),
                fundId = fundId,
                fromCur = fromCur,
                fromAmt = a,
                toCur = toCur,
                toAmt = a * r,
                rate = r,
                note = note.trim(),
                img = imgPath
            )
            val err = viewModel.saveTsVoucherWithValidation(voucher) { onDismiss() }
            if (err != null) errMsg = err
        }
    ) {
        Text("صرافة من أرصدة الصندوق: $fundName", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
        TsDateAndPhotoHeader(date, { date = it }, imgPath, { imgPath = it }, viewModel)

        TsDropdownField(
            label = "العملة المصروفة (المتوفر: ${fmt(availableFrom)})",
            selectedText = fromCur,
            options = currencies.map {
                val av = tsState.fundCurrencyQty[fundId to it.name] ?: 0.0
                it.name to "${it.name} (${fmt(av)})"
            },
            onSelect = { fromCur = it }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = "المبلغ المصروف", modifier = Modifier.weight(1f))
            WesternNumberField(value = rateStr, onValueChange = { rateStr = it }, label = "سعر الصرف", modifier = Modifier.weight(1f))
        }

        TsDropdownField(
            label = "العملة المستلمة",
            selectedText = toCur,
            options = currencies.map { it.name to it.name },
            onSelect = { toCur = it }
        )

        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF0FDF4),
            border = BorderStroke(1.dp, Color(0xFF16A34A)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("المبلغ المستلم (تلقائي)", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                Text("${fmt(outAmt)} $toCur", fontWeight = FontWeight.Black, color = Color(0xFF15803D))
            }
        }

        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())

        if (errMsg.isNotBlank()) {
            Text(errMsg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TsGapModalDialog(gap: TasfeerGapSummary, onDismiss: () -> Unit) {
    val label = when (gap.side) {
        "acc" -> "الفارق الباقي للحسابات (الحسابات أكبر من الصناديق)"
        "fund" -> "الفارق الباقي للصناديق (الصناديق أكبر من الحسابات)"
        else -> "لا يوجد فارق"
    }
    val col = when (gap.side) {
        "acc" -> AppColors.CreditGreen
        "fund" -> AppColors.DebitRed
        else -> Color(0xFF64748B)
    }
    TsModalShell(title = "ناتج المبالغ بين الحسابات والصناديق", onDismiss = onDismiss) {
        SummaryStatCard("رصيد الحسابات الكامل", fmt(abs(gap.accountsTotal)), if (gap.accountsTotal >= 0) AppColors.CreditGreen else AppColors.DebitRed, Modifier.fillMaxWidth())
        SummaryStatCard("رصيد الصناديق الكامل", fmt(abs(gap.fundsTotal)), if (gap.fundsTotal >= 0) AppColors.CreditGreen else AppColors.DebitRed, Modifier.fillMaxWidth())
        SummaryStatCard(label, fmt(abs(gap.gap)), col, Modifier.fillMaxWidth())
    }
}

@Composable
fun TsStatsModalDialog(uiState: SmartAdminUiState, onDismiss: () -> Unit) {
    val snap = uiState.snapshot
    val tsState = uiState.tasfeerState
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val credit = tsState.accountBalances.values.filter { it > 0 }.sum()
    val debit = tsState.accountBalances.values.filter { it < 0 }.sumOf { abs(it) }

    TsModalShell(title = "📊 الإحصائيات", onDismiss = onDismiss) {
        SummaryStatCard("مجلدات وحسابات الصرافة", "${snap.tsFolders.size} مجلد — ${snap.tsAccounts.size} حساب", MaterialTheme.colorScheme.primary, Modifier.fillMaxWidth())
        SummaryStatCard("إجمالي لكم ($baseCur)", fmt(credit), AppColors.CreditGreen, Modifier.fillMaxWidth())
        SummaryStatCard("إجمالي عليكم ($baseCur)", fmt(debit), AppColors.DebitRed, Modifier.fillMaxWidth())
    }
}

@Composable
fun TsSearchModalDialog(
    uiState: SmartAdminUiState,
    onOpenAccount: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val matches = remember(q, uiState.snapshot.tsAccounts, uiState.tasfeerState.accountBalances) {
        val trim = q.trim()
        if (trim.isBlank()) uiState.snapshot.tsAccounts
        else uiState.snapshot.tsAccounts.filter {
            it.name.contains(trim, true) || it.phone.contains(trim, true)
        }
    }

    TsModalShell(title = "🔍 البحث السريع", onDismiss = onDismiss) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text("اسم الحساب أو رقم الهاتف") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        matches.forEach { acc ->
            val bal = uiState.tasfeerState.accountBalances[acc.id] ?: 0.0
            Surface(
                onClick = { onOpenAccount(acc.id); onDismiss() },
                shape = RoundedCornerShape(10.dp),
                color = Color.White,
                border = BorderStroke(1.dp, TsGoldBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(acc.name, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                        if (acc.phone.isNotBlank()) Text(acc.phone, style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B))
                    }
                    Text(
                        "${if (bal < 0) "عليكم " else if (bal > 0) "لكم " else ""}${fmt(abs(bal))}",
                        fontWeight = FontWeight.Bold,
                        color = if (bal < 0) AppColors.DebitRed else if (bal > 0) AppColors.CreditGreen else Color(0xFF64748B)
                    )
                }
            }
        }
    }
}

@Composable
fun TsFolderEditDialog(
    existing: TsFolder?,
    nextOrder: Int,
    hasAccounts: Boolean,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var orderStr by remember { mutableStateOf((existing?.order ?: nextOrder).toString()) }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }
    var err by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { imgPath = it }
    }

    TsModalShell(
        title = if (existing != null) "📁 تعديل مجلد" else "📁 إضافة مجلد",
        confirmLabel = "حفظ",
        onDismiss = onDismiss,
        onConfirm = {
            if (name.isBlank()) {
                err = "أدخل اسم المجلد"
                return@TsModalShell
            }
            val fol = (existing ?: TsFolder()).copy(
                name = name.trim(),
                order = num(orderStr).toInt().coerceAtLeast(1),
                img = imgPath
            )
            viewModel.saveTsFolder(fol)
            onDismiss()
        }
    ) {
        OutlinedButton(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
        ) {
            Icon(Icons.Default.PhotoCamera, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (imgPath.isNotBlank()) "تم اختيار صورة — استبدال" else "صورة المجلد")
        }
        NameSuggestTextField(value = name, onValueChange = { name = it; err = "" }, label = "اسم المجلد", modifier = Modifier.fillMaxWidth())
        WesternNumberField(value = orderStr, onValueChange = { orderStr = it }, label = "ترتيب المجلد", allowDecimal = false, modifier = Modifier.fillMaxWidth())
        if (existing != null) {
            if (hasAccounts) {
                Text("انقل حسابات هذا المجلد أو احذفها أولاً للحذف", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            } else {
                TextButton(
                    onClick = { viewModel.deleteTsFolder(existing.id); onDismiss() },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("حذف المجلد")
                }
            }
        }
        if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun TsFundEditDialog(
    existing: TsFund?,
    nextOrder: Int,
    hasVouchers: Boolean,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var orderStr by remember { mutableStateOf((existing?.order ?: nextOrder).toString()) }
    var err by remember { mutableStateOf("") }

    TsModalShell(
        title = if (existing != null) "تعديل الصندوق" else "إضافة صندوق",
        confirmLabel = "💾 حفظ",
        onDismiss = onDismiss,
        onConfirm = {
            if (name.isBlank()) {
                err = "أدخل اسم الصندوق"
                return@TsModalShell
            }
            val f = (existing ?: TsFund()).copy(
                name = name.trim(),
                order = num(orderStr).toInt().coerceAtLeast(1)
            )
            viewModel.saveTsFund(f)
            onDismiss()
        }
    ) {
        NameSuggestTextField(value = name, onValueChange = { name = it; err = "" }, label = "الاسم", modifier = Modifier.fillMaxWidth())
        WesternNumberField(value = orderStr, onValueChange = { orderStr = it }, label = "الترتيب", allowDecimal = false, modifier = Modifier.fillMaxWidth())
        if (existing != null) {
            if (hasVouchers) {
                Text("لا يمكن مسح الصندوق لأنه يحتوي على عملات", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            } else {
                OutlinedButton(
                    onClick = { viewModel.deleteTsFund(existing.id); onDismiss() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Text("🗑 مسح الصندوق", fontWeight = FontWeight.Bold)
                }
            }
        }
        if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun TsAccountEditDialog(
    folderId: String,
    existing: TsAccount?,
    existingNames: Set<String>,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var hasLimit by remember { mutableStateOf((existing?.limitAmount ?: 0.0) > 0.0) }
    var limitStr by remember { mutableStateOf(if (existing != null && existing.limitAmount > 0.0) rawNumberString(existing.limitAmount) else "") }
    var err by remember { mutableStateOf("") }

    TsModalShell(
        title = if (existing != null) "تعديل الحساب" else "إضافة حساب جديد",
        confirmLabel = "حفظ",
        onDismiss = onDismiss,
        onConfirm = {
            val n = name.trim()
            if (n.isBlank()) {
                err = "أدخل الاسم"
                return@TsModalShell
            }
            if (existing == null && n in existingNames) {
                err = "يوجد حساب بنفس الاسم"
                return@TsModalShell
            }
            val acc = (existing ?: TsAccount(folderId = folderId)).copy(
                name = n,
                phone = phone.trim(),
                limitAmount = if (hasLimit) num(limitStr).coerceAtLeast(0.0) else 0.0
            )
            viewModel.saveTsAccount(acc)
            onDismiss()
        }
    ) {
        NameSuggestTextField(value = name, onValueChange = { name = it; err = "" }, label = "الاسم", modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = phone, onValueChange = { phone = WesternDigits.toWestern(it) }, label = { Text("رقم الهاتف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { hasLimit = !hasLimit }) {
            Checkbox(checked = hasLimit, onCheckedChange = { hasLimit = it })
            Text("إضافة سقف مديونية")
        }
        if (hasLimit) {
            WesternNumberField(value = limitStr, onValueChange = { limitStr = it }, label = "مبلغ سقف المديونية", modifier = Modifier.fillMaxWidth())
        }
        if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun TsVoucherDetailDialog(
    v: TsVoucher,
    uiState: SmartAdminUiState,
    onDismiss: () -> Unit
) {
    val snap = uiState.snapshot
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val accName = snap.tsAccounts.firstOrNull { it.id == v.accId }?.name ?: ""
    val fundName = snap.tsFunds.firstOrNull { it.id == v.fundId || it.id == v.fromFundId }?.name ?: ""
    val tot = TasfeerFxEngine.voucherTotalBase(v, baseCur)

    TsModalShell(title = "👁 تفاصيل السند", onDismiss = onDismiss) {
        Text("التاريخ: ${DateHelper.displaySlash(v.date)}", fontWeight = FontWeight.Bold)
        if (fundName.isNotBlank()) Text("الصندوق: $fundName")
        if (accName.isNotBlank()) Text("الحساب: $accName")
        if (v.pg.isNotBlank()) Text("صفحة المراقب: ${v.pg}")
        if (v.sender.isNotBlank()) Text("المرسل: ${v.sender}")
        if (v.receiver.isNotBlank()) Text("المستلم: ${v.receiver}")
        if (v.transferNo.isNotBlank()) Text("رقم الحوالة: ${v.transferNo}")
        if (v.dest.isNotBlank()) Text("الجهة: ${v.dest}")
        if (v.com > 0.0) Text("العمولة: ${fmt(v.com)}")
        if (v.note.isNotBlank()) Text("البيان: ${v.note}")
        v.rows.forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(r.cur, fontWeight = FontWeight.Bold)
                Text("${fmt(r.a)} × ${fmt(r.r)} = ${fmt(r.a * r.r)}")
            }
        }
        SummaryStatCard("الإجمالي", fmt(tot), MaterialTheme.colorScheme.primary, Modifier.fillMaxWidth())
        if (v.img.isNotBlank() && File(v.img).exists()) {
            Image(
                painter = rememberAsyncImagePainter(File(v.img)),
                contentDescription = "صورة السند",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            )
        }
    }
}
