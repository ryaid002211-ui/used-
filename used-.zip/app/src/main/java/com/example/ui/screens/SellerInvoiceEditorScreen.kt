package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellerInvoiceEditorScreen(
    folderId: String,
    invoiceId: String?,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val folder = uiState.snapshot.weekFolders.firstOrNull { it.id == folderId }

    val existing = remember(folder, invoiceId) {
        if (invoiceId != null) folder?.invoices?.firstOrNull { it.id == invoiceId } else null
    }

    val suggestedDate = remember(folder) {
        if (folder != null) {
            val taken = folder.invoices.map { it.initDateISO }.toSet()
            DateHelper.suggestNextFreeDate(folder.startDate, folder.endDate, taken)
        } else DateHelper.todayIso()
    }

    var dateIso by remember(existing) { mutableStateOf(existing?.initDateISO ?: suggestedDate) }
    var sellerName by remember(existing) { mutableStateOf(existing?.initSeller ?: "") }
    var initNo by remember(existing) { mutableStateOf(existing?.initNo ?: "") }
    var note by remember(existing) { mutableStateOf(existing?.note ?: "") }
    var specId by remember(existing, folder) { mutableStateOf(existing?.specialtyId ?: folder?.specialtyId.orEmpty()) }
    var sellerPhotoPath by remember(existing) { mutableStateOf(existing?.sellerPhotoPath ?: "") }
    var paperPhotoPath by remember(existing) { mutableStateOf(existing?.invoicePaperPhotoPath ?: "") }
    var formData by remember(existing) {
        mutableStateOf(
            existing?.formData ?: SellerFormData(
                salesRows = listOf(SaleRow()),
                receivedRows = listOf(MoneyNameRow()),
                outRows = listOf(MoneyNameRow()),
                withdrawRows = listOf(MoneyNameRow()),
                weeklyRows = listOf(MoneyNameRow()),
                currencyRows = listOf(SellerCurrencyRow(cur = "يمني"))
            )
        )
    }

    var cashEntries by remember(existing) {
        val initial = existing?.formData?.salesRows?.filter {
            it.s1n.isNotBlank() || it.s1m.isNotBlank() ||
                it.s2n.isNotBlank() || it.s2m.isNotBlank() ||
                it.s3n.isNotBlank() || it.s3m.isNotBlank()
        }.orEmpty()
        mutableStateOf(
            initial.ifEmpty { listOf(SaleRow()) }.map {
                SaleRow(
                    id = it.id,
                    s1n = it.s1n, s1m = it.s1m,
                    s2n = it.s2n, s2m = it.s2m,
                    s3n = it.s3n, s3m = it.s3m
                )
            }
        )
    }
    var debtEntries by remember(existing) {
        val initial = existing?.formData?.salesRows?.filter {
            it.dname.isNotBlank() || it.dn.isNotBlank() || it.dm.isNotBlank()
        }.orEmpty()
        mutableStateOf(
            initial.ifEmpty { listOf(SaleRow()) }.map {
                SaleRow(id = it.id, dname = it.dname, dn = it.dn, dm = it.dm)
            }
        )
    }
    var outEntries by remember(existing) {
        val initial = existing?.formData?.salesRows?.filter {
            it.oname.isNotBlank() || it.onQty.isNotBlank() || it.om.isNotBlank()
        }.orEmpty()
        mutableStateOf(
            initial.ifEmpty { listOf(SaleRow()) }.map {
                SaleRow(id = it.id, oname = it.oname, onQty = it.onQty, om = it.om)
            }
        )
    }

    fun syncSalesRows(
        cash: List<SaleRow> = cashEntries,
        debt: List<SaleRow> = debtEntries,
        out: List<SaleRow> = outEntries
    ) {
        cashEntries = cash
        debtEntries = debt
        outEntries = out
        val count = maxOf(cash.size, debt.size, out.size, 1)
        val merged = (0 until count).map { idx ->
            val c = cash.getOrNull(idx)
            val d = debt.getOrNull(idx)
            val o = out.getOrNull(idx)
            SaleRow(
                id = c?.id ?: d?.id ?: o?.id ?: newId("sr"),
                s1n = c?.s1n.orEmpty(),
                s1m = c?.s1m.orEmpty(),
                s2n = c?.s2n.orEmpty(),
                s2m = c?.s2m.orEmpty(),
                s3n = c?.s3n.orEmpty(),
                s3m = c?.s3m.orEmpty(),
                dn = d?.dn.orEmpty(),
                dm = d?.dm.orEmpty(),
                dname = d?.dname.orEmpty(),
                onQty = o?.onQty.orEmpty(),
                om = o?.om.orEmpty(),
                oname = o?.oname.orEmpty()
            )
        }
        formData = formData.copy(salesRows = merged)
    }

    var activeTab by remember { mutableIntStateOf(0) } // 0=البيع والدين, 1=السحوبات والمسلم, 2=العملات والمرفقات
    var showPaperParser by remember { mutableStateOf(false) }
    var previewImg by remember { mutableStateOf<String?>(null) }
    var validationError by remember { mutableStateOf("") }

    val calc = remember(formData) { SellerInvoiceCalculator.calculate(formData) }

    val sellerPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { sellerPhotoPath = it }
    }
    val paperPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { paperPhotoPath = it }
    }

    fun buildInvoice(): FolderInvoice {
        val cleanIso = DateHelper.parseFlexibleDate(dateIso).ifBlank { dateIso.trim() }
        return FolderInvoice(
            id = existing?.id ?: newId("inv"),
            folderId = folderId,
            invoiceKind = "seller",
            initDate = DateHelper.formatInvoiceDate(cleanIso, uiState.settings.lang == "en"),
            initDateISO = cleanIso,
            initSeller = sellerName.trim(),
            initWeeklyFilter = folder?.name ?: "",
            initNo = initNo.trim(),
            note = note.trim(),
            specialtyId = specId,
            sellerPhotoPath = sellerPhotoPath,
            invoicePaperPhotoPath = paperPhotoPath,
            formData = formData.copy(note = note.trim()),
            createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun validateAndSave() {
        val cleanIso = DateHelper.parseFlexibleDate(dateIso).ifBlank { dateIso.trim() }
        if (!DateHelper.isIsoDate(cleanIso)) {
            validationError = strings.t("يرجى إدخال تاريخ صحيح بصيغة YYYY-MM-DD", "Invalid date YYYY-MM-DD")
            return
        }
        if (folder != null) {
            if (folder.startDate.isNotBlank() && folder.endDate.isNotBlank() &&
                (cleanIso < folder.startDate || cleanIso > folder.endDate)
            ) {
                validationError = strings.t(
                    "التاريخ خارج نطاق المجلد (${folder.startDate} إلى ${folder.endDate})",
                    "Date outside folder range"
                )
                return
            }
            val duplicate = folder.invoices.any { it.initDateISO == cleanIso && it.id != existing?.id }
            if (duplicate) {
                validationError = strings.t("توجد فاتورة مسجلة مسبقاً لهذا التاريخ ($cleanIso)", "Duplicate invoice date")
                return
            }
        }
        validationError = ""
        viewModel.saveInvoice(buildInvoice()) { onBack() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(strings.t("فاتورة البائع", "Seller Invoice"), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            DateHelper.formatInvoiceDate(dateIso, uiState.settings.lang == "en"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showPaperParser = true },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("open_paper_parser_btn")
                    ) {
                        Icon(Icons.Default.DocumentScanner, contentDescription = strings.t("تفريغ نص", "Parse Text"))
                    }
                    IconButton(
                        onClick = {
                            val inv = buildInvoice()
                            val html = PrintReportBuilders.buildSellerInvoiceHtml(inv, uiState.settings)
                            viewModel.printHtmlReport(activity, "فاتورة ${inv.initSeller}", html)
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("print_seller_invoice_btn")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = strings.print)
                    }
                    FilledTonalButton(
                        onClick = { validateAndSave() },
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .heightIn(min = 48.dp)
                            .testTag("save_seller_invoice_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.save)
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 8.dp, shadowElevation = 8.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FooterStat(
                            label = strings.t("رصيد الكمية", "Qty Bal"),
                            value = fmt(calc.qtyBalance),
                            ok = abs(calc.qtyBalance) < 1e-6
                        )
                        FooterStat(
                            label = strings.t("صافي الكاش", "Cash Net"),
                            value = fmt(calc.cashBalance),
                            ok = true
                        )
                        FooterStat(
                            label = strings.t("العملات", "Currencies"),
                            value = fmt(calc.currencyTotal),
                            ok = true
                        )
                        FooterStat(
                            label = strings.t("الفارق", "Diff"),
                            value = fmt(calc.currencyDiff),
                            ok = abs(calc.currencyDiff) < 1e-6
                        )
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
        ) {
            if (validationError.isNotBlank()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            validationError,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }

            // Header Info Card
            item {
                StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ClickableDateField(
                                value = dateIso,
                                onDatePicked = { dateIso = it },
                                label = strings.date,
                                modifier = Modifier.weight(1f),
                                testTag = "seller_date_input"
                            )
                            WesternNumberField(
                                value = formData.qty,
                                onValueChange = { formData = formData.copy(qty = it) },
                                label = strings.t("الكمية المسجلة", "Entered Qty"),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("seller_qty_input")
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NameSuggestTextField(
                                value = sellerName,
                                onValueChange = { sellerName = it },
                                label = strings.t("اسم البائع", "Seller Name"),
                                testTag = "seller_name_input",
                                modifier = Modifier.weight(1.4f)
                            )
                            OutlinedTextField(
                                value = initNo,
                                onValueChange = { initNo = WesternDigits.toWestern(it) },
                                label = { Text(strings.t("رقم الجدول", "No.")) },
                                singleLine = true,
                                modifier = Modifier.weight(0.6f)
                            )
                        }
                    }
                }
            }

            // Tabs
            item {
                TabRow(selectedTabIndex = activeTab) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        text = { Text(strings.t("البيع والدين", "Sales & Debt"), maxLines = 1) }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        text = { Text(strings.t("السحوبات والمسلم", "Cash Flow"), maxLines = 1) }
                    )
                    Tab(
                        selected = activeTab == 2,
                        onClick = { activeTab = 2 },
                        text = { Text(strings.t("العملات والورقة", "Currency & Media"), maxLines = 1) }
                    )
                }
            }

            if (activeTab == 0) {
                // Card 1: كمية ومبلغ النقد
                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth().testTag("cash_sales_card")) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = strings.t("كمية ومبلغ النقد", "Cash Qty & Amount"),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    AssistChip(
                                        onClick = {
                                            val nextCols = (formData.saleColCount % 3) + 1
                                            formData = formData.copy(saleColCount = nextCols)
                                        },
                                        label = {
                                            Text(
                                                strings.t("${formData.saleColCount}ع", "${formData.saleColCount}C"),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        },
                                        modifier = Modifier.height(30.dp).testTag("cycle_sale_cols_chip")
                                    )
                                }
                                FilledTonalButton(
                                    onClick = { syncSalesRows(cash = cashEntries + SaleRow()) },
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("add_cash_row_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.t("إضافة", "Add"))
                                }
                            }

                            cashEntries.forEachIndexed { idx, row ->
                                fun updateCash(updated: SaleRow) {
                                    val list = cashEntries.toMutableList().apply { set(idx, updated) }
                                    syncSalesRows(cash = list)
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        WesternNumberField(
                                            value = row.s1n,
                                            onValueChange = { updateCash(row.copy(s1n = it)) },
                                            label = if (formData.saleColCount == 1) strings.t("كمية نقد", "Cash Qty") else strings.t("كمية نقد 1", "Qty 1"),
                                            modifier = Modifier.weight(1f)
                                        )
                                        WesternNumberField(
                                            value = row.s1m,
                                            onValueChange = { updateCash(row.copy(s1m = it)) },
                                            label = if (formData.saleColCount == 1) strings.t("مبلغ نقد", "Cash Amt") else strings.t("مبلغ نقد 1", "Amt 1"),
                                            modifier = Modifier.weight(1.25f)
                                        )
                                        if (cashEntries.size > 1) {
                                            IconButton(
                                                onClick = {
                                                    val list = cashEntries.toMutableList().apply { removeAt(idx) }
                                                    syncSalesRows(cash = list)
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }

                                    if (formData.saleColCount >= 2) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            WesternNumberField(
                                                value = row.s2n,
                                                onValueChange = { updateCash(row.copy(s2n = it)) },
                                                label = strings.t("كمية نقد 2", "Qty 2"),
                                                modifier = Modifier.weight(1f)
                                            )
                                            WesternNumberField(
                                                value = row.s2m,
                                                onValueChange = { updateCash(row.copy(s2m = it)) },
                                                label = strings.t("مبلغ نقد 2", "Amt 2"),
                                                modifier = Modifier.weight(1.25f)
                                            )
                                        }
                                    }

                                    if (formData.saleColCount >= 3) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            WesternNumberField(
                                                value = row.s3n,
                                                onValueChange = { updateCash(row.copy(s3n = it)) },
                                                label = strings.t("كمية نقد 3", "Qty 3"),
                                                modifier = Modifier.weight(1f)
                                            )
                                            WesternNumberField(
                                                value = row.s3m,
                                                onValueChange = { updateCash(row.copy(s3m = it)) },
                                                label = strings.t("مبلغ نقد 3", "Amt 3"),
                                                modifier = Modifier.weight(1.25f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Card 2: كمية ومبلغ الدين
                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth().testTag("debt_sales_card")) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.t("كمية ومبلغ الدين", "Debt Qty & Amount"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                FilledTonalButton(
                                    onClick = { syncSalesRows(debt = debtEntries + SaleRow()) },
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("add_debt_row_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.t("إضافة", "Add"))
                                }
                            }

                            debtEntries.forEachIndexed { idx, row ->
                                fun updateDebt(updated: SaleRow) {
                                    val list = debtEntries.toMutableList().apply { set(idx, updated) }
                                    syncSalesRows(debt = list)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    NameSuggestTextField(
                                        value = row.dname,
                                        onValueChange = { updateDebt(row.copy(dname = it)) },
                                        label = strings.t("اسم الدين", "Debtor"),
                                        modifier = Modifier.weight(1.3f)
                                    )
                                    WesternNumberField(
                                        value = row.dn,
                                        onValueChange = { updateDebt(row.copy(dn = it)) },
                                        label = strings.t("دين ك", "Qty"),
                                        modifier = Modifier.weight(0.7f)
                                    )
                                    WesternNumberField(
                                        value = row.dm,
                                        onValueChange = { updateDebt(row.copy(dm = it)) },
                                        label = strings.t("دين م", "Amt"),
                                        modifier = Modifier.weight(1.1f)
                                    )
                                    if (debtEntries.size > 1) {
                                        IconButton(
                                            onClick = {
                                                val list = debtEntries.toMutableList().apply { removeAt(idx) }
                                                syncSalesRows(debt = list)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Card 3: كمية ومبلغ الخرج
                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth().testTag("out_sales_card")) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.t("كمية ومبلغ الخرج", "Out Qty & Amount"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                FilledTonalButton(
                                    onClick = { syncSalesRows(out = outEntries + SaleRow()) },
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("add_out_row_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.t("إضافة", "Add"))
                                }
                            }

                            outEntries.forEachIndexed { idx, row ->
                                fun updateOut(updated: SaleRow) {
                                    val list = outEntries.toMutableList().apply { set(idx, updated) }
                                    syncSalesRows(out = list)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    NameSuggestTextField(
                                        value = row.oname,
                                        onValueChange = { updateOut(row.copy(oname = it)) },
                                        label = strings.t("بيان الخرج", "Out Note"),
                                        modifier = Modifier.weight(1.3f)
                                    )
                                    WesternNumberField(
                                        value = row.onQty,
                                        onValueChange = { updateOut(row.copy(onQty = it)) },
                                        label = strings.t("خرج ك", "Qty"),
                                        modifier = Modifier.weight(0.7f)
                                    )
                                    WesternNumberField(
                                        value = row.om,
                                        onValueChange = { updateOut(row.copy(om = it)) },
                                        label = strings.t("خرج م", "Amt"),
                                        modifier = Modifier.weight(1.1f)
                                    )
                                    if (outEntries.size > 1) {
                                        IconButton(
                                            onClick = {
                                                val list = outEntries.toMutableList().apply { removeAt(idx) }
                                                syncSalesRows(out = list)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${strings.t("نقدي", "Cash")}: ${fmt(calc.saleCash)}", fontWeight = FontWeight.Bold)
                            Text("${strings.t("دين", "Debt")}: ${fmt(calc.sumDebtAmt)}", color = AppColors.DebitRed, fontWeight = FontWeight.Bold)
                            Text("${strings.t("خرج كمية", "Out Qty")}: ${fmt(calc.sumQatOutQty)}")
                        }
                    }
                }
            }

            if (activeTab == 1) {
                item {
                    MoneyNameSectionCard(
                        title = strings.t("المبالغ المسلمة (${fmt(calc.sumReceived)})", "Received (${fmt(calc.sumReceived)})"),
                        nameLabel = strings.t("اسم المسلم", "Payer"),
                        rows = formData.receivedRows,
                        onUpdate = { formData = formData.copy(receivedRows = it) }
                    )
                }
                item {
                    MoneyNameSectionCard(
                        title = strings.t("الخوارج والمصروف (${fmt(calc.sumOut)})", "Expenses Out (${fmt(calc.sumOut)})"),
                        nameLabel = strings.t("البيان", "Item"),
                        rows = formData.outRows,
                        onUpdate = { formData = formData.copy(outRows = it) }
                    )
                }
                item {
                    MoneyNameSectionCard(
                        title = strings.t("السحوبات (${fmt(calc.sumWithdraw)})", "Withdrawals (${fmt(calc.sumWithdraw)})"),
                        nameLabel = strings.t("اسم الساحب", "Receiver"),
                        rows = formData.withdrawRows,
                        onUpdate = { formData = formData.copy(withdrawRows = it) }
                    )
                }
                item {
                    MoneyNameSectionCard(
                        title = strings.t("سداد الديون الأسبوعي (${fmt(calc.sumWeekly)})", "Weekly Debt Paid (${fmt(calc.sumWeekly)})"),
                        nameLabel = strings.t("اسم العميل", "Customer"),
                        rows = formData.weeklyRows,
                        onUpdate = { formData = formData.copy(weeklyRows = it) }
                    )
                }
            }

            if (activeTab == 2) {
                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    strings.t("توزيع العملات (${fmt(calc.currencyTotal)})", "Currencies (${fmt(calc.currencyTotal)})"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                FilledTonalButton(
                                    onClick = {
                                        formData = formData.copy(
                                            currencyRows = formData.currencyRows + SellerCurrencyRow(cur = "سعودي")
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text(strings.t("عملة", "Add"))
                                }
                            }

                            val currencyChoices = listOf("يمني", "سعودي", "عماني", "درهم", "دولار")
                            formData.currencyRows.forEachIndexed { idx, cr ->
                                val amt = num(cr.amount)
                                val rate = if (cr.cur.contains("يمني")) 1.0 else num(cr.rate).let { if (it > 0) it else 1.0 }
                                val valAmt = amt * rate
                                var curMenu by remember { mutableStateOf(false) }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(modifier = Modifier.weight(0.95f)) {
                                        OutlinedButton(onClick = { curMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text(cr.cur, maxLines = 1)
                                        }
                                        DropdownMenu(expanded = curMenu, onDismissRequest = { curMenu = false }) {
                                            currencyChoices.forEach { c ->
                                                DropdownMenuItem(
                                                    text = { Text(c) },
                                                    onClick = {
                                                        val list = formData.currencyRows.toMutableList()
                                                        list[idx] = cr.copy(cur = c)
                                                        formData = formData.copy(currencyRows = list)
                                                        curMenu = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    WesternNumberField(
                                        value = cr.amount,
                                        onValueChange = { v ->
                                            val list = formData.currencyRows.toMutableList()
                                            list[idx] = cr.copy(amount = v)
                                            formData = formData.copy(currencyRows = list)
                                        },
                                        label = strings.amount,
                                        modifier = Modifier.weight(1f)
                                    )
                                    WesternNumberField(
                                        value = if (cr.cur.contains("يمني")) "1" else cr.rate,
                                        onValueChange = { v ->
                                            val list = formData.currencyRows.toMutableList()
                                            list[idx] = cr.copy(rate = v)
                                            formData = formData.copy(currencyRows = list)
                                        },
                                        label = strings.t("الصرف", "Rate"),
                                        readOnly = cr.cur.contains("يمني"),
                                        modifier = Modifier.weight(0.85f)
                                    )
                                    Text(
                                        text = fmt(valAmt),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.widthIn(min = 52.dp)
                                    )
                                    IconButton(
                                        onClick = {
                                            val list = formData.currencyRows.toMutableList().apply { removeAt(idx) }
                                            formData = formData.copy(currencyRows = list)
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }

                // Photos & Notes
                item {
                    StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = note,
                                onValueChange = { note = it },
                                label = { Text(strings.t("ملاحظات الفاتورة", "Invoice Note")) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                PhotoAttachmentSlot(
                                    label = strings.t("صورة البائع", "Seller Photo"),
                                    path = sellerPhotoPath,
                                    onPick = { sellerPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                    onView = { previewImg = sellerPhotoPath },
                                    modifier = Modifier.weight(1f)
                                )
                                PhotoAttachmentSlot(
                                    label = strings.t("صورة ورقة الفاتورة", "Paper Invoice Photo"),
                                    path = paperPhotoPath,
                                    onPick = { paperPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                    onView = { previewImg = paperPhotoPath },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPaperParser) {
        PaperParserDialog(
            viewModel = viewModel,
            onApply = { targetType, parsed ->
                when (targetType) {
                    "debt" -> {
                        val extra = parsed.map { (q, a, nm) -> SaleRow(dn = q, dm = a, dname = nm) }
                        val cleaned = debtEntries.filter { it.dname.isNotBlank() || it.dn.isNotBlank() || it.dm.isNotBlank() }
                        syncSalesRows(debt = cleaned + extra)
                    }
                    "received" -> {
                        val extra = parsed.map { (_, a, nm) -> MoneyNameRow(name = nm, amount = a) }
                        formData = formData.copy(receivedRows = formData.receivedRows + extra)
                    }
                    "withdraw" -> {
                        val extra = parsed.map { (_, a, nm) -> MoneyNameRow(name = nm, amount = a) }
                        formData = formData.copy(withdrawRows = formData.withdrawRows + extra)
                    }
                    else -> {
                        val extra = parsed.map { (q, a, _) -> SaleRow(s1n = q, s1m = a) }
                        val cleaned = cashEntries.filter { it.s1n.isNotBlank() || it.s1m.isNotBlank() || it.s2n.isNotBlank() || it.s2m.isNotBlank() || it.s3n.isNotBlank() || it.s3m.isNotBlank() }
                        syncSalesRows(cash = cleaned + extra)
                    }
                }
                showPaperParser = false
            },
            onDismiss = { showPaperParser = false }
        )
    }

    previewImg?.let { p ->
        AppImageViewerDialog(
            imagePath = p,
            onSaveToGallery = { viewModel.saveImageToGallery(p) },
            onDelete = {
                if (p == sellerPhotoPath) sellerPhotoPath = ""
                if (p == paperPhotoPath) paperPhotoPath = ""
            },
            onDismiss = { previewImg = null }
        )
    }
}

@Composable
private fun FooterStat(label: String, value: String, ok: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = if (ok) AppColors.CreditGreen else AppColors.DebitRed
        )
    }
}

@Composable
private fun MoneyNameSectionCard(
    title: String,
    nameLabel: String,
    rows: List<MoneyNameRow>,
    onUpdate: (List<MoneyNameRow>) -> Unit
) {
    val strings = LocalAppStrings.current
    StyledAppCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                FilledTonalButton(onClick = { onUpdate(rows + MoneyNameRow()) }) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(strings.t("إضافة", "Add"))
                }
            }
            rows.forEachIndexed { idx, r ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NameSuggestTextField(
                        value = r.name,
                        onValueChange = { v ->
                            onUpdate(rows.toMutableList().apply { set(idx, r.copy(name = v)) })
                        },
                        label = nameLabel,
                        modifier = Modifier.weight(1.3f)
                    )
                    WesternNumberField(
                        value = r.amount,
                        onValueChange = { v ->
                            onUpdate(rows.toMutableList().apply { set(idx, r.copy(amount = v)) })
                        },
                        label = strings.amount,
                        modifier = Modifier.weight(1f)
                    )
                    if (rows.size > 1) {
                        IconButton(
                            onClick = { onUpdate(rows.toMutableList().apply { removeAt(idx) }) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoAttachmentSlot(
    label: String,
    path: String,
    onPick: () -> Unit,
    onView: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall)
        if (path.isNotBlank() && File(path).exists()) {
            Image(
                painter = rememberAsyncImagePainter(File(path)),
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onView)
            )
            TextButton(onClick = onPick) { Text(strings.t("تغيير", "Change")) }
        } else {
            OutlinedButton(
                onClick = onPick,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AddAPhoto, contentDescription = label)
                    Text(strings.t("إرفاق", "Attach"), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun PaperParserDialog(
    viewModel: SmartAdminViewModel,
    onApply: (String, List<Triple<String, String, String>>) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var raw by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("debt") }
    val preview = remember(raw) { viewModel.parsePaperLines(raw) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.t("تفريغ نص الورقة إلى صفوف", "Parse Paper Text to Rows")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = raw,
                    onValueChange = { raw = it },
                    label = { Text(strings.t("ألصق الأسطر (مثال: أحمد 15000)", "Paste lines (e.g. Ahmed 15000)")) },
                    minLines = 4,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("debt" to "دين", "cash" to "نقد", "received" to "مسلمة", "withdraw" to "سحب").forEach { (k, lbl) ->
                        FilterChip(selected = target == k, onClick = { target = k }, label = { Text(lbl) })
                    }
                }
                Text(
                    strings.t("الصفوف المستخرجة: ${preview.size}", "Parsed rows: ${preview.size}"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (preview.isNotEmpty()) onApply(target, preview) },
                enabled = preview.isNotEmpty()
            ) {
                Text(strings.t("إدراج الصفوف", "Insert Rows"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}
