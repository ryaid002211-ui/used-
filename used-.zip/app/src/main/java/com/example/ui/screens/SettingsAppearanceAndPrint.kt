package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.ui.components.StyledAppCard
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.roundToInt

@Composable
internal fun AppearanceSettingsSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    val a = settings.appearance
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path ->
            viewModel.updateSettings { it.copy(appearance = it.appearance.copy(backgroundPath = path)) }
        }
    }
    var customFrameHex by remember(a.frameColor) {
        mutableStateOf(if (a.frameColor.startsWith("#")) a.frameColor else "")
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Master & Granular Frame Toggles
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.t("تفعيل خيارات الإطار", "Frame Controls"), fontWeight = FontWeight.Bold)
                SettingSwitchRow(
                    title = strings.t("إطار التطبيق الرئيسي", "Master App Frame"),
                    checked = a.frameEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameEnabled = on)) } }
                )
                HorizontalDivider()
                SettingSwitchRow(
                    title = strings.t("لون الإطار", "Frame Color"),
                    checked = a.frameColorEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameColorEnabled = on)) } }
                )
                SettingSwitchRow(
                    title = strings.t("شكل الإطار", "Frame Shape"),
                    checked = a.frameShapeEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameShapeEnabled = on)) } }
                )
                SettingSwitchRow(
                    title = strings.t("نمط خط الإطار", "Frame Line Style"),
                    checked = a.frameStyleEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameStyleEnabled = on)) } }
                )
                SettingSwitchRow(
                    title = strings.t("سمك الإطار", "Frame Thickness"),
                    checked = a.frameThicknessEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameThicknessEnabled = on)) } }
                )
            }
        }

        // Theme Mode, Language, Font Weight, Font Family, Font Size
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingSwitchRow(
                    title = strings.t("الوضع الليلي", "Dark Theme"),
                    checked = settings.dark,
                    onCheckedChange = { viewModel.toggleDarkTheme() }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(strings.t("اللغة: ${if (settings.lang == "ar") "العربية" else "English"}", "Language"))
                    OutlinedButton(onClick = { viewModel.toggleLanguage() }) {
                        Text(if (settings.lang == "ar") "English" else "العربية")
                    }
                }

                Text(strings.t("لون الثيم الأساسي (${ThemeCatalog.paletteColors.size} لون)", "Primary Color"), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ThemeCatalog.paletteColors, key = { it.first }) { (hex, label) ->
                        val col = parseHexColor(hex)
                        val selected = settings.primaryColorHex.equals(hex, ignoreCase = true)
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.onSurface else Color.LightGray, CircleShape)
                                    .clickable { viewModel.setPrimaryColor(hex) }
                            )
                            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }

                Text(strings.t("وزن الخط", "Font Weight"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("light" to "نحيف", "medium" to "متوسط", "bold" to "عريض").forEach { (k, lbl) ->
                        FilterChip(
                            selected = settings.fontWeight == k,
                            onClick = { viewModel.updateSettings { it.copy(fontWeight = k) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("نوع الخط وحجمه", "Font Family & Size"), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("cairo" to "Cairo", "tajawal" to "Tajawal", "almarai" to "Almarai", "ibm" to "IBM Plex", "default" to "System")) { (k, lbl) ->
                        FilterChip(
                            selected = settings.fontFamily == k,
                            onClick = { viewModel.updateSettings { it.copy(fontFamily = k) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("small" to "صغير", "medium" to "متوسط", "large" to "كبير").forEach { (k, lbl) ->
                        FilterChip(
                            selected = settings.fontSize == k,
                            onClick = { viewModel.updateSettings { it.copy(fontSize = k) } },
                            label = { Text(lbl) }
                        )
                    }
                }
            }
        }

        // Design System + Shape / Line Style / Thickness / Button / Shadows
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(strings.t("نوع التصميم (15 نمط)", "Design System (15 Types)"), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ThemeCatalog.designTypes, key = { it.first }) { (k, lbl) ->
                        FilterChip(
                            selected = a.designType == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(designType = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("لون الإطار", "Frame Color"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("theme" to "الثيم", "gold" to "ذهبي", "silver" to "فضي", "copper" to "نحاسي").forEach { (k, lbl) ->
                        FilterChip(
                            selected = a.frameColor == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameColor = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ThemeCatalog.paletteColors, key = { "frame_${it.first}" }) { (hex, _) ->
                        val col = parseHexColor(hex)
                        val sel = a.frameColor.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(col)
                                .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.LightGray, CircleShape)
                                .clickable {
                                    customFrameHex = hex
                                    viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameColor = hex)) }
                                }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = customFrameHex,
                        onValueChange = { customFrameHex = it },
                        label = { Text(strings.t("كود لون الإطار (#RRGGBB)", "Custom Hex")) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = {
                        if (Regex("^#[0-9a-fA-F]{6}$").matches(customFrameHex.trim())) {
                            viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameColor = customFrameHex.trim())) }
                        }
                    }) { Text(strings.t("تطبيق", "Apply")) }
                }

                Text(strings.t("شكل الإطار", "Frame Shape"), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(
                        listOf(
                            "square" to "مربع",
                            "soft" to "زوايا خفيفة",
                            "rounded" to "مستدير",
                            "round" to "دائري الزوايا",
                            "pill" to "كبسولي",
                            "circle" to "دائري"
                        )
                    ) { (k, lbl) ->
                        FilterChip(
                            selected = a.frameShape == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameShape = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("نمط خط الإطار", "Frame Line Style"), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(
                        listOf(
                            "solid" to "متصل",
                            "dashed" to "متقطع",
                            "dotted" to "منقّط",
                            "double" to "مزدوج",
                            "groove" to "محفور",
                            "ridge" to "بارز",
                            "inset" to "داخلي",
                            "outset" to "خارجي"
                        )
                    ) { (k, lbl) ->
                        FilterChip(
                            selected = a.frameStyle == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameStyle = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("سمك الإطار", "Frame Thickness"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("thin" to "رفيع", "medium" to "متوسط", "thick" to "سميك").forEach { (k, lbl) ->
                        FilterChip(
                            selected = a.frameThickness == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(frameThickness = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("شكل الأزرار", "Button Shape"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("classic" to "كلاسيكي", "rounded" to "دائري", "simple" to "بسيط").forEach { (k, lbl) ->
                        FilterChip(
                            selected = a.buttonShape == k,
                            onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(buttonShape = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                SettingSwitchRow(
                    title = strings.t("الظلال للبطاقات", "Card Shadows"),
                    checked = a.shadows,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appearance = it.appearance.copy(shadows = on)) } }
                )
            }
        }

        // Background Image + Opacity
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("صورة الخلفية ودرجة الوضوح", "Background & Opacity"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f)
                    ) { Text(strings.t("اختيار صورة من الجهاز", "Choose Photo")) }
                    if (a.backgroundPath.isNotBlank()) {
                        OutlinedButton(onClick = { viewModel.updateSettings { it.copy(appearance = it.appearance.copy(backgroundPath = "")) } }) {
                            Text(strings.t("إزالة الصورة", "Remove"))
                        }
                    }
                }
                Text(strings.t("درجة وضوح الخلفية: ${a.backgroundOpacity}%", "Opacity: ${a.backgroundOpacity}%"), style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = a.backgroundOpacity.coerceIn(10, 100).toFloat(),
                    onValueChange = { v ->
                        val step = ((v / 5f).roundToInt() * 5).coerceIn(10, 100)
                        viewModel.updateSettings { it.copy(appearance = it.appearance.copy(backgroundOpacity = step)) }
                    },
                    valueRange = 10f..100f
                )
            }
        }
    }
}

@Composable
internal fun MessagesSettingsSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val m = settings.messages

    var intro by remember(m.msgIntro) { mutableStateOf(m.msgIntro) }
    var endTxt by remember(m.msgEnd) { mutableStateOf(m.msgEnd) }
    var payEnd by remember(m.payEnd) { mutableStateOf(m.payEnd) }
    var fmtDebt by remember(m.msgFormatDebt) { mutableStateOf(m.msgFormatDebt) }
    var fmtPay by remember(m.msgFormatPay) { mutableStateOf(m.msgFormatPay) }
    var code by remember(m.countryCode) { mutableStateOf(m.countryCode) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Header banner with Share Messages Template button
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    strings.t("تخصيص نماذج الرسائل", "Customize Message Templates"),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = {
                        val preview = viewModel.buildAccountMessageText(
                            accountName = "عميل تجريبي",
                            typeLabel = "سند قبض",
                            amount = 25000.0,
                            currency = settings.defaultCurrency,
                            note = "دفعة على الحساب",
                            netBalance = 10000.0,
                            netIsCreditForClient = false
                        )
                        ShareHelper.shareText(context, strings.t("نموذج رسالة الحساب", "Message Template Preview"), preview)
                    },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = strings.share, tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }

        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("إعدادات الإرسال العامة", "General Sending Options"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = m.sendMethod == "whatsapp",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(sendMethod = "whatsapp")) } },
                        label = { Text("واتساب") }
                    )
                    FilterChip(
                        selected = m.sendMethod == "sms",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(sendMethod = "sms")) } },
                        label = { Text("SMS") }
                    )
                }
                Text(strings.t("توقيت الإرسال", "Send Timing"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("auto" to "تلقائي", "confirm" to "بعد التأكيد", "never" to "إيقاف").forEach { (k, lbl) ->
                        FilterChip(
                            selected = m.sendWhen == k,
                            onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(sendWhen = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                SettingSwitchRow(
                    title = strings.t("تطبيق الإعدادات العامة على جميع الحسابات", "Apply Global Settings to All Accounts"),
                    checked = m.globalMessageSettings,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(messages = it.messages.copy(globalMessageSettings = on)) } }
                )
            }
        }

        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("مقدمة الرسالة وخاتمتها وصيغتها", "Intro, Closing & Format"), fontWeight = FontWeight.Bold)
                SettingSwitchRow(
                    title = strings.t("تفعيل مقدمة الرسالة", "Enable Intro"),
                    checked = m.msgIntroEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(messages = it.messages.copy(msgIntroEnabled = on)) } }
                )
                OutlinedTextField(value = intro, onValueChange = { intro = it }, label = { Text(strings.t("مقدمة الرسالة", "Intro Text")) }, modifier = Modifier.fillMaxWidth())
                SettingSwitchRow(
                    title = strings.t("تفعيل خاتمة الرسالة", "Enable Closing"),
                    checked = m.msgEndEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(messages = it.messages.copy(msgEndEnabled = on)) } }
                )
                OutlinedTextField(value = endTxt, onValueChange = { endTxt = it }, label = { Text(strings.t("خاتمة الرسالة", "Closing Text")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = payEnd, onValueChange = { payEnd = it }, label = { Text(strings.t("ختام طلب السداد", "Payment Request Footer")) }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = fmtDebt, onValueChange = { fmtDebt = it }, label = { Text(strings.t("صيغة (عليه)", "Debit Word")) }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = fmtPay, onValueChange = { fmtPay = it }, label = { Text(strings.t("صيغة (له)", "Credit Word")) }, modifier = Modifier.weight(1f))
                }
                Text(strings.t("صيغة الرصيد في الرسالة", "Balance Format"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("both" to "حسب الرصيد", "pay" to "لكم فقط", "debt" to "عليكم فقط").forEach { (k, lbl) ->
                        FilterChip(
                            selected = m.messageFormat == k,
                            onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(messageFormat = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
            }
        }

        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("الوجهة والواتساب ومفتاح الدولة", "Destination, WhatsApp & Country"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = m.messageContent == "text",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(messageContent = "text")) } },
                        label = { Text("رسالة نصية") }
                    )
                    FilterChip(
                        selected = m.messageContent == "image",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(messageContent = "image")) } },
                        label = { Text("صورة المعاملة") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = m.sendDest == "phone",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(sendDest = "phone")) } },
                        label = { Text("إلى رقم الجوال") }
                    )
                    FilterChip(
                        selected = m.sendDest == "other",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(sendDest = "other")) } },
                        label = { Text("مشاركة أخرى") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = m.waType == "business",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(waType = "business")) } },
                        label = { Text("واتساب الأعمال") }
                    )
                    FilterChip(
                        selected = m.waType == "green",
                        onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(waType = "green")) } },
                        label = { Text("واتساب الأخضر") }
                    )
                }
                OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text(strings.t("مفتاح الدولة", "Country Code")) }, modifier = Modifier.fillMaxWidth())
                Text(strings.t("مفتاح الخط للرسائل النصية", "SMS Line Key"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("empty" to "فارغ", "zero" to "صفر", "country" to "الدولة").forEach { (k, lbl) ->
                        FilterChip(
                            selected = m.lineKey == k,
                            onClick = { viewModel.updateSettings { it.copy(messages = it.messages.copy(lineKey = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(strings.t("حجم الصورة المرفقة", "Image Scale"), fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalIconButton(onClick = {
                            val next = (m.imageSize - 0.1).coerceIn(0.5, 2.0)
                            viewModel.updateSettings { it.copy(messages = it.messages.copy(imageSize = next)) }
                        }) { Text("−", fontWeight = FontWeight.Bold) }
                        Text(String.format(java.util.Locale.US, "%.1f", m.imageSize), fontWeight = FontWeight.Bold)
                        FilledTonalIconButton(onClick = {
                            val next = (m.imageSize + 0.1).coerceIn(0.5, 2.0)
                            viewModel.updateSettings { it.copy(messages = it.messages.copy(imageSize = next)) }
                        }) { Text("+", fontWeight = FontWeight.Bold) }
                    }
                }
                Button(
                    onClick = {
                        viewModel.updateSettings {
                            it.copy(
                                messages = it.messages.copy(
                                    msgIntro = intro,
                                    msgEnd = endTxt,
                                    payEnd = payEnd,
                                    msgFormatDebt = fmtDebt.ifBlank { "عليكم" },
                                    msgFormatPay = fmtPay.ifBlank { "الرصيد لك" },
                                    countryCode = code.ifBlank { "+967" }
                                )
                            )
                        }
                        viewModel.emitMessage("تم حفظ إعدادات الرسائل")
                    },
                    modifier = Modifier.fillMaxWidth().testTag("save_messages_settings_btn")
                ) { Text(strings.save) }
            }
        }
    }
}

@Composable
internal fun PrintingSettingsSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    val ps = settings.printing
    val lux = ps.lux
    val luxBgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path ->
            viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(bgPath = path))) }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("طريقة الطباعة ومقاس الورق", "Print Method & Paper Sizes"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = ps.printMethod == "pdf",
                        onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(printMethod = "pdf")) } },
                        label = { Text("إلى PDF") }
                    )
                    FilterChip(
                        selected = ps.printMethod == "printer",
                        onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(printMethod = "printer")) } },
                        label = { Text("إلى الطابعة") }
                    )
                }
                Text(strings.t("ورق الكشوفات والمصادقة", "Statement Paper"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("a4" to "A4", "a3" to "A3", "80" to "80mm", "58" to "58mm").forEach { (k, lbl) ->
                        FilterChip(
                            selected = ps.paperStatement == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(paperStatement = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Text(strings.t("ورق السندات", "Voucher Paper"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("a5" to "A5", "a4" to "A4", "a3" to "A3", "80" to "80mm", "58" to "58mm")) { (k, lbl) ->
                        FilterChip(
                            selected = ps.paperVoucher == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(paperVoucher = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Text(strings.t("ترتيب سندات جملة البيع", "Sale Vouchers Sort"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("date" to "التاريخ", "name" to "الأبجدي", "amount" to "المبلغ").forEach { (k, lbl) ->
                        FilterChip(
                            selected = ps.saleSortBy == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(saleSortBy = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                    FilterChip(
                        selected = ps.saleSortDir == "asc",
                        onClick = {
                            val next = if (ps.saleSortDir == "asc") "desc" else "asc"
                            viewModel.updateSettings { it.copy(printing = it.printing.copy(saleSortDir = next)) }
                        },
                        label = { Text(if (ps.saleSortDir == "asc") "↑ تصاعدي" else "↓ تنازلي") }
                    )
                }
            }
        }

        // Color, Font & Scale
        StyledAppCard(Modifier.fillMaxWidth()) {
            var customPrintTextHex by remember(ps.printTextColor) { mutableStateOf(ps.printTextColor) }
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("الألوان والخطوط", "Colors & Fonts"), fontWeight = FontWeight.Bold)
                if (lux.on) {
                    Text(
                        strings.t("ملاحظة: الطباعة المرفهة مفعلة وتتحكم بالألوان والشكل وتُعطّل ألوان الطباعة العادية", "Luxury Print overrides standard colors"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("color" to "ملون", "gray" to "رمادي", "bw" to "أسود وأبيض").forEach { (k, lbl) ->
                        FilterChip(
                            enabled = !lux.on,
                            selected = ps.printColorMode == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(printColorMode = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Text(strings.t("لون ترويسة الجداول", "Table Accent Color"), style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("#6B1A2F", "#1E40AF", "#071F4F", "#0F766E", "#7C2D12", "#AEBFFF", "#111111")) { hex ->
                        val col = parseHexColor(hex)
                        val sel = ps.printColor.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(col)
                                .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.LightGray, CircleShape)
                                .clickable(enabled = !lux.on) {
                                    viewModel.updateSettings { it.copy(printing = it.printing.copy(printColor = hex)) }
                                }
                        )
                    }
                }
                Text(strings.t("لون النص في الطباعة", "Print Text Color"), style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("#111111", "#1E293B", "#0F172A", "#1E3A8A", "#6B1A2F", "#15803D")) { hex ->
                        val col = parseHexColor(hex)
                        val sel = ps.printTextColor.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(col)
                                .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.LightGray, CircleShape)
                                .clickable(enabled = !lux.on) {
                                    customPrintTextHex = hex
                                    viewModel.updateSettings { it.copy(printing = it.printing.copy(printTextColor = hex)) }
                                }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = customPrintTextHex,
                        onValueChange = { customPrintTextHex = it },
                        enabled = !lux.on,
                        label = { Text(strings.t("كود لون النص (#RRGGBB)", "Text Color Hex")) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        enabled = !lux.on,
                        onClick = {
                            if (Regex("^#[0-9a-fA-F]{6}$").matches(customPrintTextHex.trim())) {
                                viewModel.updateSettings { it.copy(printing = it.printing.copy(printTextColor = customPrintTextHex.trim())) }
                            }
                        }
                    ) { Text(strings.t("تطبيق", "Apply")) }
                    TextButton(
                        enabled = !lux.on,
                        onClick = {
                            customPrintTextHex = "#111111"
                            viewModel.updateSettings { it.copy(printing = it.printing.copy(printTextColor = "#111111")) }
                        }
                    ) { Text(strings.t("افتراضي", "Reset")) }
                }
                Text(strings.t("خط الطباعة (PDF)", "PDF Font"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("cairo" to "Cairo", "tajawal" to "Tajawal", "honor" to "Honor Sans", "arial" to "Arial", "tahoma" to "Tahoma", "times" to "Times")) { (k, lbl) ->
                        FilterChip(
                            selected = ps.printFont == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(printFont = k)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Text(strings.t("حجم خط الطباعة", "Print Font Scale"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(85 to "صغير", 100 to "متوسط", 115 to "كبير", 130 to "كبير جداً").forEach { (pct, lbl) ->
                        FilterChip(
                            selected = ps.printFontScale == pct,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(printFontScale = pct)) } },
                            label = { Text(lbl) }
                        )
                    }
                }
            }
        }

        // Content & Header Toggles + Currency Statement Options + Per-Doc Stamps
        StyledAppCard(Modifier.fillMaxWidth()) {
            val allCurNames = remember(settings.currencies) { settings.currencies.map { it.name.trim() }.filter { it.isNotBlank() } }
            val selectedCurs = remember(ps.currencyStmtList, allCurNames) {
                ps.currencyStmtList ?: allCurNames
            }
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.t("خيارات الكشف والأختام", "Header, Meta & Stamps"), fontWeight = FontWeight.Bold)
                SettingSwitchRow(strings.t("عرض بيانات رأس الصفحة والشعار", "Show Header & Logo"), ps.showHeaderData) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(showHeaderData = on)) }
                }
                SettingSwitchRow(strings.t("تكرار الترويسة", "Repeat Header"), ps.repeatHeader) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(repeatHeader = on)) }
                }
                SettingSwitchRow(strings.t("عرض تاريخ الطباعة", "Show Print Date"), ps.showPrintDate) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(showPrintDate = on)) }
                }
                SettingSwitchRow(strings.t("عرض الوقت في الطباعة", "Show Print Time"), ps.showPrintTime) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(showPrintTime = on)) }
                }
                SettingSwitchRow(strings.t("عرض رقم جوال الحساب", "Show Account Phone"), ps.showPhone) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(showPhone = on)) }
                }
                SettingSwitchRow(strings.t("عرض ملاحظة الحساب", "Show Account Note"), ps.showAccountNote) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(showAccountNote = on)) }
                }
                SettingSwitchRow(strings.t("إضافة ملاحظة أسفل كشف الحساب", "Add Note on Statement"), ps.addNoteOnStatement) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(addNoteOnStatement = on)) }
                }
                HorizontalDivider()
                Text(strings.t("كشف العملات للطباعة", "Currency Statement Print Settings"), fontWeight = FontWeight.Bold)
                SettingSwitchRow(strings.t("عرض الترويسة في كشف العملات", "Currency Statement Header"), ps.currencyStmtHeader) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(currencyStmtHeader = on)) }
                }
                SettingSwitchRow(strings.t("عرض التجميع أسفل كشف العملات", "Currency Statement Summary"), ps.currencyStmtSummary) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(currencyStmtSummary = on)) }
                }
                Text(strings.t("العملات المطبوعة", "Printed Currencies"), style = MaterialTheme.typography.labelLarge)
                settings.currencies.forEach { cur ->
                    val nm = cur.name.trim()
                    val checked = nm in selectedCurs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val next = selectedCurs.toMutableList()
                                if (checked) next.removeAll { it == nm } else if (nm !in next) next.add(nm)
                                viewModel.updateSettings { it.copy(printing = it.printing.copy(currencyStmtList = next)) }
                            }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { on ->
                                val next = selectedCurs.toMutableList()
                                if (on && nm !in next) next.add(nm) else if (!on) next.removeAll { it == nm }
                                viewModel.updateSettings { it.copy(printing = it.printing.copy(currencyStmtList = next)) }
                            }
                        )
                        Text("${cur.name} (${cur.symbol})", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                HorizontalDivider()
                StampModeSelector(strings.t("الختم والتوقيع على السندات", "Voucher Stamp"), ps.stampSettings.vouchers) { v ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(stampSettings = it.printing.stampSettings.copy(vouchers = v))) }
                }
                StampModeSelector(strings.t("الختم والتوقيع على الفواتير", "Invoice Stamp"), ps.stampSettings.invoices) { v ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(stampSettings = it.printing.stampSettings.copy(invoices = v))) }
                }
                StampModeSelector(strings.t("الختم والتوقيع على الكشف", "Statement Stamp"), ps.stampSettings.statement) { v ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(stampSettings = it.printing.stampSettings.copy(statement = v))) }
                }
                StampModeSelector(strings.t("الختم والتوقيع على المصادقة", "Auth Stamp"), ps.stampSettings.balance) { v ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(stampSettings = it.printing.stampSettings.copy(balance = v))) }
                }
            }
        }

        // Luxury Printing Card (Full clone of __luxuryPrintCard in admin/app.js)
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SettingSwitchRow(strings.t("تفعيل الطباعة المرفهة (Luxury)", "Luxury Print Styling"), lux.on) { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(on = on))) }
                }
                Text(
                    strings.t(
                        "عند التفعيل تتحكم الطباعة المرفهة بالشكل والألوان وشكل الورقة في كل الكشوفات والسندات، وتتعطل ألوان الطباعة العادية.",
                        "When enabled, Luxury Print controls layout, borders, text/number colors, and paper finish."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(strings.t("قوالب جاهزة (تتجاوز الخيارات الأخرى)", "Preset Templates"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val templates = listOf(
                        "" to "بدون قالب",
                        "1" to "1: ذهبي فاخر",
                        "2" to "2: زجاجي حديث",
                        "3" to "3: مينيمال نظيف",
                        "4" to "4: نيوبروتاليزم",
                        "5" to "5: شبكة بينتو",
                        "6" to "6: مادة 3",
                        "7" to "7: مستقبلي داكن",
                        "8" to "8: تحريري أنيق",
                        "9" to "9: كلاسيكي مزخرف",
                        "10" to "10: هجين عصري"
                    )
                    items(templates, key = { "tpl_${it.first}" }) { (k, lbl) ->
                        FilterChip(
                            selected = lux.tpl == k,
                            onClick = {
                                viewModel.updateSettings { st ->
                                    val curLux = st.printing.lux
                                    val updatedLux = applyLuxuryTemplate(curLux, k)
                                    st.copy(printing = st.printing.copy(lux = updatedLux))
                                }
                            },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("نوع التصميم للخلايا والأعمدة (15 نمط)", "Cell Design Style"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val luxStyles = listOf(
                        "neu" to "Neumorphism",
                        "skeu" to "Skeuomorphism",
                        "glass" to "Glassmorphism",
                        "fluent" to "Fluent Design",
                        "flat" to "Flat Design",
                        "m3" to "Material Design 3",
                        "minimal" to "Minimal UI",
                        "neobrut" to "Neobrutalism",
                        "luxury" to "Luxury UI",
                        "bento" to "Bento Grid",
                        "editorial" to "Editorial UI",
                        "classic" to "Classic UI",
                        "futuristic" to "Futuristic UI",
                        "3d" to "3D UI",
                        "hybrid" to "Hybrid UI"
                    )
                    items(luxStyles, key = { "lst_${it.first}" }) { (k, lbl) ->
                        FilterChip(
                            selected = lux.style == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(style = k, tpl = ""))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("شكل الإطار للخلايا والأعمدة", "Cell Frame Shape"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("box" to "مربع", "soft" to "زوايا خفيفة", "rounded" to "مستدير", "corners" to "دائري الزوايا", "capsule" to "كبسولي", "circle" to "دائري")) { (k, lbl) ->
                        FilterChip(
                            selected = lux.shape == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(shape = k, tpl = ""))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("نمط خط الإطار للخلايا والأعمدة", "Cell Border Line"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("solid" to "متصل", "dashed" to "متقطع", "dotted" to "منقط", "double" to "مزدوج", "groove" to "محفور", "ridge" to "بارز", "inset" to "داخلي", "outset" to "خارجي")) { (k, lbl) ->
                        FilterChip(
                            selected = lux.line == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(line = k, tpl = ""))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("شكل الأزرار للخلايا والأعمدة", "Header Button Style"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("classic" to "كلاسيكي مزخرف", "rounded" to "مستطيل دائري", "simple" to "بسيط").forEach { (k, lbl) ->
                        FilterChip(
                            selected = lux.btn == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(btn = k, tpl = ""))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("قوالب أزرار الخلايا (تضاف فوق)", "Cell Button Templates"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("" to "بدون", "pill" to "حبوب", "grad" to "تدرج داكن", "outline" to "إطار شفاف", "raised" to "بارز مع ظل", "glass" to "زجاجي", "neon" to "نيون")) { (k, lbl) ->
                        FilterChip(
                            selected = lux.btnT == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(btnT = k))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("قوالب الأعمدة (تضاف فوق)", "Column Templates"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("" to "بدون", "zebra" to "تخطيط متناوب", "firstAccent" to "عمود أول مميز", "vsep" to "فواصل عمودية فقط", "hsep" to "فواصل أفقية فقط", "gold" to "إطار ذهبي", "tint" to "ألوان لكم وعليكم")) { (k, lbl) ->
                        FilterChip(
                            selected = lux.colT == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(colT = k))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                Text(strings.t("عناصر عصرية (تضاف فوق)", "Modern Templates"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("" to "بدون", "rowcards" to "صفوف منفصلة", "floating" to "جدول عائم", "gradbar" to "شريط عنوان متدرج", "pillsum" to "إجمالي حبة", "mono" to "أحادي أنيق", "dark" to "داكن")) { (k, lbl) ->
                        FilterChip(
                            selected = lux.modT == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(modT = k))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                SettingSwitchRow(strings.t("الظلال للإطار والخلايا والأعمدة", "Table Shadows"), lux.shadow == "on") { on ->
                    viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(shadow = if (on) "on" else "off", tpl = ""))) }
                }

                Text(strings.t("سمك الإطار للخلايا والأعمدة", "Border Thickness"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("thin" to "رفيع", "medium" to "متوسط", "thick" to "سميك").forEach { (k, lbl) ->
                        FilterChip(
                            selected = lux.thick == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(thick = k, tpl = ""))) } },
                            label = { Text(lbl) }
                        )
                    }
                }

                HorizontalDivider()
                LuxColorFieldRow(
                    title = strings.t("لون النصوص العادية", "Normal Text Color"),
                    currentHex = lux.txtColor,
                    defaultHex = "#111827",
                    presets = listOf("#111827", "#1E293B", "#0F172A", "#1E3A8A", "#6B1A2F", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(txtColor = hex))) } }

                Text(strings.t("مبالغ «لكم»", "Credit («لكم») Colors"), fontWeight = FontWeight.Bold)
                LuxColorFieldRow(
                    title = strings.t("لون نص مبلغ «لكم»", "Credit Text Color"),
                    currentHex = lux.txtLColor,
                    defaultHex = "#15803d",
                    presets = listOf("#15803d", "#16a34a", "#047857", "#0f766e", "#1e40af", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(txtLColor = hex))) } }
                LuxColorFieldRow(
                    title = strings.t("لون أرقام المبالغ «لكم»", "Credit Amount Color"),
                    currentHex = lux.numLColor,
                    defaultHex = "#15803d",
                    presets = listOf("#15803d", "#16a34a", "#047857", "#0f766e", "#1e40af", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(numLColor = hex))) } }

                Text(strings.t("مبالغ «عليكم»", "Debit («عليكم») Colors"), fontWeight = FontWeight.Bold)
                LuxColorFieldRow(
                    title = strings.t("لون نص مبلغ «عليكم»", "Debit Text Color"),
                    currentHex = lux.txtOColor,
                    defaultHex = "#dc2626",
                    presets = listOf("#dc2626", "#b91c1c", "#e11d48", "#be123c", "#991b1b", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(txtOColor = hex))) } }
                LuxColorFieldRow(
                    title = strings.t("لون أرقام المبالغ «عليكم»", "Debit Amount Color"),
                    currentHex = lux.numOColor,
                    defaultHex = "#dc2626",
                    presets = listOf("#dc2626", "#b91c1c", "#e11d48", "#be123c", "#991b1b", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(numOColor = hex))) } }

                Text(strings.t("المبالغ الإجمالية", "Totals Colors"), fontWeight = FontWeight.Bold)
                LuxColorFieldRow(
                    title = strings.t("لون نص الإجماليات", "Totals Text Color"),
                    currentHex = lux.txtTColor,
                    defaultHex = "#0f172a",
                    presets = listOf("#0f172a", "#1e3a8a", "#6B1A2F", "#15803d", "#b45309", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(txtTColor = hex))) } }
                LuxColorFieldRow(
                    title = strings.t("لون أرقام الإجماليات", "Totals Amount Color"),
                    currentHex = lux.numTColor,
                    defaultHex = "#0f172a",
                    presets = listOf("#0f172a", "#1e3a8a", "#6B1A2F", "#15803d", "#b45309", "#000000")
                ) { hex -> viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(numTColor = hex))) } }

                HorizontalDivider()
                Text(strings.t("شكل الورقة", "Paper Style"), fontWeight = FontWeight.Bold)
                Text(strings.t("لون الورقة", "Paper Tint"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("#ffffff" to "أبيض", "#fffbeb" to "كريمي", "#f8fafc" to "ثلجي", "#f0fdf4" to "نعناعي", "#fef2f2" to "وردي خفيف", "#0b1220" to "ليلي")) { (hex, lbl) ->
                        FilterChip(
                            selected = lux.paperColor.equals(hex, ignoreCase = true),
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(paperColor = hex))) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Text(strings.t("إطار الورقة", "Page Frame"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("" to "بدون", "thin" to "رفيع", "thick" to "سميك", "double" to "مزدوج").forEach { (k, lbl) ->
                        FilterChip(
                            selected = lux.frame == k,
                            onClick = { viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(frame = k))) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { luxBgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f)
                    ) { Text(strings.t("خلفية الورقة", "Watermark Image")) }
                    if (lux.bgPath.isNotBlank()) {
                        if (File(lux.bgPath).exists()) {
                            Image(
                                painter = rememberAsyncImagePainter(File(lux.bgPath)),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(6.dp)).alpha(0.85f)
                            )
                        }
                        TextButton(onClick = {
                            viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(bgPath = ""))) }
                        }) { Text(strings.delete) }
                    }
                }
                Text(strings.t("درجة وضوح خلفية الورقة: ${lux.clear}%", "Watermark Opacity: ${lux.clear}%"), style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = lux.clear.coerceIn(0, 100).toFloat(),
                    onValueChange = { v ->
                        viewModel.updateSettings { it.copy(printing = it.printing.copy(lux = it.printing.lux.copy(clear = v.roundToInt()))) }
                    },
                    valueRange = 0f..100f
                )
            }
        }
    }
}

private fun applyLuxuryTemplate(current: LuxuryPrintSettings, tpl: String): LuxuryPrintSettings {
    return when (tpl) {
        "1" -> current.copy(tpl = "1", style = "luxury", shape = "corners", line = "solid", btn = "classic", shadow = "on", thick = "medium", on = true)
        "2" -> current.copy(tpl = "2", style = "glass", shape = "rounded", line = "solid", btn = "rounded", shadow = "on", thick = "thin", on = true)
        "3" -> current.copy(tpl = "3", style = "minimal", shape = "soft", line = "solid", btn = "simple", shadow = "off", thick = "thin", on = true)
        "4" -> current.copy(tpl = "4", style = "neobrut", shape = "box", line = "solid", btn = "simple", shadow = "on", thick = "thick", on = true)
        "5" -> current.copy(tpl = "5", style = "bento", shape = "rounded", line = "solid", btn = "rounded", shadow = "on", thick = "thin", on = true)
        "6" -> current.copy(tpl = "6", style = "m3", shape = "corners", line = "solid", btn = "rounded", shadow = "off", thick = "medium", on = true)
        "7" -> current.copy(tpl = "7", style = "futuristic", shape = "soft", line = "dotted", btn = "simple", shadow = "on", thick = "thin", on = true)
        "8" -> current.copy(tpl = "8", style = "editorial", shape = "box", line = "double", btn = "simple", shadow = "off", thick = "thin", on = true)
        "9" -> current.copy(tpl = "9", style = "classic", shape = "box", line = "double", btn = "classic", shadow = "off", thick = "medium", on = true)
        "10" -> current.copy(tpl = "10", style = "hybrid", shape = "rounded", line = "dashed", btn = "rounded", shadow = "on", thick = "medium", on = true)
        else -> current.copy(tpl = "")
    }
}

@Composable
private fun LuxColorFieldRow(
    title: String,
    currentHex: String,
    defaultHex: String,
    presets: List<String>,
    onApply: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var hexText by remember(currentHex) { mutableStateOf(currentHex) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(presets, key = { "$title-$it" }) { hex ->
                val sel = currentHex.equals(hex, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(parseHexColor(hex))
                        .border(if (sel) 2.5.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.LightGray, CircleShape)
                        .clickable {
                            hexText = hex
                            onApply(hex)
                        }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = hexText,
                onValueChange = { hexText = it },
                singleLine = true,
                label = { Text("#RRGGBB") },
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = {
                if (Regex("^#[0-9a-fA-F]{6}$").matches(hexText.trim())) onApply(hexText.trim())
            }) { Text(strings.t("تطبيق", "Apply")) }
            TextButton(onClick = {
                hexText = defaultHex
                onApply(defaultHex)
            }) { Text(strings.t("إعادة الافتراضي", "Reset")) }
        }
    }
}

@Composable
internal fun SettingSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun StampModeSelector(title: String, current: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("sign" to "التوقيع", "stamp" to "الختم", "all" to "الكل", "none" to "لا شيء").forEach { (k, lbl) ->
                FilterChip(selected = current == k, onClick = { onSelect(k) }, label = { Text(lbl) })
            }
        }
    }
}
