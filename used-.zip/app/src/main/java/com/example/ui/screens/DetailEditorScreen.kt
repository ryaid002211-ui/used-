package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailEditorScreen(
    detailId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val stored = uiState.snapshot.details.firstOrNull { it.id == detailId }
    if (stored == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    var record by remember(stored) { mutableStateOf(stored) }
    var unlockEdit by remember { mutableStateOf(false) }
    var moneyEditedManually by remember(stored.id) { mutableStateOf(false) }
    var showFilterPicker by remember { mutableStateOf(false) }

    val fd = remember(record.formData) { DetailCalculator.recalculate(record.formData) }
    val currencyNames = remember(uiState.settings.currencies) {
        uiState.settings.currencies.map { it.name }.filter { !it.contains("دولار") }
    }

    fun updateForm(nextForm: DetailFormData) {
        val cleanedForm = if (moneyEditedManually) nextForm.copy(moneyDaysSnapshot = emptyList()) else nextForm
        record = record.copy(formData = DetailCalculator.recalculate(cleanedForm))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(record.initDetail.ifBlank { strings.detail }, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val toPrint = record.copy(formData = fd)
                            val html = PrintReportBuilders.buildDetailHtml(toPrint, uiState.settings)
                            viewModel.printHtmlReport(activity, toPrint.initDetail, html)
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = strings.print)
                    }
                    Button(
                        onClick = {
                            val preparedForm = if (moneyEditedManually) fd.copy(moneyDaysSnapshot = emptyList()) else fd
                            viewModel.saveDetailRecord(record.copy(formData = preparedForm), pushToClock = true)
                        },
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .heightIn(min = 48.dp)
                            .testTag("push_detail_to_clock_btn")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.t("إلى المراقب", "To Clock"))
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            // Top Toolbar matching HTML nf-toolbar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (unlockEdit) {
                        Button(
                            onClick = { unlockEdit = false },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("detail_toggle_edit_btn")
                        ) {
                            Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("🔒 إغلاق التعديل اليدوي", maxLines = 1)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { unlockEdit = true },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("detail_toggle_edit_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("🔓 تعديل أي بيانات", maxLines = 1)
                        }
                    }

                    if (fd.manualOverrides.isNotEmpty()) {
                        FilledTonalButton(
                            onClick = { updateForm(fd.copy(manualOverrides = emptyMap())) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إلغاء اليدوي")
                        }
                    }
                }
            }

            // Summary KPI Strip
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryStatCard(strings.t("جملة البيع", "Grand Sales"), fmt(fd.calcSGrand), modifier = Modifier.weight(1f))
                    SummaryStatCard(strings.t("المطلوب", "Required"), fmt(fd.calcMidTotal), modifier = Modifier.weight(1f))
                    SummaryStatCard(
                        strings.t("الفارق", "Diff"),
                        fmt(fd.calcChkDiff),
                        color = if (abs(fd.calcChkDiff) < 1e-6) AppColors.CreditGreen else AppColors.DebitRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Header Info Table (Name + From Date + To Date with Calendars)
            item {
                DetailHeaderTableCard(
                    record = record,
                    onUpdateRecord = { record = it }
                )
            }

            // Specialty Assignment + Optional Weekly Filter Re-sync
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = record.specialtyId,
                        onAssign = { record = record.copy(specialtyId = it) },
                        onAddSpecialty = { name, amt -> viewModel.addHomeSpecialty(name, amt) },
                        modifier = Modifier.weight(1f)
                    )
                    if (uiState.snapshot.weeklyFilters.isNotEmpty()) {
                        Box {
                            OutlinedButton(
                                onClick = { showFilterPicker = true },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("من فلتر", maxLines = 1)
                            }
                            DropdownMenu(expanded = showFilterPicker, onDismissRequest = { showFilterPicker = false }) {
                                uiState.snapshot.weeklyFilters.forEach { wf ->
                                    DropdownMenuItem(
                                        text = { Text("${wf.name} (${DateHelper.displaySlash(wf.fromDate)})") },
                                        onClick = {
                                            showFilterPicker = false
                                            val wCalc = WeeklyFilterCalculator.calculate(wf)
                                            val saleGross = wf.salesRows.sumOf { WesternDigits.num(it.saleGross) }
                                            val outAmt = wf.salesRows.sumOf { WesternDigits.num(it.outAmt) }
                                            val newSale = if (abs(saleGross - outAmt) > 1e-6) saleGross - outAmt else wCalc.totSalesCash
                                            val keepName = fd.receivedRows.firstOrNull { it.name.isNotBlank() }?.name ?: ""
                                            val newPrev = listOf(DetailReceivedRow(name = keepName, amount = WesternDigits.rawNumberString(wCalc.totSalesWeekly)))
                                            val newMoney = listOf(
                                                DetailMoneyRow(label = "يمني", amount = WesternDigits.rawNumberString(wCalc.totYemeni), value = WesternDigits.rawNumberString(wCalc.totYemeni)),
                                                DetailMoneyRow(label = "سعودي", amount = WesternDigits.rawNumberString(wCalc.totSaudiAmt), value = WesternDigits.rawNumberString(wCalc.totSaudiExch)),
                                                DetailMoneyRow(label = "عماني", amount = WesternDigits.rawNumberString(wCalc.totOmaniAmt), value = WesternDigits.rawNumberString(wCalc.totOmaniExch)),
                                                DetailMoneyRow(label = "درهم", amount = WesternDigits.rawNumberString(wCalc.totDirhamAmt), value = WesternDigits.rawNumberString(wCalc.totDirhamExch))
                                            )
                                            val mDays = wf.moneyRows.filter { it.date.isNotBlank() }.flatMap { r ->
                                                listOf(
                                                    DetailMoneyDayItem("يمني", WesternDigits.num(r.yemeni), 1.0, WesternDigits.num(r.yemeni), r.date, r.day),
                                                    DetailMoneyDayItem("سعودي", WesternDigits.num(r.saudiAmt), if (WesternDigits.num(r.saudiAmt) > 0) WesternDigits.num(r.saudiExch) / WesternDigits.num(r.saudiAmt) else 1.0, WesternDigits.num(r.saudiExch), r.date, r.day),
                                                    DetailMoneyDayItem("عماني", WesternDigits.num(r.omaniAmt), if (WesternDigits.num(r.omaniAmt) > 0) WesternDigits.num(r.omaniExch) / WesternDigits.num(r.omaniAmt) else 1.0, WesternDigits.num(r.omaniExch), r.date, r.day),
                                                    DetailMoneyDayItem("درهم", WesternDigits.num(r.dirhamAmt), if (WesternDigits.num(r.dirhamAmt) > 0) WesternDigits.num(r.dirhamExch) / WesternDigits.num(r.dirhamAmt) else 1.0, WesternDigits.num(r.dirhamExch), r.date, r.day)
                                                ).filter { it.value > 0.0 }
                                            }
                                            moneyEditedManually = false
                                            record = record.copy(
                                                autoFilterId = wf.id,
                                                initFilter = wf.name,
                                                initDateFrom = wf.fromDate.ifBlank { record.initDateFrom },
                                                initDateTo = wf.toDate.ifBlank { record.initDateTo },
                                                formData = DetailCalculator.recalculate(
                                                    fd.copy(
                                                        qQty = WesternDigits.rawNumberString(wCalc.totQty),
                                                        qCash = WesternDigits.rawNumberString(wCalc.totCashQty),
                                                        qDebt = WesternDigits.rawNumberString(wCalc.totDebtQty),
                                                        qOut = WesternDigits.rawNumberString(wCalc.totExpQty),
                                                        sSale = WesternDigits.rawNumberString(newSale),
                                                        sWeekly = WesternDigits.rawNumberString(wCalc.totSalesWeeklySales),
                                                        wValue = WesternDigits.rawNumberString(wCalc.totSalesPrev),
                                                        receivedRows = newPrev,
                                                        moneyRows = newMoney,
                                                        moneyDaysSnapshot = mDays
                                                    )
                                                )
                                            )
                                            viewModel.emitMessage("تم استيراد إجماليات الفلتر «${wf.name}»")
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Adaptive Grid: Side-by-side on wide screens, stacked on phones
            item {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    if (maxWidth >= 680.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(Modifier.weight(1f)) {
                                DetailQtyCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                            }
                            Column(Modifier.weight(1.35f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                DetailSalesSplitCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                                DetailReceivedCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                                DetailDebtTableCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            DetailQtyCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                            DetailSalesSplitCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                            DetailReceivedCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                            DetailDebtTableCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
                        }
                    }
                }
            }

            // Mid Gather Table (تجميع البيع)
            item {
                DetailMidGatherCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
            }

            // Money & Withdraw Table (العملات والسحب)
            item {
                DetailMoneyTableCard(
                    fd = fd,
                    unlockEdit = unlockEdit,
                    currencyNames = currencyNames,
                    onFormChange = ::updateForm,
                    onMoneyManualTouch = { moneyEditedManually = true }
                )
            }

            // Final Reconciliation Check Table (المطابقة النهائية والفارق)
            item {
                DetailCheckMatchCard(fd = fd, unlockEdit = unlockEdit, onFormChange = ::updateForm)
            }

            // General Note
            item {
                DetailTableShell(title = "ملاحظة عامة") {
                    OutlinedTextField(
                        value = fd.note,
                        onValueChange = { updateForm(fd.copy(note = it)) },
                        placeholder = { Text("أضف ملاحظة...") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp)
                    )
                }
            }

            // Footer Bar (حفظ التفصيل + ترحيل للمراقب)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val preparedForm = if (moneyEditedManually) fd.copy(moneyDaysSnapshot = emptyList()) else fd
                            viewModel.saveDetailRecord(record.copy(formData = preparedForm), pushToClock = false)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppColors.CreditGreen),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 50.dp)
                            .testTag("detail_save_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("💾 حفظ التفصيل", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            val preparedForm = if (moneyEditedManually) fd.copy(moneyDaysSnapshot = emptyList()) else fd
                            viewModel.saveDetailRecord(record.copy(formData = preparedForm), pushToClock = true)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 50.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("حفظ وترحيل للمراقب", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
