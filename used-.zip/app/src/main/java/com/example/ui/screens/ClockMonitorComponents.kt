package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.AppDatePickerDialog
import com.example.ui.components.CreditDebitPill
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import kotlin.math.abs

@Composable
internal fun ClockSummaryCardsRow(
    credit: Double,
    debit: Double,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val net = credit - debit
    val creditColor = if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
    val debitColor = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
    val netLabel = when {
        net > 1e-9 -> strings.t("الباقي لكم", "Net Credit")
        net < -1e-9 -> strings.t("الباقي عليكم", "Net Debt")
        else -> strings.t("لا يوجد رصيد", "Balanced")
    }
    val netColor = when {
        net > 1e-9 -> MaterialTheme.colorScheme.onSurface
        net < -1e-9 -> debitColor
        else -> MaterialTheme.colorScheme.onSurface
    }
    val borderStroke = BorderStroke(
        width = 1.4.dp,
        color = if (settings.dark) tokens.borderColor else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ClockSummaryCard(
            value = fmt(debit),
            label = strings.t("الإجمالي عليكم", "Total Debit"),
            valueColor = debitColor,
            border = borderStroke,
            modifier = Modifier.weight(1f)
        )
        ClockSummaryCard(
            value = fmt(credit),
            label = strings.t("الإجمالي لكم", "Total Credit"),
            valueColor = creditColor,
            border = borderStroke,
            modifier = Modifier.weight(1f)
        )
        ClockSummaryCard(
            value = fmt(abs(net)),
            label = netLabel,
            valueColor = netColor,
            border = borderStroke,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ClockSummaryCard(
    value: String,
    label: String,
    valueColor: Color,
    border: BorderStroke,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = border,
        shadowElevation = tokens.elevation
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = value,
                color = valueColor,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Text(
                text = label,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
internal fun ClockDarkSortBar(
    sortField: String,
    sortAsc: Boolean,
    onSortFieldChange: (String) -> Unit,
    onSortDirChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var showSortDropdown by remember { mutableStateOf(false) }

    val sortOptions = listOf(
        Triple("date", strings.t("التاريخ", "Date"), Icons.Default.CalendarMonth),
        Triple("name", strings.t("الأبجدية", "Name"), Icons.Default.SortByAlpha),
        Triple("amount", strings.t("المبلغ", "Amount"), Icons.Default.Payments)
    )
    val selectedOption = sortOptions.firstOrNull { it.first == sortField } ?: sortOptions.first()

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
            BorderStroke(1.dp, tokens.borderColor)
        } else null,
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.heightIn(min = 36.dp)
            ) {
                Box(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.t("ترتيب حسب:", "Sort:"),
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            Box {
                Surface(
                    onClick = { showSortDropdown = true },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.6f)),
                    modifier = Modifier.heightIn(min = 36.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = selectedOption.third,
                            contentDescription = null,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = selectedOption.second,
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                DropdownMenu(
                    expanded = showSortDropdown,
                    onDismissRequest = { showSortDropdown = false }
                ) {
                    sortOptions.forEach { (key, label, icon) ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = label,
                                    fontWeight = if (key == sortField) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            leadingIcon = { Icon(icon, contentDescription = null) },
                            onClick = {
                                onSortFieldChange(key)
                                showSortDropdown = false
                            }
                        )
                    }
                }
            }

            ClockSortDirButton(
                label = "↑ ${strings.t("تصاعدي", "Asc")}",
                selected = sortAsc,
                onClick = { onSortDirChange(true) },
                modifier = Modifier.weight(1f)
            )
            ClockSortDirButton(
                label = "↓ ${strings.t("تنازلي", "Desc")}",
                selected = !sortAsc,
                onClick = { onSortDirChange(false) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ClockSortDirButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = Color.Transparent,
        border = BorderStroke(
            1.dp,
            if (selected) tokens.borderColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = modifier.heightIn(min = 38.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (selected) tokens.darkTileBrush
                    else Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                )
                .padding(horizontal = 6.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = if (selected) tokens.darkTileContent else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
internal fun ClockDarkDateRangeBar(
    fromDate: String,
    toDate: String,
    onRangeChange: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var pickingTarget by remember { mutableStateOf<String?>(null) }

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
            BorderStroke(1.dp, tokens.borderColor)
        } else null,
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, -1)
                    onRangeChange(nf, nt)
                },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = tokens.barButtonBg,
                border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
                    BorderStroke(1.dp, tokens.barDivider)
                } else null,
                modifier = Modifier
                    .size(44.dp)
                    .testTag("date_shift_prev_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.t("الفترة السابقة", "Previous"),
                        tint = tokens.barContent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            ClockDatePillButton(
                dateIso = fromDate,
                placeholder = strings.from,
                onClick = { pickingTarget = "from" },
                modifier = Modifier
                    .weight(1f)
                    .testTag("date_from_input")
            )

            Text(
                text = strings.to,
                color = tokens.darkTileContent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )

            ClockDatePillButton(
                dateIso = toDate,
                placeholder = strings.to,
                onClick = { pickingTarget = "to" },
                modifier = Modifier
                    .weight(1f)
                    .testTag("date_to_input")
            )

            Surface(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, 1)
                    onRangeChange(nf, nt)
                },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = tokens.barButtonBg,
                border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
                    BorderStroke(1.dp, tokens.barDivider)
                } else null,
                modifier = Modifier
                    .size(44.dp)
                    .testTag("date_shift_next_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = strings.t("الفترة التالية", "Next"),
                        tint = tokens.barContent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    pickingTarget?.let { target ->
        AppDatePickerDialog(
            initialIso = if (target == "from") fromDate else toDate,
            onPicked = { picked ->
                if (target == "from") onRangeChange(picked, toDate)
                else onRangeChange(fromDate, picked)
                pickingTarget = null
            },
            onDismiss = { pickingTarget = null }
        )
    }
}

@Composable
private fun ClockDatePillButton(
    dateIso: String,
    placeholder: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)),
        modifier = modifier.heightIn(min = 42.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CalendarMonth,
                contentDescription = null,
                tint = tokens.iconTileTint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = if (dateIso.isNotBlank()) DateHelper.displaySlash(dateIso) else placeholder,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun ClockLedgerTableHeader(
    showQtyColumn: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
            BorderStroke(1.dp, tokens.borderColor)
        } else null,
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TableHeaderCell(
                text = strings.t("النوع", "Type"),
                color = tokens.darkTileContent,
                modifier = Modifier.weight(if (showQtyColumn) 0.58f else 0.65f)
            )
            TableHeaderCell(
                text = strings.t("التاريخ", "Date"),
                color = tokens.darkTileContent,
                modifier = Modifier.weight(if (showQtyColumn) 1.02f else 1.08f)
            )
            TableHeaderCell(
                text = strings.t("المبلغ", "Amount"),
                color = tokens.darkTileContent,
                modifier = Modifier.weight(if (showQtyColumn) 0.92f else 0.92f)
            )
            if (showQtyColumn) {
                TableHeaderCell(
                    text = strings.t("الكمية", "Qty"),
                    color = tokens.darkTileContent,
                    modifier = Modifier.weight(0.62f)
                )
            }
            TableHeaderCell(
                text = strings.t("البيان", "Details"),
                color = tokens.darkTileContent,
                modifier = Modifier.weight(if (showQtyColumn) 1.32f else 1.50f)
            )
            TableHeaderCell(
                text = strings.t("الرصيد", "Balance"),
                color = tokens.darkTileContent,
                modifier = Modifier.weight(if (showQtyColumn) 0.94f else 0.92f)
            )
        }
    }
}

@Composable
private fun TableHeaderCell(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Text(
        text = text,
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.padding(horizontal = 2.dp)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun ClockLedgerTableRow(
    entry: ClockEntry,
    runningBalance: Double,
    showQtyColumn: Boolean,
    isSelected: Boolean,
    specialtyName: String,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val haptic = LocalHapticFeedback.current
    val isCredit = entry.dir != "عليكم"
    val creditColor = if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
    val debitColor = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
    val dirColor = if (isCredit) creditColor else debitColor
    val balColor = if (runningBalance >= 0.0) creditColor else debitColor

    val displayDate = DateHelper.displaySlash(entry.date.ifBlank { entry.to })
    val mainDesc = entry.name.ifBlank { entry.note }.ifBlank { "-" }
    val extraNote = if (entry.name.isNotBlank() && entry.note.isNotBlank() && entry.note != entry.name) {
        entry.note
    } else ""
    val periodSub = if (entry.to.isNotBlank() && entry.to != entry.date && entry.date.isNotBlank()) {
        "من ${entry.date} إلى ${entry.to}"
    } else if (entry.from.isNotBlank() && entry.to.isNotBlank() && entry.from != entry.to) {
        "من ${entry.from} إلى ${entry.to}"
    } else ""

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else tokens.borderColor.copy(alpha = 0.85f)
        ),
        shadowElevation = 0.5.dp,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isCredit) "لكم" else "عليكم",
                color = dirColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier
                    .weight(if (showQtyColumn) 0.58f else 0.65f)
                    .padding(horizontal = 2.dp)
            )

            Column(
                modifier = Modifier
                    .weight(if (showQtyColumn) 1.02f else 1.08f)
                    .padding(horizontal = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = displayDate,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
                if (entry.time.isNotBlank()) {
                    Text(
                        text = entry.time,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }

            Text(
                text = fmt(abs(entry.amount)),
                color = dirColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(0.92f)
                    .padding(horizontal = 2.dp)
            )

            if (showQtyColumn) {
                Text(
                    text = fmt(entry.qty),
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(0.62f)
                        .padding(horizontal = 2.dp)
                )
            }

            Column(
                modifier = Modifier
                    .weight(if (showQtyColumn) 1.32f else 1.50f)
                    .padding(horizontal = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = mainDesc,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (extraNote.isNotBlank()) {
                    Text(
                        text = extraNote,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (periodSub.isNotBlank()) {
                    Text(
                        text = periodSub,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (specialtyName.isNotBlank()) {
                    Text(
                        text = specialtyName,
                        color = tokens.iconTileTint,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Text(
                text = fmt(runningBalance),
                color = balColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(if (showQtyColumn) 0.94f else 0.92f)
                    .padding(horizontal = 2.dp)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun ClockCurrencyEntryCard(
    entry: ClockEntry,
    rows: List<TsRowCurrency>,
    headerTitle: String,
    isSelected: Boolean,
    specialtyName: String,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val haptic = LocalHapticFeedback.current
    val isCredit = entry.dir != "عليكم"
    val creditColor = if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
    val debitColor = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
    val dirColor = if (isCredit) creditColor else debitColor
    val dateLabel = if (entry.to.isNotBlank() && entry.to != entry.date && entry.date.isNotBlank()) {
        "${entry.date} → ${entry.to}"
    } else {
        entry.date.ifBlank { entry.to }
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else tokens.borderColor.copy(alpha = 0.85f)
        ),
        shadowElevation = tokens.elevation,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = headerTitle,
                    color = dirColor,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = dateLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }

            if (rows.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(tokens.darkTileBrush)
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TableHeaderCell("اسم العملة", Modifier.weight(1.05f), color = tokens.darkTileContent)
                            TableHeaderCell("مبلغ العملة", Modifier.weight(1f), color = tokens.darkTileContent)
                            TableHeaderCell("سعر الصرف", Modifier.weight(0.95f), color = tokens.darkTileContent)
                            TableHeaderCell("ناتج الصرف", Modifier.weight(1f), color = tokens.darkTileContent)
                        }
                        rows.forEachIndexed { idx, r ->
                            if (idx > 0) {
                                HorizontalDivider(thickness = 0.6.dp, color = MaterialTheme.colorScheme.outlineVariant)
                            }
                            val rateText = if (r.cur.contains("يمني") && abs(r.r - 1.0) < 1e-6) {
                                "-"
                            } else {
                                fmt(r.r)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = r.cur,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1.05f)
                                )
                                Text(
                                    text = fmt(r.a),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = rateText,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    modifier = Modifier.weight(0.95f)
                                )
                                Text(
                                    text = fmt(r.a * r.r),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            if (entry.note.isNotBlank() || specialtyName.isNotBlank() || entry.img.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (entry.note.isNotBlank()) {
                        Text(
                            text = "البيان: ${entry.note}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (specialtyName.isNotBlank()) {
                        Text(
                            text = specialtyName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (entry.img.isNotBlank()) {
                        Icon(
                            imageVector = Icons.Default.Photo,
                            contentDescription = "صورة مرفقة",
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الإجمالي: ${fmt(entry.amount)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = dirColor
                )
                CreditDebitPill(isCredit = isCredit)
            }
        }
    }
}
