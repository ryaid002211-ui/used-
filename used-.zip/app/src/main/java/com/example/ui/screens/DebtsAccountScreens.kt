package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

@Composable
fun DebtAccountsScreen(
    cashboxId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenAccount: (DebtAccount) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val box = uiState.snapshot.debtCashboxes.firstOrNull { it.id == cashboxId }

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortField by remember { mutableStateOf(DebtSortField.DATE) }
    var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
    var selectAllChecked by remember { mutableStateOf(false) }

    var showSearch by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var showAddAcc by remember { mutableStateOf(false) }
    var editingAcc by remember { mutableStateOf<DebtAccount?>(null) }
    var menuAcc by remember { mutableStateOf<DebtAccount?>(null) }
    var transferAccRequest by remember { mutableStateOf<Pair<DebtAccount, Boolean>?>(null) } // account to isMove

    val activeSpec = uiState.settings.activeSpecialty

    val boxAccounts = remember(uiState.snapshot.debtAccounts, cashboxId) {
        uiState.snapshot.debtAccounts.filter { it.cashboxId == cashboxId }
    }

    val periodVouchers = remember(uiState.snapshot.debtVouchers, boxAccounts, activeSpec, fromDate, toDate) {
        val accIds = boxAccounts.map { it.id }.toSet()
        uiState.snapshot.debtVouchers
            .filter { it.accountId in accIds }
            .filter { matchesSpecialtyFilter(it.specialtyId, activeSpec) }
            .filter { v ->
                (fromDate.isBlank() || v.date.isBlank() || v.date >= fromDate) &&
                    (toDate.isBlank() || v.date.isBlank() || v.date <= toDate)
            }
    }

    val boxTotals = remember(periodVouchers) {
        val pay = periodVouchers.filter { it.type == "pay" }.sumOf { it.amount }
        val debt = periodVouchers.filter { it.type == "debt" }.sumOf { it.amount }
        DebtTotals(pay = pay, debt = debt)
    }

    val accTotalsMap = remember(boxAccounts, periodVouchers) {
        boxAccounts.associate { acc ->
            val vs = periodVouchers.filter { it.accountId == acc.id }
            val pay = vs.filter { it.type == "pay" }.sumOf { it.amount }
            val debt = vs.filter { it.type == "debt" }.sumOf { it.amount }
            val lastDate = vs.maxOfOrNull { it.date } ?: ""
            acc.id to Triple(DebtTotals(pay = pay, debt = debt), lastDate, acc.createdAt)
        }
    }

    val filteredAccounts = remember(boxAccounts, search, sortField, sortDir, accTotalsMap) {
        val list = boxAccounts.filter {
            search.isBlank() || it.name.contains(search, true) || it.phone.contains(search)
        }
        val sorted = when (sortField) {
            DebtSortField.DATE -> list.sortedBy { accTotalsMap[it.id]?.second?.ifBlank { "9999" } ?: "9999" }
            DebtSortField.NAME -> list.sortedBy { it.name }
            DebtSortField.AMOUNT -> list.sortedBy { abs(accTotalsMap[it.id]?.first?.net ?: 0.0) }
        }
        if (sortDir == DebtSortDir.DESC) sorted.reversed() else sorted
    }

    Scaffold(
        topBar = {
            DebtsTopLuxuryBar(
                title = box?.name ?: strings.t("الحسابات", "Accounts"),
                onBack = onBack,
                actions = {
                    DebtsHeaderActionButton("", Icons.Default.Search, onClick = { showSearch = !showSearch })
                    DebtsHeaderActionButton(strings.t("طباعة", "Print"), Icons.Default.Print, onClick = {
                        val html = PrintReportBuilders.buildDebtCashboxHtml(
                            box?.name ?: "صندوق الديون",
                            filteredAccounts,
                            periodVouchers,
                            fromDate,
                            toDate,
                            false,
                            uiState.settings
                        )
                        viewModel.printHtmlReport(activity, box?.name ?: "كشف حسابات", html)
                    })
                    DebtsHeaderActionButton(strings.t("مصادقة", "Auth"), Icons.Default.Verified, onClick = {
                        val html = PrintReportBuilders.buildDebtCashboxHtml(
                            box?.name ?: "صندوق الديون",
                            filteredAccounts,
                            periodVouchers,
                            fromDate,
                            toDate,
                            true,
                            uiState.settings
                        )
                        viewModel.printHtmlReport(activity, "مصادقة ${box?.name ?: ""}", html)
                    })
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showAddAcc = true },
                contentDescription = strings.t("حساب جديد", "New Account"),
                modifier = Modifier.testTag("add_debt_account_fab")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 92.dp)
        ) {
            item(key = "controls") {
                DebtsControlStrip(
                    specialties = uiState.settings.specialties,
                    activeSpecialty = activeSpec,
                    onSelectSpecialty = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    selectAllChecked = selectAllChecked,
                    onToggleSelectAll = { selectAllChecked = !selectAllChecked },
                    totals = boxTotals,
                    sortField = sortField,
                    sortDir = sortDir,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortDir = it },
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            item(key = "search_panel") {
                AnimatedVisibility(visible = showSearch) {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        placeholder = { Text(strings.t("بحث بالاسم أو الهاتف...", "Search accounts...")) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (filteredAccounts.isEmpty()) {
                item(key = "empty") {
                    EmptyStateView(
                        icon = Icons.Default.PeopleOutline,
                        title = strings.t("لا توجد حسابات في هذا الصندوق", "No Accounts in Cashbox")
                    )
                }
            } else {
                items(filteredAccounts, key = { it.id }) { acc ->
                    val totals = accTotalsMap[acc.id]?.first ?: DebtTotals()
                    DebtAccountCardItem(
                        account = acc,
                        net = totals.net,
                        currency = uiState.settings.defaultCurrency,
                        onClick = { onOpenAccount(acc) },
                        onLongClick = { menuAcc = acc }
                    )
                }
            }
        }
    }

    if (showAddAcc) {
        DebtAccountEditDialog(
            cashboxId = cashboxId,
            existing = null,
            viewModel = viewModel,
            onDismiss = { showAddAcc = false }
        )
    }

    editingAcc?.let { acc ->
        DebtAccountEditDialog(
            cashboxId = cashboxId,
            existing = acc,
            viewModel = viewModel,
            onDismiss = { editingAcc = null }
        )
    }

    menuAcc?.let { acc ->
        val accVouchers = periodVouchers.filter { it.accountId == acc.id }
        AlertDialog(
            onDismissRequest = { menuAcc = null },
            title = { Text(acc.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DebtMenuActionButton(strings.t("تعديل الحساب", "Edit Account"), Icons.Default.Edit) {
                        menuAcc = null
                        editingAcc = acc
                    }
                    DebtMenuActionButton(strings.t("حذف الحساب", "Delete Account"), Icons.Default.Delete, isDestructive = true) {
                        viewModel.deleteDebtAccount(acc)
                        menuAcc = null
                    }
                    DebtMenuActionButton(strings.t("طباعة كشف للفترة المحددة", "Print Statement"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildDebtStatementHtml(acc, accVouchers, false, uiState.settings)
                        viewModel.printHtmlReport(activity, acc.name, html)
                        menuAcc = null
                    }
                    DebtMenuActionButton(strings.t("طباعة مصادقة حساب للفترة المحددة", "Print Auth Statement"), Icons.Default.Verified) {
                        val html = PrintReportBuilders.buildDebtStatementHtml(acc, accVouchers, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة ${acc.name}", html)
                        menuAcc = null
                    }
                    DebtMenuActionButton(strings.t("نسخ الحساب إلى صندوق آخر", "Copy to Another Cashbox"), Icons.Default.ContentCopy) {
                        transferAccRequest = acc to false
                        menuAcc = null
                    }
                    DebtMenuActionButton(strings.t("نقل الحساب إلى صندوق آخر", "Move to Another Cashbox"), Icons.Default.DriveFileMove) {
                        transferAccRequest = acc to true
                        menuAcc = null
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuAcc = null }) { Text(strings.close) } }
        )
    }

    transferAccRequest?.let { (acc, isMove) ->
        val targets = uiState.snapshot.debtCashboxes.filter { !isMove || it.id != acc.cashboxId }
        AlertDialog(
            onDismissRequest = { transferAccRequest = null },
            title = { Text(strings.t(if (isMove) "نقل الحساب إلى صندوق" else "نسخ الحساب إلى صندوق", "Select Cashbox"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (targets.isEmpty()) {
                        Text(strings.t("لا توجد صناديق أخرى", "No other cashboxes available"))
                    } else {
                        targets.forEach { targetBox ->
                            DebtMenuActionButton(targetBox.name, Icons.Default.Folder) {
                                viewModel.copyOrMoveDebtAccount(acc, targetBox.id, isMove)
                                transferAccRequest = null
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { transferAccRequest = null }) { Text(strings.close) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DebtAccountCardItem(
    account: DebtAccount,
    net: Double,
    currency: String,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val haptic = LocalHapticFeedback.current

    val initialChar = account.name.trim().firstOrNull()?.toString() ?: "؟"
    val sideLabel = when {
        abs(net) < 1e-9 -> strings.t("متعادل", "Even")
        net > 0 -> strings.t("لكم", "Credit")
        else -> strings.t("عليكم", "Debt")
    }
    val balColor = when {
        abs(net) < 1e-9 -> Color(0xFF16A37A)
        net > 0 -> if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
        else -> if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f)),
        tonalElevation = 1.dp,
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 74.dp)
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Circular Initial Avatar (black circle matching Screenshot 2)
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0E1015)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialChar,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Middle: Account Name + Phone + optional Debt Cap
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = account.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (account.limitEnabled && account.limitAmount > 0.0) {
                        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) {
                            Text(
                                text = strings.t("سقف ${fmt(account.limitAmount)}", "Cap ${fmt(account.limitAmount)}"),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                if (account.phone.isNotBlank()) {
                    Text(
                        text = account.phone,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // End: Status label + Balance amount
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = sideLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = balColor.copy(alpha = 0.85f)
                )
                Text(
                    text = fmt(abs(net)),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = balColor
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DebtAccountLedgerScreen(
    accountId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val activity = LocalContext.current.findActivityOrNull()
    val haptic = LocalHapticFeedback.current

    val account = uiState.snapshot.debtAccounts.firstOrNull { it.id == accountId }
    if (account == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortField by remember { mutableStateOf(DebtSortField.DATE) }
    var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
    var selectMode by remember { mutableStateOf(false) }
    val selectedIds = remember { mutableStateListOf<String>() }

    var showNewVoucher by remember { mutableStateOf(false) }
    var editingVoucher by remember { mutableStateOf<DebtVoucher?>(null) }
    var showEditAccount by remember { mutableStateOf(false) }
    var menuVoucher by remember { mutableStateOf<DebtVoucher?>(null) }
    var previewImg by remember { mutableStateOf<String?>(null) }
    var askSendConfirm by remember { mutableStateOf<Pair<DebtVoucher, Double>?>(null) }
    var transferVoucherRequest by remember { mutableStateOf<Pair<List<DebtVoucher>, Boolean>?>(null) } // vouchers to isMove

    val activeSpec = uiState.settings.activeSpecialty

    val chronologicalVouchers = remember(uiState.snapshot.debtVouchers, accountId, activeSpec, fromDate, toDate) {
        uiState.snapshot.debtVouchers
            .filter { it.accountId == accountId }
            .filter { matchesSpecialtyFilter(it.specialtyId, activeSpec) }
            .filter { v ->
                (fromDate.isBlank() || v.date.isBlank() || v.date >= fromDate) &&
                    (toDate.isBlank() || v.date.isBlank() || v.date <= toDate)
            }
            .sortedWith(compareBy<DebtVoucher> { it.date }.thenBy { it.createdAt })
    }

    val runningBalanceMap = remember(chronologicalVouchers) {
        var run = 0.0
        buildMap {
            chronologicalVouchers.forEach { v ->
                run += if (v.type == "pay") v.amount else -v.amount
                put(v.id, run)
            }
        }
    }

    val displayedVouchers = remember(chronologicalVouchers, sortField, sortDir) {
        val sorted = when (sortField) {
            DebtSortField.DATE -> chronologicalVouchers
            DebtSortField.NAME -> chronologicalVouchers.sortedBy { it.note }
            DebtSortField.AMOUNT -> chronologicalVouchers.sortedBy { it.amount }
        }
        if (sortDir == DebtSortDir.DESC) sorted.reversed() else sorted
    }

    val totals = remember(chronologicalVouchers) {
        val pay = chronologicalVouchers.filter { it.type == "pay" }.sumOf { it.amount }
        val debt = chronologicalVouchers.filter { it.type == "debt" }.sumOf { it.amount }
        DebtTotals(pay = pay, debt = debt)
    }

    val allAccountVouchers = remember(uiState.snapshot.debtVouchers, accountId) {
        uiState.snapshot.debtVouchers.filter { it.accountId == accountId }
    }

    fun dispatchDebtMessage(typeLabel: String, amount: Double, currency: String, note: String, netPayMinusDebt: Double) {
        val txt = viewModel.buildAccountMessageText(
            accountName = account.name,
            typeLabel = typeLabel,
            amount = amount,
            currency = currency,
            note = note,
            netBalance = netPayMinusDebt,
            netIsCreditForClient = netPayMinusDebt > 0
        )
        viewModel.sendAccountMessage(account.phone, txt)
    }

    Scaffold(
        topBar = {
            DebtsTopLuxuryBar(
                title = account.name,
                onBack = onBack,
                actions = {
                    DebtsHeaderActionButton("", Icons.Default.Send, onClick = {
                        dispatchDebtMessage(
                            typeLabel = strings.t("كشف رصيد", "Balance Statement"),
                            amount = abs(totals.net),
                            currency = uiState.settings.defaultCurrency,
                            note = "",
                            netPayMinusDebt = totals.net
                        )
                    })
                    DebtsHeaderActionButton("", Icons.Default.Print, onClick = {
                        val html = PrintReportBuilders.buildDebtStatementHtml(account, chronologicalVouchers, false, uiState.settings)
                        viewModel.printHtmlReport(activity, account.name, html)
                    })
                    DebtsHeaderActionButton("", Icons.Default.Verified, onClick = {
                        val html = PrintReportBuilders.buildDebtStatementHtml(account, chronologicalVouchers, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة ${account.name}", html)
                    })
                    DebtsHeaderActionButton("", Icons.Default.Edit, onClick = { showEditAccount = true })
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showNewVoucher = true },
                contentDescription = strings.t("سند جديد", "New Voucher"),
                modifier = Modifier.testTag("add_debt_voucher_fab")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 92.dp)
        ) {
            item(key = "controls") {
                DebtsControlStrip(
                    specialties = uiState.settings.specialties,
                    activeSpecialty = activeSpec,
                    onSelectSpecialty = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    selectAllChecked = selectMode && displayedVouchers.isNotEmpty() && selectedIds.size == displayedVouchers.size,
                    onToggleSelectAll = {
                        if (selectMode && selectedIds.size == displayedVouchers.size) {
                            selectMode = false
                            selectedIds.clear()
                        } else {
                            selectMode = true
                            selectedIds.clear()
                            selectedIds.addAll(displayedVouchers.map { it.id })
                        }
                    },
                    totals = totals,
                    sortField = sortField,
                    sortDir = sortDir,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortDir = it },
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            if (selectMode) {
                item(key = "bulk_actions") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val selectedList = displayedVouchers.filter { it.id in selectedIds }
                        FilledTonalButton(
                            onClick = { if (selectedList.isNotEmpty()) transferVoucherRequest = selectedList to true },
                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                        ) { Text(strings.t("نقل (${selectedList.size})", "Move")) }
                        FilledTonalButton(
                            onClick = { if (selectedList.isNotEmpty()) transferVoucherRequest = selectedList to false },
                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                        ) { Text(strings.t("نسخ", "Copy")) }
                        Button(
                            onClick = {
                                if (selectedList.isNotEmpty()) {
                                    viewModel.deleteDebtVouchers(selectedList.map { it.id })
                                    selectedIds.clear()
                                    selectMode = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                        ) { Text(strings.delete) }
                        IconButton(onClick = { selectMode = false; selectedIds.clear() }, modifier = Modifier.size(44.dp)) {
                            Icon(Icons.Default.Close, contentDescription = strings.cancel)
                        }
                    }
                }
            }

            // Table Header (.dfT)
            item(key = "table_head") {
                Surface(
                    shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.t("النوع", "Type"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(0.75f), textAlign = TextAlign.Center)
                        Text(strings.t("المبلغ", "Amount"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center)
                        Text(strings.t("التفاصيل", "Details"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1.6f), textAlign = TextAlign.Center)
                        Text(strings.t("الرصيد", "Balance"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1.1f), textAlign = TextAlign.Center)
                    }
                }
            }

            if (displayedVouchers.isEmpty()) {
                item(key = "empty") {
                    EmptyStateView(
                        icon = Icons.Default.ReceiptLong,
                        title = strings.t("لا توجد معاملات ضمن الفترة المحددة", "No Transactions in Period")
                    )
                }
            } else {
                items(displayedVouchers, key = { it.id }) { v ->
                    val isPay = v.type == "pay"
                    val run = runningBalanceMap[v.id] ?: 0.0
                    val isSel = v.id in selectedIds
                    val rowBg = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                    val dirColor = if (isPay) {
                        if (settings.dark) AppColors.CreditGreenDark else AppColors.CreditGreen
                    } else {
                        if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed
                    }
                    val runSide = when {
                        run > 1e-9 -> strings.t("لكم", "Credit")
                        run < -1e-9 -> strings.t("عليكم", "Debt")
                        else -> strings.t("متعادل", "Even")
                    }

                    Surface(
                        color = rowBg,
                        border = BorderStroke(if (isSel) 2.dp else 0.5.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = {
                                    if (selectMode) {
                                        if (isSel) selectedIds.remove(v.id) else selectedIds.add(v.id)
                                    } else {
                                        menuVoucher = v
                                    }
                                },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    menuVoucher = v
                                }
                            )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(0.75f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (selectMode) {
                                    Icon(
                                        if (isSel) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Text(
                                    text = if (isPay) "له" else "عليه",
                                    fontWeight = FontWeight.Black,
                                    color = dirColor,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            Column(
                                modifier = Modifier.weight(1.2f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(fmt(v.amount), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text(DateHelper.displaySlash(v.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Row(
                                modifier = Modifier.weight(1.6f).padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = v.note.ifBlank { if (isPay) "سند قبض" else "دين" },
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center
                                )
                                if (v.imagePath.isNotBlank() && File(v.imagePath).exists()) {
                                    Image(
                                        painter = rememberAsyncImagePainter(File(v.imagePath)),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable { previewImg = v.imagePath }
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1.1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(fmt(abs(run)), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = runSide,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (run < -1e-9) AppColors.DebitRed else if (run > 1e-9) AppColors.CreditGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewVoucher || editingVoucher != null) {
        val defaultSpec = if (activeSpec in listOf("all", "none")) "" else activeSpec
        DebtVoucherEditDialog(
            account = account,
            existing = editingVoucher,
            defaultSpecialtyId = defaultSpec,
            specialties = uiState.settings.specialties,
            currencies = uiState.settings.currencies,
            defaultCurrency = uiState.settings.defaultCurrency,
            viewModel = viewModel,
            onSavedAskMessage = { savedVoucher, newDebtMinusPay ->
                // Convert debtMinusPay -> payMinusDebt for message consistency
                val payMinusDebt = -newDebtMinusPay
                val timing = account.messageSend.ifBlank { uiState.settings.messages.sendWhen }
                when (timing) {
                    "auto" -> dispatchDebtMessage(
                        typeLabel = if (savedVoucher.type == "debt") "عليه (دين)" else "له (سداد)",
                        amount = savedVoucher.amount,
                        currency = savedVoucher.currency,
                        note = savedVoucher.note,
                        netPayMinusDebt = payMinusDebt
                    )
                    "confirm" -> askSendConfirm = savedVoucher to payMinusDebt
                    else -> Unit
                }
            },
            onDismiss = { showNewVoucher = false; editingVoucher = null }
        )
    }

    askSendConfirm?.let { (v, payMinusDebt) ->
        ConfirmActionDialog(
            title = strings.t("إرسال رسالة", "Send Message"),
            message = strings.t("تم حفظ المعاملة. هل تريد إرسال رسالة للحساب؟", "Transaction saved. Send message to account?"),
            confirmText = strings.t("إرسال", "Send"),
            isDestructive = false,
            onConfirm = {
                dispatchDebtMessage(
                    typeLabel = if (v.type == "debt") "عليه (دين)" else "له (سداد)",
                    amount = v.amount,
                    currency = v.currency,
                    note = v.note,
                    netPayMinusDebt = payMinusDebt
                )
            },
            onDismiss = { askSendConfirm = null }
        )
    }

    if (showEditAccount) {
        DebtAccountEditDialog(
            cashboxId = account.cashboxId,
            existing = account,
            viewModel = viewModel,
            onDeleted = onBack,
            onDismiss = { showEditAccount = false }
        )
    }

    menuVoucher?.let { v ->
        val isSel = v.id in selectedIds
        AlertDialog(
            onDismissRequest = { menuVoucher = null },
            title = { Text(strings.t("إجراءات المعاملة", "Voucher Actions"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DebtMenuActionButton(strings.t("طباعة سند المعاملة", "Print Voucher"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildDebtSingleVoucherHtml(account, v, allAccountVouchers, uiState.settings)
                        viewModel.printHtmlReport(activity, account.name, html, isVoucher = true)
                        menuVoucher = null
                    }
                    DebtMenuActionButton(strings.t("تعديل المعاملة", "Edit Voucher"), Icons.Default.Edit) {
                        menuVoucher = null
                        editingVoucher = v
                    }
                    DebtMenuActionButton(
                        strings.t(if (isSel) "إلغاء تحديد المعاملة" else "تحديد المعاملة", if (isSel) "Deselect" else "Select"),
                        Icons.Default.CheckBox
                    ) {
                        selectMode = true
                        if (isSel) selectedIds.remove(v.id) else selectedIds.add(v.id)
                        menuVoucher = null
                    }
                    DebtMenuActionButton(strings.t("تحديد الكل في الحساب الحالي", "Select All in Account"), Icons.Default.SelectAll) {
                        selectMode = true
                        selectedIds.clear()
                        selectedIds.addAll(displayedVouchers.map { it.id })
                        menuVoucher = null
                    }
                    DebtMenuActionButton(
                        strings.t(if (v.imagePath.isNotBlank()) "فتح الصورة المرفقة" else "إضافة صورة للمعاملة", "Photo"),
                        Icons.Default.Image
                    ) {
                        menuVoucher = null
                        if (v.imagePath.isNotBlank() && File(v.imagePath).exists()) {
                            previewImg = v.imagePath
                        } else {
                            editingVoucher = v
                        }
                    }
                    DebtMenuActionButton(strings.t("نقل المعاملة إلى حساب آخر", "Move to Another Account"), Icons.Default.DriveFileMove) {
                        transferVoucherRequest = listOf(v) to true
                        menuVoucher = null
                    }
                    DebtMenuActionButton(strings.t("نسخ المعاملة إلى حساب آخر", "Copy to Another Account"), Icons.Default.ContentCopy) {
                        transferVoucherRequest = listOf(v) to false
                        menuVoucher = null
                    }
                    DebtMenuActionButton(strings.t("حذف المعاملة", "Delete Voucher"), Icons.Default.Delete, isDestructive = true) {
                        viewModel.deleteDebtVoucher(v.id)
                        menuVoucher = null
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuVoucher = null }) { Text(strings.close) } }
        )
    }

    transferVoucherRequest?.let { (vouchersToTransfer, isMove) ->
        val targetAccounts = uiState.snapshot.debtAccounts.filter { it.id != accountId }
        AlertDialog(
            onDismissRequest = { transferVoucherRequest = null },
            title = {
                Text(
                    strings.t(if (isMove) "نقل المعاملة إلى حساب" else "نسخ المعاملة إلى حساب", "Select Target Account"),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (targetAccounts.isEmpty()) {
                        Text(strings.t("لا توجد حسابات أخرى", "No other accounts available"))
                    } else {
                        targetAccounts.forEach { target ->
                            DebtMenuActionButton(target.name, Icons.Default.Person) {
                                viewModel.copyOrMoveDebtVouchers(vouchersToTransfer, target.id, isMove)
                                selectedIds.clear()
                                selectMode = false
                                transferVoucherRequest = null
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { transferVoucherRequest = null }) { Text(strings.close) } }
        )
    }

    previewImg?.let { path ->
        AppImageViewerDialog(
            imagePath = path,
            onSaveToGallery = { viewModel.saveImageToGallery(path) },
            onDismiss = { previewImg = null }
        )
    }
}
