package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClockDetailScreen(
    section: ClockSection,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val activity = LocalContext.current.findActivityOrNull()

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var showSearch by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var sortField by remember { mutableStateOf("date") } // date, name, amount
    var sortAsc by remember { mutableStateOf(true) }
    var showManualDialog by remember { mutableStateOf(false) }
    var editingManualEntry by remember { mutableStateOf<ClockEntry?>(null) }
    var inspectingEntry by remember { mutableStateOf<ClockEntry?>(null) }
    var editingCurrencyEntry by remember { mutableStateOf<ClockEntry?>(null) }
    var showCurrencyOpDialog by remember { mutableStateOf<String?>(null) } // "receipt" or "exchange"
    var selectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    val specMap = remember(uiState.settings.specialties) {
        uiState.settings.specialties.associate { it.id to it.name }
    }
    val entries = remember(uiState.snapshot.clockEntries, section, uiState.settings.activeSpecialty, fromDate, toDate, search) {
        uiState.snapshot.clockEntries
            .filter { it.section == section }
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.activeSpecialty) }
            .filter { e ->
                val d = e.date.ifBlank { e.to }
                (fromDate.isBlank() || d.isBlank() || d >= fromDate) &&
                    (toDate.isBlank() || d.isBlank() || d <= toDate)
            }
            .filter { e ->
                search.isBlank() || e.name.contains(search, true) || e.note.contains(search, true)
            }
            .sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
    }

    val running = remember(entries) { ClockCalculator.runningBalances(entries) }
    val sortedEntries = remember(entries, sortField, sortAsc) {
        val base = when (sortField) {
            "name" -> entries.sortedBy { it.note.ifBlank { it.name } }
            "amount" -> entries.sortedBy { abs(it.amount) }
            else -> entries
        }
        if (sortAsc) base else base.reversed()
    }
    val credit = remember(entries) { entries.filter { it.dir != "عليكم" }.sumOf { abs(it.amount) } }
    val debit = remember(entries) { entries.filter { it.dir == "عليكم" }.sumOf { abs(it.amount) } }
    val deletableIds = remember(entries) { entries.filter { it.tsVoucherId.isBlank() }.map { it.id }.toSet() }
    val allSelected = selectMode && deletableIds.isNotEmpty() && selectedIds.containsAll(deletableIds)

    val toggleSelectAll: () -> Unit = {
        if (allSelected) {
            selectedIds = emptySet()
            selectMode = false
        } else {
            selectMode = true
            selectedIds = deletableIds
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            DebtsTopLuxuryBar(
                title = if (uiState.settings.lang == "en") section.labelEn else section.labelAr,
                onBack = onBack,
                actions = {
                    DebtsHeaderActionButton(
                        label = "",
                        icon = if (showSearch || search.isNotBlank()) Icons.Default.SearchOff else Icons.Default.Search,
                        onClick = {
                            if (showSearch) {
                                showSearch = false
                                search = ""
                            } else {
                                showSearch = true
                            }
                        },
                        testTag = "clock_search_btn"
                    )
                    DebtsHeaderActionButton(
                        label = strings.print,
                        icon = Icons.Default.Print,
                        onClick = {
                            val html = PrintReportBuilders.buildClockLedgerHtml(section, entries, fromDate, toDate, false, uiState.settings)
                            viewModel.printHtmlReport(activity, section.labelAr, html)
                        },
                        testTag = "clock_print_btn"
                    )
                    DebtsHeaderActionButton(
                        label = strings.auth,
                        icon = Icons.Default.Verified,
                        onClick = {
                            val html = PrintReportBuilders.buildClockLedgerHtml(section, entries, fromDate, toDate, true, uiState.settings)
                            viewModel.printHtmlReport(activity, "مصادقة ${section.labelAr}", html)
                        },
                        testTag = "clock_auth_btn"
                    )
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = {
                    if (section == ClockSection.CURRENCY) {
                        editingCurrencyEntry = ClockEntry(section = ClockSection.CURRENCY)
                    } else {
                        editingManualEntry = null
                        showManualDialog = true
                    }
                },
                contentDescription = strings.t("إضافة قيد", "Add Entry"),
                modifier = Modifier.testTag("clock_add_entry_fab")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AnimatedVisibility(visible = showSearch || search.isNotBlank()) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text(strings.t("بحث في الحركات...", "Search entries...")) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (search.isNotBlank()) {
                            IconButton(onClick = { search = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = strings.close)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(tokens.cornerRadius),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (section == ClockSection.CURRENCY) {
                ClockCurrencyStripBar(
                    entries = entries,
                    currencies = uiState.settings.currencies
                )
                ClockDarkSortBar(
                    sortField = sortField,
                    sortAsc = sortAsc,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortAsc = it }
                )
                ClockDarkDateRangeBar(
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
                LuxurySpecialtyHeaderBar(
                    specialties = uiState.settings.specialties,
                    selectedId = uiState.settings.activeSpecialty,
                    onSelect = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    showManageButton = true,
                    showSelectAll = true,
                    selectAllChecked = allSelected,
                    onToggleSelectAll = toggleSelectAll
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ClockCurrencyActionButton(
                        label = strings.t("حوالة من العملات", "Remittance"),
                        icon = Icons.Default.Send,
                        onClick = { showCurrencyOpDialog = "receipt" },
                        modifier = Modifier.weight(1f)
                    )
                    ClockCurrencyActionButton(
                        label = strings.t("مصارفة عملة", "Exchange"),
                        icon = Icons.Default.CurrencyExchange,
                        onClick = { showCurrencyOpDialog = "exchange" },
                        modifier = Modifier.weight(1f)
                    )
                }
            } else {
                LuxurySpecialtyHeaderBar(
                    specialties = uiState.settings.specialties,
                    selectedId = uiState.settings.activeSpecialty,
                    onSelect = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    showManageButton = true,
                    showSelectAll = true,
                    selectAllChecked = allSelected,
                    onToggleSelectAll = toggleSelectAll
                )
                ClockSummaryCardsRow(
                    credit = credit,
                    debit = debit
                )
                ClockDarkSortBar(
                    sortField = sortField,
                    sortAsc = sortAsc,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortAsc = it }
                )
                ClockDarkDateRangeBar(
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            if (selectMode) {
                Surface(
                    shape = RoundedCornerShape(tokens.cornerRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, tokens.borderColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { selectedIds = deletableIds },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                        ) {
                            Text(strings.t("تحديد الكل", "Select All"), fontSize = 12.sp, maxLines = 1)
                        }
                        Button(
                            onClick = {
                                val toDel = entries.filter { it.id in selectedIds && it.tsVoucherId.isBlank() }
                                if (toDel.isNotEmpty()) viewModel.deleteClockEntries(toDel)
                                selectedIds = emptySet()
                                selectMode = false
                            },
                            enabled = selectedIds.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = AppColors.DebitRed),
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.weight(1.2f).heightIn(min = 44.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("${strings.delete} (${selectedIds.size})", fontSize = 12.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { selectedIds = emptySet(); selectMode = false },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) {
                            Text(strings.cancel, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }

            if (section != ClockSection.CURRENCY) {
                ClockLedgerTableHeader(showQtyColumn = section == ClockSection.SALE)
            }

            if (sortedEntries.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Timeline,
                    title = strings.t("لا توجد حركات ضمن الفترة المحددة", "No Entries in Period")
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(sortedEntries, key = { it.id }) { e ->
                        val isSel = e.id in selectedIds
                        val spName = specMap[e.specialtyId] ?: ""

                        val onRowClick: () -> Unit = {
                            if (selectMode) {
                                if (e.tsVoucherId.isNotBlank()) {
                                    viewModel.emitMessage("سند مرتبط بالصرافة — يُحذف من قسم الصرافة")
                                } else {
                                    selectedIds = if (isSel) selectedIds - e.id else selectedIds + e.id
                                }
                            } else if (section == ClockSection.CURRENCY) {
                                when {
                                    e.srcDetailId.isNotBlank() -> viewModel.emitMessage("سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً")
                                    e.tsVoucherId.isNotBlank() -> viewModel.emitMessage("سند مرتبط بالصرافة — عدّله من قسم الصرافة")
                                    else -> editingCurrencyEntry = e
                                }
                            } else {
                                if (!e.auto && e.tsVoucherId.isBlank()) {
                                    editingManualEntry = e
                                    showManualDialog = true
                                } else {
                                    inspectingEntry = e
                                }
                            }
                        }

                        val onRowLongClick: () -> Unit = {
                            selectMode = true
                            if (e.tsVoucherId.isBlank()) selectedIds = selectedIds + e.id
                        }

                        if (section == ClockSection.CURRENCY) {
                            val rows = remember(e) { clockEntryRows(e) }
                            val headerTitle = remember(e, section, specMap) { clockOriginTitle(e, section, specMap) }
                            ClockCurrencyEntryCard(
                                entry = e,
                                rows = rows,
                                headerTitle = headerTitle,
                                isSelected = isSel,
                                specialtyName = spName,
                                onClick = onRowClick,
                                onLongClick = onRowLongClick
                            )
                        } else {
                            val bal = running[e.id] ?: 0.0
                            ClockLedgerTableRow(
                                entry = e,
                                runningBalance = bal,
                                showQtyColumn = section == ClockSection.SALE,
                                isSelected = isSel,
                                specialtyName = spName,
                                onClick = onRowClick,
                                onLongClick = onRowLongClick
                            )
                        }
                    }
                }
            }
        }
    }

    if (showManualDialog && section != ClockSection.CURRENCY) {
        val existing = editingManualEntry
        var dir by remember(existing?.id) {
            mutableStateOf(existing?.dir?.ifBlank { "لكم" } ?: if (section == ClockSection.WITHDRAW) "عليكم" else "لكم")
        }
        var amtStr by remember(existing?.id) {
            mutableStateOf(if (existing != null && existing.amount > 0.0) rawNumberString(existing.amount) else "")
        }
        var qtyStr by remember(existing?.id) {
            mutableStateOf(if (existing != null && existing.qty > 0.0) rawNumberString(existing.qty) else "")
        }
        var name by remember(existing?.id) { mutableStateOf(existing?.name ?: "") }
        var date by remember(existing?.id) { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
        var note by remember(existing?.id) { mutableStateOf(existing?.note ?: "") }
        var entrySpecId by remember(existing?.id, uiState.settings.activeSpecialty) {
            mutableStateOf(
                existing?.specialtyId
                    ?: if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty
            )
        }
        var confirmDelete by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showManualDialog = false; editingManualEntry = null },
            title = {
                Text(
                    if (existing != null) strings.t("تعديل قيد في ${section.labelAr}", "Edit Entry")
                    else strings.t("قيد يدوي في ${section.labelAr}", "Add Manual Entry"),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = dir == "لكم", onClick = { dir = "لكم" }, label = { Text(strings.credit) })
                        FilterChip(selected = dir == "عليكم", onClick = { dir = "عليكم" }, label = { Text(strings.debit) })
                    }
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = entrySpecId,
                        onAssign = { entrySpecId = it },
                        onAddSpecialty = { n, w -> viewModel.addHomeSpecialty(n, w) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    WesternNumberField(value = amtStr, onValueChange = { amtStr = it }, label = strings.amount, modifier = Modifier.fillMaxWidth())
                    if (section == ClockSection.SALE) {
                        WesternNumberField(value = qtyStr, onValueChange = { qtyStr = it }, label = strings.t("الكمية", "Quantity"), modifier = Modifier.fillMaxWidth())
                    }
                    NameSuggestTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = strings.t("الاسم / العنوان", "Title"),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ClickableDateField(
                        value = date,
                        onDatePicked = { date = it },
                        label = strings.date,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "clock_entry_date_input"
                    )
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.note) }, modifier = Modifier.fillMaxWidth())
                    if (existing != null) {
                        OutlinedButton(
                            onClick = { confirmDelete = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AppColors.DebitRed),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.delete, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val a = num(amtStr)
                    if (a > 0.0) {
                        val updated = (existing ?: ClockEntry(
                            section = section,
                            time = DateHelper.nowTime(),
                            auto = false
                        )).copy(
                            section = section,
                            specialtyId = entrySpecId,
                            dir = dir,
                            amount = a,
                            qty = if (section == ClockSection.SALE) num(qtyStr) else (existing?.qty ?: 0.0),
                            name = name.trim(),
                            date = date.trim(),
                            note = note.trim(),
                            auto = false
                        )
                        viewModel.saveClockEntry(updated)
                        showManualDialog = false
                        editingManualEntry = null
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showManualDialog = false; editingManualEntry = null }) { Text(strings.cancel) }
            }
        )

        if (confirmDelete && existing != null) {
            ConfirmActionDialog(
                title = strings.t("حذف هذا القيد؟", "Delete Entry?"),
                message = strings.t("سيتم نقل القيد إلى سلة المهملات.", "Entry will be moved to trash."),
                confirmText = strings.delete,
                onConfirm = {
                    viewModel.deleteClockEntry(existing)
                    showManualDialog = false
                    editingManualEntry = null
                },
                onDismiss = { confirmDelete = false }
            )
        }
    }

    inspectingEntry?.let { e ->
        val spName = specMap[e.specialtyId] ?: ""
        AlertDialog(
            onDismissRequest = { inspectingEntry = null },
            title = { Text(e.name.ifBlank { section.labelAr }, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${strings.t("النوع", "Type")}: ${e.dir}", fontWeight = FontWeight.Bold)
                    Text("${strings.amount}: ${fmt(abs(e.amount))}")
                    if (section == ClockSection.SALE) {
                        Text("${strings.t("الكمية", "Quantity")}: ${fmt(e.qty)}")
                    }
                    Text("${strings.date}: ${DateHelper.displaySlash(e.date)}${if (e.time.isNotBlank()) " — ${e.time}" else ""}")
                    if (e.to.isNotBlank() && e.to != e.date) {
                        Text("${strings.t("الفترة", "Period")}: من ${e.date} إلى ${e.to}")
                    }
                    if (e.note.isNotBlank()) {
                        Text("${strings.note}: ${e.note}")
                    }
                    if (spName.isNotBlank()) {
                        Text("${strings.t("التخصيص", "Specialty")}: $spName")
                    }
                    if (e.srcDetailId.isNotBlank()) {
                        Text(
                            strings.t("سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً", "Synced from Detail — edit in Detail page."),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (e.tsVoucherId.isNotBlank()) {
                        Text(
                            strings.t("سند مرتبط بالصرافة — عدّله من قسم الصرافة", "Linked to Tasfeer — edit in Tasfeer."),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { inspectingEntry = null }) { Text(strings.close) }
            }
        )
    }

    editingCurrencyEntry?.let { entry ->
        val isNew = entry.name.isBlank() && entry.rows.isEmpty() && entry.amount == 0.0
        ClockCurrencyEntryDialog(
            existing = if (isNew) null else entry,
            uiState = uiState,
            viewModel = viewModel,
            onDismiss = { editingCurrencyEntry = null }
        )
    }

    showCurrencyOpDialog?.let { kind ->
        ClockCurrencyOperationDialog(
            kind = kind,
            uiState = uiState,
            viewModel = viewModel,
            onDismiss = { showCurrencyOpDialog = null }
        )
    }
}

@Composable
private fun ClockCurrencyActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = Color.Transparent,
        border = BorderStroke(1.dp, tokens.borderColor),
        shadowElevation = tokens.elevation,
        modifier = modifier.heightIn(min = 44.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tokens.barAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                color = tokens.darkTileContent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
