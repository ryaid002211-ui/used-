package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance

object AppColors {
    val NavyDeep = Color(0xFF071F4F)
    val NavyMid = Color(0xFF0D2E6E)
    val GoldAccent = Color(0xFFD8AE52)
    val GoldLight = Color(0xFFF3D98B)

    val CreditGreen = Color(0xFF15803D)
    val CreditGreenContainerLight = Color(0xFFDCFCE7)
    val CreditGreenDark = Color(0xFF4ADE80)
    val CreditGreenContainerDark = Color(0xFF14532D)

    val DebitRed = Color(0xFFDC2626)
    val DebitRedContainerLight = Color(0xFFFEE2E2)
    val DebitRedDark = Color(0xFFF87171)
    val DebitRedContainerDark = Color(0xFF7F1D1D)

    val Copper = Color(0xFFB87333)
    val Silver = Color(0xFF94A3B8)
}

fun parseHexColor(hex: String, fallback: Color = Color(0xFF1E40AF)): Color {
    val clean = hex.trim().removePrefix("#")
    return try {
        when (clean.length) {
            6 -> Color(("FF$clean").toLong(16))
            8 -> Color(clean.toLong(16))
            else -> fallback
        }
    } catch (_: Exception) {
        fallback
    }
}

fun buildAppColorScheme(primaryHex: String, dark: Boolean): ColorScheme {
    val primary = parseHexColor(primaryHex, Color(0xFF1E40AF))
    val onPrimary = if (primary.luminance() > 0.55f) Color(0xFF0F172A) else Color.White

    return if (dark) {
        val primaryLight = lerp(primary, Color.White, 0.32f)
        val onPrimaryDark = if (primaryLight.luminance() > 0.55f) Color(0xFF0B1120) else Color.White
        val secondary = lerp(primaryLight, AppColors.GoldAccent, 0.35f)
        darkColorScheme(
            primary = primaryLight,
            onPrimary = onPrimaryDark,
            primaryContainer = lerp(primary, Color(0xFF0B1120), 0.55f),
            onPrimaryContainer = Color(0xFFE2E8F0),
            secondary = secondary,
            onSecondary = Color(0xFF0F172A),
            secondaryContainer = Color(0xFF1E293B),
            onSecondaryContainer = Color(0xFFF8FAFC),
            tertiary = AppColors.GoldAccent,
            onTertiary = Color(0xFF1E1B18),
            background = Color(0xFF0B1120),
            onBackground = Color(0xFFF1F5F9),
            surface = Color(0xFF111827),
            onSurface = Color(0xFFF1F5F9),
            surfaceVariant = Color(0xFF1E293B),
            onSurfaceVariant = Color(0xFFCBD5E1),
            surfaceContainerLowest = Color(0xFF090E1A),
            surfaceContainerLow = Color(0xFF131C2E),
            surfaceContainer = Color(0xFF172136),
            surfaceContainerHigh = Color(0xFF1E293B),
            surfaceContainerHighest = Color(0xFF283548),
            outline = Color(0xFF334155),
            outlineVariant = Color(0xFF1E293B),
            error = AppColors.DebitRedDark,
            onError = Color(0xFF450A0A)
        )
    } else {
        val container = lerp(primary, Color.White, 0.86f)
        val secondary = lerp(primary, AppColors.GoldAccent, 0.40f)
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = container,
            onPrimaryContainer = lerp(primary, Color.Black, 0.45f),
            secondary = secondary,
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFF1F5F9),
            onSecondaryContainer = Color(0xFF1E293B),
            tertiary = AppColors.GoldAccent,
            onTertiary = Color(0xFF1E1B18),
            background = Color(0xFFF4F6FB),
            onBackground = Color(0xFF0F172A),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF0F172A),
            surfaceVariant = Color(0xFFE8EEF7),
            onSurfaceVariant = Color(0xFF475569),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFF8FAFC),
            surfaceContainer = Color(0xFFF1F5F9),
            surfaceContainerHigh = Color(0xFFE8EEF7),
            surfaceContainerHighest = Color(0xFFDCE4F0),
            outline = Color(0xFFCBD5E1),
            outlineVariant = Color(0xFFE2E8F0),
            error = AppColors.DebitRed,
            onError = Color.White
        )
    }
}
