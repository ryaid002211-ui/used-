package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalSavedNames
import kotlin.math.abs

private val ManualCellBg = Color(0xFFFFF3C4)
private val OverriddenCellBg = Color(0xFFFFE8B0)
private val BadCellBg = Color(0xFFFFDEDE)
private val MatchCellBg = Color(0xFFDCFCE7)

@Composable
internal fun DetailTableShell(
    title: String,
    modifier: Modifier = Modifier,
    onAddClick: (() -> Unit)? = null,
    addEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        tonalElevation = 1.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (onAddClick != null) {
                    FilledTonalIconButton(
                        onClick = onAddClick,
                        enabled = addEnabled,
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f),
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة صف", modifier = Modifier.size(18.dp))
                    }
                }
            }
            content()
        }
    }
}

@Composable
internal fun DetailCellInput(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    numeric: Boolean = true,
    readOnly: Boolean = false,
    bgColor: Color = Color.Transparent,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    bold: Boolean = false,
    placeholder: String = "",
    enableNameSuggestions: Boolean = false
) {
    val savedNames = if (enableNameSuggestions) LocalSavedNames.current else emptyList()
    var isFocused by remember { mutableStateOf(false) }
    var dismissedForValue by remember { mutableStateOf<String?>(null) }
    val suggestions = remember(enableNameSuggestions, value, savedNames) {
        if (!enableNameSuggestions) emptyList()
        else NameSuggestionHelper.suggestNames(value, savedNames, limit = 5)
    }

    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 38.dp)
            .background(bgColor)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        if (value.isEmpty() && placeholder.isNotEmpty()) {
            Text(
                text = placeholder,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
        BasicTextField(
            value = value,
            onValueChange = { raw ->
                if (readOnly) return@BasicTextField
                dismissedForValue = null
                val cleaned = if (numeric) WesternDigits.cleanNumericInput(raw) else raw
                onValueChange(cleaned)
            },
            readOnly = readOnly,
            singleLine = true,
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
            textStyle = TextStyle(
                color = textColor,
                fontSize = 13.sp,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { st ->
                    isFocused = st.isFocused
                    if (!st.isFocused) dismissedForValue = null
                }
        )

        if (enableNameSuggestions && !readOnly && isFocused && suggestions.isNotEmpty() && dismissedForValue != value) {
            Popup(
                alignment = Alignment.BottomCenter,
                properties = PopupProperties(focusable = false)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(min = 170.dp, max = 260.dp)
                ) {
                    Column {
                        suggestions.forEachIndexed { idx, candidate ->
                            if (idx > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .clickable {
                                        dismissedForValue = candidate
                                        onValueChange(candidate)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = candidate,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun DetailLabelCell(
    text: String,
    modifier: Modifier = Modifier,
    bgColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    bold: Boolean = true
) {
    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 38.dp)
            .background(bgColor)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            .padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun DetailCalcCell(
    calcKey: String,
    autoValue: Double,
    form: DetailFormData,
    unlockEdit: Boolean,
    isBad: Boolean = false,
    isGood: Boolean = false,
    onOverrideChange: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val overrideVal = form.manualOverrides[calcKey]
    val isManual = overrideVal != null
    val shownText = if (isManual) overrideVal!! else rawNumberString(autoValue, 2).ifBlank { "0" }
    val bg = when {
        isBad -> BadCellBg
        isGood -> MatchCellBg
        isManual -> OverriddenCellBg
        unlockEdit -> ManualCellBg
        else -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
    }
    val fg = when {
        isBad -> AppColors.DebitRed
        isGood -> AppColors.CreditGreen
        isManual -> Color(0xFF8A4B00)
        else -> MaterialTheme.colorScheme.onPrimaryContainer
    }
    DetailCellInput(
        value = shownText,
        onValueChange = { txt ->
            if (txt.isBlank()) onOverrideChange(null) else onOverrideChange(txt)
        },
        numeric = true,
        readOnly = !unlockEdit,
        bgColor = bg,
        textColor = fg,
        bold = true,
        modifier = modifier
    )
}

@Composable
internal fun DetailHeaderTableCard(
    record: DetailRecord,
    onUpdateRecord: (DetailRecord) -> Unit
) {
    val strings = LocalAppStrings.current
    DetailTableShell(title = strings.t("بيانات التفصيل الأساسية", "Detail Info")) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NameSuggestTextField(
                value = record.initDetail,
                onValueChange = { onUpdateRecord(record.copy(initDetail = it)) },
                label = strings.t("اسم التفصيل", "Detail Title"),
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClickableDateField(
                    value = record.initDateFrom,
                    onDatePicked = { onUpdateRecord(record.copy(initDateFrom = it)) },
                    label = strings.t("التاريخ من", "From Date"),
                    modifier = Modifier.weight(1f),
                    testTag = "detail_from_date_input"
                )
                ClickableDateField(
                    value = record.initDateTo,
                    onDatePicked = { onUpdateRecord(record.copy(initDateTo = it)) },
                    label = strings.t("التاريخ إلى", "To Date"),
                    modifier = Modifier.weight(1f),
                    testTag = "detail_to_date_input"
                )
            }
            val rangeTxt = buildString {
                if (record.initDateFrom.isNotBlank()) append(DateHelper.formatInvoiceDate(record.initDateFrom, false))
                if (record.initDateTo.isNotBlank()) {
                    if (isNotEmpty()) append("  ←  ")
                    append(DateHelper.formatInvoiceDate(record.initDateTo, false))
                }
            }
            if (rangeTxt.isNotBlank() || record.initFilter.isNotBlank() || record.initNo.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (rangeTxt.isNotBlank()) {
                        Text(rangeTxt, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    if (record.initFilter.isNotBlank()) {
                        Text("الفلتر: ${record.initFilter}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
internal fun DetailQtyCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        DetailTableShell(title = "عمود الكمية") {
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("الكمية", Modifier.weight(1.1f))
                DetailCellInput(fd.qQty, { onFormChange(fd.copy(qQty = it)) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("النقد", Modifier.weight(1.1f))
                DetailCellInput(fd.qCash, { onFormChange(fd.copy(qCash = it)) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("الدين", Modifier.weight(1.1f))
                DetailCellInput(fd.qDebt, { onFormChange(fd.copy(qDebt = it)) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("الخرج", Modifier.weight(1.1f))
                DetailCellInput(fd.qOut, { onFormChange(fd.copy(qOut = it)) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("الباقي", Modifier.weight(1.1f))
                DetailCalcCell(
                    calcKey = "qRest",
                    autoValue = fd.calcQRest,
                    form = fd,
                    unlockEdit = unlockEdit,
                    isBad = fd.calcQRest < -1e-9,
                    onOverrideChange = { v ->
                        val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("qRest") else put("qRest", v) }
                        onFormChange(fd.copy(manualOverrides = next))
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Text("الباقي = الكمية − النقد − الدين − الخرج", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
internal fun DetailSalesSplitCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    DetailTableShell(title = "البيع (تقسيم)") {
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("جملة نقد البيع", Modifier.weight(1.2f))
            DetailCellInput(fd.sSale, { onFormChange(fd.copy(sSale = it)) }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("+ مسلم أسبوع", Modifier.weight(1.2f))
            DetailCellInput(fd.sWeekly, { onFormChange(fd.copy(sWeekly = it)) }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("خرج العمال", Modifier.weight(1.2f))
            DetailCellInput(
                value = fd.sPrivateOut,
                onValueChange = { onFormChange(fd.copy(sPrivateOut = it)) },
                readOnly = !unlockEdit,
                bgColor = if (unlockEdit) ManualCellBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                modifier = Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("باقي النقد", Modifier.weight(1.2f))
            DetailCalcCell(
                calcKey = "sCashRest",
                autoValue = fd.calcSCashRest,
                form = fd,
                unlockEdit = unlockEdit,
                onOverrideChange = { v ->
                    val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("sCashRest") else put("sCashRest", v) }
                    onFormChange(fd.copy(manualOverrides = next))
                },
                modifier = Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("جملة بيع الدين", Modifier.weight(1.2f))
            DetailCalcCell(
                calcKey = "sDebtSale",
                autoValue = fd.calcSDebtSale,
                form = fd,
                unlockEdit = unlockEdit,
                onOverrideChange = { v ->
                    val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("sDebtSale") else put("sDebtSale", v) }
                    onFormChange(fd.copy(manualOverrides = next))
                },
                modifier = Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("جملة البيع النهائية", Modifier.weight(1.2f))
            DetailCalcCell(
                calcKey = "sGrand",
                autoValue = fd.calcSGrand,
                form = fd,
                unlockEdit = unlockEdit,
                onOverrideChange = { v ->
                    val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("sGrand") else put("sGrand", v) }
                    onFormChange(fd.copy(manualOverrides = next))
                },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
internal fun DetailReceivedCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    DetailTableShell(
        title = "مسلم فلوس",
        onAddClick = { onFormChange(fd.copy(receivedRows = fd.receivedRows + DetailReceivedRow())) }
    ) {
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("الاسم", Modifier.weight(1.4f))
            DetailLabelCell("المبلغ", Modifier.weight(1f))
            DetailLabelCell("", Modifier.width(38.dp))
        }
        if (fd.receivedRows.isEmpty()) {
            DetailLabelCell("لا توجد صفوف — اضغط + للإضافة", Modifier.fillMaxWidth(), bgColor = Color.Transparent, bold = false)
        } else {
            fd.receivedRows.forEachIndexed { idx, row ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    DetailCellInput(
                        value = row.name,
                        onValueChange = { v ->
                            val list = fd.receivedRows.toMutableList().apply { set(idx, row.copy(name = v)) }
                            onFormChange(fd.copy(receivedRows = list))
                        },
                        numeric = false,
                        enableNameSuggestions = true,
                        modifier = Modifier.weight(1.4f)
                    )
                    DetailCellInput(
                        value = row.amount,
                        onValueChange = { v ->
                            val list = fd.receivedRows.toMutableList().apply { set(idx, row.copy(amount = v)) }
                            onFormChange(fd.copy(receivedRows = list))
                        },
                        numeric = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val list = fd.receivedRows.toMutableList().apply { removeAt(idx) }
                            onFormChange(fd.copy(receivedRows = list))
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "حذف", tint = AppColors.DebitRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("المجموع", Modifier.weight(1.4f))
            DetailCalcCell(
                calcKey = "prevTotal",
                autoValue = fd.calcPrevTotal,
                form = fd,
                unlockEdit = unlockEdit,
                onOverrideChange = { v ->
                    val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("prevTotal") else put("prevTotal", v) }
                    onFormChange(fd.copy(manualOverrides = next))
                },
                modifier = Modifier.weight(1f)
            )
            Box(Modifier.width(38.dp))
        }
    }
}

@Composable
internal fun DetailDebtTableCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    DetailTableShell(
        title = "بيع الدين",
        onAddClick = { onFormChange(fd.copy(debtRows = fd.debtRows + DetailDebtRow())) },
        addEnabled = unlockEdit
    ) {
        Box(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            Column(modifier = Modifier.widthIn(min = 520.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    DetailLabelCell("الاسم", Modifier.width(120.dp))
                    DetailLabelCell("الكمية", Modifier.width(70.dp))
                    DetailLabelCell("المبلغ", Modifier.width(90.dp))
                    DetailLabelCell("مسلم أسبوع", Modifier.width(90.dp))
                    DetailLabelCell("مبلغ الدين الباقي", Modifier.width(105.dp))
                    DetailLabelCell("", Modifier.width(38.dp))
                }
                if (fd.debtRows.isEmpty()) {
                    DetailLabelCell("لا توجد ديون مسجلة", Modifier.fillMaxWidth(), bgColor = Color.Transparent, bold = false)
                } else {
                    fd.debtRows.forEachIndexed { idx, row ->
                        val rest = row.rest
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            DetailCellInput(
                                value = row.name,
                                onValueChange = { v ->
                                    val list = fd.debtRows.toMutableList().apply { set(idx, row.copy(name = v)) }
                                    onFormChange(fd.copy(debtRows = list))
                                },
                                numeric = false,
                                readOnly = !unlockEdit,
                                enableNameSuggestions = true,
                                modifier = Modifier.width(120.dp)
                            )
                            DetailCellInput(
                                value = row.qty,
                                onValueChange = { v ->
                                    val list = fd.debtRows.toMutableList().apply { set(idx, row.copy(qty = v)) }
                                    onFormChange(fd.copy(debtRows = list))
                                },
                                numeric = false,
                                readOnly = !unlockEdit,
                                modifier = Modifier.width(70.dp)
                            )
                            DetailCellInput(
                                value = row.amount,
                                onValueChange = { v ->
                                    val list = fd.debtRows.toMutableList().apply { set(idx, row.copy(amount = v)) }
                                    onFormChange(fd.copy(debtRows = list))
                                },
                                numeric = true,
                                readOnly = !unlockEdit,
                                modifier = Modifier.width(90.dp)
                            )
                            DetailCellInput(
                                value = row.weekly,
                                onValueChange = { v ->
                                    val list = fd.debtRows.toMutableList().apply { set(idx, row.copy(weekly = v)) }
                                    onFormChange(fd.copy(debtRows = list))
                                },
                                numeric = true,
                                readOnly = !unlockEdit,
                                modifier = Modifier.width(90.dp)
                            )
                            DetailLabelCell(
                                text = rawNumberString(rest, 2).ifBlank { "0" },
                                bgColor = if (rest < -1e-9) BadCellBg else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                textColor = if (rest < -1e-9) AppColors.DebitRed else MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.width(105.dp)
                            )
                            IconButton(
                                onClick = {
                                    val list = fd.debtRows.toMutableList().apply { removeAt(idx) }
                                    onFormChange(fd.copy(debtRows = list))
                                },
                                enabled = unlockEdit,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "حذف", tint = if (unlockEdit) AppColors.DebitRed else Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    DetailLabelCell("المجموع", Modifier.width(370.dp))
                    DetailCalcCell(
                        calcKey = "debtTotal",
                        autoValue = fd.calcSDebtSale,
                        form = fd,
                        unlockEdit = unlockEdit,
                        onOverrideChange = { v ->
                            val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("debtTotal") else put("debtTotal", v) }
                            onFormChange(fd.copy(manualOverrides = next))
                        },
                        modifier = Modifier.width(105.dp)
                    )
                    Box(Modifier.width(38.dp))
                }
            }
        }
    }
}

@Composable
internal fun DetailMidGatherCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        DetailTableShell(title = "تجميع البيع") {
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("باقي النقد", Modifier.weight(1f))
                DetailLabelCell("مسلم فلوس", Modifier.weight(1f))
                DetailLabelCell("خرج العمال", Modifier.weight(1f))
                DetailLabelCell("الجملة", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell(fmt(fd.calcSCashRest), Modifier.weight(1f), bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                DetailLabelCell(fmt(fd.calcPrevTotal), Modifier.weight(1f), bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                DetailLabelCell(fmt(num(fd.sPrivateOut)), Modifier.weight(1f), bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                DetailCalcCell(
                    calcKey = "midTotal",
                    autoValue = fd.calcMidTotal,
                    form = fd,
                    unlockEdit = unlockEdit,
                    onOverrideChange = { v ->
                        val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("midTotal") else put("midTotal", v) }
                        onFormChange(fd.copy(manualOverrides = next))
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Text("الجملة = باقي النقد + مسلم فلوس + خرج العمال", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
internal fun DetailMoneyTableCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    currencyNames: List<String>,
    onFormChange: (DetailFormData) -> Unit,
    onMoneyManualTouch: () -> Unit
) {
    val curOptions = remember(currencyNames) {
        (listOf("يمني", "سعودي", "عماني", "درهم") + currencyNames).distinct()
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        DetailTableShell(
            title = "العملات والسحب",
            onAddClick = {
                onMoneyManualTouch()
                onFormChange(fd.copy(moneyRows = fd.moneyRows + DetailMoneyRow(label = curOptions.firstOrNull() ?: "يمني")))
            }
        ) {
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("العملة", Modifier.weight(1.1f))
                DetailLabelCell("مبلغ العملة", Modifier.weight(1f))
                DetailLabelCell("مبلغ صرف العملة", Modifier.weight(1f))
                DetailLabelCell("", Modifier.width(38.dp))
            }
            fd.moneyRows.forEachIndexed { idx, row ->
                var curExpanded by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1.1f)) {
                        Surface(
                            onClick = { curExpanded = true },
                            color = Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 38.dp)
                                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(row.label.ifBlank { "يمني" }, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                        DropdownMenu(expanded = curExpanded, onDismissRequest = { curExpanded = false }) {
                            curOptions.forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(opt) },
                                    onClick = {
                                        curExpanded = false
                                        onMoneyManualTouch()
                                        val list = fd.moneyRows.toMutableList().apply { set(idx, row.copy(label = opt)) }
                                        onFormChange(fd.copy(moneyRows = list))
                                    }
                                )
                            }
                        }
                    }
                    DetailCellInput(
                        value = row.amount,
                        onValueChange = { v ->
                            onMoneyManualTouch()
                            val updatedRow = if (row.label.contains("يمني") && (row.value.isBlank() || row.value == row.amount)) {
                                row.copy(amount = v, value = v)
                            } else {
                                row.copy(amount = v)
                            }
                            val list = fd.moneyRows.toMutableList().apply { set(idx, updatedRow) }
                            onFormChange(fd.copy(moneyRows = list))
                        },
                        numeric = true,
                        modifier = Modifier.weight(1f)
                    )
                    DetailCellInput(
                        value = row.value,
                        onValueChange = { v ->
                            onMoneyManualTouch()
                            val list = fd.moneyRows.toMutableList().apply { set(idx, row.copy(value = v)) }
                            onFormChange(fd.copy(moneyRows = list))
                        },
                        numeric = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            onMoneyManualTouch()
                            val list = fd.moneyRows.toMutableList().apply { removeAt(idx) }
                            onFormChange(fd.copy(moneyRows = list))
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "حذف", tint = AppColors.DebitRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
            // Fixed Withdraw Row (السحب فلوس)
            val withdrawRowBg = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)
            Row(Modifier.fillMaxWidth().background(withdrawRowBg), verticalAlignment = Alignment.CenterVertically) {
                DetailLabelCell(
                    "السحب فلوس",
                    Modifier.weight(1.1f),
                    bgColor = withdrawRowBg,
                    textColor = MaterialTheme.colorScheme.primary
                )
                DetailCellInput(
                    value = fd.wLabel,
                    onValueChange = { onFormChange(fd.copy(wLabel = it)) },
                    numeric = false,
                    placeholder = "ملاحظة",
                    modifier = Modifier.weight(1f)
                )
                DetailCellInput(
                    value = fd.wValue,
                    onValueChange = { onFormChange(fd.copy(wValue = it)) },
                    numeric = true,
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.width(38.dp))
            }
            Row(Modifier.fillMaxWidth()) {
                DetailLabelCell("جملة مبلغ صرف", Modifier.weight(2.1f))
                DetailCalcCell(
                    calcKey = "mTotal",
                    autoValue = fd.calcMTotal,
                    form = fd,
                    unlockEdit = unlockEdit,
                    onOverrideChange = { v ->
                        val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("mTotal") else put("mTotal", v) }
                        onFormChange(fd.copy(manualOverrides = next))
                    },
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.width(38.dp))
            }
        }
        Text("جملة مبلغ صرف = مجموع مبالغ صرف العملات + قيمة السحب فلوس", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
internal fun DetailCheckMatchCard(
    fd: DetailFormData,
    unlockEdit: Boolean,
    onFormChange: (DetailFormData) -> Unit
) {
    val isMatch = abs(fd.calcChkDiff) < 1e-6
    DetailTableShell(title = "المطابقة النهائية والفارق") {
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell("الجملة المطلوبة (تجميع البيع)", Modifier.weight(1f))
            DetailLabelCell("مجموع العملات", Modifier.weight(1f))
            DetailLabelCell("الفرق", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            DetailLabelCell(fmt(fd.calcMidTotal), Modifier.weight(1f), bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            DetailLabelCell(fmt(fd.calcMTotal), Modifier.weight(1f), bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            DetailCalcCell(
                calcKey = "chkDiff",
                autoValue = fd.calcChkDiff,
                form = fd,
                unlockEdit = unlockEdit,
                isBad = !isMatch,
                isGood = isMatch,
                onOverrideChange = { v ->
                    val next = fd.manualOverrides.toMutableMap().apply { if (v == null) remove("chkDiff") else put("chkDiff", v) }
                    onFormChange(fd.copy(manualOverrides = next))
                },
                modifier = Modifier.weight(1f)
            )
        }
    }
}
