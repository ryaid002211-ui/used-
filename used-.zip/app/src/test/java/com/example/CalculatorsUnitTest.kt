package com.example

import com.example.domain.*
import org.junit.Assert.*
import org.junit.Test

class CalculatorsUnitTest {

    @Test
    fun westernDigits_convertsArabicIndicAndFormatsCleanly() {
        assertEquals("1234.50", WesternDigits.toWestern("١٢٣٤٫٥٠".replace("٫", ".")))
        assertEquals(1234.5, WesternDigits.num("١٢٣٤.٥"), 1e-6)
        assertEquals("1,250.5", WesternDigits.fmt(1250.5))
        assertEquals("12345.67", WesternDigits.cleanNumericInput("١٢,٣٤٥.٦٧abc"))
    }

    @Test
    fun safeExpressionEvaluator_handlesPrecedenceParenthesesAndPercentages() {
        assertEquals(14.0, SafeExpressionEvaluator.evaluate("2+3*4")!!, 1e-6)
        assertEquals(20.0, SafeExpressionEvaluator.evaluate("(2+3)×4")!!, 1e-6)
        assertEquals(50.0, SafeExpressionEvaluator.evaluate("1000*5%")!!, 1e-6)
        assertEquals(50.0, SafeExpressionEvaluator.evaluate("١٠٠÷٢")!!, 1e-6)
        assertNull(SafeExpressionEvaluator.evaluate("10/0"))
        assertNull(SafeExpressionEvaluator.evaluate("2++"))
    }

    @Test
    fun sellerInvoiceCalculator_computesQtyCashAndCurrenciesExactly() {
        val form = SellerFormData(
            saleColCount = 2,
            qty = "100",
            salesRows = listOf(
                SaleRow(s1n = "30", s1m = "30000", s2n = "20", s2m = "20000", dn = "15", dm = "15000", dname = "أحمد", onQty = "5", om = "2000")
            ),
            receivedRows = listOf(MoneyNameRow(name = "صالح", amount = "10000")),
            outRows = listOf(MoneyNameRow(name = "غداء", amount = "3000")),
            withdrawRows = listOf(MoneyNameRow(name = "محمد", amount = "7000")),
            weeklyRows = listOf(MoneyNameRow(name = "أحمد", amount = "5000")),
            currencyRows = listOf(
                SellerCurrencyRow(cur = "يمني", amount = "5000", rate = "1"),
                SellerCurrencyRow(cur = "سعودي", amount = "100", rate = "500")
            )
        )
        val res = SellerInvoiceCalculator.calculate(form)
        // Qty balance = 100 - (30+20) - 15 - 5 = 30
        assertEquals(50.0, res.sumCashQty, 1e-6)
        assertEquals(50000.0, res.saleCash, 1e-6)
        assertEquals(30.0, res.qtyBalance, 1e-6)
        // CashAfterOut = 50000 - 3000 = 47000
        assertEquals(47000.0, res.cashAfterOut, 1e-6)
        // CashBalance = 47000 + 5000(wk) + 10000(rec) - 7000(wdr) = 55000
        assertEquals(55000.0, res.cashBalance, 1e-6)
        // Currencies = 5000 + 100*500 = 55000 -> Diff = 0
        assertEquals(55000.0, res.currencyTotal, 1e-6)
        assertEquals(0.0, res.currencyDiff, 1e-6)
    }

    @Test
    fun autoDebtFifo_deductsPaymentsChronologically() {
        val entries = listOf(
            ClockEntry(
                section = ClockSection.DEBTS,
                kind = "debtsale",
                date = "2026-01-01",
                sentStamp = 1L,
                name = "الأسبوع الأول",
                subRows = listOf(ClockDebtSubRow(name = "خالد", qty = 5.0, amount = 10000.0, rest = 10000.0))
            ),
            ClockEntry(
                section = ClockSection.DEBTS,
                kind = "debtsale",
                date = "2026-01-08",
                sentStamp = 2L,
                name = "الأسبوع الثاني",
                subRows = listOf(ClockDebtSubRow(name = "خالد", qty = 3.0, amount = 6000.0, rest = 6000.0))
            ),
            ClockEntry(
                section = ClockSection.DEBTS,
                kind = "received",
                date = "2026-01-10",
                sentStamp = 3L,
                name = "سداد",
                subRows = listOf(ClockDebtSubRow(name = "خالد", amount = 12000.0))
            )
        )
        val open = AutoDebtFifoCalculator.computeOpenDebts(entries)
        assertEquals(1, open.size)
        assertEquals("خالد", open[0].customerName)
        assertEquals("الأسبوع الثاني", open[0].detailTitle)
        assertEquals(4000.0, open[0].remainingDebt, 1e-6)
    }

    @Test
    fun tasfeerFxEngine_computesWeightedAvgProfitAndGapCorrectly() {
        val currencies = AppSettings.defaultCurrencies()
        val accounts = listOf(TsAccount(id = "a1", name = "عميل 1"), TsAccount(id = "fx", name = "أرباح الصرف"))
        val funds = listOf(TsFund(id = "f1", name = "الصندوق الرئيسي"))
        val v1 = TsVoucher(
            id = "v1", kind = "receipt", dir = "in", date = "2026-01-01", createdAt = 1L,
            accId = "a1", fundId = "f1", cur = "ريال سعودي", amount = 100.0, rate = 400.0
        )
        val v2 = TsVoucher(
            id = "v2", kind = "receipt", dir = "out", date = "2026-01-02", createdAt = 2L,
            accId = "a1", fundId = "f1", cur = "ريال سعودي", amount = 40.0, rate = 450.0
        )
        // Available before out = 100 SAR; selling 40 should pass
        assertNull(
            TasfeerFxEngine.checkFundCoverage(
                existingVouchers = listOf(v1),
                currencies = currencies,
                fundId = "f1",
                requestedByCur = mapOf("ريال سعودي" to 40.0)
            )
        )
        // Selling 120 SAR should fail coverage
        assertNotNull(
            TasfeerFxEngine.checkFundCoverage(
                existingVouchers = listOf(v1),
                currencies = currencies,
                fundId = "f1",
                requestedByCur = mapOf("ريال سعودي" to 120.0)
            )
        )

        val recalc = TasfeerFxEngine.recalculate(accounts, funds, listOf(v1, v2), currencies, fxAccId = "fx", comAccId = "")
        // Weighted cost of 100 SAR = 40,000 -> sold 40 at 450 = 18,000 vs cost 16,000 => FX Profit = +2,000
        assertEquals(2000.0, recalc.accountBalances["fx"] ?: 0.0, 1e-6)
        // Fund remaining = 60 SAR * 400 = 24,000; Acc a1 = 40,000 - 18,000 = 22,000; Acc fx = 2,000 => Total Acc = 24,000 => Gap = 0
        assertEquals(24000.0, recalc.fundValues["f1"] ?: 0.0, 1e-6)
        assertEquals(0.0, recalc.gapSummary.gap, 1e-6)
        assertEquals("even", recalc.gapSummary.side)
    }

    @Test
    fun buyerCalculators_computesExchangeConversionAnd5050ProfitSplit() {
        val sp = Specialty(id = "sp1", name = "رداع", workersAmount = 0.0)
        val ts = BuyerTransferSheet(
            id = "ts1",
            specialtyId = "sp1",
            name = "الأسبوع 1",
            fromDate = "2026-01-01",
            toDate = "2026-01-07",
            rows = listOf(BuyerTransferRow(name = "شراء", buy = 900.0, exp = 100.0)), // oldTotal = 1000
            oldPrice = 500.0, // exchange = 2.0
            newPrice = 600.0, // newTotal = 1200
            rentRada = 50.0,
            rentShip = 50.0, // totalExp = 1300
            weeklySale = 1700.0 // diff = +400 profit -> 200 seller / 200 supplier
        )
        val calc = BuyerCalculators.calculateTransfer(ts)
        assertEquals(1000.0, calc.oldTotal, 1e-6)
        assertEquals(2.0, calc.exchange, 1e-6)
        assertEquals(1200.0, calc.newTotal, 1e-6)
        assertEquals(1300.0, calc.totalExpenses, 1e-6)
        assertEquals(400.0, calc.diff, 1e-6)
        assertEquals("ربح", calc.profitLabel)

        val (_, _, profits) = BuyerCalculators.syncBuyerEcosystem(
            folders = emptyList(),
            specialties = listOf(sp),
            transferSheets = listOf(ts),
            existingAnnualFolders = emptyList(),
            existingSales = emptyList(),
            existingProfits = emptyList()
        )
        assertEquals(2, profits.size)
        assertEquals(200.0, profits.first { it.target == "seller" }.amount, 1e-6)
        assertEquals(200.0, profits.first { it.target == "supplier" }.amount, 1e-6)
    }

    @Test
    fun dateHelper_shiftPeriod_handlesFullYearAndFullMonth() {
        assertEquals("2026-01-01" to "2026-12-31", DateHelper.yearStartIso("2026-06-15") to DateHelper.yearEndIso("2026-06-15"))
        assertEquals("2027-01-01" to "2027-12-31", DateHelper.shiftPeriod("2026-01-01", "2026-12-31", 1))
        assertEquals("2025-01-01" to "2025-12-31", DateHelper.shiftPeriod("2026-01-01", "2026-12-31", -1))
        assertEquals("2026-02-01" to "2026-02-28", DateHelper.shiftPeriod("2026-01-01", "2026-01-31", 1))
    }

    @Test
    fun driveBackupSettings_hasExpectedDefaults() {
        val g = DriveBackupSettings()
        assertFalse(g.connected)
        assertEquals("24h", g.dataInterval)
        assertTrue(g.dataEnabled)
        assertFalse(g.imagesBackupEnabled)
    }

    @Test
    fun weeklyFilterCalculator_computesTotalsAndDifference() {
        val wf = WeeklyFilter(
            name = "أسبوع اختبار",
            fromDate = "2026-01-01",
            toDate = "2026-01-02",
            qtyRows = listOf(
                WeeklyQtyRow(day = "الخميس", date = "2026-01-01", qty = "10", cash = "6", debt = "2", expense = "1"),
                WeeklyQtyRow(day = "الجمعة", date = "2026-01-02", qty = "5", cash = "4", debt = "0", expense = "0")
            ),
            salesRows = listOf(
                WeeklySalesRow(day = "الخميس", date = "2026-01-01", cash = "1000", weeklyAmt = "500", weeklySalesAmt = "200", prevAmt = "100")
            ),
            moneyRows = listOf(
                WeeklyMoneyRow(day = "الخميس", date = "2026-01-01", yemeni = "600", saudiAmt = "2", saudiExch = "1000")
            )
        )
        val res = WeeklyFilterCalculator.calculate(wf)
        assertEquals(1.0, res.rowQtyRemaining[0], 1e-6)
        assertEquals(2.0, res.totQtyRemaining, 1e-6)
        assertEquals(1600.0, res.totSalesAll, 1e-6)
        assertEquals(1600.0, res.totMoneyAll, 1e-6)
        assertEquals(0.0, res.diff, 1e-6)
    }
}

